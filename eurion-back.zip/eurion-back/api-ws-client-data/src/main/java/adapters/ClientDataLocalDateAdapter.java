package adapters;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ClientDataLocalDateAdapter {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public static LocalDate unmarshal(String value) {
        return LocalDate.parse(value, DATE_FORMAT);
    }

    public static String marshal(LocalDate localDate) {
        return DATE_FORMAT.format(localDate);
    }
}