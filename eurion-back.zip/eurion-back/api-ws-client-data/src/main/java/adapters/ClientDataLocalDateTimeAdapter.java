package adapters;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ClientDataLocalDateTimeAdapter {

    private static final DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

    public static LocalDateTime unmarshal(String value) {
        return LocalDateTime.parse(value, DATE_TIME_FORMAT);
    }

    public static String marshal(LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        return DATE_TIME_FORMAT.format(localDateTime);
    }
}