package adapters;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class ZonedDateTimeAdapter extends XmlAdapter<String, ZonedDateTime> {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    @Override
    public ZonedDateTime unmarshal(String value) {
        return ZonedDateTime.parse(value, DATE_TIME_FORMATTER);
    }

    @Override
    public String marshal(ZonedDateTime value) {
        if (value != null) {
            return value.format(DATE_TIME_FORMATTER);
        }
        return null;
    }
}
