package util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LocalDateTimeAdapter {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");

    public static LocalDateTime unmarshal(String v) {
        if (v == null) {
            return null;
        }
        return LocalDateTime.parse(v);
    }

    public static String marshal(LocalDateTime v) {
        if (v == null) {
            return null;
        }
        return v.format(FORMATTER);
    }
}
