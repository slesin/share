package util;

public class BooleanAdapter {

    public static Boolean unmarshal(String v) {
        if (v == null || v.isEmpty()) {
            return null;
        }

        if ("1".equals(v)) {
            return Boolean.TRUE;
        } else if ("0".equals(v)) {
            return Boolean.FALSE;
        }
        return Boolean.parseBoolean(v);
    }

    public static String marshal(Boolean v) {
        if (v == null) {
            return null;
        }
        return Boolean.toString(v);
    }
}
