package util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class LocalDateAdapter {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static LocalDate unmarshal(String v) {
        if (v == null || v.isEmpty()) {
            return null;
        }
        return LocalDate.parse(v, FORMATTER);
    }

    public static String marshal(LocalDate v) {
        if (v == null) {
            return null;
        }
        return v.format(FORMATTER);
    }
}
