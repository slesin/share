package ru.rsb.eurion;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.annotation.Nonnull;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.function.Supplier;

@Slf4j
public class RequestIdFilter extends OncePerRequestFilter {
    private static final int REQUEST_ID_LENGTH_IN_BYTE = 12;
    private static final String HEADER_NAME = "X-Request-Id";
    private static final String MDC_REQUEST_ID_NAME = "requestId";
    private static final String MDC_SESSION_ID_NAME = "sessionId";

    private final SecureRandom secureRandom;

    RequestIdFilter() {
        this.secureRandom = new SecureRandom(SecureRandom.getSeed(16));
    }

    @Override
    protected void doFilterInternal(@Nonnull HttpServletRequest request, @Nonnull HttpServletResponse response,
                                    @Nonnull FilterChain filterChain) throws ServletException, IOException {
        long t = System.nanoTime();
        String requestId = generateRequestId();
        log.debug("Starting request: {} - {} {} ", requestId, request.getMethod(),
                new DeferredToString(() -> takePath(request)));
        response.addHeader(HEADER_NAME, requestId);
        HttpSession session = request.getSession();
        String sessionId;
        if (session != null) {
            sessionId = session.getId();
            MDC.put(MDC_SESSION_ID_NAME, SessionStoreFilter.takeSessionId());
        } else {
            sessionId = null;
        }
        MDC.put(MDC_REQUEST_ID_NAME, requestId);
        try {
            filterChain.doFilter(request, response);
        } finally {
            t = (System.nanoTime() - t) / 1000000;
            MDC.remove(MDC_SESSION_ID_NAME);
            MDC.remove(MDC_REQUEST_ID_NAME);
            log.debug("Finished request: requestId={} sessionId={} ({} ms)", requestId, sessionId, t);
        }
    }

    private String takePath(@Nonnull HttpServletRequest request) {
        return request.getServletPath() + (request.getPathInfo() != null ? request.getPathInfo() : "");
    }

    private String generateRequestId() {
        byte[] bytes = new byte[REQUEST_ID_LENGTH_IN_BYTE];
        secureRandom.nextBytes(bytes);
        return DatatypeConverter.printHexBinary(bytes);
    }

    @AllArgsConstructor
    private static final class DeferredToString {

        private final Supplier<String> supplier;

        @Override
        public String toString() {
            return supplier.get();
        }

    }
}
