package ru.rsb.eurion.domain;

public interface Interval<T extends Comparable<T>> {
    T getStartValue();

    T getEndValue();

    default boolean intersects(Interval<T> interval) {
        return (getStartValue().compareTo(interval.getStartValue()) > 0 &&
                getStartValue().compareTo(interval.getEndValue()) < 0) ||
                (getEndValue().compareTo(interval.getStartValue()) > 0 &&
                        getEndValue().compareTo(interval.getEndValue()) < 0);
    }
}
