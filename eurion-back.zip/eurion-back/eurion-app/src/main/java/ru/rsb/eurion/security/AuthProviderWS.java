package ru.rsb.eurion.security;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.TechUser;
import ru.rsb.eurion.settings.AppConfig;

import javax.annotation.Nullable;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.List;

/**
 * @author sergius on 9/12/18.
 */
@Component
@AllArgsConstructor
@Slf4j
public class AuthProviderWS implements AuthenticationProvider {
    static final String RTDM_AUTHORITY = "RTDM";
    static final String TELEPHONY_AUTHORITY = "TELEPHONY";
    static final String EIS_AUTHORITY = "EIS";
    private static final String MESSAGE_DIGEST_ALG = "SHA-256";
    private static final Charset PASSWORD_CHARSET = StandardCharsets.UTF_8;

    private final AppConfig config;
    private final TechUserDao techUserDao;

    @Override
    public Authentication authenticate(Authentication auth) throws AuthenticationException {
        String username = auth.getPrincipal() != null ? auth.getPrincipal().toString() : null;
        @Nullable
        String password = auth.getCredentials() != null ? auth.getCredentials().toString() : null;

        if (!config.isApplicationProviderAuth()) {
            return createAuthentication("fake_user", RTDM_AUTHORITY);
        }

        TechUser user = techUserDao.findByLogin(username);

        if (user == null) {
            log.info("User is not found: {}", username);
            throw new UsernameNotFoundException("User not found: " + username);
        }

        if (!validatePassword(password, user)) {
            throw new AuthenticationCredentialsNotFoundException("Wrong password: " + username);
        }

        return createAuthentication(username, user.getLogin().toUpperCase());
    }

    private boolean validatePassword(String password, TechUser user) {
        try {
            String calculatedPasswordHash;
            if (password != null) {

                MessageDigest messageDigest = MessageDigest.getInstance(MESSAGE_DIGEST_ALG);
                byte[] digest = messageDigest.digest(password.getBytes(PASSWORD_CHARSET));
                calculatedPasswordHash = DatatypeConverter.printHexBinary(digest);
            } else {
                calculatedPasswordHash = "";
            }

            if (!calculatedPasswordHash.equals(user.getPasswordHash())) {
                log.info("Wrong password: {}", user.getLogin());
                log.debug("expected password hash '{}', actual was '{}'", user.getPasswordHash(), calculatedPasswordHash);
                return false;
            }
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
        return true;
    }

    private Authentication createAuthentication(String username, String authority) {
        log.debug("User is authenticated: {}", username);
        //ToDo authority for telephony
        GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(authority);
        List<? extends GrantedAuthority> authorities = Collections.singletonList(grantedAuthority);
        return new UsernamePasswordAuthenticationToken(username.toUpperCase(), null, authorities);
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }
}
