package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.XmlTransient;

@Getter
@Setter
public class DeclineReason extends BasicReference {
    @XmlTransient
    private DeclineCategory category;

    private String code;

    private Integer timeout;
}
