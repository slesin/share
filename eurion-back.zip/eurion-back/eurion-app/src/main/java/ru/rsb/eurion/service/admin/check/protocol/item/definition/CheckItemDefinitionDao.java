package ru.rsb.eurion.service.admin.check.protocol.item.definition;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.CheckItemDefinition;
import ru.rsb.eurion.domain.CheckItemElement;
import ru.rsb.eurion.domain.CheckItemValue;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface CheckItemDefinitionDao {

    @Select("select * from CHECK_ITEM_VALUE where CHECK_ITEM_ELEMENT_ID = #{id}")
    @Results(id = "checkItemValueMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "orderNumber", column = "ORDER_NUMBER"),
            @Result(property = "stopFactor", column = "STOP_FACTOR"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "resultCode", column = "RESULT_CODE"),
    })
    @SuppressWarnings("unused")
    CheckItemValue getCheckItemValue();

    @Select("select * from CHECK_ITEM_ELEMENT where CHECK_ITEM_DEFINITION_ID = #{id}")
    @Results(id = "checkItemElementMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "checkItemType", column = "TYPE"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "itemValueList", many = @Many(select = "getCheckItemValue", fetchType = FetchType.EAGER),
                    column = "id"),
    })
    @SuppressWarnings("unused")
    CheckItemElement getCheckItemElement();

    @Select("select * from CHECK_ITEM_DEFINITION where ID = #{id}")
    @Results(id = "checkItemDefinitionMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "kind", column = "KIND"),
            @Result(property = "orderNumber", column = "ORDER_NUMBER"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "items", many = @Many(select = "getCheckItemElement", fetchType = FetchType.EAGER),
                    column = "id"),
            @Result(property = "isRequiredForReject", column = "IS_REQUIRED_FOR_REJECT")
    })
    CheckItemDefinition findOne(@Param("id") Integer id);

    @Select("select * from CHECK_ITEM_DEFINITION ORDER BY NAME")
    @ResultMap("checkItemDefinitionMapping")
    List<CheckItemDefinition> list();

    @Insert("insert into CHECK_ITEM_DEFINITION(NAME, KIND, ORDER_NUMBER, CREATED_AT, UPDATED_AT, CODE, IS_REQUIRED_FOR_REJECT)\n" +
            "values (#{checkItemDefinition.name, jdbcType = VARCHAR},\n" +
            "#{checkItemDefinition.kind, jdbcType = VARCHAR},\n" +
            "#{checkItemDefinition.orderNumber, jdbcType = INTEGER},\n" +
            "#{checkItemDefinition.createdAt, jdbcType = TIMESTAMP},\n" +
            "#{checkItemDefinition.updatedAt, jdbcType = TIMESTAMP},\n" +
            "#{checkItemDefinition.code, jdbcType=VARCHAR},\n" +
            "#{checkItemDefinition.isRequiredForReject, jdbcType=BOOLEAN})")
    @SelectKey(
            keyProperty = "checkItemDefinition.id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_check_item_definition.currval AS id from dual"}
    )
    void create(@Param("checkItemDefinition") CheckItemDefinition checkItemDefinition);

    @Update("update CHECK_ITEM_DEFINITION\n" +
            "set NAME                   = #{checkItemDefinition.name, jdbcType = VARCHAR},\n" +
            "    KIND                   = #{checkItemDefinition.kind, jdbcType = VARCHAR},\n" +
            "    ORDER_NUMBER           = #{checkItemDefinition.orderNumber, jdbcType = VARCHAR},\n" +
            "    UPDATED_AT             = #{checkItemDefinition.updatedAt, jdbcType = TIMESTAMP},\n" +
            "    DISABLED_AT            = #{checkItemDefinition.disabledAt, jdbcType = TIMESTAMP},\n" +
            "    CODE                   = #{checkItemDefinition.code, jdbcType = VARCHAR},\n" +
            "    IS_REQUIRED_FOR_REJECT = #{checkItemDefinition.isRequiredForReject, jdbcType=BOOLEAN}\n" +
            "where ID = #{checkItemDefinition.id}")
    void updateCheckItemDefinition(@Param("checkItemDefinition") CheckItemDefinition checkItemDefinition);

    @Update("update CHECK_ITEM_ELEMENT\n" +
            "set TYPE         = #{checkItemElement.checkItemType},\n" +
            "    UPDATED_AT   = #{updatedAt, jdbcType = TIMESTAMP},\n" +
            "    DISABLED_AT  = #{checkItemElement.disabledAt, jdbcType = TIMESTAMP}\n" +
            "where ID = #{checkItemElement.id}")
    void updateCheckItemElement(@Param("checkItemElement") CheckItemElement checkItemElement,
                                @Param("updatedAt") LocalDateTime updated);

    @Update("UPDATE CHECK_ITEM_VALUE\n" +
            "set NAME       = #{checkItemValue.name, jdbcType = VARCHAR},\n" +
            "  ORDER_NUMBER = #{checkItemValue.orderNumber, jdbcType = INTEGER},\n" +
            "  STOP_FACTOR  = #{checkItemValue.stopFactor, jdbcType = BOOLEAN},\n" +
            "  CODE         = #{checkItemValue.code, jdbcType = VARCHAR},\n" +
            "  RESULT_CODE  = #{checkItemValue.resultCode, jdbcType = VARCHAR},\n" +
            "  UPDATED_AT   = #{updatedAt, jdbcType = TIMESTAMP},\n" +
            "  DISABLED_AT  = #{checkItemValue.disabledAt, jdbcType = TIMESTAMP}\n" +
            "where ID = #{checkItemValue.id, jdbcType = INTEGER}")
    void updateCheckItemValue(@Param("checkItemValue") CheckItemValue checkItemValue,
                              @Param("updatedAt") LocalDateTime updated);

    @Insert("insert into CHECK_ITEM_ELEMENT(CHECK_ITEM_DEFINITION_ID, TYPE, CREATED_AT)\n" +
            "values (#{checkItemDefinitionId},\n" +
            "    #{element.checkItemType},\n" +
            "    #{createdAt})")
    @SelectKey(
            keyProperty = "element.id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_check_item_element.currval AS id from dual"}
    )
    void createCheckItemElement(@Param("checkItemDefinitionId") Integer checkItemDefinitionId,
                                @Param("element") CheckItemElement element,
                                @Param("createdAt") LocalDateTime createdAt);

    @Insert({"insert into CHECK_ITEM_VALUE (CHECK_ITEM_ELEMENT_ID, NAME, ORDER_NUMBER, CREATED_AT, UPDATED_AT, STOP_FACTOR, CODE, RESULT_CODE)\n" +
            "values (#{checkItemElementId}, #{item.name}, #{item.orderNumber}, #{createdAt}, #{createdAt}, #{item.stopFactor}, #{item.code, jdbcType = VARCHAR}, #{item.resultCode, jdbcType = VARCHAR})"})
    @SelectKey(
            keyProperty = "item.id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_check_item_value.currval AS id from dual"}
    )
    void createCheckItemValue(@Param("checkItemElementId") Integer checkItemElementId,
                              @Param("item") CheckItemValue item,
                              @Param("createdAt") LocalDateTime createdAt);

    @Update("update CHECK_ITEM_ELEMENT\n" +
            "set DISABLED_AT = #{disabledAt},\n" +
            "    UPDATED_AT  = current_timestamp " +
            "where ID = #{checkItemElement.id}")
    void disableCheckItemElement(@NotNull @Param("checkItemElement") CheckItemElement checkItemElement,
                                 @Param("disabledAt") LocalDateTime disabledAt);

    @Update("update CHECK_ITEM_VALUE\n" +
            "set DISABLED_AT = #{disabledAt, jdbcType=DATE},\n" +
            "    UPDATED_AT  = #{disabledAt, jdbcType=DATE}\n" +
            "where ID = #{checkItemValue.id}")
    void disableCheckItemValue(@Param("checkItemValue") CheckItemValue checkItemValue,
                               @Param("disabledAt") LocalDateTime disabledAt);

    @Update("update CHECK_ITEM_DEFINITION\n" +
            "set DISABLED_AT = #{disabledAt, jdbcType=DATE},\n" +
            "    UPDATED_AT  = #{disabledAt, jdbcType=DATE}\n" +
            "where ID = #{checkItemDefinitionId}")
    void disableCheckItemDefinition(@Param("checkItemDefinitionId") Integer id,
                                    @Param("disabledAt") LocalDateTime disabledAt);

    @Update("update CHECK_ITEM_DEFINITION\n" +
            "set DISABLED_AT = NULL,\n" +
            "    UPDATED_AT  = #{updatedAt, jdbcType=DATE}\n" +
            "where ID = #{checkItemDefinitionId}")
    void enableCheckItemDefinition(@Param("checkItemDefinitionId") Integer id,
                                   @Param("updatedAt") LocalDateTime updatedAt);

    @Update("update CHECK_ITEM_DEFINITION\n" +
            "set DISABLED_AT = #{disabledAt, jdbcType=DATE},\n" +
            "    UPDATED_AT  = #{disabledAt, jdbcType=DATE}\n" +
            "where ID IN (#{checkItemDefinitionIds})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void disableCheckItemDefinitionList(@Param("checkItemDefinitionIds") List<Integer> ids,
                                        @Param("disabledAt") LocalDateTime disabledAt);

    @Update("update CHECK_ITEM_DEFINITION\n" +
            "set DISABLED_AT = NULL,\n" +
            "    UPDATED_AT  = #{updatedAt, jdbcType=DATE}\n" +
            "where ID IN (#{checkItemDefinitionIds})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void enableCheckItemDefinitionList(@Param("checkItemDefinitionIds") List<Integer> ids,
                                       @Param("updatedAt") LocalDateTime updatedAt);

    @Select("select * from CHECK_ITEM_VALUE where CHECK_ITEM_ELEMENT_ID = #{id} and DISABLED_AT is null")
    @ResultMap("checkItemValueMapping")
    @SuppressWarnings("unused")
    CheckItemValue getActiveCheckItemValue();

    @Select("select * from CHECK_ITEM_ELEMENT where CHECK_ITEM_DEFINITION_ID = #{id} and DISABLED_AT is null")
    @ResultMap("checkItemElementMapping")
    @SuppressWarnings("unused")
    CheckItemElement getActiveCheckItemElement();

    @Select("select cid.*\n" +
            "from SKILL_FORM_CHECK sfc\n" +
            "       join CHECK_ITEM_DEFINITION cid on sfc.CHECK_ITEM_DEFINITION_ID = cid.ID\n" +
            "where sfc.SKILL_ID = #{skillGroupId} and sfc.FORM_ID = #{formId} and cid.DISABLED_AT is null")
    @ResultMap("checkItemDefinitionMapping")
    List<CheckItemDefinition> getActiveCheckItemDefinitions(@Param("skillGroupId") Integer skillGroupId,
                                                            @Param("formId") Integer formId);

    @Select("select cid.*\n" +
            "from SKILL_FORM_CHECK sfc\n" +
            "       join CHECK_ITEM_DEFINITION cid on sfc.CHECK_ITEM_DEFINITION_ID = cid.ID\n" +
            "where sfc.SKILL_ID = #{skillGroupId} and sfc.FORM_ID = #{formId}")
    @ResultMap("checkItemDefinitionMapping")
    List<CheckItemDefinition> getCheckItemDefinitions(@Param("skillGroupId") Integer skillGroupId,
                                                      @Param("formId") Integer formId);

    @Delete("delete from CHECK_ITEM_DEFINITION where ID = #{checkItemDefinitionId}")
    void deleteCheckItemDefinition(@Param("checkItemDefinitionId") Integer id);

    @Delete("delete from CHECK_ITEM_VALUE where ID = #{checkItemValueId}")
    void deleteCheckItemValue(@NotNull @Param("checkItemValueId") Integer id);

    @Delete("delete from CHECK_ITEM_ELEMENT where ID = #{checkItemElementId}")
    void deleteCheckItemElement(@NotNull @Param("checkItemElementId") Integer id);
}
