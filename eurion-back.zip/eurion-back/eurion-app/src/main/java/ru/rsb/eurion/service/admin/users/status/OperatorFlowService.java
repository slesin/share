package ru.rsb.eurion.service.admin.users.status;

import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.flowable.engine.RepositoryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.StatusType;
import ru.rsb.eurion.domain.UserStatus;
import ru.rsb.eurion.service.admin.users.UserDao;
import ru.rsb.eurion.service.application.flow.ApplicationProcessService;
import ru.rsb.eurion.service.application.priority.ApplicationPriorityService;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@Service("operator")
@Transactional
@AllArgsConstructor
@SuppressWarnings("unused")
@Slf4j
public class OperatorFlowService {

    private final UserDao userDao;
    private final UserStatusDao userStatusDao;
    private final UserStatusService userStatusService;
    private final ApplicationPriorityService applicationPriorityService;
    private final ApplicationProcessService applicationProcessService;
    private final RepositoryService repositoryService;

    public StatusType defaultEnterStatus() {
        UserStatus defaultEnterStatus = userStatusService.getDefaultEnterStatus();
        return defaultEnterStatus.getCode();
    }

    public StatusType defaultExitStatus() {
        UserStatus defaultEnterStatus = userStatusService.getDefaultExitStatus();
        return defaultEnterStatus.getCode();
    }

    public String readyTimeout() {
        return "PT30S";
    }

    public void setupStatus(@NonNull @Nonnull Integer userId,
                            @NonNull @Nonnull String statusCodeStr,
                            @Nullable String roleStr,
                            @NonNull @Nonnull String sessionId) {
        StatusType statusType = StatusType.valueOf(statusCodeStr);
        UserStatus userStatus = userStatusService.getUserStatusByCode(statusType);
        Role role = roleStr != null ? Role.valueOf(roleStr) : null;
        userStatusService.setUserStatusAndRole(userId, userStatus, role, sessionId);
    }

    public void triggerReadyEvent(@NonNull @Nonnull Integer userId) {
        ApplicationView applicationView = applicationPriorityService.loadNextForOperator(userId);
        if (applicationView == null) {
            log.info("No appropriate application for operator: userId={}", userId);
            return;
        }
        // ищем бизнес-процесс, соответствующий данной заявке, отправляем месседж о готовности оператора
        applicationProcessService.sendOperatorReadyMessage(applicationView.getId(), userId);
    }

    public String getCurrentStatus(Integer userId) {
        UserStatusAndRole statusAndRole = userStatusService.getCurrentStatusAndRole(userId);
        return statusAndRole.getStatus().getCode().name();
    }
}
