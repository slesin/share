package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

// todo delete all forms???
/**
 * Базовый класс для форм
 */
@Getter
@Setter
public class BasicForm {
}
