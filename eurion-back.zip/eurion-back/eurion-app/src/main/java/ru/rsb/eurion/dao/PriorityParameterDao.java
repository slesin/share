package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.priority.PriorityParameter;

import java.util.List;

@Mapper
public interface PriorityParameterDao {

    String BASE_SQL = "select ID,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT,\n" +
            "       NAME,\n" +
            "       DESCR,\n" +
            "       IS_ENABLED,\n" +
            "       SORT_DIRECTION,\n" +
            "       ORDER_IDX\n" +
            "from PRIORITY_PARAM\n" +
            "order by ORDER_IDX, ID";

    @Select(BASE_SQL)
    @Results(id = "PriorityParameterMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "description", column = "DESCR"),
            @Result(property = "enabled", column = "IS_ENABLED"),
            @Result(property = "direction", column = "SORT_DIRECTION"),
            @Result(property = "order", column = "ORDER_IDX")
    })
    List<PriorityParameter> findAllOrdered();

    @Update("update PRIORITY_PARAM\n" +
            "set IS_ENABLED = #{enabled},\n" +
            "    SORT_DIRECTION = #{direction},\n" +
            "    ORDER_IDX = #{order}," +
            "    UPDATED_AT = current_timestamp " +
            "where ID = #{id}")
    void update(PriorityParameter priorityParameter);
}
