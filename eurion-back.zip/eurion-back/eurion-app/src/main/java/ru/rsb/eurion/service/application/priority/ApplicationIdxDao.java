package ru.rsb.eurion.service.application.priority;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.ApplicationIdx;

import javax.annotation.Nullable;

@Mapper
public interface ApplicationIdxDao {
    String INSERT_SQL = "insert into APPLICATION_IDX(ID,\n" +
            "                            CREATE_DATE,\n" +
            "                            SUSPEND_TIME,\n" +
            "                            SUPERVISOR_PRIORITY,\n" +
            "                            RTDM_PRIORITY,\n" +
            "                            SKILL_GROUP_PRIORITY,\n" +
            "                            REGION_CLIENT_PRIORITY,\n" +
            "                            REGION_APP_PRIORITY,\n" +
            "                            AMOUNT_PRIORITY,\n" +
            "                            CHANNEL_PRIORITY,\n" +
            "                            ATTRACT_CHANNEL_PRIORITY,\n" +
            "                            PRODUCT_PRIORITY,\n" +
            "                            IS_NOVEL,\n" +
            "                            IS_FRAUD_RETURN,\n" +
            "                            IS_SUSPENSIVE_TERMS,\n" +
            "                            IS_OUT_OF_DIAL_TIME,\n" +
            "                            LAST_USER_ID,\n" +
            "                            DIAL_START_TIME,\n" +
            "                            DIAL_END_TIME,\n" +
            "                            HOLIDAY_DIAL_START_TIME,\n" +
            "                            HOLIDAY_DIAL_END_TIME,\n" +
            "                            MONTHLY_PAYMENT_DATE\n" +
            "                            )\n" +
            "values (#{id},\n" +
            "    #{createDate, jdbcType = TIMESTAMP},\n" +
            "    #{suspendTime, jdbcType = TIMESTAMP},\n" +
            "    #{supervisorPriority, jdbcType = SMALLINT},\n" +
            "    #{rtdmPriority, jdbcType = INTEGER},\n" +
            "    #{skillGroup, jdbcType = SMALLINT},\n" +
            "    #{regionClientPriority, jdbcType = SMALLINT},\n" +
            "    #{regionAppPriority, jdbcType = SMALLINT},\n" +
            "    #{amountPriority, jdbcType = SMALLINT},\n" +
            "    #{channelPriority, jdbcType = SMALLINT},\n" +
            "    #{attractChannelPriority, jdbcType = SMALLINT},\n" +
            "    #{productPriority, jdbcType = SMALLINT},\n" +
            "    #{novel, jdbcType = TINYINT},\n" +
            "    #{fraudReturn, jdbcType = TINYINT},\n" +
            "    #{suspensiveTerms, jdbcType = TINYINT},\n" +
            "    #{outOfDialTime, jdbcType = TINYINT},\n" +
            "    #{lastUserId, jdbcType = INTEGER},\n" +
            "    #{dialStartTime, jdbcType = INTEGER},\n" +
            "    #{dialEndTime, jdbcType = INTEGER},\n" +
            "    #{holidayDialStartTime, jdbcType = INTEGER},\n" +
            "    #{holidayDialEndTime, jdbcType = INTEGER},\n" +
            "    #{monthlyPaymentDate, jdbcType = TIMESTAMP})";

    @Insert(INSERT_SQL)
    void create(ApplicationIdx applicationIdx);

    @Select("select case\n" +
            "         when exists(select * from APPLICATION_IDX where ID = #{id}) then 1\n" +
            "         else 0 end as is_exists\n" +
            "from dual")
    boolean exists(@Param("id") Long id);

    @Delete("delete from APPLICATION_IDX where ID = #{id}")
    void delete(@Param("id") Long id);

    @Update("update APPLICATION_IDX set SUPERVISOR_PRIORITY = #{priority} where ID = #{id}")
    void updateSupervisorPriority(@Param("id") Long id, @Param("priority") short supervisorPriority);

    @Select("select * from APPLICATION_IDX where ID = #{id}")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "CREATE_DATE", property = "createDate"),
            @Result(column = "SUSPEND_TIME", property = "suspendTime"),
            @Result(column = "SUPERVISOR_PRIORITY", property = "supervisorPriority"),
            @Result(column = "RTDM_PRIORITY", property = "rtdmPriority"),
            @Result(column = "SKILL_GROUP_PRIORITY", property = "skillGroup"),
            @Result(column = "REGION_APP_PRIORITY", property = "regionAppPriority"),
            @Result(column = "REGION_CLIENT_PRIORITY", property = "regionClientPriority"),
            @Result(column = "AMOUNT_PRIORITY", property = "amountPriority"),
            @Result(column = "CHANNEL_PRIORITY", property = "channelPriority"),
            @Result(column = "ATTRACT_CHANNEL_PRIORITY", property = "attractChannelPriority"),
            @Result(column = "PRODUCT_PRIORITY", property = "productPriority"),
            @Result(column = "IS_NOVEL", property = "novel"),
            @Result(column = "IS_FRAUD_RETURN", property = "fraudReturn"),
            @Result(column = "IS_SUSPENSIVE_TERMS", property = "suspensiveTerms"),
            @Result(column = "IS_OUT_OF_DIAL_TIME", property = "outOfDialTime"),
            @Result(column = "LAST_USER_ID", property = "lastUserId"),
            @Result(column = "MONTHLY_PAYMENT_DATE", property = "monthlyPaymentDate")
    })
    @Nullable
    ApplicationIdx findById(@Param("id") Long id);
}
