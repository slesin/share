package ru.rsb.eurion.service.application.statistics;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.service.admin.skill.group.SkillGroupDao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Service
@Transactional
public class StatisticsService {

    private final SkillGroupDao skillGroupDao;

    public SkillInfoView getApplicationStatistics() {
        List<ApplicationInfoBySkill> infoBySkills = skillGroupDao.getApplicationInfoBySkill();
        return getSkillGroupViews(infoBySkills);
    }

    private SkillInfoView getSkillGroupViews(List<ApplicationInfoBySkill> infoBySkills) {
        Map<Integer, String> roles = new HashMap<>();
        Map<Integer, String> groups = new HashMap<>();
        Map<CreditType, Set<Integer>> typeToRole = new HashMap<>();
        Map<CreditType, Set<Integer>> typeToGroup = new HashMap<>();
        Map<Integer, Set<Integer>> groupToRole = new HashMap<>();
        Map<Integer, Map<ApplicationViewStatus, Integer>> countByRole = new HashMap<>();
        Map<CreditType, Map<Integer, Map<ApplicationViewStatus, Integer>>> countByCreditType = new HashMap<>();
        Map<CreditType, Map<Integer, Map<ApplicationViewStatus, Integer>>> countByCreditTypeGroup = new HashMap<>();
        Map<CreditType, Map<ApplicationViewStatus, Integer>> countByCreditTypeTotal = new HashMap<>();
        Map<Integer, Map<ApplicationViewStatus, Integer>> countByGroup = new HashMap<>();

        Map<ApplicationViewStatus, Integer> total = new HashMap<>();
        for (ApplicationInfoBySkill info : infoBySkills) {
            incrementInMap(countByRole, info.getSkillGroupRoleId(), info);
            incrementInMap(countByGroup, info.getSkillGroupId(), info);
            incrementInMapBySkillGroup(countByCreditType, info.getCreditType(), info);

            incrementInMapBySkillGroupRole(countByCreditTypeGroup, info.getCreditType(), info);
            incrementInMapByCreditType(countByCreditTypeTotal, info.getCreditType(), info);

            incrementCounter(total, info.getStatus(), info.getAmount());

            roles.put(info.getSkillGroupId(), info.getSkillGroupName());
            groups.put(info.getSkillGroupRoleId(), info.getSkillGroupRoleName());

            groupToRole.computeIfAbsent(info.getSkillGroupRoleId(), k -> new HashSet<>())
                    .add(info.getSkillGroupId());
            typeToRole.computeIfAbsent(info.getCreditType(), k -> new HashSet<>())
                    .add(info.getSkillGroupId());
            typeToGroup.computeIfAbsent(info.getCreditType(), k -> new HashSet<>())
                    .add(info.getSkillGroupRoleId());
        }

        List<SkillGroupCreditTypeView> skillGroupCreditTypeViews = countByCreditType.keySet()
                .stream()
                .map(type -> {
                    SkillGroupCreditTypeView skillGroupCreditTypeView = new SkillGroupCreditTypeView();
                    skillGroupCreditTypeView.setCreditType(type);

                    Set<Integer> roleIds = typeToRole.get(type);
                    List<SkillGroupView> roleList = roleIds.stream()
                            .map(roleId -> {
                                SkillGroupView skillGroupView = new SkillGroupView();
                                Integer groupId;
                                Optional<Map.Entry<Integer, Set<Integer>>> groupMap = groupToRole.entrySet()
                                        .stream()
                                        .filter(role -> role.getValue().contains(roleId))
                                        .findFirst();
                                if (groupMap.isPresent()) {
                                    groupId = groupMap.get().getKey();
                                } else {
                                    throw new IllegalStateException("Group not found");
                                }
                                skillGroupView.setGroupId(groupId);
                                skillGroupView.setSkillGroupName(roles.get(roleId));
                                skillGroupView.setAmounts(countByCreditType.get(type).get(roleId));
                                return skillGroupView;
                            })
                            .collect(Collectors.toList());

                    Set<Integer> groupIds = typeToGroup.get(type);
                    List<SkillGroupRoleView> groupList = groupIds.stream()
                            .map(groupId -> {
                                SkillGroupRoleView skillGroupRoleView = new SkillGroupRoleView();
                                skillGroupRoleView.setSkillGroupRoleName(groups.get(groupId));
                                skillGroupRoleView.setAmounts(countByCreditTypeGroup.get(type).get(groupId));
                                List<SkillGroupView> roleListByGroup = roleList.stream()
                                        .filter(role -> role.getGroupId().equals(groupId))
                                        .collect(Collectors.toList());
                                skillGroupRoleView.setSkillGroupViews(roleListByGroup);
                                return skillGroupRoleView;
                            })
                            .collect(Collectors.toList());

                    skillGroupCreditTypeView.setSkillGroupRoleViews(groupList);
                    skillGroupCreditTypeView.setAmounts(countByCreditTypeTotal.get(type));
                    return skillGroupCreditTypeView;
                })
                .collect(Collectors.toList());

        SkillInfoView skillInfoView = new SkillInfoView();
        skillInfoView.setAmounts(total);
        skillInfoView.setSkillGroupCreditTypeViews(skillGroupCreditTypeViews);
        return skillInfoView;
    }

    private void incrementInMap(Map<Integer, Map<ApplicationViewStatus, Integer>> map, int key, ApplicationInfoBySkill info) {
        Map<ApplicationViewStatus, Integer> roleCount = map.getOrDefault(key, new HashMap<>());
        incrementCounter(roleCount, info.getStatus(), info.getAmount());
        map.put(key, roleCount);
    }

    private void incrementCounter(Map<ApplicationViewStatus, Integer> roleCount, ApplicationViewStatus infoStatus, Integer amount) {
        roleCount.compute(infoStatus, (status, count) -> count == null ? amount : count + amount);
    }

    private void incrementInMapBySkillGroup(Map<CreditType, Map<Integer, Map<ApplicationViewStatus, Integer>>> countByCreditType, CreditType creditType, ApplicationInfoBySkill info) {
        Map<Integer, Map<ApplicationViewStatus, Integer>> roleStatusCount = countByCreditType.getOrDefault(creditType, new HashMap<>());
        Map<ApplicationViewStatus, Integer> roleCount = roleStatusCount.getOrDefault(info.getSkillGroupId(), new HashMap<>());
        incrementCounter(roleCount, info.getStatus(), info.getAmount());
        roleStatusCount.put(info.getSkillGroupId(), roleCount);
        countByCreditType.put(creditType, roleStatusCount);
    }

    private void incrementInMapBySkillGroupRole(Map<CreditType, Map<Integer, Map<ApplicationViewStatus, Integer>>> countByCreditType, CreditType creditType, ApplicationInfoBySkill info) {
        Map<Integer, Map<ApplicationViewStatus, Integer>> roleStatusCount = countByCreditType.getOrDefault(creditType, new HashMap<>());
        Map<ApplicationViewStatus, Integer> roleCount = roleStatusCount.getOrDefault(info.getSkillGroupRoleId(), new HashMap<>());
        incrementCounter(roleCount, info.getStatus(), info.getAmount());
        roleStatusCount.put(info.getSkillGroupRoleId(), roleCount);
        countByCreditType.put(creditType, roleStatusCount);
    }

    private void incrementInMapByCreditType(Map<CreditType, Map<ApplicationViewStatus, Integer>> countByCreditType, CreditType creditType, ApplicationInfoBySkill info) {
        Map<ApplicationViewStatus, Integer> creditTypeCount = countByCreditType.getOrDefault(creditType, new HashMap<>());
        incrementCounter(creditTypeCount, info.getStatus(), info.getAmount());
        countByCreditType.put(creditType, creditTypeCount);
    }

}
