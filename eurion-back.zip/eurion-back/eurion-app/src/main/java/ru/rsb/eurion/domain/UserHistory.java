package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class UserHistory {

    private Integer id;

    private Integer userId;

    private Integer actionUserId;

    private String propertyName;

    private String oldValue;

    private String newValue;

    private LocalDateTime updatedAt;
}
