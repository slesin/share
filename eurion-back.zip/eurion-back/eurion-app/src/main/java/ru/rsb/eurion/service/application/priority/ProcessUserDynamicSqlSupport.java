package ru.rsb.eurion.service.application.priority;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;

public class ProcessUserDynamicSqlSupport {

    public static final ProcessUserTable PROCESS_USER_TABLE = new ProcessUserTable();

    public static final SqlColumn<Integer> ID = PROCESS_USER_TABLE.column("ID", JDBCType.INTEGER);
    public static final SqlColumn<String> USER_FULL_NAME = PROCESS_USER_TABLE.column("FULL_NAME", JDBCType.VARCHAR);

    private static final class ProcessUserTable extends SqlTable {
        ProcessUserTable() {
            super("APP_USER");
        }

        @Override
        public int hashCode() {
            return ProcessUserDynamicSqlSupport.class.hashCode();
        }

        @Override
        @SuppressFBWarnings("EQ_UNUSUAL")
        public boolean equals(Object obj) {
            return obj != null && obj.getClass() == ProcessUserDynamicSqlSupport.class;
        }
    }
}

