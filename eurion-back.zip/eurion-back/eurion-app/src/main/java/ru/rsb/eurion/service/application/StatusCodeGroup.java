package ru.rsb.eurion.service.application;

import lombok.Getter;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Getter
public enum StatusCodeGroup {
    QUEUE(StatusCode.QUEUE),
    UNDER_CONSIDERATION(StatusCode.ASSIGNED, StatusCode.IN_WORK, StatusCode.POSTPONED);

    @Nonnull
    private final List<StatusCode> statusCodes;

    StatusCodeGroup(@Nonnull StatusCode... statusCodes) {
        this.statusCodes = Collections.unmodifiableList(Arrays.asList(statusCodes));
    }
}
