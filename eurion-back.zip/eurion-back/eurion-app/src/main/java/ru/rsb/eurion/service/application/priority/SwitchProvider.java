package ru.rsb.eurion.service.application.priority;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.priority.PrioritySwitch;
import ru.rsb.eurion.settings.AppConfig;

@Service
@AllArgsConstructor
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class SwitchProvider {
    private final AppConfig config;
    private final PrioritySwitchDao dao;

    public void reset() {
        PrioritySwitch prioritySwitch = dao.loadWithLock();
        prioritySwitch.setCounter(0);
        prioritySwitch.setReverse(false);
        dao.update(prioritySwitch);
    }

    public boolean takeSwitch() {
        if (!config.isSwitchableOrder()) {
            return false;
        }

        PrioritySwitch prioritySwitch = dao.loadWithLock();
        prioritySwitch.setCounter(prioritySwitch.getCounter() + 1);
        int limit;
        if (!prioritySwitch.isReverse()) {
            limit = config.getSwitchTopCount();
        } else {
            limit = config.getSwitchBottomCount();
        }

        if (prioritySwitch.getCounter() > limit) {
            prioritySwitch.setCounter(0);
            prioritySwitch.setReverse(!prioritySwitch.isReverse());
        }
        dao.update(prioritySwitch);
        return prioritySwitch.isReverse();
    }
}
