package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Единица дохода
 */
@Getter
@Setter
public class IncomeItem {
    /**
     * Источник дохода
     */
    private String source;
    /**
     * Сумма дохода
     */
    private BigDecimal amount;
    /**
     * Дата (todo что это за дата?)
     */
    private LocalDate date;
    /**
     * Доход подтверждён в указанном размере (true - да, false - нет)
     */
    private boolean confirmed;
    /**
     * Подтверждённый доход
     */
    private BigDecimal confirmedAmount;
    /**
     * Источник подтверждения
     */
    private String confirmSource;
}
