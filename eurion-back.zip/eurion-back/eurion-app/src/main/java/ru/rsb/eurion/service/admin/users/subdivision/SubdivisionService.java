package ru.rsb.eurion.service.admin.users.subdivision;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.admin.users.UserService;
import ru.rsb.eurion.service.application.statistics.productivity.dto.UserProductivityByTime;
import ru.rsb.eurion.service.report.dto.DecisionInfo;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static ru.rsb.eurion.service.admin.users.subdivision.OrgItemType.SUBDIVISION;
import static ru.rsb.eurion.service.admin.users.subdivision.OrgItemType.USER;

@Service
@Transactional
@AllArgsConstructor
@Slf4j
public class SubdivisionService {

    public static final int NON_STATISTICS_SUBDIVISION_ID = 2;
    private final SubdivisionDao dao;
    private final UserService userService;

    public OrgTreeNode getOrgItemTree() {
        List<User> userList = userService.listForSubdivision();
        Set<Subdivision> subdivisions = dao.list();
        Set<OrgItem> orgItems = getOrgItems(userList, subdivisions);
        Set<OrgStructureData> orgStructureDataSet = orgItems.stream()
                .map(orgItem -> {
                    OrgStructureData item = new OrgStructureData();
                    item.setOrgItem(orgItem);
                    return item;
                })
                .collect(Collectors.toSet());
        return getTreeNode(orgStructureDataSet);
    }

    public Set<Subdivision> getSubdivisionSet() {
        return dao.list().stream()
                .filter(subdivision -> !subdivision.getId().equals(NON_STATISTICS_SUBDIVISION_ID))
                .collect(Collectors.toSet());
    }

    public OrgTreeNode getOrgStatisticItemTree(List<DecisionInfo> decisionInfo, Integer subdivisionId) throws BusinessException {
        List<User> userList = getUsers(decisionInfo, subdivisionId);

        Set<Subdivision> subdivisions = getSubdivisionsById(subdivisionId);

        Set<OrgItem> orgItems = getOrgItems(userList, subdivisions);
        orgItems = excludeNonStatistic(orgItems);

        Map<Integer, Set<OrgItem>> itemsByParentId = orgItems.stream()
                .filter(item -> item.getParentId() != null)
                .collect(Collectors.groupingBy(OrgItem::getParentId, Collectors.toSet()));

        Map<Integer, OrgItem> orgItemMap = orgItems.stream()
                .collect(Collectors.toMap(OrgItem::getId, Function.identity()));

        Map<OrgItem, Set<OrgItem>> itemsByParent = getItemsByParent(itemsByParentId, orgItemMap);
        Map<Integer, OrgStatisticItem> userStatistic = getOrgStatisticItemMap(decisionInfo);
        Map<Integer, OrgStatisticItem> subdivisionStatistic = getSubdivisionStatisticMap(orgItems, itemsByParent, userStatistic);
        return getOrgTreeNode(orgItems, userStatistic, subdivisionStatistic);
    }

    public OrgTreeNode getProductivityItemTree(List<UserProductivityByTime> productivity, List<User> userList, Integer subdivisionId) throws BusinessException {
        Set<Subdivision> subdivisions = getSubdivisionsById(subdivisionId);

        Set<OrgItem> orgItems = getOrgItems(userList, subdivisions);
        orgItems = excludeNonStatistic(orgItems);

        Map<Integer, Set<OrgItem>> itemsByParentId = orgItems.stream()
                .filter(item -> item.getParentId() != null)
                .collect(Collectors.groupingBy(OrgItem::getParentId, Collectors.toSet()));

        Map<Integer, OrgItem> orgItemMap = orgItems.stream()
                .collect(Collectors.toMap(OrgItem::getId, Function.identity()));

        Map<OrgItem, Set<OrgItem>> itemsByParent = getItemsByParent(itemsByParentId, orgItemMap);

        Map<Integer, OrgProductivityItem> userProductivity = getUserProductivity(productivity);
        Map<Integer, OrgProductivityItem> subdivisionProductivity = getSubdivisionProductivity(orgItems, itemsByParent, userProductivity);
        return getOrgProductivityTreeNode(orgItems, userProductivity, subdivisionProductivity);
    }

    private Map<OrgItem, Set<OrgItem>> getItemsByParent(Map<Integer, Set<OrgItem>> itemsByParentId, Map<Integer, OrgItem> orgItemMap) {
        Map<OrgItem, Set<OrgItem>> itemsByParent = new HashMap<>();
        for (Map.Entry<Integer, Set<OrgItem>> entry : itemsByParentId.entrySet()) {
            OrgItem parent = orgItemMap.get(entry.getKey());
            if (parent != null) {
                itemsByParent.put(parent, entry.getValue());
            }
        }
        return itemsByParent;
    }

    private Map<Integer, OrgProductivityItem> getUserProductivity(List<UserProductivityByTime> productivity) {
        return productivity.stream()
                .map(item -> OrgProductivityItem.builder()
                        .orgItemId(-item.getUserId())
                        .loginAt(item.getLoginAt())
                        .lastLoginAt(item.getLastLoginAt())
                        .logoutAt(item.getLogoutAt())
                        .workTime(item.getWorkTime())
                        .dinnerTime(item.getDinnerTime())
                        .breakTime(item.getBreakTime())
                        .meetingTime(item.getMeetingTime())
                        .trainingTime(item.getTrainingTime())
                        .absentTime(item.getAbsentTime())
                        .additionalWorkWithOutApplicationTime(item.getAdditionalWorkWithOutApplicationTime())
                        .averageTimePerApplication(item.getAverageTimePerApplication())
                        .applicationDecisionPerHour(item.getApplicationDecisionPerHour())
                        .productivityPercent(item.getProductivityPercent())
                        .status(item.getStatus())
                        .build())
                .collect(Collectors.toMap(OrgProductivityItem::getOrgItemId, Function.identity()));
    }

    private Map<Integer, OrgProductivityItem> getSubdivisionProductivity(Set<OrgItem> orgItems, Map<OrgItem, Set<OrgItem>> itemsByParent,
                                                                         Map<Integer, OrgProductivityItem> userProductivity) {

        Map<OrgItem, Integer> levelMap = getLevelMap(orgItems, itemsByParent);

        List<OrgItem> sortedOrgIdByLevel = levelMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.comparingInt(Integer::intValue).reversed()))
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        Map<Integer, OrgProductivityItem> supervisorProductivitySum = getSupervisorOrgProductivityMap(userProductivity, itemsByParent);
        Map<Integer, OrgProductivityItem> subdivisionProductivity = new HashMap<>();
        for (OrgItem orgItem : sortedOrgIdByLevel) {
            Set<OrgItem> children = itemsByParent.get(orgItem);
            List<OrgProductivityItem> orgProductivityItems = new ArrayList<>();
            if (children != null) {
                for (OrgItem child : children) {
                    switch (child.getOrgItemType()) {
                        case USER:
                            OrgProductivityItem userProductivityItem = userProductivity.get(child.getId());
                            if (userProductivityItem != null) {
                                orgProductivityItems.add(userProductivityItem);
                            }
                            OrgProductivityItem supervisorProductivityItem = supervisorProductivitySum.get(child.getId());
                            if (supervisorProductivityItem != null) {
                                orgProductivityItems.add(supervisorProductivityItem);
                            }
                            break;
                        case SUBDIVISION:
                            OrgProductivityItem subStatisticItem = subdivisionProductivity.get(child.getId());
                            if (subStatisticItem != null) {
                                orgProductivityItems.add(subStatisticItem);
                            }
                            break;
                        default:
                            throw new IllegalStateException("Illegal OrgItemType: " + child.getOrgItemType());
                    }
                }
                OrgProductivityItem statSum = getSumOrgProductivity(orgProductivityItems);
                subdivisionProductivity.put(orgItem.getId(), statSum);
            }
        }

        return subdivisionProductivity;
    }

    private Map<OrgItem, Integer> getLevelMap(Set<OrgItem> orgItems, Map<OrgItem, Set<OrgItem>> itemsByParent) {
        Map<OrgItem, Integer> levelMap = new HashMap<>();
        for (Map.Entry<OrgItem, Set<OrgItem>> entry : itemsByParent.entrySet()) {
            int level = getLevel(entry.getKey(), orgItems);
            levelMap.put(entry.getKey(), level);
        }
        return levelMap;
    }

    private Set<OrgItem> excludeNonStatistic(Set<OrgItem> orgItems) {
        orgItems = orgItems.stream()
                .filter(item -> !Objects.equals(item.getId(), NON_STATISTICS_SUBDIVISION_ID)
                        && !Objects.equals(item.getParentId(), NON_STATISTICS_SUBDIVISION_ID))
                .collect(Collectors.toSet());
        return orgItems;
    }

    private OrgTreeNode getOrgTreeNode(Set<OrgItem> orgItems, Map<Integer, OrgStatisticItem> userStatistic, Map<Integer, OrgStatisticItem> subdivisionStatistic) {
        Set<OrgStructureData> orgStructureDataSet = orgItems.stream()
                .map(orgItem -> {
                    OrgStructureData item = new OrgStructureData();
                    item.setOrgItem(orgItem);
                    if (USER == orgItem.getOrgItemType()) {
                        item.setOrgStatisticItem(userStatistic.get(orgItem.getId()));
                    }
                    if (SUBDIVISION == orgItem.getOrgItemType()) {
                        item.setOrgStatisticItem(subdivisionStatistic.get(orgItem.getId()));
                    }
                    return item;
                })
                .collect(Collectors.toSet());
        return getTreeNode(orgStructureDataSet);
    }

    private OrgTreeNode getOrgProductivityTreeNode(Set<OrgItem> orgItems, Map<Integer, OrgProductivityItem> userProductivity, Map<Integer,
            OrgProductivityItem> subdivisionProductivity) {
        Set<OrgStructureData> orgStructureDataSet = orgItems.stream()
                .map(orgItem -> {
                    OrgStructureData item = new OrgStructureData();
                    item.setOrgItem(orgItem);
                    if (USER == orgItem.getOrgItemType()) {
                        item.setOrgProductivityItem(userProductivity.get(orgItem.getId()));
                    }
                    if (SUBDIVISION == orgItem.getOrgItemType()) {
                        item.setOrgProductivityItem(subdivisionProductivity.get(orgItem.getId()));
                    }
                    return item;
                })
                .collect(Collectors.toSet());
        return getTreeNode(orgStructureDataSet);
    }

    private Map<Integer, OrgStatisticItem> getSubdivisionStatisticMap(Set<OrgItem> orgItems, Map<OrgItem, Set<OrgItem>> itemsByParent,
                                                                      Map<Integer, OrgStatisticItem> userStatistic) {
        Map<OrgItem, Integer> levelMap = getLevelMap(orgItems, itemsByParent);

        List<OrgItem> sortedOrgIdByLevel = levelMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.comparingInt(Integer::intValue).reversed()))
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        Map<Integer, OrgStatisticItem> supervisorStatisticSum = getSupervisorOrgStatisticMap(userStatistic, itemsByParent);
        Map<Integer, OrgStatisticItem> subdivisionStatistic = new HashMap<>();
        for (OrgItem orgItem : sortedOrgIdByLevel) {
            Set<OrgItem> children = itemsByParent.get(orgItem);
            List<OrgStatisticItem> orgStatisticItems = new ArrayList<>();
            if (children != null) {
                for (OrgItem child : children) {
                    switch (child.getOrgItemType()) {
                        case USER:
                            OrgStatisticItem userStatisticItem = userStatistic.get(child.getId());
                            if (userStatisticItem != null) {
                                orgStatisticItems.add(userStatisticItem);
                            }
                            OrgStatisticItem supervisorStatisticItem = supervisorStatisticSum.get(child.getId());
                            if (supervisorStatisticItem != null) {
                                orgStatisticItems.add(supervisorStatisticItem);
                            }
                            break;
                        case SUBDIVISION:
                            OrgStatisticItem subStatisticItem = subdivisionStatistic.get(child.getId());
                            if (subStatisticItem != null) {
                                orgStatisticItems.add(subStatisticItem);
                            }
                            break;
                        default:
                            throw new IllegalStateException("Illegal OrgItemType: " + child.getOrgItemType());
                    }
                }
                OrgStatisticItem statSum = getSumOrgStatistic(orgStatisticItems);
                subdivisionStatistic.put(orgItem.getId(), statSum);
            }
        }

        calculateSubdivisionApprovePercent(subdivisionStatistic);
        return subdivisionStatistic;
    }

    private void calculateSubdivisionApprovePercent(Map<Integer, OrgStatisticItem> subdivisionStatistic) {
        for (Map.Entry<Integer, OrgStatisticItem> entry : subdivisionStatistic.entrySet()) {
            OrgStatisticItem orgStatisticItem = entry.getValue();
            int approveAmount = orgStatisticItem.getApproveAmount();
            int rejectAmount = orgStatisticItem.getRejectAmount();
            if (approveAmount != 0) {
                int approvePercent = BigDecimal.valueOf(approveAmount).multiply(BigDecimal.valueOf(100))
                        .divide(BigDecimal.valueOf(approveAmount + rejectAmount), 0, BigDecimal.ROUND_HALF_UP).intValue();
                orgStatisticItem.setApprovePercent(approvePercent);
            }
        }
    }

    private Map<Integer, OrgStatisticItem> getSupervisorOrgStatisticMap(Map<Integer, OrgStatisticItem> userStatistic, Map<OrgItem, Set<OrgItem>> itemsByParent) {
        Map<Integer, OrgStatisticItem> supervisorStatisticSum = new HashMap<>();
        for (Map.Entry<OrgItem, Set<OrgItem>> entry : itemsByParent.entrySet()) {
            OrgItem orgItem = entry.getKey();
            Set<OrgItem> children = entry.getValue();
            if (orgItem.getOrgItemType() == USER) {
                List<OrgStatisticItem> orgStatisticItems = new ArrayList<>();
                for (OrgItem child : children) {
                    OrgStatisticItem orgStatisticItem = userStatistic.get(child.getId());
                    if (orgStatisticItem != null) {
                        orgStatisticItems.add(orgStatisticItem);
                    }
                }
                OrgStatisticItem sum = getSumOrgStatistic(orgStatisticItems);
                supervisorStatisticSum.put(orgItem.getId(), sum);
            }
        }
        return supervisorStatisticSum;
    }

    private Map<Integer, OrgProductivityItem> getSupervisorOrgProductivityMap(Map<Integer, OrgProductivityItem> userProductivity, Map<OrgItem, Set<OrgItem>> itemsByParent) {
        Map<Integer, OrgProductivityItem> supervisorProductivitySum = new HashMap<>();
        for (Map.Entry<OrgItem, Set<OrgItem>> entry : itemsByParent.entrySet()) {
            OrgItem orgItem = entry.getKey();
            Set<OrgItem> children = entry.getValue();
            if (orgItem.getOrgItemType() == USER) {
                List<OrgProductivityItem> orgProductivityItems = new ArrayList<>();
                for (OrgItem child : children) {
                    OrgProductivityItem orgProductivityItem = userProductivity.get(child.getId());
                    if (orgProductivityItem != null) {
                        orgProductivityItems.add(orgProductivityItem);
                    }
                }
                OrgProductivityItem sum = getSumOrgProductivity(orgProductivityItems);
                supervisorProductivitySum.put(orgItem.getId(), sum);
            }
        }
        return supervisorProductivitySum;
    }

    private Map<Integer, OrgStatisticItem> getOrgStatisticItemMap(List<DecisionInfo> decisionInfo) {
        return decisionInfo.stream()
                .map(info -> {
                    OrgStatisticItem orgStatisticItem = new OrgStatisticItem();
                    orgStatisticItem.setOrgItemId(-info.getUserId());
                    orgStatisticItem.setInWork(info.getInWorkCount());
                    orgStatisticItem.setRejectAmount(info.getRejectAmount());
                    orgStatisticItem.setInPostpone(info.getPostponeCount());
                    orgStatisticItem.setFullAmount(info.getApproveAmount() + info.getRejectAmount());
                    orgStatisticItem.setApproveAmount(info.getApproveAmount());
                    orgStatisticItem.setApprovePercent(info.getApprovePercent());
                    return orgStatisticItem;
                }).collect(Collectors.toMap(OrgStatisticItem::getOrgItemId, Function.identity()));
    }

    private int getLevel(OrgItem orgItem, Set<OrgItem> orgItems) {
        int level = 0;
        OrgItem temp = orgItem;
        while (temp != null) {
            ++level;
            OrgItem parent = temp;
            temp = orgItems.stream()
                    .filter(item -> Objects.equals(item.getId(), parent.getParentId()))
                    .findFirst()
                    .orElse(null);
        }
        return level;
    }

    private OrgStatisticItem getSumOrgStatistic(List<OrgStatisticItem> orgStat) {
        OrgStatisticItem orgStatisticItem = new OrgStatisticItem();
        for (OrgStatisticItem item : orgStat) {
            orgStatisticItem.setApproveAmount(orgStatisticItem.getApproveAmount() + item.getApproveAmount());
            orgStatisticItem.setInWork(orgStatisticItem.getInWork() + item.getInWork());
            orgStatisticItem.setFullAmount(orgStatisticItem.getFullAmount() + item.getFullAmount());
            orgStatisticItem.setInPostpone(orgStatisticItem.getInPostpone() + item.getInPostpone());
            orgStatisticItem.setRejectAmount(orgStatisticItem.getRejectAmount() + item.getRejectAmount());
        }
        return orgStatisticItem;
    }

    private OrgProductivityItem getSumOrgProductivity(List<OrgProductivityItem> orgProductivity) {
        OrgProductivityItem orgProductivityItem = new OrgProductivityItem();
        for (OrgProductivityItem item : orgProductivity) {

            Duration timeInWork = plusLocalTime(orgProductivityItem.getWorkTime(), item.getWorkTime());
            orgProductivityItem.setWorkTime(timeInWork);

            Duration dinnerTime = plusLocalTime(orgProductivityItem.getDinnerTime(), item.getDinnerTime());
            orgProductivityItem.setDinnerTime(dinnerTime);

            Duration breakTime = plusLocalTime(orgProductivityItem.getBreakTime(), item.getBreakTime());
            orgProductivityItem.setBreakTime(breakTime);

            Duration meetingTime = plusLocalTime(orgProductivityItem.getMeetingTime(), item.getMeetingTime());
            orgProductivityItem.setMeetingTime(meetingTime);

            Duration trainingTime = plusLocalTime(orgProductivityItem.getTrainingTime(), item.getTrainingTime());
            orgProductivityItem.setTrainingTime(trainingTime);

            Duration absentTime = plusLocalTime(orgProductivityItem.getAbsentTime(), item.getAbsentTime());
            orgProductivityItem.setAbsentTime(absentTime);

            Duration additionalWorkWithOutApplicationTime = plusLocalTime(orgProductivityItem.getAdditionalWorkWithOutApplicationTime(),
                    item.getAdditionalWorkWithOutApplicationTime());
            orgProductivityItem.setAdditionalWorkWithOutApplicationTime(additionalWorkWithOutApplicationTime);

            Duration averageTimePerApplication = plusLocalTime(orgProductivityItem.getAverageTimePerApplication(), item.getAverageTimePerApplication());
            orgProductivityItem.setAverageTimePerApplication(averageTimePerApplication);

            BigDecimal appPerHour = orgProductivityItem.getApplicationDecisionPerHour().add(item.getApplicationDecisionPerHour());
            orgProductivityItem.setApplicationDecisionPerHour(appPerHour);

            BigDecimal productivityPercent = orgProductivityItem.getProductivityPercent().add(item.getProductivityPercent());
            orgProductivityItem.setProductivityPercent(productivityPercent);
        }
        return orgProductivityItem;
    }

    private Duration plusLocalTime(Duration first, Duration second) {
        return first.plus(second);
    }

    public void updateSubdivision(OrgItem newOrgItem) {
        List<User> userList = userService.listForSubdivision();
        Set<Subdivision> subdivisions = dao.list();
        Set<OrgItem> oldValues = getOrgItems(userList, subdivisions);
        if (newOrgItem.getId() != null) {
            OrgItem oldSubdivision = oldValues.stream()
                    .filter(item -> Objects.equals(newOrgItem.getId(), item.getId()))
                    .findFirst()
                    .orElseThrow(() -> new IllegalStateException("Subdivision not found id = " + newOrgItem.getId()));
            merge(oldSubdivision, newOrgItem, oldValues);
        } else {
            create(newOrgItem);
        }
    }

    public void delete(OrgItem subdivision) {
        List<User> userList = userService.listForSubdivision();
        Set<Subdivision> subdivisions = dao.list();
        Set<OrgItem> oldValues = getOrgItems(userList, subdivisions);
        delete(oldValues, subdivision);
    }

    public void update(Integer id, Integer parentId, String value, Integer orderIdx) {
        if (Objects.equals(id, parentId)) {
            throw new IllegalStateException("Id and parentId must be unique.");
        }
        dao.update(id, parentId, value, orderIdx);
    }

    private Set<OrgItem> getOrgItems(List<User> userList, Set<Subdivision> subdivisions) {
        Set<OrgItem> subdivisionOrgItems = getSubdivisionOrgItems(subdivisions);
        Set<OrgItem> userOrgItems = new HashSet<>();
        for (User user : userList) {
            if (user.getSupervisor() == null) {
                OrgItem orgItem = getOrgItem(-user.getId(), user.getSubdivisionId(), user.getName(),
                        true, false, false, USER, null);
                userOrgItems.add(orgItem);
                List<User> operators = userList.stream()
                        .filter(operator -> Objects.nonNull(operator.getSupervisor()))
                        .filter(operator -> operator.getSupervisor().getId().equals(user.getId()))
                        .collect(Collectors.toList());
                operators.forEach(
                        operator -> {
                            OrgItem operatorOrgItem = getOrgItem(-operator.getId(), -user.getId(), operator.getName(),
                                    false, false, false, USER, null);
                            userOrgItems.add(operatorOrgItem);
                        }
                );
            }
        }
        subdivisionOrgItems.addAll(userOrgItems);
        return subdivisionOrgItems;
    }

    private OrgTreeNode getTreeNode(Set<OrgStructureData> orgItems) {
        Map<Integer, Set<OrgStructureData>> itemsByParent = orgItems.stream()
                .filter(item -> item.getOrgItem().getParentId() != null)
                .collect(Collectors.groupingBy(item -> item.getOrgItem().getParentId(), Collectors.toSet()));

        OrgStructureData rootItem = orgItems.stream()
                .filter(item -> item.getOrgItem().getParentId() == null)
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("Root subdivision not found"));

        OrgTreeNode root = new OrgTreeNode(rootItem);
        List<OrgTreeNode> nodes = new ArrayList<>();
        List<OrgTreeNode> childNodes = new ArrayList<>();
        nodes.add(root);

        while (nodes.size() != 0) {
            for (OrgTreeNode node : nodes) {
                for (Map.Entry<Integer, Set<OrgStructureData>> entry : itemsByParent.entrySet()) {
                    if (Objects.equals(entry.getKey(), node.getId())) {
                        childNodes.addAll(addNode(node, entry.getValue()));
                    }
                }
            }
            nodes = new ArrayList<>(childNodes);
            childNodes.clear();
        }
        return root;
    }

    private List<OrgTreeNode> addNode(OrgTreeNode node, Set<OrgStructureData> items) {
        List<OrgTreeNode> nodes = new ArrayList<>();
        items.forEach(item -> {
            OrgTreeNode newNode = node.addChild(item);
            sortChild(node);
            nodes.add(newNode);
        });
        return nodes;
    }

    private void sortChild(OrgTreeNode orgTreeNode) {
        List<OrgTreeNode> sortedNodes = orgTreeNode.getData().stream()
                .sorted(Comparator.comparing(OrgTreeNode::getValue))
                .collect(Collectors.toList());
        orgTreeNode.getData().clear();
        orgTreeNode.getData().addAll(sortedNodes);
    }

    private OrgItem getOrgItem(Integer id, Integer parentId, String name, boolean canMove, boolean canEditChild,
                               boolean canRename, OrgItemType type, Integer orderIdx) {
        OrgItem orgItem = new OrgItem();
        orgItem.setId(id);
        orgItem.setValue(name);
        orgItem.setParentId(parentId);
        orgItem.setCanMove(canMove);
        orgItem.setCanEditChild(canEditChild);
        orgItem.setCanRename(canRename);
        orgItem.setOrgItemType(type);
        orgItem.setOrderIdx(orderIdx);
        return orgItem;
    }

    private void merge(OrgItem oldOrgItem, OrgItem newOrgItem, Set<OrgItem> oldOrgItems) {
        if (!oldOrgItem.equals(newOrgItem)) {
            switch (newOrgItem.getOrgItemType()) {
                case USER:
                    if (!Objects.equals(newOrgItem.getParentId(), oldOrgItem.getParentId())) {
                        OrgItem parentSubDivision = oldOrgItems.stream()
                                .filter(parent -> Objects.equals(parent.getId(), newOrgItem.getParentId()))
                                .findFirst()
                                .orElseThrow(() -> new IllegalStateException("Illegal parent id for user, id = " + newOrgItem.getId()));

                        if (!parentSubDivision.isCanEditChild()) {
                            throw new IllegalStateException("Incorrect action for user, id  = " + newOrgItem.getId());
                        }
                    }
                    userService.updateSubdivision(Math.abs(newOrgItem.getId()), newOrgItem.getParentId());
                    break;
                case SUBDIVISION:
                    if (oldOrgItem.getParentId() == null && newOrgItem.getParentId() != null) {
                        throw new IllegalStateException("Incorrect action for main Subdivision. Subdivision id = " + oldOrgItem.getId());
                    }
                    updateOrderIdx(oldOrgItem, newOrgItem);
                    break;
                default:
                    throw new IllegalStateException("Incorrect subdivision type:" + newOrgItem.getOrgItemType());
            }
        }
    }

    private void updateOrderIdx(OrgItem oldOrgItem, OrgItem newOrgItem) {
        List<Subdivision> subdivisions = dao.getChildren(newOrgItem.getParentId());
        if (!Objects.equals(oldOrgItem.getParentId(), newOrgItem.getParentId())) {
            int orderIdx = subdivisions.stream()
                    .max(Comparator.comparing(Subdivision::getOrderIdx))
                    .map(Subdivision::getOrderIdx)
                    .orElse(1);
            update(newOrgItem.getId(), newOrgItem.getParentId(), newOrgItem.getValue(), ++orderIdx);
        } else {
            boolean reverse = oldOrgItem.getOrderIdx() > newOrgItem.getOrderIdx();
            int shift = Math.abs(oldOrgItem.getOrderIdx() - newOrgItem.getOrderIdx());
            update(newOrgItem.getId(), newOrgItem.getParentId(), newOrgItem.getValue(), null);
            if (reverse) {
                subdivisions.stream()
                        .filter(subdivision -> subdivision.getOrderIdx() < oldOrgItem.getOrderIdx())
                        .sorted(Comparator.comparing(Subdivision::getOrderIdx).reversed())
                        .limit(shift)
                        .forEach(subdivision -> update(subdivision.getId(), subdivision.getParentId(),
                                subdivision.getName(), subdivision.getOrderIdx() + 1));
            } else {
                subdivisions.stream()
                        .filter(subdivision -> subdivision.getOrderIdx() > oldOrgItem.getOrderIdx())
                        .sorted(Comparator.comparing(Subdivision::getOrderIdx))
                        .limit(shift)
                        .forEach(subdivision -> update(subdivision.getId(), subdivision.getParentId(),
                                subdivision.getName(), subdivision.getOrderIdx() - 1));
            }
            update(newOrgItem.getId(), newOrgItem.getParentId(), newOrgItem.getValue(), newOrgItem.getOrderIdx());
        }
    }

    private void delete(Set<OrgItem> oldOrgItems, OrgItem deleteOrgItem) {
        if (deleteOrgItem.getOrgItemType() == SUBDIVISION) {
            if (deleteOrgItem.getParentId() == null) {
                throw new IllegalStateException("Incorrect action for main Subdivision. Subdivision id = " + deleteOrgItem.getId());
            }
            List<OrgItem> childList = oldOrgItems.stream()
                    .filter(child -> Objects.equals(deleteOrgItem.getId(), child.getParentId()))
                    .collect(Collectors.toList());
            if (!childList.isEmpty()) {
                throw new IllegalStateException("Incorrect action for Subdivision. There are nested elements. Subdivision id = " + deleteOrgItem.getId());
            }
            dao.delete(deleteOrgItem.getId());
            oldOrgItems.stream()
                    .filter(orgItem -> orgItem.getOrgItemType().equals(SUBDIVISION) &&
                            Objects.equals(orgItem.getParentId(), deleteOrgItem.getParentId()) &&
                            orgItem.getOrderIdx() > deleteOrgItem.getOrderIdx())
                    .sorted(Comparator.comparingInt(OrgItem::getOrderIdx))
                    .forEach(orgItem -> {
                        int orderIdx = orgItem.getOrderIdx() - 1;
                        update(orgItem.getId(), orgItem.getParentId(), orgItem.getValue(), orderIdx);
                    });
        } else {
            throw new IllegalStateException("Incorrect action for user, id = " + deleteOrgItem.getId());
        }
    }

    private void create(OrgItem orgItem) {
        if (orgItem.getOrgItemType() == SUBDIVISION) {
            Integer lastOrderIdx = dao.getLastOrderIdx(orgItem.getParentId());
            if (lastOrderIdx != null) {
                orgItem.setOrderIdx(++lastOrderIdx);
            }
            int newOrderIdx = orgItem.getOrderIdx() != null ? orgItem.getOrderIdx() : 1;
            dao.create(orgItem.getParentId(), orgItem.getValue(), newOrderIdx);
        } else {
            throw new IllegalStateException("Incorrect action for user, id = " + orgItem.getId());
        }
    }

    private Set<OrgItem> getSubdivisionOrgItems(Set<Subdivision> subdivisions) {
        return subdivisions.stream()
                .map(subdivision -> getOrgItem(subdivision.getId(), subdivision.getParentId(), subdivision.getName(),
                        subdivision.getParentId() != null, true, true, SUBDIVISION, subdivision.getOrderIdx()))
                .collect(Collectors.toSet());
    }

    private Set<Subdivision> getSubdivisionsById(Integer subdivisionId) throws BusinessException {
        Set<Subdivision> subdivisions = dao.getChild(subdivisionId);
        subdivisions.stream()
                .filter(subdivision -> subdivision.getId().equals(subdivisionId))
                .findFirst()
                .orElseThrow(() -> new BusinessException("subdivision", "Подразденеие не найдено."))
                .setParentId(null);
        return subdivisions;
    }

    private List<User> getUsers(List<DecisionInfo> decisionInfo, Integer subdivisionId) {
        List<User> userList = userService.listBySubdivision(subdivisionId, NON_STATISTICS_SUBDIVISION_ID);

        List<Integer> usersWithDecisions = decisionInfo.stream()
                .map(DecisionInfo::getUserId)
                .collect(Collectors.toList());

        userList = userList.stream().filter(user ->
                user.isHasRoleSupervisor() || usersWithDecisions.contains(user.getId()))
                .collect(Collectors.toList());
        return userList;
    }
}
