package ru.rsb.eurion.service.admin.skill.group;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.DeclineCategory;

import java.util.List;

@Getter
@Setter
public class SkillGroupDeclineCategory {
    private Integer skillGroupId;
    private List<DeclineCategory> declineCategories;
}
