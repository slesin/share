package ru.rsb.eurion.service.application.statistics.productivity.dto;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.UserDecision;

import java.util.List;

@Setter
@Getter
public class UserProductivity {

    private Integer plannedCountDecision;

    private List<UserDecision> userDecisionInfoList;
}
