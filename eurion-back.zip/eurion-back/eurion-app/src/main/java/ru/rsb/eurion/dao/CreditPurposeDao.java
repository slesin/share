package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.CreditPurpose;

import java.util.List;

@Mapper
public interface CreditPurposeDao {

    String BASE_SELECT_SQL = "select ID, NAME, CREATED_AT, UPDATED_AT, DISABLED_AT from CREDIT_PURPOSE";

    @Select(BASE_SELECT_SQL + " order by ID")
    @Results(id = "creditPurposeMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<CreditPurpose> findAll();

    @Select(BASE_SELECT_SQL + " where ID = #{id}")
    @ResultMap("creditPurposeMapping")
    CreditPurpose findById(Integer id);
}
