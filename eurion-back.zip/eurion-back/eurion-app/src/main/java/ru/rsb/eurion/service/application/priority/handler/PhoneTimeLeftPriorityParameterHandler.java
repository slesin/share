package ru.rsb.eurion.service.application.priority.handler;

import lombok.RequiredArgsConstructor;
import org.mybatis.dynamic.sql.SortSpecification;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.priority.PriorityParameter;
import ru.rsb.eurion.domain.priority.SortDirection;
import ru.rsb.eurion.service.application.priority.PriorityParameterHandler;
import ru.rsb.eurion.service.calendar.CalendarService;

import static ru.rsb.eurion.service.application.priority.ApplicationPriorityService.PRIORITY_HANDLER_PREFIX;

@RequiredArgsConstructor
@Component(PRIORITY_HANDLER_PREFIX + "PHONE_TIME_LEFT")
public class PhoneTimeLeftPriorityParameterHandler implements PriorityParameterHandler {

    private final CalendarService calendarService;

    @Override
    public SortSpecification apply(PriorityParameter parameter) {
        return new PhoneTimeLeftPriorityParameterHandler.Spec(
                parameter.getDirection() == SortDirection.DESC ^ !parameter.isReverse(),
                calendarService.isTodayHoliday());
    }

    @Override
    public boolean isCommon() {
        return true;
    }

    public static class Spec implements SortSpecification {

        private static final String WORK_EXPRESSION = "LEFT_TIME NULLS LAST";
        private static final String WORK_EXPRESSION_DESC = "LEFT_TIME DESC NULLS LAST";

        private static final String HOLIDAY_EXPRESSION = "HOLIDAY_LEFT_TIME NULLS LAST";
        private static final String HOLIDAY_EXPRESSION_DESC = "HOLIDAY_LEFT_TIME DESC NULLS LAST";

        private final boolean descending;
        private final boolean isDayIsHoliday;

        private Spec(boolean descending, boolean isDayIsHoliday) {
            this.descending = descending;
            this.isDayIsHoliday = isDayIsHoliday;
        }

        @Override
        public SortSpecification descending() {
            return new PhoneTimeLeftPriorityParameterHandler.Spec(true, false);
        }

        @Override
        public String aliasOrName() {
            if (isDayIsHoliday) {
                return descending ? HOLIDAY_EXPRESSION_DESC : HOLIDAY_EXPRESSION;
            }
            return descending ? WORK_EXPRESSION_DESC : WORK_EXPRESSION;
        }

        @Override
        public boolean isDescending() {
            return false;
        }
    }
}
