package ru.rsb.eurion.domain;

import lombok.Data;

import java.io.Serializable;

/**
 * Статус пользователя
 */
@Data
public class UserStatus implements Serializable {

    private Integer id;

    private String name;

    private StatusType code;

    private Integer orderNum;

}
