package ru.rsb.eurion.service.admin.users.status;

import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.flowable.common.engine.api.FlowableOptimisticLockingException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.StatusType;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.domain.UserStatus;
import ru.rsb.eurion.security.AppAuthenticationToken;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.admin.users.UserService;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@Slf4j
@Service
@Transactional
@AllArgsConstructor
public class UserStatusFacade {
    private final UserService userService;
    private final UserStatusService userStatusService;
    private final UserStatusHelper userStatusHelper;

    public UserStatusAndRole setUserStatusAndRole(@Nullable UserStatus userStatus, @NonNull @Nonnull Role role) {
        if (userStatus == null) {
            userStatus = takeDefaultStatusForRole(role);
        }
        UserStatusAndRole statusAndRole;
        UserData userData = AuthUtil.loggedUser();
        try {
            userStatusHelper.setupStatusAndRole(userData.getId(), role, userStatus.getCode());
        } catch (FlowableOptimisticLockingException e) {
            log.warn(e.getMessage());
            boolean isUpdateByAnotherTransaction;
            isUpdateByAnotherTransaction = e.getMessage().contains("was updated by another transaction concurrently");
            if (!isUpdateByAnotherTransaction) {
                throw e;
            }
        }
        statusAndRole = new UserStatusAndRole(userStatus, role);
        userData.setCurrentStatus(statusAndRole);
        User user = userService.findByIdFromAD(userData.getId());
        if (user != null) {
            AppAuthenticationToken token = new AppAuthenticationToken(user, new UserStatusAndRole(userStatus, role));
            SecurityContextHolder.getContext().setAuthentication(token);
        }
        return statusAndRole;
    }

    @Nonnull
    private UserStatus takeDefaultStatusForRole(Role role) {
        StatusType code;
        switch (role) {
            default:
                code = StatusType.WORK;
        }
        UserStatus userStatus = userStatusService.getUserStatusByCode(code);
        if (userStatus == null) {
            throw new IllegalStateException("Unknown status code");
        }
        return userStatus;
    }
}