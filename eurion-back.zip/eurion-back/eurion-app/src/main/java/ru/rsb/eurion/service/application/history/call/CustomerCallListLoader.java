package ru.rsb.eurion.service.application.history.call;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rsb.eurion.clients.UtilsServiceClient;
import ru.rsb.eurion.service.check.protocol.history.dto.ProcedureParam;

import javax.annotation.Nonnull;
import java.sql.JDBCType;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Service
@AllArgsConstructor
public class CustomerCallListLoader {
    public static final String PROC_NAME = "front.dbo.web_ask_f_req_searchreq";
    private final UtilsServiceClient utilsServiceClient;

    public List<CustomerCallItem> load(@Nonnull Long clientId) {
        ProcedureParam param = new ProcedureParam("@ks_idclient", JDBCType.NUMERIC.name(),
                "IN", clientId.toString());
        Stream<UtilsServiceClient.DataRow> stream = utilsServiceClient.executeProcedure(PROC_NAME, param);
        return stream.map(this::mapRow)
                .collect(Collectors.toList());
    }


    private CustomerCallItem mapRow(UtilsServiceClient.DataRow row) {
        CustomerCallItem item = new CustomerCallItem();
        item.setNumReg(row.getString("num_reg"));
        item.setDateCreate(row.getLocalDateTime("date_create"));
        item.setNameReq(row.getString("name_req"));
        item.setNameTheme(row.getString("name_theme"));
        item.setNameReqDecode(row.getString("name_reqdecod"));
        item.setNameReqStat(row.getString("name_reqstat"));
        item.setNum(row.getString("num"));
        item.setNameUser(row.getString("name_user"));
        item.setNameRegion(row.getString("name_region"));
        item.setNameOffice(row.getString("name_office"));
        item.setNameReply(row.getString("name_reply"));
        return item;
    }
}
