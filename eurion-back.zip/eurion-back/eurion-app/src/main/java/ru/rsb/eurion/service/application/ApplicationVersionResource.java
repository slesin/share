package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.Application;
import ru.rsb.eurion.service.ResultWrapper;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping(path = ApplicationResource.APPLICATION_PATH, produces = APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class ApplicationVersionResource {

    private final ApplicationVersionService appVersionService;

    @GetMapping(path = "/version/{appVersionId}")
    public Application getApplicationVersion(@PathVariable("appVersionId") Long appVersionId) {
        return appVersionService.findById(appVersionId);
    }

    @GetMapping(path = "/version/last/{appId}")
    public ResultWrapper<Application> getApplicationVersion(@PathVariable("appId") Integer appId) {
        Application application = appVersionService.findLastByAppId(appId);
        return ResultWrapper.of(application);
    }

}
