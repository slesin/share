package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Договор клиента
 */
@Getter
@Setter
public class Contract {
    /**
     * Тип продукта
     */
    private ProductType productType;
    /**
     * Сумма
     */
    private BigDecimal amount;
    /**
     * Срок в днях
     */
    private Integer periodInDays;
    /**
     * Дата открытия
     */
    private LocalDate created;
    /**
     * Тип карты
     */
    private CardType cardType;
    /**
     * Текущий остаток
     */
    private BigDecimal balance;
    /**
     * Сумма задолженности
     */
    private BigDecimal debt;

}
