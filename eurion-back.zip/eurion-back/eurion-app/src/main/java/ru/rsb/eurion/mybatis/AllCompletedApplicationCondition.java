package ru.rsb.eurion.mybatis;

import org.mybatis.dynamic.sql.AbstractColumnComparisonCondition;
import org.mybatis.dynamic.sql.BasicColumn;

public class AllCompletedApplicationCondition<T> extends AbstractColumnComparisonCondition<T> {
    private AllCompletedApplicationCondition(BasicColumn column) {
        super(column);
    }

    @Override
    protected String renderCondition(String leftColumn, String rightColumn) {
        return " ((AP.PROCESS_NAME = 'APPLICATION' and A.STATUS_CATEGORY_CODE = 'COMPLETED') or" +
                " (AP.PROCESS_NAME <> 'APPLICATION' and APS.CATEGORY_CODE = 'COMPLETED'))";
    }

    public static <T> AllCompletedApplicationCondition<T> of(BasicColumn column) {
        return new AllCompletedApplicationCondition<>(column);
    }
}
