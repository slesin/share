package ru.rsb.eurion.service.application.branch;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.rsb.eurion.service.admin.users.upd.BaseEisClient;
import ru.rsb.eurion.settings.EisConfig;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class BranchService extends BaseEisClient {

    private final EisConfig eisConfig;
    private BranchInfo branchInfo;

    @Scheduled(fixedDelay = 60_000)
    @Scheduled(cron = "${app.schedule.branch.cron}")
    public void loadBranches() {
        BranchInfoRequest request = new BranchInfoRequest();
        request.setReturnReferenceValues(true);
        request.setSiteVisible(1);
        try {
            branchInfo = executePost(BranchInfo.class, eisConfig.getEisReferenceServiceUrl(), request, MediaType.APPLICATION_JSON, Collections.emptyMap());
            log.info("Branch info is updated successfully");
        } catch (Exception e) {
            log.error("Get branch error", e);
        }
    }

    @Nullable
    public BranchItem getById(Long id) {
        if (branchInfo != null && !branchInfo.getBranches().isEmpty()) {
            List<BranchItem> branchItems = branchInfo.getBranches();
            return branchItems.stream()
                    .filter(item -> id.equals(item.getId()))
                    .findFirst()
                    .orElse(null);
        }
        return null;
    }

    @Nullable
    public BranchItem getByExternalId(Long externalId) {
        if (branchInfo != null && !branchInfo.getBranches().isEmpty()) {
            List<BranchItem> branchItems = branchInfo.getBranches();
            return branchItems.stream()
                    .filter(item -> externalId.equals(item.getExternalId()))
                    .findFirst()
                    .orElse(null);
        }
        return null;
    }
}
