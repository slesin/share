package ru.rsb.eurion.service.application.flow.api;

import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.flowable.common.engine.api.FlowableOptimisticLockingException;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.DeclineReasonDao;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.domain.StatusType;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.admin.skill.group.CheckType;
import ru.rsb.eurion.service.admin.skill.group.SkillGroupDao;
import ru.rsb.eurion.service.admin.skill.group.SkillGroupService;
import ru.rsb.eurion.service.admin.users.UserDao;
import ru.rsb.eurion.service.admin.users.status.UserStatusAndRole;
import ru.rsb.eurion.service.admin.users.status.UserStatusService;
import ru.rsb.eurion.service.application.ApplicationDao;
import ru.rsb.eurion.service.application.ApplicationService;
import ru.rsb.eurion.service.application.ApplicationVersionService;
import ru.rsb.eurion.service.application.NotificationService;
import ru.rsb.eurion.service.application.UserMessage;
import ru.rsb.eurion.service.application.flow.ApplicationProcessService;
import ru.rsb.eurion.service.application.priority.ApplicationPriorityService;
import ru.rsb.eurion.settings.AppConfig;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static ru.rsb.eurion.service.application.flow.ApplicationProcessService.DEFAULT_USER_NAME;

@Service("app")
@Transactional
@AllArgsConstructor
@Slf4j
@SuppressWarnings("unused")
public class AppService {
    private final ApplicationService service;
    private final ApplicationPriorityService priorityService;
    private final UserDao userDao;
    private final DeclineReasonDao declineReasonDao;
    private final SkillGroupService skillGroupService;
    private final SkillGroupDao skillGroupDao;
    private final ApplicationDao dao;
    private final ApplicationPriorityService applicationPriorityService;
    private final ApplicationProcessService applicationProcessService;
    private final UserStatusService userStatusService;
    private final AppConfig config;
    private final NotificationService notificationService;
    private final ApplicationVersionService appVersionService;

    public void assign(Long applicationId, Integer userId) {
        doAssign(applicationId, userId, DEFAULT_USER_NAME);
    }

    public void assign(Long applicationId, Integer userId, String currentUserName) {
        doAssign(applicationId, userId, currentUserName);
    }

    private void doAssign(Long applicationId, Integer userId, String currentUserName) {
        User user;
        if (userId != null) {
            user = userDao.findById(userId);
            if (user == null) {
                throw new IllegalStateException("User is not found by id: " + userId);
            }
        } else {
            user = null;
        }

        ApplicationEntity entity = getApplicationEntity(applicationId, user);
        service.setUser(applicationId, user, currentUserName);
        entity.setUser(user);
        priorityService.remove(entity);
        log.info("Assigned application to user: id={} to userId={}", applicationId, userId);
        if (entity.getRtdmPriority() != null && entity.getRtdmPriority().isNeedNotification()) {
            try {
                notificationService.onHighRtdmPriorityApplication(entity);
            } catch (MessagingException e) {
                log.warn("", e);
            }
        }
    }

    public boolean isPreviousOperatorCapable(Long applicationId) {
        ApplicationEntity entity = service.findById(applicationId);
        User user = entity.getUser();
        if (user == null) {
            log.debug("Previous operator is null, no one can be assigned to: id={}", applicationId);
            return false;
        }
        UserStatusAndRole userStatus = userStatusService.getCurrentStatusAndRole(user.getId());
        if (Role.SUPERVISOR == userStatus.getRole() || userStatus.getStatus().getCode() != StatusType.WORK) {
            return false;
        }
        if (entity.getCreditAmount() == null) {
            log.warn("Application creditLoad is null, not assignable to operator ({}): id={}", user, applicationId);
        }
        boolean userHasSkillGroup = user.getSkillGroupIds().contains(entity.getSkillGroup().getId());
        return user.getLimit().compareTo(entity.getRequestedCreditAmount()) >= 0 && userHasSkillGroup;
    }

    public void setDone(@NonNull Long id, @NonNull Boolean value) {
        if (value) {
            service.setDone(id, LocalDateTime.now());
        } else {
            service.setDone(id, null);
        }
    }

    public boolean hasAuthority(Long applicationId, Integer userId) {
        User user = getUserById(userId);
        ApplicationEntity entity = service.findById(applicationId);
        return skillGroupService.hasUserSkillGroup(user.getId(), entity.getSkillGroup().getId())
                && (user.getLimit().compareTo(entity.getProductCreditAmountSum()) >= 0);
    }

    public boolean hasAuthorityApprove(Long applicationId, Integer userId) {
        User user = getUserById(userId);
        ApplicationEntity entity = service.findById(applicationId);
        if (!skillGroupService.hasUserSkillGroup(user.getId(), entity.getSkillGroup().getId())) {
            applicationProcessService.setReAssignCause(applicationId, "Доступ к Skill группе отсутствует. Заявка пойдет на супервайзера.");
            return false;
        }
        if (!(user.getLimit().compareTo(entity.getProductCreditAmountSum()) >= 0)) {
            applicationProcessService.setReAssignCause(applicationId, "Лимит превышен. Заявка пойдет на супервайзера.");
            return false;
        }
        applicationProcessService.removeReAssignCause(applicationId);
        return true;
    }

    public Integer getSupervisorId(Integer userId) {
        BasicReference supervisor = getUserById(userId).getSupervisor();
        if (supervisor == null) {
            throw new IllegalStateException("Supervisor is not found for user id: " + userId);
        }
        return supervisor.getId();
    }

    public Integer getSupervisorIdForUser(Integer userId) throws BusinessException {
        BasicReference supervisor = getUserById(userId).getSupervisor();
        if (supervisor == null) {
            log.warn("Supervisor is not found for user id: {}", userId);
            throw new BusinessException("supervisor_not_found", "Для текущего пользователя супервайзер не найден.");
        }
        return supervisor.getId();
    }

    public void assignSupervisor(Long applicationId, Integer supervisorId) {
        doAssignSupervisor(applicationId, supervisorId, DEFAULT_USER_NAME);
    }

    public void assignSupervisor(Long applicationId, Integer supervisorId, String currentUserName) {
        doAssignSupervisor(applicationId, supervisorId, currentUserName);
    }

    private void doAssignSupervisor(Long applicationId, Integer supervisorId, String currentUserName) {
        User supervisor = getUserById(supervisorId);
        getApplicationEntity(applicationId, supervisor);
        service.setUser(applicationId, supervisor, currentUserName);
    }

    public void setFraudSkillGroup(Long applicationId) {
        SkillGroup skillGroupFraud = skillGroupService.getFirstGroupByCheckType(CheckType.FRAUD);
        service.setupSkillGroup(applicationId, skillGroupFraud);
    }

    public void setRecount(Integer applicationId, boolean recount) {
        // оставлено для совместимости со старыми версиями BPMN-процесса
    }

    public Long findApplicationForUser(Integer userId) {
        ApplicationView applicationView = getApplicationForUser(userId);
        return applicationView != null ? applicationView.getId() : null;
    }

    public void sendOperatorReadyMessage(Long applicationId, Integer userId) {
        // ищем бизнес-процесс, соответствующий данной заявке, отправляем месседж о готовности оператора
        applicationProcessService.sendOperatorReadyMessage(applicationId, userId);
    }

    @Deprecated
    public void startFindApplicationForOperator(Integer userId, boolean withTimeOut) {
        UserStatusAndRole status = userStatusService.getCurrentStatusAndRole(userId);
        if (status.getRole() == Role.UNDERWRITER) {
            if (withTimeOut) {
                applicationProcessService.findApplicationForOperatorByTimeOut(userId, TimeOutType.DECISION);
            } else {
                applicationProcessService.findApplicationForOperatorByTimeOut(userId, TimeOutType.DEFAULT);
            }
        }
    }

    public void findApplicationForOperatorByTimeOut(Integer userId, TimeOutType timeOutType) {
        UserStatusAndRole status = userStatusService.getCurrentStatusAndRole(userId);
        if (status.getRole() == Role.UNDERWRITER) {
            applicationProcessService.findApplicationForOperatorByTimeOut(userId, timeOutType);
        }
    }

    public void initAssignApplicationByTimeOut() {
        if (config.isFindApplicationTimerEnable()) {
            Integer appStatusTimeout = config.getAppStatusTimeout();
            Integer userStatusTimeout = config.getUserStatusTimeout();
            List<User> users = userDao.findFreeUsers(LocalDateTime.now(), appStatusTimeout, userStatusTimeout);
            for (User user : users) {
                log.info("Find application for operator: userId={}", user.getId());
                ApplicationView applicationView = getApplicationForUser(user.getId());
                if (applicationView != null) {
                    try {
                        applicationProcessService.sendOperatorReadyMessage(applicationView.getId(), user.getId());
                    } catch (FlowableOptimisticLockingException e) {
                        log.info("Send operator ready message error: {}", e.getMessage());
                    }
                    log.info("Send operator ready message for operator: userId={}", user.getId());
                } else {
                    log.info("No appropriate application for operator: userId={}", user.getId());
                }
            }
        }
    }

    public String getFindApplicationTimerTimeOut() {
        return config.getFindApplicationTimerTimeout();
    }

    @Deprecated
    public String getFindApplicationTimeOut() {
        return config.getFindApplicationTimeout();
    }

    public String getFindApplicationTimeOut(TimeOutType timeOutType) {
        switch (timeOutType) {
            case REASSIGN:
            case POSTPONE:
            case DECISION:
            case RECOUNT:
                return config.getFindApplicationTimeout();
            case DEFAULT:
            default:
                return "PT0S";
        }
    }

    public boolean isAfterRecount(@NonNull Long applicationId) {
        ApplicationEntity entity = dao.findById(applicationId);
        return entity != null && entity.getDecision() == ApplicationDecision.RECOUNT;
    }

    public void notifyUser(@NonNull @Nonnull Long applicationId,
                           @NonNull @Nonnull String eventName,
                           @NonNull @Nonnull String message) {
        UserMessage.UserEvent event = UserMessage.UserEvent.valueOf(eventName);
        ApplicationEntity entity = dao.findById(applicationId);
        if (entity == null) {
            throw new IllegalStateException("Application is not found: id=" + applicationId);
        }
        try {
            notificationService.doNotification(entity, event, message);
        } catch (MessagingException e) {
            log.warn("", e);
        }
    }

    public boolean isFindUserByClientIdEnable() {
        return config.isFindOperatorByClientIdEnable();
    }

    public boolean isSkillGroupMatchForFindUser(Long applicationId) {
        String skillGroupsAsString = config.getSkillGroupExcludeForFindPreviousUser();
        if (StringUtils.isBlank(skillGroupsAsString)) {
            return true;
        } else {
            List<String> skillGroupAsStringArray = Arrays.asList(skillGroupsAsString.split(";"));
            List<Integer> skillGroupForExclude = skillGroupAsStringArray.stream()
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());
            ApplicationEntity applicationEntity = dao.findById(applicationId);
            SkillGroup skillGroup = applicationEntity.getSkillGroup();
            return !skillGroupForExclude.contains(skillGroup.getId());
        }
    }

    @Nullable
    private ApplicationView getApplicationForUser(Integer userId) {
        List<ApplicationView> applicationViews = applicationPriorityService.loadNextForOperators(userId);
        for (ApplicationView applicationView : applicationViews) {
            if (applicationProcessService.isProcessInQueue(applicationView.getId())) {
                return applicationView;
            }
            log.info("Application is not in queue: applicationId={}", applicationView.getId());
        }
        return null;
    }

    @Nonnull
    private User getUserById(Integer userId) {
        if (userId == null) {
            throw new IllegalStateException("User id is null");
        }
        User user = userDao.findById(userId);
        if (user == null) {
            throw new IllegalStateException("User is not found by id: " + userId);
        }
        return user;
    }

    @Nonnull
    private ApplicationEntity getApplicationEntity(Long applicationId, User user) {
        return service.findById(applicationId);
    }
}
