package ru.rsb.eurion.domain;

public enum ApplicationStatus {
    NEW,
    ASSIGNED,
    IN_WORK,
    QUEUED,
    FOR_APPROVAL,
    DELAYED,
    RECALC,
    // this status is under question
    DONE
}
