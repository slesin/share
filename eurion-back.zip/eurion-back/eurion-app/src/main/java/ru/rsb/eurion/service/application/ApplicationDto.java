package ru.rsb.eurion.service.application;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.Application;
import ru.rsb.eurion.domain.DecisionRequest;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Getter
@Setter
public class ApplicationDto {

    @NotNull
    @Valid
    private Application application;

    @NotNull
    @Valid
    private DecisionRequest decisionRequest;
}
