package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.service.phone.autodialer.MassCallInfo;
import ru.rsb.eurion.service.phone.autodialer.MassCallPhone;
import ru.rsb.eurion.service.phone.autodialer.MassCallStatus;
import ru.rsb.eurion.service.phone.autodialer.MassCallType;
import ru.rsb.eurion.service.phone.autodialer.PhoneNumberInfo;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface MassCallDao {

    String BASE_SQL = "select \n" +
            "       ID,\n" +
            "       APPLICATION_ID,\n" +
            "       USER_ID,\n" +
            "       UUID,\n" +
            "       STATUS,\n" +
            "       TYPE,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT\n" +
            "from MASS_CALL_INFO";

    String BASE_PHONE_SQL = "select ID,\n" +
            "       MASS_CALL_INFO_ID,\n" +
            "       PHONE_NUMBER,\n" +
            "       TYPE,\n" +
            "       ACTION_ID,\n" +
            "       SOURCE,\n" +
            "       REMARK,\n" +
            "       CALL_RESULT_TYPE,\n" +
            "       STATUS,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT\n" +
            "from MASS_CALL_PHONE";

    @Select(BASE_SQL + " where UUID = #{uuid, jdbcType = VARCHAR}")
    @Results(id = "massCallMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "applicationId", column = "APPLICATION_ID"),
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "uuid", column = "UUID"),
            @Result(property = "status", column = "STATUS"),
            @Result(property = "type", column = "TYPE"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT")
    })
    MassCallInfo findByUUID(@Param("uuid") String uuid);

    @Select(BASE_SQL +
            " where USER_ID = #{userId, jdbcType = INTEGER} and TYPE = #{type, jdbcType = VARCHAR} order by CREATED_AT desc fetch first row only")
    @ResultMap("massCallMapping")
    MassCallInfo findLastByUserID(@Param("userId") Integer userId,
                                  @Param("type") MassCallType type);

    @Select(BASE_SQL + " where USER_ID = #{userId, jdbcType = INTEGER} and TYPE = #{type, jdbcType = VARCHAR} and STATUS <> 'COMPLETED' \n")
    @ResultMap("massCallMapping")
    MassCallInfo findNotCompletedByUserId(@Param("userId") Integer userId,
                                          @Param("type") MassCallType type);

    @Insert("INSERT INTO MASS_CALL_INFO (APPLICATION_ID, USER_ID, UUID, STATUS, TYPE, CLIENT_ID, CREATED_AT)\n" +
            "VALUES (#{info.applicationId, jdbcType=BIGINT},\n" +
            "        #{info.userId, jdbcType=VARCHAR},\n" +
            "        #{info.uuid, jdbcType=VARCHAR},\n" +
            "        #{info.status, jdbcType=VARCHAR},\n" +
            "        #{info.type, jdbcType=VARCHAR},\n" +
            "        #{info.clientId, jdbcType=INTEGER},\n" +
            "        #{info.createdAt, jdbcType = TIMESTAMP})")
    @SelectKey(
            keyProperty = "info.id",
            before = false,
            resultType = Long.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_mass_call_info.currval AS id from dual"}
    )
    void create(@Param("info") MassCallInfo info);

    @Update("update MASS_CALL_INFO\n" +
            "set STATUS     = #{status, jdbcType=VARCHAR},\n" +
            "    UPDATED_AT = #{updatedAt, jdbcType=TIMESTAMP}\n" +
            "where ID = #{id, jdbcType=VARCHAR}")
    void updateStatus(@Param("status") MassCallStatus status,
                      @Param("updatedAt") LocalDateTime updatedAt,
                      @Param("id") Long id);

    @Insert("INSERT INTO MASS_CALL_PHONE (MASS_CALL_INFO_ID, PHONE_NUMBER, TYPE, SOURCE, REMARK, CREATED_AT)\n" +
            "VALUES (#{massCallInfoId, jdbcType=BIGINT},\n" +
            "        #{info.number, jdbcType=VARCHAR},\n" +
            "        #{info.type, jdbcType=VARCHAR},\n" +
            "        #{info.source, jdbcType=VARCHAR},\n" +
            "        #{info.remark, jdbcType=VARCHAR},\n" +
            "        #{createdAt, jdbcType = TIMESTAMP}" +
            ")")
    @SelectKey(
            keyProperty = "id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_mass_call_phone.currval AS id from dual"}
    )
    void createPhoneInfo(@Param("massCallInfoId") Long massCallInfoId,
                         @Param("info") PhoneNumberInfo info,
                         @Param("createdAt") LocalDateTime createdAt);

    @Select(BASE_PHONE_SQL + " where MASS_CALL_INFO_ID = #{massCallInfoId, jdbcType = INTEGER}")
    @Results(id = "massCallPhoneMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "massCallInfoId", column = "MASS_CALL_INFO_ID"),
            @Result(property = "phoneNumber", column = "PHONE_NUMBER"),
            @Result(property = "type", column = "TYPE"),
            @Result(property = "actionId", column = "ACTION_ID"),
            @Result(property = "source", column = "SOURCE"),
            @Result(property = "remark", column = "REMARK"),
            @Result(property = "callResultType", column = "CALL_RESULT_TYPE"),
            @Result(property = "status", column = "STATUS"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT")
    })
    List<MassCallPhone> findPhoneByInfoId(@Param("massCallInfoId") Long massCallInfoId);

    @Update("update MASS_CALL_PHONE\n" +
            "set STATUS           = #{massCallPhone.status, jdbcType = VARCHAR},\n" +
            "    UPDATED_AT       = #{massCallPhone.updatedAt, jdbcType=TIMESTAMP},\n" +
            "    ACTION_ID        = #{massCallPhone.actionId, jdbcType = VARCHAR},\n" +
            "    CALL_RESULT_TYPE = #{massCallPhone.callResultType, jdbcType = INTEGER}\n" +
            "where ID = #{massCallPhone.id, jdbcType = INTEGER}")
    void updatePhoneStatus(@Param("massCallPhone") MassCallPhone massCallPhone);

}
