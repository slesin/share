package ru.rsb.eurion.service.admin.control.question;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.FetchType;
import ru.rsb.eurion.domain.ControlQuestion;
import ru.rsb.eurion.domain.ControlQuestionAnswer;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Mapper
public interface QuestionDao {

    String BASE_SELECT_SQL = "select cq.ID, cq.NAME, cq.CREATED_AT, cq.UPDATED_AT, cq.DISABLED_AT" +
            " from CONTROL_QUESTION cq ";

    @Select("select ID, CONTROL_QUESTION_ID, NAME, IS_TRUE, CREATED_AT, UPDATED_AT, DISABLED_AT " +
            "from CONTROL_QUESTION_ANSWER where CONTROL_QUESTION_ID = #{id}")
    @Results(value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "correct", column = "IS_TRUE"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    @SuppressWarnings("unused")
    List<ControlQuestionAnswer> findAnswerByQuestionId(Integer id);

    @Select("select ID, NAME, CREATED_AT, UPDATED_AT, DISABLED_AT " +
            "from CONTROL_QUESTION_ANSWER where CONTROL_QUESTION_ID = #{id}")
    @Results(value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    @SuppressWarnings("unused")
    ControlQuestionAnswer findAnswerWithOutTrueAnswerByQuestionId();

    @Select(BASE_SELECT_SQL + " where cq.id = #{id}")
    @Results(id = "questionListAdminMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "answers", many = @Many(select = "findAnswerByQuestionId", fetchType = FetchType.EAGER),
                    column = "id")
    })
    ControlQuestion findQuestionById(Integer id);

    @Select(BASE_SELECT_SQL)
    @ResultMap("questionListAdminMapping")
    List<ControlQuestion> getAllQuestions();

    @Insert("insert into CONTROL_QUESTION (NAME, DISABLED_AT) " +
            "values (#{controlQuestion.name}, #{controlQuestion.disabledAt,jdbcType=TIMESTAMP})")
    @SelectKey(
            keyProperty = "controlQuestion.id",
            before = false,
            resultType = Integer.class,
            statement = {"select seq_control_question.currval AS id from dual"}
    )
    void createQuestion(@Param("controlQuestion") ControlQuestion controlQuestion);

    @Update("update CONTROL_QUESTION set DISABLED_AT = #{disabledAt,jdbcType=DATE}, " +
            "UPDATED_AT = current_timestamp where ID in (#{ids})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void disableQuestions(@Param("ids") Set<Integer> ids,
                          @Param("disabledAt") LocalDateTime disabledAt);

    @Update("update CONTROL_QUESTION " +
            "set NAME = #{controlQuestion.name}, DISABLED_AT = #{controlQuestion.disabledAt,jdbcType=TIMESTAMP}, " +
            "UPDATED_AT = current_timestamp " +
            "where ID = #{controlQuestion.id}")
    void updateQuestion(@Param("controlQuestion") ControlQuestion controlQuestion);

    @SuppressWarnings("SqlResolve")
    @Select(BASE_SELECT_SQL +
            "where cq.DISABLED_AT is null " +
            "order by DBMS_RANDOM.VALUE " +
            "fetch first #{limit} rows only")
    @Results(id = "questionListMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "answers", many = @Many(select = "findAnswerWithOutTrueAnswerByQuestionId",
                    fetchType = FetchType.EAGER), column = "id")
    })
    List<ControlQuestion> getRandomQuestionList(@Param("limit") Integer limit);

    @Insert("insert into question_answer_history (USER_ID, USER_SESSION_ID, QUESTION_ID) " +
            "values (#{userId}, #{sessionId}, #{questionId})")
    void saveHistoryQuestionForUser(@Param("userId") Integer userId, @Param("sessionId") String sessionId,
                                    @Param("questionId") Integer questionId);

    @Select("select count(*) " +
            "from QUESTION_ANSWER_HISTORY " +
            "where USER_ID = #{userId} and USER_SESSION_ID = #{sessionId, jdbcType=VARCHAR}")
    int getQuestionCountInSession(@Param("userId") Integer userId, @Param("sessionId") String sessionId);

    @Select("select " +
            "  cq.ID, " +
            "  cq.NAME, " +
            "  cq.CREATED_AT, " +
            "  cq.UPDATED_AT, " +
            "  cq.DISABLED_AT " +
            "from QUESTION_ANSWER_HISTORY h " +
            "  left join CONTROL_QUESTION cq on h.QUESTION_ID = cq.ID " +
            "where USER_ID = #{userId} and USER_SESSION_ID = #{sessionId}")
    @ResultMap("questionListAdminMapping")
    List<ControlQuestion> getQuestionBySession(@Param("userId") Integer userId, @Param("sessionId") String sessionId);

    @Update("update QUESTION_ANSWER_HISTORY " +
            "set ANSWER_ID = #{answerId}, " +
            "  ANSWERED_AT = sysdate " +
            "where QUESTION_ID = #{questionId} and USER_ID = #{userId} and USER_SESSION_ID = #{sessionId} and ANSWER_ID is null")
    void saveAnswer(@Param("questionId") Integer questionId, @Param("answerId") Integer answerId,
                    @Param("userId") Integer userId, @Param("sessionId") String sessionId);

    @Select("select count(*) " +
            "from QUESTION_ANSWER_HISTORY qh " +
            "  left join CONTROL_QUESTION_ANSWER qa on qh.ANSWER_ID = qa.ID " +
            "where ANSWER_ID is not null and USER_SESSION_ID = #{sessionId} and USER_ID = #{userId} and IS_TRUE = 1")
    int getTrueAnswerCount(@Param("userId") Integer userId, @Param("sessionId") String sessionId);

    @Select("select count(*) " +
            "from QUESTION_ANSWER_HISTORY qh " +
            "  left join CONTROL_QUESTION_ANSWER qa on qh.ANSWER_ID = qa.ID " +
            "where USER_SESSION_ID = #{sessionId} and USER_ID = #{userId} and ANSWER_ID is null")
    int getUnansweredCount(@Param("userId") Integer userId, @Param("sessionId") String sessionId);

    @Select(BASE_SELECT_SQL + " where ID in (#{ids})")
    @Lang(MybatisExtendedLanguageDriver.class)
    @ResultMap("questionListAdminMapping")
    List<ControlQuestion> getQuestions(@Param("ids") Set<Integer> ids);

    @Insert("insert into CONTROL_QUESTION_ANSWER (CONTROL_QUESTION_ID, NAME, IS_TRUE) values " +
            "  (#{controlQuestion.id}, #{controlQuestionAnswer.name}, #{controlQuestionAnswer.correct})")
    @SelectKey(
            keyProperty = "controlQuestionAnswer.id",
            before = false,
            resultType = Integer.class,
            statement = {"select seq_control_question_answer.currval AS id from dual"}
    )
    void createAnswerByQuestion(@Param("controlQuestion") ControlQuestion question,
                                @Param("controlQuestionAnswer") ControlQuestionAnswer controlQuestionAnswer);

    @Update("update CONTROL_QUESTION_ANSWER " +
            "set NAME = #{controlQuestionAnswer.name}, IS_TRUE = #{controlQuestionAnswer.correct}," +
            "UPDATED_AT = current_timestamp " +
            "where ID = #{controlQuestionAnswer.id}")
    void updateAnswer(@Param("controlQuestionAnswer") ControlQuestionAnswer controlQuestionAnswer);

    @Delete("delete from CONTROL_QUESTION_ANSWER where ID = #{controlQuestionAnswer.id}")
    void deleteAnswer(@Param("controlQuestionAnswer") ControlQuestionAnswer controlQuestionAnswer);

    // todo updated - автоматом проставлять на стороне БД
}
