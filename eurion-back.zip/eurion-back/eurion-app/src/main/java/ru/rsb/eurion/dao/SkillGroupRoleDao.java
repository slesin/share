package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.SkillGroupRole;

import java.util.List;

@Mapper
public interface SkillGroupRoleDao {

    String BASE_SELECT_SQL = "select ID, NAME, CREATED_AT, UPDATED_AT, DISABLED_AT from SKILL_GROUP_ROLE";

    @Select(BASE_SELECT_SQL + " ORDER BY ID")
    @Results(id = "skillGroupRoleMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<SkillGroupRole> findAll();

    @Select(BASE_SELECT_SQL + " WHERE ID = #{id}")
    @ResultMap("skillGroupRoleMapping")
    SkillGroupRole findById(Integer id);
}
