package ru.rsb.eurion.service.application.flow.api;

import lombok.Getter;

@Getter
public enum ProcessDefinitionKey {
    APPLICATION("applicationProcess"),
    APPLICATION_AUTHOR("applicationAuthorProcess"),
    OPERATOR("operatorProcess"),
    APPLICATION_VERIFIER("applicationAuthorProcess");

    private final String value;

    ProcessDefinitionKey(final String value) {
        this.value = value;
    }
}
