package ru.rsb.eurion.security;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.service.admin.users.status.OperatorProcessService;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@Slf4j
@AllArgsConstructor
@Component
public class WebSessionListener implements HttpSessionListener {

    private final OperatorProcessService operatorProcessService;

    @Override
    public void sessionCreated(HttpSessionEvent httpSessionEvent) {
        // nothing to do
        log.debug("Session is started: {}", httpSessionEvent.getSession().getId());
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
        log.debug("Session is destroyed: {}", httpSessionEvent.getSession().getId());

        SecurityContext securityContext = (SecurityContext) httpSessionEvent.getSession()
                .getAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY);
        if (securityContext == null) {
            return;
        }
        AppAuthenticationToken authentication = (AppAuthenticationToken) securityContext.getAuthentication();
        if (authentication == null) {
            return;
        }
        UserData user = authentication.getUser();
        if (user != null && user.getId() != null) {
            operatorProcessService.stop(user.getId());
        }
    }
}
