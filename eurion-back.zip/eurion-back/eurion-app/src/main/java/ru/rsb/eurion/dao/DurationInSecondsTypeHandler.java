package ru.rsb.eurion.dao;

import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;

public class DurationInSecondsTypeHandler implements TypeHandler {
    @Override
    public void setParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType) {
        throw new IllegalStateException("Not implemented yet");
    }

    @Override
    public Duration getResult(ResultSet rs, String columnName) throws SQLException {
        Long str = rs.getLong(columnName);
        return convert(str);
    }

    @Override
    public Duration getResult(ResultSet rs, int columnIndex) throws SQLException {
        Long str = rs.getLong(columnIndex);
        return convert(str);
    }

    @Override
    public Duration getResult(CallableStatement cs, int columnIndex) throws SQLException {
        Long str = cs.getLong(columnIndex);
        return convert(str);
    }

    private Duration convert(Long value) {
        return value != null ? Duration.ofSeconds(value) : null;
    }
}
