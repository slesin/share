package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Тип кредита
 */
@Getter
@Setter
public class LoanType extends BasicReference {
}
