package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Setter
@Getter
public class CallHistory {
    /**
     * Идентификатор
     */
    private Integer id;
    /**
     * Идентификатор клиента
     */
    private Integer clientId;
    /**
     * Идентификатор детальной информации по телефону
     */
    private Integer phoneDetailId;
    /**
     * Время когда состоялся звонок
     */
    private LocalDateTime callDate;
    /**
     * Звонок состоялся
     */
    private Boolean callDone;
    /**
     * Наличие домохозяства
     */
    private boolean hasHouseholdIncome;
    /**
     * Доход от домохозяйства
     */
    private BigDecimal householdIncome;
    /**
     * Дата создания
     */
    private LocalDateTime createdAt;
    /**
     * Идентификатор звонка
     */
    private String actionId;
    /**
     * Номер телефона
     */
    private String phoneNumber;
    /**
     * Запрет контактов
     */
    private boolean contactForbidden;
    /**
     * Идентификатор типа контакта
     */
    private Integer contactTypeId;
    /**
     * Идентификатор результата
     */
    private Integer callResultId;
    /**
     * Идентификатор типа номера телефона
     */
    private Integer phoneTypeId;
    /**
     * Код номера телефона
     */
    private PhoneTypeCode phoneTypeCode;
    /**
     * Идентификатор анкеты в КС
     */
    private Integer blankId;
    /**
     * Комментарий
     */
    private String remark;
    /**
     * Источник иных телефонов
     */
    private String otherPhoneSource;

    private Integer userId;
}