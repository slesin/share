package ru.rsb.eurion.service.application.statistics;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Setter
@Getter
public class SkillInfoView {

    private List<SkillGroupCreditTypeView> skillGroupCreditTypeViews;
    private Map<ApplicationViewStatus, Integer> amounts;

    public List<SkillGroupCreditTypeView> getSkillGroupCreditTypeViews() {
        if (skillGroupCreditTypeViews == null) {
            skillGroupCreditTypeViews = new ArrayList<>();
        }
        return skillGroupCreditTypeViews;
    }

}
