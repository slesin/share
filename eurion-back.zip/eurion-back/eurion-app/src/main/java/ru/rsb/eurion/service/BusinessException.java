package ru.rsb.eurion.service;

import lombok.Getter;

@Getter
public class BusinessException extends Exception {
    private final String code;

    public BusinessException(String code, String message) {
        super(message);
        this.code = code;
    }
}
