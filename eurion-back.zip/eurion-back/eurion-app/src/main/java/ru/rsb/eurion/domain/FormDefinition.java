package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Описание форм
 */
@Setter
@Getter
public class FormDefinition extends BasicReference {
    private Form form;
    private List<CheckItemDefinition> checkItemDefinitions;
    private boolean hasRemark;

    public List<CheckItemDefinition> getCheckItemDefinitions() {
        if (checkItemDefinitions == null) {
            checkItemDefinitions = new ArrayList<>();
        }
        return checkItemDefinitions;
    }

    @Override
    public int hashCode() {
        return this.getId();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FormDefinition formDefinition = (FormDefinition) o;

        return getId().equals(formDefinition.getId());
    }
}
