package ru.rsb.eurion.service.admin.users.upd;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import ru.rsb.eurion.security.AuthUtil;

import java.util.Map;

public abstract class BaseEisClient {
    @Value("${eis.login}")
    private String login;
    @Value("${eis.password}")
    private String password;
    @Autowired
    private RestTemplate restTemplate;

    protected <T> T executeGet(Class<T> clazz, String url) {
        String uri = UriComponentsBuilder.fromHttpUrl(url)
                .toUriString();
        return doExecute(clazz, uri);
    }

    protected <T> T executeGet(Class<T> clazz, String url, Map<String, String> parameters) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        parameters.forEach(builder::queryParam);
        String uri = builder
                .toUriString();
        return doExecute(clazz, uri);
    }

    protected <T> T executePost(Class<T> clazz, String url, Object postData, MediaType contentType, Map<String, String> parameters) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        parameters.forEach(builder::queryParam);
        String uri = builder.toUriString();
        HttpHeaders headers = getAuthHeaders();
        headers.setContentType(contentType);
        HttpEntity<Object> requestHttpEntity = new HttpEntity<>(postData, headers);
        ResponseEntity<T> response = restTemplate.exchange(uri, HttpMethod.POST, requestHttpEntity, clazz);
        return response.getBody();
    }

    private <T> T doExecute(Class<T> clazz, String uri) {
        HttpHeaders headers = getAuthHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity requestHttpEntity = new HttpEntity(headers);
        ResponseEntity<T> response = restTemplate.exchange(uri, HttpMethod.GET, requestHttpEntity, clazz);
        return response.getBody();
    }

    private HttpHeaders getAuthHeaders() {
        return AuthUtil.getBasicAuthHeaders(login, password);
    }

}
