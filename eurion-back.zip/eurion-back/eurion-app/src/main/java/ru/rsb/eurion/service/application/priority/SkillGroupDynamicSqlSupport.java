package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;

public class SkillGroupDynamicSqlSupport {
    public static final SkillGroupTable SKILL_GROUP_TABLE = new SkillGroupDynamicSqlSupport.SkillGroupTable();

    public static final SqlColumn<Integer> ID = SKILL_GROUP_TABLE.column("ID", JDBCType.INTEGER);
    public static final SqlColumn<String> SKILL_GROUP_NAME = SKILL_GROUP_TABLE.column("NAME", JDBCType.VARCHAR);
    public static final SqlColumn<String> WORK_GROUP = SKILL_GROUP_TABLE.column("WORK_GROUP", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> ROLE_ID = SKILL_GROUP_TABLE.column("ROLE_ID", JDBCType.INTEGER);
    public static final SqlColumn<Integer> SORT_PRIORITY = SKILL_GROUP_TABLE.column("SORT_PRIORITY", JDBCType.INTEGER);

    private static final class SkillGroupTable extends SqlTable {
        SkillGroupTable() {
            super("SKILL_GROUP");
        }
    }
}
