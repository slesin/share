package ru.rsb.eurion.service.admin.users;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SkillGroupAssociation {
    private Integer userId;
    private Integer skillGroupId;
}
