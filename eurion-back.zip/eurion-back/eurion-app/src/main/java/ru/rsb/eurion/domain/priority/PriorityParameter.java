package ru.rsb.eurion.domain.priority;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.admin.priority.PriorityParameterCode;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.time.LocalDateTime;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
public class PriorityParameter {

    /**
     * Код параметра
     */
    private PriorityParameterCode id;

    /**
     * Дата создания
     */
    private LocalDateTime createdAt;

    /**
     * Дата редактирования
     */
    private LocalDateTime updatedAt;

    /**
     * Наименование параметра
     */
    private String name;

    /**
     * Подробное описание параметра
     */
    private String description;

    /**
     * Флаг "Включено"
     */
    private boolean enabled;

    /**
     * Направление сортировки (по возрастанию/убыванию)
     */
    private SortDirection direction;

    /**
     * Порядковый номер параметра
     */
    private short order;

    /**
     * Флаг обратить порядок сортировки (transient)
     */
    private boolean reverse;
}
