package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Справочник форм
 */
@Setter
@Getter
public class Form extends BasicReference {

    private String code;

    private Integer orderIndex;

}
