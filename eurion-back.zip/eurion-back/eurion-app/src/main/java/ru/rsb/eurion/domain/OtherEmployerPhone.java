package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

/**
 * Другой телефон работодателя
 */
@Getter
@Setter
public class OtherEmployerPhone {
    /**
     * Номер телефона
     */
    private String phoneNumber;
    /**
     * Источник
     */
    private String source;
    /**
     * Дата (todo что это за дата? дата внесения телефона в БД)
     */
    private LocalDate created;
}
