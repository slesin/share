package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.util.PageableUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

@RequestMapping(path = ApplicationResource.APPLICATION_PATH, produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class SearchApplicationResource {
    private static final int DEFAULT_PAGE_SIZE = 10;

    private final ApplicationListProvider listProvider;

    @GetMapping
    public List<ApplicationView> list(@RequestParam(value = "archive", defaultValue = "false") boolean archive) {
        ApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        if (!archive) {
            filterSpec.getStatus().add("Назначено");
            filterSpec.getStatus().add("В работе");
            filterSpec.getStatus().add("В очереди");
        }
        return listProvider.list(filterSpec);
    }

    @GetMapping(path = "/my-in-work")
    public List<ApplicationView> listMyInWork() {
        ApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.getStatus().add("В работе");
        filterSpec.getStatus().add("Пересчет");
        return getApplicationViews(filterSpec);
    }

    @GetMapping(path = "/my-in-not-work")
    public List<ApplicationView> listMyInNotWork() {
        ApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.getStatus().add("Назначено");
        return getApplicationViews(filterSpec);
    }

    @GetMapping(path = "/completed")
    public PagedResult<ApplicationView> listAllCompleted(
            @Nonnull ApplicationListProvider.AppPageable pageable,
            @Nonnull ApplicationListProvider.FilterSpec filterSpec) {
        PageableUtils.setupDefaultValues(pageable, DEFAULT_PAGE_SIZE);
        SearchView.COMPLETED.getFilterCustomizer().accept(filterSpec);
        return listProvider.listPage(pageable, filterSpec);
    }

    @GetMapping("/list/by-client/{clientId}")
    public PagedResult<ApplicationView> list(@Nonnull @PathVariable("clientId") Integer clientId,
                                             @Nonnull ApplicationListProvider.AppPageable pageable) {
        ApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.setClientId(clientId);
        filterSpec.setProcessNames(Collections.singletonList(ProcessDefinitionKey.APPLICATION));
        return listProvider.listPage(pageable, filterSpec);
    }

    @PostMapping(path = "/search")
    public PagedResult<ApplicationView> search(@Nonnull BaseApplicationListProvider.AppPageable pageable,
                                               @NotNull @Nonnull
                                               @RequestBody ApplicationListProvider.FilterSpec filterSpec) {
        PageableUtils.setupDefaultValues(pageable, DEFAULT_PAGE_SIZE);
        PagedResult<ApplicationView> pagedResult = listProvider.listPage(pageable, filterSpec);
        Set<Role> roles = AuthUtil.loggedUser().getRoles();
        if (roles.contains(Role.AUTHORIZED) && roles.size() == 1) {
            pagedResult.getItems().forEach(item -> {
                item.setBirthDate(null);
                item.setCheckType(null);
                item.setPassportSeries(null);
                item.setPassportNumber(null);
                item.setAssignBySupervisor(null);
                item.setMobilePhone(null);
                item.setUser(null);
            });
        }
        return pagedResult;
    }

    private List<ApplicationView> getApplicationViews(ApplicationListProvider.FilterSpec filterSpec) {
        UserData userData = AuthUtil.currentAuth();
        if (userData == null) {
            return Collections.emptyList();
        }
        Integer currentUserId = userData.getId();
        filterSpec.setUserId(currentUserId);
        return listProvider.list(filterSpec);
    }

    @AllArgsConstructor
    public enum SearchView {
        COMPLETED("completed", SearchView::completed);

        @Nonnull
        private final String viewCode;
        @Nonnull
        @Getter
        private final Consumer<ApplicationListProvider.FilterSpec> filterCustomizer;

        @Nullable
        @JsonCreator
        public static SearchView of(@Nonnull String viewCode) {
            return Stream.of(SearchView.values())
                    .filter(value -> Objects.equals(viewCode, value.viewCode))
                    .findAny()
                    .orElse(null);
        }

        private static void completed(ApplicationListProvider.FilterSpec filterSpec) {
            filterSpec.getStatusCodes().clear();
            filterSpec.setAllCompleted(true);
        }
    }
}
