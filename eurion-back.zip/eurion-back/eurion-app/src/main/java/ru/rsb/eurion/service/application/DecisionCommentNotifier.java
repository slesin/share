package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.rsb.eis.api.clientdata.ClientDataFault;
import ru.rsb.eis.api.clientdata.ClientDataWS;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.settings.AppConfig;

import java.util.function.Supplier;

/**
 * <p>Компонент интеграции с Клиентской Системой.</p>
 * <p>
 * Реализует сохранение комментариев к решениям Андеррайтинга в КС.
 */
@Component
@AllArgsConstructor
@Slf4j
public class DecisionCommentNotifier {
    private final Supplier<ClientDataWS> clientDataWSWSSupplier;
    private final AppConfig appConfig;

    public void saveComment(ApplicationEntity entity, String decisionComment) {
        ClientDataWS port = clientDataWSWSSupplier.get();
        try {
            port.addCommentAboutClient(appConfig.getCommentType(),
                    entity.getClientId(), decisionComment, entity.getBlankId());
        } catch (ClientDataFault fault) {
            log.error("", fault);
        }
    }
}
