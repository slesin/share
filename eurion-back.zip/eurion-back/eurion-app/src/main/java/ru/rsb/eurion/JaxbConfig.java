package ru.rsb.eurion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.rsb.eurion.service.passport.CheckPassportDto;
import ru.rsb.eurion.service.underwriting.request.SendRtdmRequest;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

@Configuration
public class JaxbConfig {

    @Bean
    JAXBContext getJAXBContext() throws JAXBException {
        return JAXBContext.newInstance(SendRtdmRequest.class, CheckPassportDto.class);
    }

}
