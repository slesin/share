package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.Application;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.admin.Consts;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.util.PageableUtils;

import javax.annotation.Nonnull;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static ru.rsb.eurion.service.application.StatusCode.ASSIGNED;
import static ru.rsb.eurion.service.application.StatusCode.COMPLETED;
import static ru.rsb.eurion.service.application.StatusCode.IN_WORK;
import static ru.rsb.eurion.service.application.StatusCode.NEW;
import static ru.rsb.eurion.service.application.StatusCode.POSTPONED;
import static ru.rsb.eurion.service.application.StatusCode.QUEUE;
import static ru.rsb.eurion.service.application.StatusCode.RECOUNT;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION_AUTHOR;

@RequestMapping(path = Consts.AUTHOR_USER_API_BASE + "/application", produces = APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class AuthorApplicationResource {

    private static final int DEFAULT_PAGE_SIZE = 10;

    private final ApplicationListProvider listProvider;
    private final ApplicationService applicationService;

    @GetMapping(path = "/{id}")
    public Application getShortApplication(@PathVariable("id") Long id) {
        Set<ProcessDefinitionKey> processNames = new HashSet<>(Arrays.asList(APPLICATION_AUTHOR, APPLICATION));
        return applicationService.getApplicationByProcessName(id, processNames);
    }

    @GetMapping("/list/{code}")
    public PagedResult<ApplicationView> list(@Nonnull @PathVariable(value = "code") ViewCode code,
                                             @Nonnull ApplicationListProvider.AppPageable pageable,
                                             @Nonnull ApplicationListProvider.FilterSpec filterSpec) {
        PageableUtils.setupDefaultValues(pageable, DEFAULT_PAGE_SIZE);
        filterSpec.getStatusCodes().clear();
        filterSpec.getProcessStatusCodes().addAll(Arrays.asList(code.getCodes()));
        filterSpec.setProcessNames(Collections.singletonList(APPLICATION_AUTHOR));
        return listProvider.listPage(pageable, filterSpec);
    }

    @GetMapping("/list-all-process/")
    public PagedResult<ApplicationView> listAll(@Nonnull ApplicationListProvider.AppPageable pageable,
                                                @Nonnull ApplicationListProvider.FilterSpec filterSpec) {
        PageableUtils.setupDefaultValues(pageable, DEFAULT_PAGE_SIZE);
        filterSpec.getStatusCodes().clear();
        filterSpec.setAllActive(true);
        PagedResult<ApplicationView> pagedResult = listProvider.listPage(pageable, filterSpec);
        pagedResult.getItems().forEach(item -> {
            item.setUser(null);
            item.setPassportSeries(null);
            item.setPassportNumber(null);
            item.setBirthDate(null);
            item.setProcessUserName(null);
        });
        return pagedResult;
    }

    @PutMapping(path = "/{id}/approve")
    public ApplicationView approve(@PathVariable("id") Long id,
                                   @NotNull @Valid @RequestBody ApplicationDto applicationDto) throws BusinessException, JsonProcessingException {
        applicationService.authorApprove(id, applicationDto, APPLICATION_AUTHOR);
        return getSingleApplicationView(id);
    }

    @PutMapping(path = "/{id}/reject")
    public ApplicationView reject(@PathVariable("id") Long id,
                                  @NotNull @Valid @RequestBody ApplicationDto applicationDto) throws BusinessException, JsonProcessingException {
        applicationService.authorReject(id, applicationDto, APPLICATION_AUTHOR);
        return getSingleApplicationView(id);
    }

    @GetMapping(path = "/{id}/take-in-work")
    public Application takeInWork(@PathVariable("id") Long id) {
        applicationService.takeInWork(id, APPLICATION_AUTHOR);
        return applicationService.getApplicationByProcessName(id, Collections.singleton(APPLICATION_AUTHOR));
    }

    @PutMapping(path = "/{id}/return-into-queue")
    public ApplicationView returnIntoQueue(@PathVariable("id") Long id) {
        applicationService.authorReturnIntoQueue(id);
        return getSingleApplicationView(id);
    }

    @Getter
    public enum ViewCode {
        ALL_ACTIVE(QUEUE, IN_WORK),
        ALL_PROCESS_ACTIVE(NEW, QUEUE, ASSIGNED, IN_WORK, POSTPONED, RECOUNT),
        MY_IN_WORK(IN_WORK),
        ALL_COMPLETED(COMPLETED);

        private final StatusCode[] codes;

        ViewCode(StatusCode... codes) {
            this.codes = codes;
        }

        public StatusCode[] getCodes() {
            return codes.clone();
        }
    }

    private ApplicationView getSingleApplicationView(Long id) {
        BaseApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.setApplicationId(id);
        return listProvider.getById(BaseApplicationListProvider.AppPageable.SINGLE_VALUE, filterSpec);
    }
}
