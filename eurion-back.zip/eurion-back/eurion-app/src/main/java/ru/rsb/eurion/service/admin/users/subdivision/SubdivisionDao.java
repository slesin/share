package ru.rsb.eurion.service.admin.users.subdivision;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import java.util.List;
import java.util.Set;

@Mapper
public interface SubdivisionDao {

    String BASE_SQL = "SELECT ID,\n" +
            "       PARENT_ID,\n" +
            "       NAME,\n" +
            "       ORDER_IDX\n" +
            "from subdivision";

    @Select(BASE_SQL)
    @Results(id = "subdivisionMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "parentId", column = "PARENT_ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "orderIdx", column = "ORDER_IDX")
    })
    Set<Subdivision> list();

    @Insert("insert into subdivision (PARENT_ID, NAME, ORDER_IDX)\n" +
            "values (#{parentId, jdbcType=INTEGER},\n" +
            "        #{name, jdbcType=VARCHAR},\n" +
            "        #{orderIdx, jdbcType=INTEGER})")
    @SelectKey(
            keyProperty = "id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_subdivision.currval AS id from dual"}
    )
    void create(@Param("parentId") Integer parenId,
                @Param("name") String name,
                @Param("orderIdx") Integer orderIdx);

    @Delete("delete from SUBDIVISION where id = #{id, jdbcType = INTEGER}")
    void delete(@Param("id") Integer id);

    @Update("update SUBDIVISION\n" +
            "set PARENT_ID = #{parentId, jdbcType=INTEGER},\n" +
            "    NAME      = #{name, jdbcType=VARCHAR},\n" +
            "    ORDER_IDX = #{orderIdx, jdbcType=INTEGER}\n" +
            "where ID = #{id, jdbcType=INTEGER}")
    void update(@Param("id") Integer id,
                @Param("parentId") Integer parenId,
                @Param("name") String name,
                @Param("orderIdx") Integer orderIdx);

    @Select(BASE_SQL + " where PARENT_ID = #{parentId, jdbcType=INTEGER} order by ID")
    @ResultMap("subdivisionMapping")
    List<Subdivision> getChildren(@Param("parentId") Integer parentId);

    @Select("select ORDER_IDX\n" +
            "from subdivision\n" +
            "where PARENT_ID = #{parentId, jdbcType=INTEGER}\n" +
            "order by ORDER_IDX desc\n" +
            "fetch first row only")
    Integer getLastOrderIdx(@Param("parentId") Integer parentId);

    @Select("select ID,\n" +
            "       PARENT_ID,\n" +
            "       NAME,\n" +
            "       ORDER_IDX\n" +
            "from SUBDIVISION\n" +
            "start with id = #{parentId, jdbcType = INTEGER}\n" +
            "connect by prior id = parent_id")
    @ResultMap("subdivisionMapping")
    Set<Subdivision> getChild(@Param("parentId") Integer parenId);
}
