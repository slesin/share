package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Актив клиента
 */
@Getter
@Setter
public class Asset {
    /**
     * Наименование актива
     */
    private String name;
    /**
     * Марка/Тип
     */
    private String type;
    /**
     * Доля в процентах
     */
    private BigDecimal percentage;
    /**
     * Стоимость покупки, рублей
     */
    private BigDecimal cost;
    /**
     * Дата покупки
     */
    private LocalDate purchaseDate;
    /**
     * Комментарий
     */
    private String remark;
}
