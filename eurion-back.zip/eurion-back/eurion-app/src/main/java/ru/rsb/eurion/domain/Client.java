package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Клиент
 */
@Getter
@Setter
public class Client {
    /**
     * Идентификатор клиента
     */
    private Long clientId;
    /**
     * Паспорт
     */
    private Passport passport;
    /**
     * Страховое свидетельство ОПС (СНИЛС)
     */
    private String insuranceNumber;
    /**
     * Дополнительные документы
     */
    private List<AdditionalDocument> additionalDocuments;
    /**
     * Личная идентификатция пройдена (true - да, false - нет)
     */
    private boolean identified;
    /**
     * Флаг регистрации на портале ГосУслуг (true - есть регистрация, false - нет)
     */
    private boolean registeredOnGosUslugi;
    /**
     * todo что это за флаг?
     */
    private boolean afsSignal;
    /**
     * Семейное положение
     */
    private MarriageStatus marriageStatus;
    /**
     * ФИО супруга(и)
     */
    private String spouseFullName;
    /**
     * Количество детей
     */
    private int childCount;
    /**
     * Образование
     */
    private String education;
}
