package ru.rsb.eurion.service.admin.users.status;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import ru.rsb.eurion.domain.UserStatusHistory;

@Mapper(componentModel = "spring")
public interface UserStatusHistoryMapper {

    @Mappings({
            @Mapping(source = "status", target = "status"),
            @Mapping(source = "role", target = "role")
    })
    UserStatusAndRole mapToDto(UserStatusHistory history);
}
