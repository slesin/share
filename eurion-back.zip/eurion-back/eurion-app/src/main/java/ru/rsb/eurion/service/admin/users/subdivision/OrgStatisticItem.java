package ru.rsb.eurion.service.admin.users.subdivision;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrgStatisticItem {

    private Integer orgItemId;

    private int fullAmount;

    private int inWork;

    private int inPostpone;

    private int approvePercent;

    private int approveAmount;

    private int rejectAmount;
}
