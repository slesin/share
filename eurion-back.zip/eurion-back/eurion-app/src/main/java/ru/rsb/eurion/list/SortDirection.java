package ru.rsb.eurion.list;

public enum SortDirection {
    ASC, DESC
}
