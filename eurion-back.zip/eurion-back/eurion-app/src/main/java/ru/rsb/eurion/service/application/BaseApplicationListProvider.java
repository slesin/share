package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.type.TypeReference;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.mybatis.dynamic.sql.AbstractSingleValueCondition;
import org.mybatis.dynamic.sql.BasicColumn;
import org.mybatis.dynamic.sql.BindableColumn;
import org.mybatis.dynamic.sql.SortSpecification;
import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlCriterion;
import org.mybatis.dynamic.sql.VisitableCondition;
import org.mybatis.dynamic.sql.render.RenderingStrategy;
import org.mybatis.dynamic.sql.select.QueryExpressionDSL;
import org.mybatis.dynamic.sql.select.SelectDSL;
import org.mybatis.dynamic.sql.select.SelectModel;
import org.mybatis.dynamic.sql.select.aggregate.CountAll;
import org.mybatis.dynamic.sql.select.function.Lower;
import org.mybatis.dynamic.sql.select.join.EqualTo;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.where.condition.IsBetween;
import org.mybatis.dynamic.sql.where.condition.IsEqualTo;
import org.mybatis.dynamic.sql.where.condition.IsEqualToColumn;
import org.mybatis.dynamic.sql.where.condition.IsGreaterThanOrEqualTo;
import org.mybatis.dynamic.sql.where.condition.IsIn;
import org.mybatis.dynamic.sql.where.condition.IsLessThanOrEqualTo;
import org.mybatis.dynamic.sql.where.condition.IsLike;
import org.mybatis.dynamic.sql.where.condition.IsNotEqualTo;
import org.mybatis.dynamic.sql.where.condition.IsNotNull;
import org.mybatis.dynamic.sql.where.condition.IsNull;
import org.springframework.format.annotation.DateTimeFormat;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.FormConclusion;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.list.Pageable;
import ru.rsb.eurion.list.PageableSelectStatementProvider;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.list.SortDirection;
import ru.rsb.eurion.mybatis.AllActiveApplicationCondition;
import ru.rsb.eurion.mybatis.AllCompletedApplicationCondition;
import ru.rsb.eurion.mybatis.LiteralApplicationProcessName;
import ru.rsb.eurion.mybatis.LiteralApplicationStatus;
import ru.rsb.eurion.mybatis.LiteralApplicationStatusUpdatedAt;
import ru.rsb.eurion.mybatis.LiteralApplicationUserName;
import ru.rsb.eurion.mybatis.LiteralDecisionComment;
import ru.rsb.eurion.mybatis.LiteralDialTime;
import ru.rsb.eurion.mybatis.LiteralOne;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.ApplicationProcessDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.ApplicationProcessStatusDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.CreditAttractChannelDynamicSupport;
import ru.rsb.eurion.service.application.priority.CreditSaleChannelDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.DialTimeDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.LastUserDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.ProcessUserDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.RegionDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.RtdmPriorityDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.SkillGroupDynamicSqlSupport;
import ru.rsb.eurion.service.application.priority.UserDynamicSqlSupport;
import ru.rsb.eurion.service.report.CreditTypeReportGroup;
import ru.rsb.eurion.service.util.JsonService;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static org.mybatis.dynamic.sql.select.SelectDSL.select;
import static ru.rsb.eurion.domain.CheckItemKind.REQUEST_DOCUMENT;
import static ru.rsb.eurion.domain.CheckItemType.REQUEST;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.APPLICATION;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.APPLICATION_REGION_CODE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.ASSIGN_BY_SUPERVISOR;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.AUTHOR_FULL_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.AUTHOR_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.BIRTH_DATE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.BLANK_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.BRANCH_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.BRANCH_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CHECK_TYPE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CLIENT_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CLIENT_REGION;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CREATED_AT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CREDIT_AMOUNT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CREDIT_SALE_CHANNEL_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.DONE_AT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CREDIT_TYPE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.FIRST_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.FORM_CONCLUSIONS;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.FORM_DEFINITIONS;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.LAST_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.MIDDLE_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.MOBILE_PHONE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.PASSPORT_NUMBER;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.PASSPORT_SERIES;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.POSTPONE_COMMENT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.PRODUCT_TYPE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.REQUESTED_BRANCH_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.REQUESTED_CREDIT_AMOUNT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.RTDM_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.SHORT_CLIENT_REGION_CODE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.SKILL_GROUP_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.STATUS;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.STATUS_CODE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.STATUS_UPDATED_AT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.SUSPEND_TIME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.UPDATED_AT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.USER_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationProcessDynamicSqlSupport.APPLICATION_PROCESS_TABLE;
import static ru.rsb.eurion.service.application.priority.ApplicationProcessDynamicSqlSupport.PROCESS_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationProcessStatusDynamicSqlSupport.APPLICATION_PROCESS_STATUS_TABLE;
import static ru.rsb.eurion.service.application.priority.ApplicationProcessStatusDynamicSqlSupport.PROCESS_CATEGORY_CODE;
import static ru.rsb.eurion.service.application.priority.ApplicationProcessStatusDynamicSqlSupport.PROCESS_DECISION;
import static ru.rsb.eurion.service.application.priority.ApplicationProcessStatusDynamicSqlSupport.PROCESS_DONE_AT;
import static ru.rsb.eurion.service.application.priority.ApplicationProcessStatusDynamicSqlSupport.PROCESS_USER_NAME;
import static ru.rsb.eurion.service.application.priority.CreditAttractChannelDynamicSupport.CREDIT_ATTRACT_CHANNEL_NAME;
import static ru.rsb.eurion.service.application.priority.CreditAttractChannelDynamicSupport.CREDIT_ATTRACT_CHANNEL_TABLE;
import static ru.rsb.eurion.service.application.priority.CreditSaleChannelDynamicSqlSupport.CREDIT_SALE_CHANNEL_NAME;
import static ru.rsb.eurion.service.application.priority.CreditSaleChannelDynamicSqlSupport.CREDIT_SALE_CHANNEL_TABLE;
import static ru.rsb.eurion.service.application.priority.LastUserDynamicSqlSupport.LAST_USER_TABLE;
import static ru.rsb.eurion.service.application.priority.LastUserDynamicSqlSupport.USER_FULL_NAME;
import static ru.rsb.eurion.service.application.priority.RegionDynamicSqlSupport.RAW_OFFSET;
import static ru.rsb.eurion.service.application.priority.RegionDynamicSqlSupport.REGION_TABLE;
import static ru.rsb.eurion.service.application.priority.SkillGroupDynamicSqlSupport.ROLE_ID;
import static ru.rsb.eurion.service.application.priority.SkillGroupDynamicSqlSupport.SKILL_GROUP_NAME;
import static ru.rsb.eurion.service.application.priority.SkillGroupDynamicSqlSupport.SKILL_GROUP_TABLE;
import static ru.rsb.eurion.service.application.priority.SkillGroupDynamicSqlSupport.WORK_GROUP;

@AllArgsConstructor
public abstract class BaseApplicationListProvider {
    private static final int MAX_LIST_SIZE = 1000;
    private static final TypeReference<List<FormDefinition>> TYPE_REF_FORM_DEFINITIONS =
            new TypeReference<List<FormDefinition>>() {
            };
    private static final TypeReference<List<FormConclusion>> TYPE_REF_FORM_CONCLUSIONS =
            new TypeReference<List<FormConclusion>>() {
            };
    protected final ApplicationDao dao;
    private final JsonService jsonService;

    @Nonnull
    public List<ApplicationView> list(@Nonnull FilterSpec filterSpec) {
        PagedResult<ApplicationView> page = listPage(AppPageable.DEFAULT, filterSpec);
        return page.getItems();
    }

    @Nonnull
    public PagedResult<ApplicationView> listPage(@Nonnull AppPageable pageable, @Nonnull FilterSpec filterSpec) {
        handleVirtualFilters(filterSpec);
        List<ApplicationView> list = execMainQuery(filterSpec, pageable);
        int total = execCountQuery(filterSpec);
        return new PagedResult<>(pageable.getOffset(), total, list);
    }

    @Nonnull
    public ApplicationView getById(@Nonnull AppPageable pageable, @Nonnull FilterSpec filterSpec) {
        List<ApplicationView> list = execMainQuery(filterSpec, pageable);
        return list.get(0);
    }

    private void handleVirtualFilters(FilterSpec filterSpec) {
        FullName clientFullName = splitFullName(filterSpec.getFullName());
        filterSpec.setLastName(clientFullName.getLastName());
        filterSpec.setFirstName(clientFullName.getFirstName());
        filterSpec.setMiddleName(clientFullName.getMiddleName());
    }

    protected QueryExpressionDSL<SelectModel>.JoinSpecificationFinisher buildFrom(
            @Nonnull QueryExpressionDSL<SelectModel> queryExpressionDSL) {
        return queryExpressionDSL
                .leftJoin(SKILL_GROUP_TABLE, "SG")
                .on(ApplicationDynamicSqlSupport.SKILL_GROUP_ID, new EqualTo(SkillGroupDynamicSqlSupport.ID))
                .leftJoin(UserDynamicSqlSupport.USER_TABLE, "U")
                .on(ApplicationDynamicSqlSupport.USER_ID, new EqualTo(UserDynamicSqlSupport.ID))
                .leftJoin(LAST_USER_TABLE, "LU")
                .on(ApplicationDynamicSqlSupport.LAST_USER_ID, new EqualTo(LastUserDynamicSqlSupport.ID))
                .leftJoin(CREDIT_SALE_CHANNEL_TABLE, "CSC")
                .on(ApplicationDynamicSqlSupport.CREDIT_SALE_CHANNEL_ID,
                        new EqualTo(CreditSaleChannelDynamicSqlSupport.ID))
                .leftJoin(CREDIT_ATTRACT_CHANNEL_TABLE, "CAC")
                .on(ApplicationDynamicSqlSupport.CREDIT_ATTRACTION_CHANNEL_ID,
                        new EqualTo(CreditAttractChannelDynamicSupport.ID))
                .leftJoin(REGION_TABLE, "R")
                .on(ApplicationDynamicSqlSupport.SHORT_CLIENT_REGION_CODE, new EqualTo(RegionDynamicSqlSupport.REGION_CODE))
                .leftJoin(APPLICATION_PROCESS_TABLE, "AP")
                .on(ApplicationDynamicSqlSupport.ID, new EqualTo(ApplicationProcessDynamicSqlSupport.ID))
                .leftJoin(APPLICATION_PROCESS_STATUS_TABLE, "APS")
                .on(ApplicationProcessStatusDynamicSqlSupport.APPLICATION_ID, new EqualTo(ApplicationProcessDynamicSqlSupport.APPLICATION_ID))
                .and(ApplicationProcessStatusDynamicSqlSupport.PROCESS_NAME, new EqualTo(ApplicationProcessDynamicSqlSupport.PROCESS_NAME))
                .leftJoin(ProcessUserDynamicSqlSupport.PROCESS_USER_TABLE, "PU")
                .on(ApplicationProcessStatusDynamicSqlSupport.USER_ID, new EqualTo(ProcessUserDynamicSqlSupport.ID))
                .leftJoin(RtdmPriorityDynamicSqlSupport.RTDM_PRIORITY_TABLE, "RP")
                .on(RtdmPriorityDynamicSqlSupport.ID, new EqualTo(ApplicationDynamicSqlSupport.RTDM_PRIORITY));
    }

    @Nonnull
    protected SelectDSL<SelectModel> setupOrder(
            @Nonnull Pageable<SortOrder> pageable,
            @Nonnull QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder dsl) {
        List<SortSpecification> specificationList = new ArrayList<>();
        AtomicInteger counter = new AtomicInteger();
        pageable.getSortBy().forEach(sortOrder -> {
            int index = counter.getAndIncrement();
            SortDirection sortDirection = pageable.getSortDir().size() > index ?
                    pageable.getSortDir().get(index) : SortDirection.ASC;

            sortOrder.getSpecifications().forEach(so -> {
                SortSpecification specification = sortDirection == SortDirection.ASC ? so : so.descending();
                specificationList.add(specification);
            });
        });

        SortSpecification[] specifications = specificationList.toArray(new SortSpecification[0]);
        return dsl.orderBy(specifications);
    }

    @Nonnull
    private QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder buildPredicates(
            @Nonnull FilterSpec filterSpec, @Nonnull QueryExpressionDSL<SelectModel>.JoinSpecificationFinisher join) {
        QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder dsl =
                join.where(LiteralOne.getInstance(), IsEqualToColumn.of(LiteralOne.getInstance()));

        if (filterSpec.getUserId() != null) {
            dsl.and(USER_ID, IsEqualTo.of(filterSpec::getUserId));
        }
        if (!filterSpec.getStatus().isEmpty()) {
            dsl.and(STATUS, IsIn.of(filterSpec.getStatus()));
        }

        if (filterSpec.getCurrentUser() != null && filterSpec.getCurrentUser()) {
            UserData loggedUser = AuthUtil.loggedUser();
            dsl.and(USER_ID, IsEqualTo.of(loggedUser::getId));
        }

        if (filterSpec.getCurrentLotusUser() != null && filterSpec.getCurrentLotusUser()) {
            UserData loggedUser = AuthUtil.loggedUser();
            int personalNumber = Integer.parseInt(loggedUser.getPersonnelNumber());
            dsl.and(AUTHOR_ID, IsEqualTo.of(() -> personalNumber));
        }

        if (filterSpec.getApplicationId() != null) {
            dsl.and(ID, IsEqualTo.of(filterSpec::getApplicationId));
        }

        if (filterSpec.getCreatedAtStart() != null) {
            dsl.and(CREATED_AT, IsGreaterThanOrEqualTo.of(filterSpec::getCreatedAtStart));
        }
        if (filterSpec.getCreatedAtEnd() != null) {
            dsl.and(CREATED_AT, IsLessThanOrEqualTo.of(filterSpec::getCreatedAtEnd));
        }

        if (filterSpec.getDoneAtBegin() != null) {
            dsl.and(DONE_AT, IsGreaterThanOrEqualTo.of(filterSpec::getDoneAtBegin));
        }
        if (filterSpec.getDoneAtEnd() != null) {
            dsl.and(DONE_AT, IsLessThanOrEqualTo.of(filterSpec::getDoneAtEnd));
        }

        if (filterSpec.getPassportSeries() != null) {
            dsl.and(PASSPORT_SERIES, likeStartWithPredicate(filterSpec.getPassportSeries()));
        }
        if (filterSpec.getPassportNumber() != null) {
            dsl.and(PASSPORT_NUMBER, likeStartWithPredicate(filterSpec.getPassportNumber()));
        }

        if (filterSpec.getMobilePhone() != null && filterSpec.getMobilePhone().length() >= 5) {
            dsl.and(MOBILE_PHONE, likeStartWithPredicate(filterSpec.getMobilePhone()));
        }

        if (!StringUtils.isBlank(filterSpec.getLastName())) {
            addILikePredicate(dsl::and, LAST_NAME, filterSpec.getLastName());
            if (!StringUtils.isBlank(filterSpec.getFirstName())) {
                addILikePredicate(dsl::and, FIRST_NAME, filterSpec.getFirstName());
                if (!StringUtils.isBlank(filterSpec.getMiddleName())) {
                    addILikePredicate(dsl::and, MIDDLE_NAME, filterSpec.getMiddleName());
                }
            }
        }

        if (filterSpec.getBirthDate() != null) {
            dsl.and(BIRTH_DATE, IsEqualTo.of(filterSpec::getBirthDate));
        }

        if (filterSpec.getClientId() != null) {
            dsl.and(CLIENT_ID, IsEqualTo.of(filterSpec::getClientId));
        }

        if (!filterSpec.getSkillGroupIds().isEmpty()) {
            dsl.and(SKILL_GROUP_ID, IsIn.of(filterSpec.getSkillGroupIds()));
        }

        if (filterSpec.getBlankId() != null) {
            dsl.and(BLANK_ID, IsEqualTo.of(filterSpec::getBlankId));
        }

        if (filterSpec.getMyEmployers() != null) {
            addMyEmployerPredicate(dsl::and, filterSpec.getMyEmployers());
        }

        if (filterSpec.getUnassigned() != null) {
            VisitableCondition<Integer> condition = new IsNotNull<>();
            if (filterSpec.getUnassigned()) {
                condition = new IsNull<>();
            }
            dsl.and(USER_ID, condition);
        }

        if (filterSpec.requestedCreditAmountLimit != null) {
            dsl.and(REQUESTED_CREDIT_AMOUNT, IsLessThanOrEqualTo.of(filterSpec::getRequestedCreditAmountLimit));
        }

        if (filterSpec.requestedCreditAmount != null) {
            dsl.and(REQUESTED_CREDIT_AMOUNT, IsEqualTo.of(filterSpec::getRequestedCreditAmount));
        }

        if (!filterSpec.getProcessNames().isEmpty()) {
            dsl.and(PROCESS_NAME, IsIn.of(filterSpec.getProcessNames()));
        }

        if (!filterSpec.getStatusCodes().isEmpty()) {
            dsl.and(STATUS_CODE, IsIn.of(filterSpec.getStatusCodes()));
        }
        if (!filterSpec.getProcessStatusCodes().isEmpty()) {
            dsl.and(PROCESS_CATEGORY_CODE, IsIn.of(filterSpec.getProcessStatusCodes()));
        }

        if (filterSpec.clientRegionRawOffSet != null) {
            dsl.and(RAW_OFFSET, IsEqualTo.of(filterSpec::getClientRegionRawOffSet));
        }

        if (filterSpec.creditAttractChannelName != null && filterSpec.getCreditAttractChannelName().length() >= 4) {
            addILikePredicate(dsl::and, CREDIT_ATTRACT_CHANNEL_NAME, filterSpec.getCreditAttractChannelName());
        }

        if (filterSpec.getAssignBySupervisor() != null && filterSpec.getAssignBySupervisor().length() >= 2) {
            addFullNamePredicate(dsl::and, ASSIGN_BY_SUPERVISOR, filterSpec.getAssignBySupervisor());
        }

        if (filterSpec.getSkillGroupName() != null && filterSpec.getSkillGroupName().length() >= 3) {
            addILikePredicate(dsl::and, SKILL_GROUP_NAME, filterSpec.getSkillGroupName());
        }

        if (!filterSpec.getSkillGroupIds().isEmpty()) {
            dsl.and(SKILL_GROUP_ID, IsIn.of(filterSpec.getSkillGroupIds()));
        }

        if (filterSpec.getProductType() != null && filterSpec.getProductType().length() >= 3) {
            addILikePredicate(dsl::and, PRODUCT_TYPE, filterSpec.getProductType());
        }

        if (filterSpec.getProcessUserName() != null && filterSpec.getProcessUserName().length() >= 2) {
            SqlCriterion<String> criterion = SqlCriterion.withColumn(Lower.of(PROCESS_USER_NAME))
                    .withConnector("or")
                    .withCondition(likeStartWithPredicate(filterSpec.getProcessUserName().toLowerCase()))
                    .build();
            dsl.and(Lower.of(UserDynamicSqlSupport.USER_FULL_NAME), likeStartWithPredicate(filterSpec.getProcessUserName().toLowerCase()), criterion);
        }

        if (filterSpec.getStatusUpdatedAt() != null) {
            LocalDateTime startDate = filterSpec.getStatusUpdatedAt().atStartOfDay();
            LocalDateTime endDate = startDate.plusDays(1);
            SqlCriterion<LocalDateTime> criterion = SqlCriterion.withColumn(ApplicationProcessStatusDynamicSqlSupport.PROCESS_STATUS_UPDATED_AT)
                    .withConnector("or")
                    .withCondition(IsBetween.isBetween(() -> startDate).and(() -> endDate))
                    .build();
            dsl.and(STATUS_UPDATED_AT, IsBetween.isBetween(() -> startDate).and(() -> endDate), criterion);
        }

        if (!filterSpec.getProcessStatus().isEmpty()) {
            filterSpec.getProcessStatus()
                    .replaceAll(String::toLowerCase);
            SqlCriterion<String> criterion = SqlCriterion.withColumn(Lower.of(ApplicationProcessStatusDynamicSqlSupport.PROCESS_STATUS))
                    .withConnector("or")
                    .withCondition(IsIn.of(filterSpec.getProcessStatus()))
                    .build();
            dsl.and(Lower.of(STATUS), IsIn.of(filterSpec.getProcessStatus()), criterion);
        }

        if (filterSpec.allActive) {
            dsl.and(LiteralOne.getInstance(), AllActiveApplicationCondition.of(LiteralOne.getInstance()));
        }

        if (filterSpec.allCompleted) {
            dsl.and(LiteralOne.getInstance(), AllCompletedApplicationCondition.of(LiteralOne.getInstance()));
        }

        if (filterSpec.suspendTime != null) {
            LocalDate suspendTime = filterSpec.suspendTime;
            LocalDate nextDay = suspendTime.plusDays(1);
            dsl.and(SUSPEND_TIME, IsBetween.isBetween(() -> suspendTime).and(() -> nextDay));
        }

        if (!StringUtils.isBlank(filterSpec.getUserName()) && filterSpec.getUserName().length() > 3) {
            addFullNamePredicate(dsl::and, UserDynamicSqlSupport.USER_FULL_NAME, filterSpec.getUserName());
        }

        CreditTypeReportGroup reportGroup = filterSpec.getCreditTypeReportGroup();
        if (reportGroup != null) {
            if (reportGroup == CreditTypeReportGroup.DOCS) {
                dsl.and(ROLE_ID, IsEqualTo.of(() -> 1))
                        .and(CREDIT_TYPE, new IsNull<>())
                ;
            } else {
                dsl.and(CREDIT_TYPE, IsIn.of(reportGroup.getTypes()));
            }
        }

        if (filterSpec.getStatusCodeGroup() != null) {
            List<StatusCode> statusCodes = filterSpec.getStatusCodeGroup().getStatusCodes();
            dsl.and(STATUS_CODE, IsIn.of(statusCodes));
        }

        if (!filterSpec.getRtdmPriorities().isEmpty()) {
            dsl.and(RtdmPriorityDynamicSqlSupport.ID, IsIn.of(filterSpec.getRtdmPriorities()));
        }

        if (filterSpec.getCreatedAtLeft() != null) {
            dsl.and(CREATED_AT, IsGreaterThanOrEqualTo.of(filterSpec::getCreatedAtLeft));
        }
        if (filterSpec.getCreatedAtRight() != null) {
            dsl.and(CREATED_AT, IsLessThanOrEqualTo.of(filterSpec::getCreatedAtRight));
        }
        return dsl;
    }

    private void addFullNamePredicate(@Nonnull PredicateCombiner<String> combiner,
                                      SqlColumn<String> column,
                                      String filterFullName) {
        String escapedUserName = filterFullName.replace("%", "\\%");
        StringBuilder sb = new StringBuilder();
        FullName userFullName = splitFullName(escapedUserName);
        sb.append(userFullName.getLastName()).append("%");
        if (!StringUtils.isEmpty(userFullName.getFirstName())) {
            sb.append(userFullName.getFirstName()).append("%");
        }
        if (!StringUtils.isEmpty(userFullName.getMiddleName())) {
            sb.append(userFullName.getMiddleName()).append("%");
        }
        String userSearchStr = sb.toString();
        combiner.combine(Lower.of(column), IsLike.of(userSearchStr::toLowerCase));
    }

    private void addMyEmployerPredicate(PredicateCombiner<Integer> combiner, boolean value) {
        Integer supervisorId = AuthUtil.loggedUser().getId();
        AbstractSingleValueCondition<Integer> condition = value ?
                IsEqualTo.of(() -> supervisorId) : IsNotEqualTo.of(() -> supervisorId);
        combiner.combine(UserDynamicSqlSupport.SUPERVISOR_ID, condition);
    }

    private void addILikePredicate(PredicateCombiner<String> combiner, BindableColumn<String> column, String expression) {
        combiner.combine(Lower.of(column), likeStartWithPredicate(expression.toLowerCase()));
    }

    private IsLike<String> likeStartWithPredicate(@Nonnull String searchString) {
        return IsLike.of(() -> {
            String escapedSearchStr = searchString.replace("%", "\\%")
                    .replace("_", "\\_");
            return escapedSearchStr + "%";
        });
    }

    @Nonnull
    protected List<ApplicationView> execMainQuery(@Nonnull FilterSpec filterSpec, Pageable<SortOrder> pageable) {
        // select ... from ... join... where
        BasicColumn[] columns = {ID,
                CLIENT_ID,
                RTDM_ID,
                LAST_NAME,
                FIRST_NAME,
                MIDDLE_NAME,
                BLANK_ID,
                BIRTH_DATE,
                CREDIT_AMOUNT,
                REQUESTED_CREDIT_AMOUNT,
                SHORT_CLIENT_REGION_CODE,
                SKILL_GROUP_ID,
                SKILL_GROUP_NAME.as("SKILL_GROUP_NAME"),
                WORK_GROUP.as("SKILL_GROUP_WORK"),
                PASSPORT_NUMBER,
                PASSPORT_SERIES,
                PRODUCT_TYPE,
                CREDIT_SALE_CHANNEL_ID,
                APPLICATION_REGION_CODE,
                MOBILE_PHONE,
                BRANCH_ID,
                USER_FULL_NAME.as("LAST_USER_FULL_NAME"),
                USER_ID,
                UserDynamicSqlSupport.USER_FULL_NAME.as("USER_FULL_NAME"),
                STATUS,
                STATUS_CODE,
                CREATED_AT,
                UPDATED_AT,
                FORM_DEFINITIONS,
                FORM_CONCLUSIONS,
                CREDIT_SALE_CHANNEL_NAME.as("CREDIT_SALE_CHANNEL_NAME"),
                RAW_OFFSET.as("RAW_OFFSET"),
                CREDIT_ATTRACT_CHANNEL_NAME.as("CREDIT_ATTRACT_CHANNEL_NAME"),
                SUSPEND_TIME,
                PROCESS_NAME.as("PROCESS_NAME"),
                PROCESS_DECISION.as("PROCESS_DECISION"),
                PROCESS_CATEGORY_CODE.as("PROCESS_CATEGORY_CODE"),
                PROCESS_DONE_AT.as("PROCESS_DONE_AT"),
                ASSIGN_BY_SUPERVISOR,
                CHECK_TYPE,
                REQUESTED_BRANCH_NAME,
                BRANCH_NAME,
                CLIENT_REGION,
                CREDIT_TYPE,
                AUTHOR_FULL_NAME,
                POSTPONE_COMMENT,
                LiteralApplicationStatus.getInstance(),
                LiteralApplicationUserName.getInstance(),
                LiteralApplicationStatusUpdatedAt.getInstance(),
                LiteralApplicationProcessName.getInstance(),
                LiteralDecisionComment.getInstance(),
                RtdmPriorityDynamicSqlSupport.ID.as("RP_ID"),
                RtdmPriorityDynamicSqlSupport.CREATED_AT.as("RP_CREATED_AT"),
                RtdmPriorityDynamicSqlSupport.UPDATED_AT.as("RP_UPDATED_AT"),
                RtdmPriorityDynamicSqlSupport.NAME.as("RP_NAME"),
                RtdmPriorityDynamicSqlSupport.IS_NEED_NOTIFICATION.as("RP_IS_NEED_NOTIFICATION"),
                RtdmPriorityDynamicSqlSupport.IS_WARNING.as("RP_IS_WARNING"),
        };
        QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder dsl = buildQuery(filterSpec, columns);

        // order by
        SelectDSL<SelectModel> selectDSL = setupOrder(pageable, dsl);

        SelectStatementProvider selectStatementProvider = selectDSL
                .build()
                .render(RenderingStrategy.MYBATIS3);

        // offset ... fetch first ... rows
        PageableSelectStatementProvider finalStatementProvider =
                new PageableSelectStatementProvider(selectStatementProvider, pageable);

        List<ApplicationView> list = dao.select(finalStatementProvider);
        setFillPercent(list);
        return list;
    }

    protected QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder buildQuery(@Nonnull FilterSpec filterSpec,
                                                                                     BasicColumn... columns) {
        QueryExpressionDSL<SelectModel> queryExpressionDSL = select(columns).from(APPLICATION, "A");
        QueryExpressionDSL<SelectModel>.JoinSpecificationFinisher join = buildFrom(queryExpressionDSL);
        return buildPredicates(filterSpec, join);
    }

    private int execCountQuery(@Nonnull FilterSpec filterSpec) {
        BasicColumn[] columns = {new CountAll()};
        QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder countDsl = buildQuery(filterSpec, columns);
        SelectStatementProvider countStatementProvider = countDsl.build()
                .render(RenderingStrategy.MYBATIS3);
        return dao.count(countStatementProvider);
    }

    protected void setFillPercent(List<ApplicationView> applicationViewList) {
        applicationViewList.forEach(applicationView -> {
            Integer percentOfComplete = getFillPercent(applicationView);
            applicationView.setFillPercent(percentOfComplete);
        });
    }

    private int getFillPercent(ApplicationView applicationView) {
        if (applicationView.getFormDefinitions() == null || applicationView.getFormDefinitions().isEmpty()) {
            return 100;
        }
        if (applicationView.getFormConclusions() == null || applicationView.getFormConclusions().isEmpty()) {
            return 0;
        }

        List<FormDefinition> definitions = jsonService.parse(applicationView.getFormDefinitions(),
                TYPE_REF_FORM_DEFINITIONS);
        int amountCheck = (int) definitions.stream()
                .flatMap(formDefinition -> formDefinition.getCheckItemDefinitions()
                        .stream()
                        .filter(checkItemDefinition -> checkItemDefinition.getKind() != REQUEST_DOCUMENT))
                .count();

        List<FormConclusion> conclusions = jsonService.parse(applicationView.getFormConclusions(), TYPE_REF_FORM_CONCLUSIONS);
        int amountCompleteCheck = (int) conclusions.stream()
                .flatMap(formConclusion -> formConclusion.getCheckItemConclusions()
                        .stream()
                        .filter(checkItemConclusion -> checkItemConclusion.getSelectedItemId() != null
                                && checkItemConclusion.getSelectedItemType() != null
                                && checkItemConclusion.getSelectedItemType() != REQUEST))
                .count();

        if (amountCheck == 0 || amountCompleteCheck == 0) {
            return 0;
        }
        return amountCompleteCheck * 100 / amountCheck;
    }

    @Nonnull
    private FullName splitFullName(String fullName) {
        FullName.FullNameBuilder builder = FullName.builder();
        if (!StringUtils.isBlank(fullName)) {
            String[] split = fullName.split("[ ,.]+");
            if (split.length > 0) {
                builder.lastName(split[0]);
                if (split.length > 1) {
                    builder.firstName(split[1]);
                }
                if (split.length > 2) {
                    builder.middleName(split[2]);
                }
            }
        }
        return builder.build();
    }

    @Getter
    public enum SortOrder {
        clientId(Collections.singletonList(CLIENT_ID.as("A.CLIENT_ID"))),
        blankId(Collections.singletonList(BLANK_ID.as("A.BLANK_ID"))),
        fullName(Arrays.asList(
                LAST_NAME.as("A.LAST_NAME"),
                FIRST_NAME.as("A.FIRST_NAME"),
                MIDDLE_NAME.as("A.MIDDLE_NAME")
        )),
        birthDate(Collections.singletonList(BIRTH_DATE.as("A.BIRTH_DATE"))),
        createdAt(Collections.singletonList(CREATED_AT.as("A.CREATED_AT"))),
        statusUpdatedAt(Collections.singletonList(STATUS_UPDATED_AT.as("STATUS_UPDATED_AT"))),
        updatedAt(Collections.singletonList(ApplicationDynamicSqlSupport.UPDATED_AT.as("A.UPDATED_AT")));

        private final List<SortSpecification> specifications;

        SortOrder(List<SortSpecification> specifications) {
            this.specifications = specifications;
        }
    }

    private interface PredicateCombiner<T> {
        void combine(BindableColumn<T> column, VisitableCondition<T> condition);
    }

    @NoArgsConstructor
    public static class AppPageable extends Pageable<SortOrder> {
        public static final AppPageable DEFAULT =
                AppPageable.of(0, MAX_LIST_SIZE, SortOrder.updatedAt, SortDirection.DESC);
        public static final AppPageable SINGLE_VALUE =
                AppPageable.of(0, 1, SortOrder.updatedAt, SortDirection.DESC);

        public AppPageable(int offset, int size, List<SortOrder> sortBy, List<SortDirection> sortDirections) {
            super(offset, size, sortBy, sortDirections);
        }

        public static AppPageable of(int offset, int size, SortOrder sortBy, SortDirection sortDirection) {
            List<SortOrder> sortOrderList = Collections.singletonList(sortBy);
            List<SortDirection> sortDirections = Collections.singletonList(sortDirection);
            return new AppPageable(offset, size, sortOrderList, sortDirections);
        }
    }

    @Getter
    @Setter
    public static class FilterSpec {
        // внутренние фильтры
        private Boolean currentUser;
        private Boolean currentLotusUser;
        private List<StatusCode> statusCodes;
        /**
         * Только мои сотрудники (берется текущий пользователь из сессии).
         */
        private Boolean myEmployers;
        /**
         * Только нераспределенные заявки
         */
        private Boolean unassigned;

        // фильтры, совпадающие с названиями полей (по конвенции имен)
        private String fullName;
        private Integer userId;
        private List<String> status;
        private Long applicationId;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime createdAtStart;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime createdAtEnd;
        private String passportSeries;
        private String passportNumber;
        private String mobilePhone;
        private String lastName;
        private String firstName;
        private String middleName;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
        private LocalDate birthDate;
        private Integer blankId;
        private Integer clientId;
        private List<Integer> skillGroupIds;
        private BigDecimal creditAmount;
        private List<String> processStatus;
        private List<StatusCode> processStatusCodes;
        private List<ProcessDefinitionKey> processNames;
        private Integer clientRegionRawOffSet;
        private String creditAttractChannelName;
        private BigDecimal requestedCreditAmount;
        private BigDecimal requestedCreditAmountLimit;
        private String assignBySupervisor;
        private String skillGroupName;
        private String productType;
        private String processUserName;
        private boolean allActive;
        private boolean allCompleted;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
        private LocalDate statusUpdatedAt;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
        private LocalDate suspendTime;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime doneAtBegin;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime doneAtEnd;
        private Integer assignBySupervisorId;

        private String userName;
        /**
         * Фильтра по типу продукта по внутренней классификации, отличающейся от используемой в RTDM
         * (см. {@link ru.rsb.eurion.rtdm.application.CreditType})
         */
        private CreditTypeReportGroup creditTypeReportGroup;
        private StatusCodeGroup statusCodeGroup;

        private List<Integer> rtdmPriorities;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime createdAtLeft;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime createdAtRight;

        @Nonnull
        List<String> getStatus() {
            if (status == null) {
                status = new ArrayList<>();
            }
            return status;
        }

        @Nonnull
        List<StatusCode> getStatusCodes() {
            if (statusCodes == null) {
                statusCodes = new ArrayList<>();
            }
            return statusCodes;
        }

        @Nonnull
        List<String> getProcessStatus() {
            if (processStatus == null) {
                processStatus = new ArrayList<>();
            }
            return processStatus;
        }

        List<StatusCode> getProcessStatusCodes() {
            if (processStatusCodes == null) {
                processStatusCodes = new ArrayList<>();
            }
            return processStatusCodes;
        }

        public List<Integer> getSkillGroupIds() {
            if (skillGroupIds == null) {
                skillGroupIds = new ArrayList<>();
            }
            return skillGroupIds;
        }

        @Nonnull
        List<ProcessDefinitionKey> getProcessNames() {
            if (processNames == null) {
                processNames = new ArrayList<>();
            }
            return processNames;
        }

        @Nonnull
        public List<Integer> getRtdmPriorities() {
            if (rtdmPriorities == null) {
                rtdmPriorities = new ArrayList<>();
            }
            return rtdmPriorities;
        }
    }

    @Getter
    @Builder
    private static class FullName {
        private final String lastName;
        private final String firstName;
        private final String middleName;
    }
}
