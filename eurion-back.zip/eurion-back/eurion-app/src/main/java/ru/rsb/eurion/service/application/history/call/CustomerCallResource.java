package ru.rsb.eurion.service.application.history.call;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.service.application.ApplicationResource;

import javax.annotation.Nonnull;
import java.util.List;

@RequestMapping(path = ApplicationResource.APPLICATION_PATH, produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class CustomerCallResource {
    private final CustomerCallListLoader loader;

    @GetMapping(path = "/customer-call")
    public List<CustomerCallItem> listCustomerCalls(@Nonnull @RequestParam("clientId") Long clientId) {
        return loader.load(clientId);
    }
}
