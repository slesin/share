package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.service.application.history.ApplicationFieldTitle;

import java.util.List;

@Mapper
public interface ApplicationFieldTitleDao {

    @Select("select ID, NAME, PATH, UPDATED_AT, CREATED_AT, BLOCK_NAME from APPLICATION_FIELD_TITLE")
    @Results(value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "path", column = "PATH"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "blockName", column = "BLOCK_NAME"),
    })
    List<ApplicationFieldTitle> getApplicationFieldTitle();
}
