package ru.rsb.eurion.domain;

/**
 * @author sergius on 9/11/18.
 */
public enum Role {
    ADMIN,
    SUPERVISOR,
    UNDERWRITER,
    AUTHORIZED,
    VERIFIER,
    CALL_HANDLER,
}
