package ru.rsb.eurion.mybatis;

import org.mybatis.dynamic.sql.BindableColumn;
import org.mybatis.dynamic.sql.render.TableAliasCalculator;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;

import java.sql.JDBCType;
import java.util.Optional;

public class LiteralApplicationStatusUpdatedAt implements BindableColumn<String> {

    private static final String renderScript = " decode(AP.PROCESS_NAME, '%s', A.STATUS_UPDATED_AT, APS.UPDATED_AT) as STATUS_UPDATED_AT";

    private static final LiteralApplicationStatusUpdatedAt INSTANCE = new LiteralApplicationStatusUpdatedAt();

    public static LiteralApplicationStatusUpdatedAt getInstance() {
        return INSTANCE;
    }

    @Override
    public Optional<String> alias() {
        return Optional.empty();
    }

    @Override
    public BindableColumn<String> as(String s) {
        return null;
    }

    @Override
    public String renderWithTableAlias(TableAliasCalculator tableAliasCalculator) {
        return String.format(renderScript, ProcessDefinitionKey.APPLICATION);
    }

    @Override
    public Optional<JDBCType> jdbcType() {
        return Optional.empty();
    }

    @Override
    public Optional<String> typeHandler() {
        return Optional.empty();
    }
}
