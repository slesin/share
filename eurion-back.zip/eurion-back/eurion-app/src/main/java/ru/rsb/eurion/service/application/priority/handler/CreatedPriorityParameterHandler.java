package ru.rsb.eurion.service.application.priority.handler;

import org.springframework.stereotype.Component;
import ru.rsb.eurion.service.application.priority.ApplicationIdxDynamicSqlSupport;

import static ru.rsb.eurion.service.application.priority.ApplicationPriorityService.PRIORITY_HANDLER_PREFIX;

@Component(PRIORITY_HANDLER_PREFIX + "CREATED")
public class CreatedPriorityParameterHandler extends SimplePriorityParameterHandler {

    public CreatedPriorityParameterHandler() {
        super(ApplicationIdxDynamicSqlSupport.CREATE_DATE);
    }

}
