package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.TemplatePlaceholder;

import java.util.List;

@Mapper
public interface TemplatePlaceholderDao {

    String SELECT_SQL = "select ID,\n" +
            "       NAME,\n" +
            "       REMARK, \n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT,\n" +
            "       DISABLED_AT\n" +
            "from TEMPLATE_PLACEHOLDER";

    @Select(SELECT_SQL)
    @Results(id = "TemplatePlaceHolderMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "remark", column = "REMARK"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<TemplatePlaceholder> findAll();
}