package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Группа доходов
 */
@Getter
@Setter
public class IncomeGroup {
    /**
     * Наименование группы
     */
    private String name;
    /**
     * Доходы
     */
    private List<IncomeItem> items;
}
