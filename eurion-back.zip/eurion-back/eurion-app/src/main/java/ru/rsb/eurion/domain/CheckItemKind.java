package ru.rsb.eurion.domain;

public enum CheckItemKind {
    CHECK,
    REQUEST_DOCUMENT,
    RATING,
    PHONE_CALL
}
