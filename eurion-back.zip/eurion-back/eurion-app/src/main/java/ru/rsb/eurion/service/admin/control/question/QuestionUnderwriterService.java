package ru.rsb.eurion.service.admin.control.question;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ControlQuestion;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.settings.AppConfig;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class QuestionUnderwriterService {

    private final QuestionDao dao;
    private final AppConfig config;

    public List<ControlQuestion> getQuestions(Integer userId, String sessionId, HttpServletRequest request)
            throws BusinessException {
        kickIgnoramusUser(userId, sessionId, request);
        if (getQuestionAmountInSession(userId, sessionId) > 0) {
            return getQuestionBySession(userId, sessionId);
        }
        List<ControlQuestion> controlQuestionList = getRandomQuestionList();
        controlQuestionList.forEach(question -> saveHistoryQuestionForUser(userId, sessionId, question.getId()));
        return controlQuestionList;
    }

    public void saveAnswer(Integer userId, String sessionId, HttpServletRequest request,
                           Integer questionId, Integer answerId) throws BusinessException {
        dao.saveAnswer(questionId, answerId, userId, sessionId);
        kickIgnoramusUser(userId, sessionId, request);
    }

    public boolean mayEnter(Integer userId, String sessionId, HttpServletRequest request) throws BusinessException {
        kickIgnoramusUser(userId, sessionId, request);
        if (dao.getUnansweredCount(userId, sessionId) != 0) {
            return false;
        }
        int trueAnswerLimit = getTrueAnswerLimit();
        return dao.getTrueAnswerCount(userId, sessionId) >= trueAnswerLimit;
    }

    public boolean noNeedToLogin(String role) {
        if (Role.UNDERWRITER.name().equals(role)) {
            return !config.isQuestionsUnderwriterEnabled();
        }
        if (Role.SUPERVISOR.name().equals(role)) {
            return !config.isQuestionsSupervisorEnabled();
        }
        return false;
    }

    private void kickIgnoramusUser(Integer userId, String sessionId, HttpServletRequest request) throws BusinessException {
        if (checkTrueAnswerLimit(userId, sessionId)) {
            AuthUtil.logout(request.getSession());
            throw new BusinessException("question", "Привышено количество неверных ответов.");
        }
    }

    private void saveHistoryQuestionForUser(Integer userId, String sessionId, Integer questionId) {
        dao.saveHistoryQuestionForUser(userId, sessionId, questionId);
    }

    private boolean checkTrueAnswerLimit(Integer userId, String sessionId) {
        int trueAnswerLimit = getTrueAnswerLimit();
        return dao.getQuestionCountInSession(userId, sessionId) != 0
                && dao.getUnansweredCount(userId, sessionId) == 0
                && dao.getTrueAnswerCount(userId, sessionId) < trueAnswerLimit;
    }

    private List<ControlQuestion> getRandomQuestionList() {
        int questionLimit = config.getQuestionsCount();
        return dao.getRandomQuestionList(questionLimit);
    }

    private int getQuestionAmountInSession(Integer userId, String sessionId) {
        return dao.getQuestionCountInSession(userId, sessionId);
    }

    private List<ControlQuestion> getQuestionBySession(Integer userId, String sessionId) {
        return dao.getQuestionBySession(userId, sessionId);
    }

    private int getTrueAnswerLimit() {
        return config.getQuestionsAnswersCount();
    }
}
