package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Пол клиента
 */
@Setter
@Getter
public class Gender extends BasicReference {

    private Integer scoringId;

    private boolean active;

    private Integer countryId;

    private Integer codeId;
}
