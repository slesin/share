package ru.rsb.eurion.service.application.flow.api;

import lombok.extern.slf4j.Slf4j;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;
import org.flowable.engine.delegate.JavaDelegate;
import org.flowable.engine.delegate.TaskListener;
import org.flowable.task.service.delegate.DelegateTask;
import org.flowable.variable.api.delegate.VariableScope;
import org.springframework.stereotype.Component;

@Slf4j
@Component("log")
@SuppressWarnings("unused")
public class LogComponent implements JavaDelegate, ExecutionListener, TaskListener {

    @Override
    public void execute(DelegateExecution execution) {
        doLog(execution);
        logVariables(execution);
    }

    @Override
    public void notify(DelegateExecution execution) {
        doLog(execution);
        logVariables(execution);
    }

    @Override
    public void notify(DelegateTask delegateTask) {
        log.debug("Task: taskKey={}, name='{}', formKey={}, event={}", delegateTask.getTaskDefinitionKey(),
                delegateTask.getName(), delegateTask.getFormKey(), delegateTask.getEventName());
        logVariables(delegateTask);
    }

    public void debug(String message, Object... args) {
        log.debug(message, args);
    }

    public void trace(String message, Object... args) {
        log.trace(message, args);
    }

    public void info(String message, Object... args) {
        log.info(message, args);
    }

    private void doLog(DelegateExecution execution) {
        log.debug("activityId={}, event={} id={}, superId={}, businessKey={}", execution.getCurrentActivityId(),
                execution.getEventName(), execution.getId(), execution.getSuperExecutionId(),
                execution.getProcessInstanceBusinessKey());
        logVariables(execution);
    }

    private void logVariables(VariableScope execution) {
        log.trace("Variables: {}", execution.getVariables());
    }
}
