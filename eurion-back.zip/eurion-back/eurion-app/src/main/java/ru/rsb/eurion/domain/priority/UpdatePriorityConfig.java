package ru.rsb.eurion.domain.priority;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class UpdatePriorityConfig extends PriorityConfig {

    private ProductPriorityPatch productPriorityPatch;

    @Getter
    @Setter
    public static class ProductPriorityPatch {
        /**
         * Список ID продуктов, которым назначается повышенный приоритет
         */
        @Size(max = 999)
        private List<Integer> added;

        /**
         * Список ID продуктов, у которых удаляется пометка "Повышенный приоритет"
         */
        @Size(max = 999)
        private List<Integer> deleted;

        public List<Integer> getAdded() {
            if (added == null) {
                added = new ArrayList<>();
            }
            return added;
        }

        public List<Integer> getDeleted() {
            if (deleted == null) {
                deleted = new ArrayList<>();
            }
            return deleted;
        }
    }
}
