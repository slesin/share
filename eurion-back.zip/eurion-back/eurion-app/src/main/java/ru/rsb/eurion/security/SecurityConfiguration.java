package ru.rsb.eurion.security;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;

@PropertySource(value = "classpath:eurion-security.properties", ignoreResourceNotFound = true)
@AllArgsConstructor
@Component
@EnableWebSecurity
public class SecurityConfiguration {

    static final String RS_QUALIFIER = "rs";
    static final String REGION_QUALIFIER = "region";

    @Bean
    public ServletListenerRegistrationBean<WebSessionListener> httpSessionListener(WebSessionListener listener) {
        return new ServletListenerRegistrationBean<>(listener);
    }

    private ActiveDirectory createActiveDirectoryBean(@NotNull LdapHelper rsLdap, @NotNull LdapHelper regionLdap) {
        ActiveDirectory bean = new ActiveDirectory(rsLdap, regionLdap);
        if (rsLdap.getUsername() == null || regionLdap.getUsername() == null) {
            throw new IllegalStateException("Required Active Directory configuration is not defined. Username is null");
        }
        // configuration validation
        bean.authenticate();
        return bean;
    }

    @Qualifier(RS_QUALIFIER)
    @Bean
    @Primary
    @ConfigurationProperties(prefix = "app.security.rs")
    public SecurityConfig rsSecurityConfig() {
        return new SecurityConfig();
    }

    @Qualifier(REGION_QUALIFIER)
    @Bean
    @ConfigurationProperties(prefix = "app.security.region")
    public SecurityConfig regionSecurityConfig() {
        return new SecurityConfig();
    }

    @Bean
    @Qualifier(RS_QUALIFIER)
    public LdapHelper rsLdapHelper(@Qualifier(RS_QUALIFIER) SecurityConfig rsConfig) {
        return new LdapHelper(rsConfig);
    }

    @Bean
    @Qualifier(REGION_QUALIFIER)
    public LdapHelper regionLdapHelper(@Qualifier(REGION_QUALIFIER) SecurityConfig regionConfig) {
        return new LdapHelper(regionConfig);
    }

    @Bean
    public ActiveDirectory userDetailServiceRegion(@Qualifier(RS_QUALIFIER) LdapHelper rsLdap,
                                                   @Qualifier(REGION_QUALIFIER) LdapHelper regionLdap) {
        return createActiveDirectoryBean(rsLdap, regionLdap);
    }

}
