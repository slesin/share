package ru.rsb.eurion.mybatis;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import org.mybatis.dynamic.sql.BindableColumn;
import org.mybatis.dynamic.sql.render.TableAliasCalculator;

import java.sql.JDBCType;
import java.util.Optional;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class LiteralOne implements BindableColumn<String> {
    private static final LiteralOne INSTANCE = new LiteralOne();

    public static LiteralOne getInstance() {
        return INSTANCE;
    }

    @Override
    public Optional<String> alias() {
        return Optional.empty();
    }

    @Override
    public BindableColumn<String> as(String alias) {
        return this;
    }

    @Override
    public Optional<JDBCType> jdbcType() {
        return Optional.of(JDBCType.VARCHAR);
    }

    @Override
    public Optional<String> typeHandler() {
        return Optional.empty();
    }

    @Override
    public String renderWithTableAlias(TableAliasCalculator tableAliasCalculator) {
        return "1";
    }
}
