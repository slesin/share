package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Семейное положение
 */
@Getter
@Setter
public class MarriageStatus extends BasicReference {
}
