package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.application.StatusCode;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * Информация о вкладках пользователя
 */
@Setter
@Getter
public class UserTab {
    /**
     * Уникальный идентификатор
     */
    private Integer id;
    /**
     * Идентифиатор заявки
     */
    @NotNull
    private Long applicationId;
    /**
     * Идентифиатор пользователя
     */
    private Integer userId;

    private String firstName;

    private String middleName;

    private String lastName;

    private StatusCode processStatusCode;
    /**
     * Дата создания
     */
    private LocalDateTime createdAt;
    /**
     * Дата редактирования
     */
    private LocalDateTime updatedAt;
    /**
     * Дата деактивации
     */
    private LocalDateTime disabledAt;
}
