package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class CommentTemplate {

    private Integer id;

    private String template;

    private Integer subjectId;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

}
