package ru.rsb.eurion.service.application.statistics;

import lombok.Getter;
import lombok.Setter;

/**
 * Статистика по заявкам
 */
@Setter
@Getter
public class ApplicationInfoBySkill {

    private int skillGroupRoleId;
    private String skillGroupRoleName;
    private int skillGroupId;
    private String skillGroupName;
    private ApplicationViewStatus status;
    private Integer amount;
    private CreditType creditType;
}
