package ru.rsb.eurion.service.admin.skill.group;

public enum CheckType {
    VERIFICATION,
    UNDERWRITING,
    FRAUD,
    AUTHOR,
    DOCUMENT
}
