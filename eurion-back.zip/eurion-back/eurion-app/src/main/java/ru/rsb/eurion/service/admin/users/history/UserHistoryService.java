package ru.rsb.eurion.service.admin.users.history;


import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.javers.core.Javers;
import org.javers.core.JaversBuilder;
import org.javers.core.diff.Diff;
import org.javers.core.diff.ListCompareAlgorithm;
import org.javers.core.diff.changetype.PropertyChange;
import org.javers.core.diff.changetype.ValueChange;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.UserHistoryDao;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.domain.UserHistory;
import ru.rsb.eurion.list.Pageable;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.list.SortDirection;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.CollectionUtils;
import ru.rsb.eurion.service.admin.users.UserDao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional
@AllArgsConstructor
@Slf4j
public class UserHistoryService {

    public static final String SUBDIVISION_ID = "subdivisionId";
    private final UserHistoryDao userHistoryDao;
    private final UserDao userDao;

    public void add(User oldUser, User newUser) {
        newUser.getRoles();
        newUser.getSkillGroupIds();
        Javers javers = JaversBuilder.javers()
                .withListCompareAlgorithm(ListCompareAlgorithm.LEVENSHTEIN_DISTANCE)
                .build();
        Diff diff = javers.compare(oldUser, newUser);
        UserData currentUser = AuthUtil.currentAuth();
        Integer currentUserId = currentUser != null ? currentUser.getId() : newUser.getId();
        savePropertyValue(diff.getChangesByType(PropertyChange.class), oldUser, newUser, currentUserId);
    }

    public void addSkillGroup(User user, Set<Integer> newSkillIds, Integer loggedUserId) {
        Set<Integer> oldSkillIds = user.getSkillGroupIds();
        String oldValue = getStringFromSet(oldSkillIds);
        String newValue = getStringFromSet(newSkillIds);
        insert(oldValue, newValue, "skillGroupIds", user, loggedUserId);
    }

    private void savePropertyValue(List<PropertyChange> propertyChanges, User oldUser, User newUser, Integer currentUserId) {
        propertyChanges.forEach(propertyChange -> {
                    String oldValue;
                    String newValue;
                    String propertyName = propertyChange.getPropertyName();
                    String propertyNameWithPath = propertyChange.getPropertyNameWithPath();
                    switch (propertyNameWithPath) {
                        case "skillGroupIds":
                            Set<Integer> oldSkillIds = oldUser.getSkillGroupIds();
                            Set<Integer> newSkillIds = newUser.getSkillGroupIds();
                            oldValue = getStringFromSet(oldSkillIds);
                            newValue = getStringFromSet(newSkillIds);
                            insert(oldValue, newValue, propertyName, newUser, currentUserId);
                            break;
                        case "roles":
                            Set<Role> oldRoles = oldUser.getRoles();
                            Set<Role> newRoles = newUser.getRoles();
                            oldValue = getStringFromSet(oldRoles);
                            newValue = getStringFromSet(newRoles);
                            insert(oldValue, newValue, propertyName, newUser, currentUserId);
                            break;
                        case "supervisor":
                            oldValue = oldUser.getSupervisor() != null ? oldUser.getSupervisor().getName() : "";
                            newValue = newUser.getSupervisor() != null ? newUser.getSupervisor().getName() : "";
                            insert(oldValue, newValue, propertyName, newUser, currentUserId);
                            break;
                        case "supervisor.name":
                            saveValue(newUser, currentUserId, propertyChange, "supervisor");
                            break;
                        case "limit":
                        case "hasUpdateLimitPermission":
                        case "subdivisionId":
                            saveValue(newUser, currentUserId, propertyChange, propertyName);
                            break;
                        default:
                            log.warn("Unexpected user history property: ={} ", propertyName);
                    }
                }
        );
    }

    public void addOperators(Set<User> oldOperators, Set<User> newOperators, User supervisor) {
        UserData currentUser = AuthUtil.loggedUser();
        CollectionUtils.mergeSet(oldOperators, newOperators, User::getId,
                user -> {
                    String oldSupervisorName = getOldSupervisorName(user.getId());
                    insert(oldSupervisorName, supervisor.getName(), "supervisor", user, currentUser.getId());
                    insertSubdivision(supervisor, user, currentUser);
                    return user;
                },
                user -> {
                    String oldSupervisorName = getOldSupervisorName(user.getId());
                    insert(supervisor.getName(), oldSupervisorName, "supervisor", user, currentUser.getId());
                    insertSubdivision(supervisor, user, currentUser);
                },
                null
        );
    }

    public PagedResult<UseHistoryView> loadUserHistory(LocalDate beginDate, LocalDate endDate, UserHistoryPageable pageable) {
        LocalDateTime beginDateTime = LocalDateTime.of(beginDate, LocalTime.MIN);
        LocalDateTime endDateTime = LocalDateTime.of(endDate, LocalTime.MAX);
        List<UseHistoryView> userHistories = userHistoryDao.list(beginDateTime, endDateTime, pageable.getOffset(), pageable.getLimit());
        int totalCount = userHistoryDao.userHistoryTotalCount(beginDateTime, endDateTime);
        return new PagedResult<>(pageable.getOffset(), totalCount, userHistories);
    }

    public enum SortAvailable {
        updatedAt
    }

    @NoArgsConstructor
    public static class UserHistoryPageable extends Pageable<SortAvailable> {
        public UserHistoryPageable(int offset, int limit, List<SortAvailable> sortBy, List<SortDirection> sortDir) {
            super(offset, limit, sortBy, sortDir);
        }
    }

    public void saveSubdivisionId(String oldValue, String newValue, User user, Integer currentUserId) {
        insert(oldValue, newValue, SUBDIVISION_ID, user, currentUserId);
    }

    private void insertSubdivision(User supervisor, User user, UserData currentUser) {
        String oldSubdivisionId = String.valueOf(user.getSubdivisionId());
        String newSubdivisionId = String.valueOf(supervisor.getSubdivisionId());
        if (!oldSubdivisionId.equals(newSubdivisionId)) {
            insert(oldSubdivisionId, newSubdivisionId, SUBDIVISION_ID, user, currentUser.getId());
        }
    }

    private void saveValue(User newUser, Integer currentUserId, PropertyChange propertyChange, String propertyName) {
        String oldValue;
        String newValue;
        ValueChange valueChange = ((ValueChange) propertyChange);
        oldValue = valueChange.getLeft() != null ? valueChange.getLeft().toString() : null;
        newValue = valueChange.getRight() != null ? valueChange.getRight().toString() : null;
        insert(oldValue, newValue, propertyName, newUser, currentUserId);
    }

    private String getOldSupervisorName(Integer userId) {
        User oldSupervisor = userDao.findById(userId);
        if (oldSupervisor != null && oldSupervisor.getSupervisor() != null) {
            return oldSupervisor.getSupervisor().getName();
        }
        return "";
    }

    private void insert(String oldValue, String newValue, String propertyName, User user, Integer currentUserId) {
        UserHistory history = new UserHistory();
        history.setUserId(user.getId());
        history.setPropertyName(propertyName);
        history.setActionUserId(currentUserId);
        history.setOldValue(oldValue);
        history.setNewValue(newValue);
        history.setUpdatedAt(LocalDateTime.now());
        userHistoryDao.insert(history);
    }

    private String getStringFromSet(Set<?> set) {
        return set.stream().map(Object::toString)
                .collect(Collectors.joining(","));
    }
}
