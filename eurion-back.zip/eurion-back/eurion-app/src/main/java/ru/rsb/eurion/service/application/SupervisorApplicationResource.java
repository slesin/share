package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.ObjectReferenceInt;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.admin.Consts;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.application.priority.ApplicationPriorityService;
import ru.rsb.eurion.service.util.PageableUtils;

import javax.annotation.Nonnull;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.Collections;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static ru.rsb.eurion.service.application.StatusCode.ASSIGNED;
import static ru.rsb.eurion.service.application.StatusCode.COMPLETED;
import static ru.rsb.eurion.service.application.StatusCode.IN_WORK;
import static ru.rsb.eurion.service.application.StatusCode.NEW;
import static ru.rsb.eurion.service.application.StatusCode.POSTPONED;
import static ru.rsb.eurion.service.application.StatusCode.QUEUE;
import static ru.rsb.eurion.service.application.StatusCode.RECOUNT;

@RequestMapping(path = Consts.SUPERVISOR_API_BASE + "/application", produces = APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class SupervisorApplicationResource {
    private static final int DEFAULT_PAGE_SIZE = 10;
    private static final int MAX_QUEUE_PAGE_SIZE = 5000;

    private final ApplicationListProvider listProvider;
    private final ApplicationPriorityService applicationPriorityService;
    private final ApplicationService applicationService;

    @GetMapping("/list/{code}")
    public PagedResult<ApplicationView> list(
            @Nonnull @PathVariable(value = "code") ViewCode code,
            @Nonnull ApplicationListProvider.AppPageable pageable,
            @Nonnull ApplicationListProvider.FilterSpec filterSpec) {
        // непонятно, как задать значения по умолчанию для query-параметров, передаваемых в бин типа Pageable
        PageableUtils.setupDefaultValues(pageable, DEFAULT_PAGE_SIZE);
        // игнорируем код представления, пришедший через query-параметры
        filterSpec.getStatusCodes().clear();
        filterSpec.getStatusCodes().addAll(Arrays.asList(code.getCodes()));
        filterSpec.setProcessNames(Collections.singletonList(ProcessDefinitionKey.APPLICATION));
        if (code.isOwned()) {
            UserData loggedUser = AuthUtil.loggedUser();
            filterSpec.setUserId(loggedUser.getId());
        }
        PagedResult<ApplicationView> pagedResult = listProvider.listPage(pageable, filterSpec);
        applicationService.clearPersonalData(pagedResult);
        return pagedResult;
    }

    @GetMapping("/queue")
    public PagedResult<ApplicationView> listQueue() {
        BaseApplicationListProvider.AppPageable pageable = new BaseApplicationListProvider.AppPageable(0, MAX_QUEUE_PAGE_SIZE, null, null);
        ApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.setStatusCodes(Collections.singletonList(StatusCode.QUEUE));
        PagedResult<ApplicationView> pagedResult = applicationPriorityService.listQueue(pageable, filterSpec);
        applicationService.clearPersonalData(pagedResult);
        return pagedResult;
    }

    @PutMapping(path = "/{id}/assign")
    public ApplicationView assign(@PathVariable("id") Long id,
                                  @NotNull @Valid @RequestBody ObjectReferenceInt operator
    ) throws BusinessException {
        applicationService.assignToUser(id, operator.getId());
        return getSingleApplicationView(id);
    }

    @PutMapping(path = "/{id}/return-into-queue")
    public ApplicationView retunIntoQueue(@Nonnull @PathVariable("id") Long id) {
        applicationService.returnIntoQueue(id);
        return getSingleApplicationView(id);
    }

    @PutMapping(path = "/{id}/supervisor-priority")
    public void setupPriority(@Nonnull @PathVariable("id") Long id,
                              @Valid @NotNull @RequestBody PriorityRequest request) {
        applicationService.setupPriority(id, request.isEnabled());
    }

    @Getter
    public enum ViewCode {
        MY_IN_WORK(true, IN_WORK, RECOUNT),

        MY_POSTPONED(true, POSTPONED),

        MY_NOT_IN_WORK(true, ASSIGNED),

        ALL_ACTIVE(false, NEW, QUEUE, ASSIGNED, IN_WORK, POSTPONED, RECOUNT),

        ALL_COMPLETED(false, COMPLETED);

        private final StatusCode[] codes;
        private final boolean owned;

        ViewCode(boolean owned, StatusCode... codes) {
            this.codes = codes;
            this.owned = owned;
        }

        public StatusCode[] getCodes() {
            return codes.clone();
        }
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PriorityRequest {
        private boolean enabled;
    }

    private ApplicationView getSingleApplicationView(Long id) {
        BaseApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.setApplicationId(id);
        return listProvider.getById(BaseApplicationListProvider.AppPageable.SINGLE_VALUE, filterSpec);
    }
}
