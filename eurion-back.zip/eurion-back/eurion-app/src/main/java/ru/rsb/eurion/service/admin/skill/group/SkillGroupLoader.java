package ru.rsb.eurion.service.admin.skill.group;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.DeclineCategoryDao;
import ru.rsb.eurion.dao.DeclineReasonDao;
import ru.rsb.eurion.dao.FormDao;
import ru.rsb.eurion.dao.SkillGroupRoleDao;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.CheckItemDefinition;
import ru.rsb.eurion.domain.DeclineCategory;
import ru.rsb.eurion.domain.DeclineReason;
import ru.rsb.eurion.domain.Form;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.domain.SkillGroupRole;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.service.admin.check.protocol.form.definition.FormDefinitionService;
import ru.rsb.eurion.service.admin.check.protocol.item.definition.CheckItemDefinitionService;
import ru.rsb.eurion.service.application.NotFoundException;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
@AllArgsConstructor
public class SkillGroupLoader {
    private final SkillGroupDao skillGroupDao;
    private final SkillGroupRoleDao skillGroupRoleDao;
    private final DeclineCategoryDao declineCategoryDao;
    private final FormDefinitionService formDefinitionService;
    private final FormDao formDao;
    private final SkillGroupService skillGroupService;
    private final CheckItemDefinitionService checkItemDefinitionService;
    private final DeclineReasonDao declineReasonDao;

    @Nonnull
    public SkillGroupAggragate load(@Nonnull Integer id) {
        final SkillGroup skillGroup = skillGroupDao.findById(id);
        if (skillGroup == null) {
            throw new NotFoundException(id);
        }

        final List<SkillGroupRole> skillGroupRoles = skillGroupRoleDao.findAll();
        final List<DeclineCategory> allDeclineCategories = takeAllDeclineCategories();

        final List<DeclineCategory> declineCategories = takeDeclineCategories(id);

        final List<FormDefinition> formDefinitions = formDefinitionService.getListBySkillGroup(id);

        final List<Form> allForms = formDao.findAll();

        final List<User> members = skillGroupService.getUsersBySkillGroupId(id);

        List<CheckItemDefinition> checkItemDefinitions = checkItemDefinitionService.list();

        return SkillGroupAggragate.builder()
                .skillGroup(skillGroup)
                .skillGroupRoles(skillGroupRoles)
                .allDeclineCategories(allDeclineCategories)
                .declineCategories(declineCategories)
                .formDefinitions(formDefinitions)
                .allForms(allForms)
                .members(members)
                .allCheckItemDefinitions(checkItemDefinitions)
                .build();
    }

    public SkillGroupAggragate loadRef() {
        final List<SkillGroupRole> skillGroupRoles = skillGroupRoleDao.findAll();
        final List<DeclineCategory> allDeclineCategories = takeAllDeclineCategories();
        final List<Form> allForms = formDao.findAll();
        List<CheckItemDefinition> checkItemDefinitions = checkItemDefinitionService.list();
        return SkillGroupAggragate.builder()
                .skillGroup(new SkillGroup())
                .skillGroupRoles(skillGroupRoles)
                .allDeclineCategories(allDeclineCategories)
                .declineCategories(Collections.emptyList())
                .formDefinitions(Collections.emptyList())
                .allForms(allForms)
                .members(Collections.emptyList())
                .allCheckItemDefinitions(checkItemDefinitions)
                .build();
    }

    public List<DeclineCategory> takeAllDeclineCategories() {
        final List<DeclineCategory> result = declineCategoryDao.findAll();
        final List<DeclineReason> allReasons = declineReasonDao.findAll();
        setupReasons(result, allReasons);
        return result;
    }

    private List<DeclineCategory> takeDeclineCategories(@Nonnull Integer id) {
        final List<DeclineCategory> result = skillGroupDao.getDeclineCategoryList(id);
        final List<DeclineReason> skillGroupReasons = declineReasonDao.findBySkillGroupId(id);
        setupReasons(result, skillGroupReasons);
        return result;
    }

    private void setupReasons(List<DeclineCategory> result, List<DeclineReason> reasonList) {
        final Map<Integer, List<DeclineReason>> index = reasonList.stream()
                .collect(Collectors.groupingBy(reason -> reason.getCategory().getId(), Collectors.toList()));
        result.forEach(item -> {
            final List<DeclineReason> reasons = index.get(item.getId());
            final List<DeclineReason> sortedList = reasons.stream()
                    .sorted(Comparator.comparing(BasicReference::getName))
                    .collect(Collectors.toList());
            item.setDeclineReasons(sortedList);
        });
    }
}
