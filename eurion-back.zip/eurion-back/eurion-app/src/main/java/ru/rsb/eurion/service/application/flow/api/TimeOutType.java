package ru.rsb.eurion.service.application.flow.api;

public enum TimeOutType {
    RESENDING,
    REASSIGN,
    POSTPONE,
    DECISION,
    RECOUNT,
    DEFAULT
}
