package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class RequestedDocument {

    private Long id;

    private Long applicationId;

    private Integer typeId;

    private Integer userId;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private LocalDateTime disabledAt;

    private boolean isRequested;

    private String userFullName;
}
