package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.UserNote;

@Mapper
public interface UserNotesDao {

    String BASE_SQL = "SELECT\n" +
            "  ID,\n" +
            "  APPLICATION_ID,\n" +
            "  USER_ID,\n" +
            "  NOTE,\n" +
            "  CREATED_AT,\n" +
            "  UPDATED_AT,\n" +
            "  VERSION\n" +
            "FROM USER_NOTES ";

    @Select(BASE_SQL + "where APPLICATION_ID = #{applicationId, jdbcType = BIGINT}")
    @Results(id = "userNoteMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "applicationId", column = "APPLICATION_ID"),
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "note", column = "NOTE"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "version", column = "VERSION"),
    })
    UserNote get(@Param("applicationId") Long applicationId);

    @Insert("INSERT INTO USER_NOTES (APPLICATION_ID, USER_ID, NOTE, CREATED_AT, VERSION)\n" +
            "VALUES (#{userNote.applicationId, jdbcType = BIGINT},\n" +
            "        #{userNote.userId, jdbcType = INTEGER},\n" +
            "        #{userNote.note, jdbcType = VARCHAR},\n" +
            "        #{userNote.createdAt, jdbcType = TIMESTAMP},\n" +
            "        #{userNote.version, jdbcType = TIMESTAMP})\n")
    @SelectKey(
            keyProperty = "userNote.id",
            before = false,
            resultType = Long.class,
            statement = {"select seq_user_notes.currval AS id from dual"})
    void create(@Param("userNote") UserNote userNote);

    @Update("UPDATE USER_NOTES\n" +
            "SET NOTE       = #{userNote.note, jdbcType = VARCHAR},\n" +
            "    UPDATED_AT = #{userNote.updatedAt, jdbcType = TIMESTAMP},\n" +
            "    USER_ID    = #{userNote.userId, jdbcType = INTEGER},\n" +
            "    VERSION    = #{userNote.version, jdbcType = TIMESTAMP}\n" +
            "    WHERE APPLICATION_ID = #{userNote.applicationId, jdbcType = BIGINT}")
    void update(@Param("userNote") UserNote userNote);
}
