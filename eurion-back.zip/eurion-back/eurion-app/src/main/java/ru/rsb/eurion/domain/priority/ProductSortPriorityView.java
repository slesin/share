package ru.rsb.eurion.domain.priority;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductSortPriorityView {
    private Integer id;
    private String name;
    private short priority;
}
