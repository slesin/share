package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Расчёты по заявке
 */
@Getter
@Setter
public class ApplicationCalculation {
    /**
     * Максимально возможный СЕВ, руб.
     */
    private BigDecimal sev;
    /**
     * Максимально возможный СЗЛ, руб.
     */
    private BigDecimal szl;
    /**
     * Макисимально возможный ЕП по запрошенному кредиту, руб.
     */
    private BigDecimal maximumPayment;
    /**
     * Макисимально возможная сумма по запрошенному кредиту, руб.
     */
    private BigDecimal maximumLoanAmount;
    /**
     * Срок кредита
     */
    private Integer loanPeriod;
}
