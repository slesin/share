package ru.rsb.eurion.domain;

import lombok.*;
import ru.rsb.eurion.rtdm.application.CreditInfoItemType;

import java.time.LocalDateTime;
import java.util.List;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CreditParameters {

    private Integer rtdmId;

    private List<CreditInfoItemType> creditInfoList;

    private LocalDateTime version;

}
