package ru.rsb.eurion.security;

import lombok.Getter;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.service.admin.users.status.UserStatusAndRole;

import java.util.stream.Collectors;

/**
 * @author sergius on 9/12/18.
 */
@Getter
public class AppAuthenticationToken extends UsernamePasswordAuthenticationToken {
    private final UserData user;

    public AppAuthenticationToken(User user) {
        super(user.getUsername(), null, user.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                .collect(Collectors.toList()));
        this.user = UserData.of(user);
    }

    public AppAuthenticationToken(User user, UserStatusAndRole status) {
        super(user.getUsername(), null, user.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                .collect(Collectors.toList()));
        this.user = UserData.of(user);
        this.user.setCurrentStatus(status);
    }
}
