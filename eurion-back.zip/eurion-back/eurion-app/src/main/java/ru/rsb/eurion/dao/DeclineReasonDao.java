package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.DeclineReason;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Mapper
public interface DeclineReasonDao {
    String SELECT_SQL = "select r.ID,\n" +
            "       r.CREATED_AT,\n" +
            "       r.UPDATED_AT,\n" +
            "       r.CODE,\n" +
            "       r.NAME,\n" +
            "       r.TIMEOUT,\n" +
            "       c.ID         as C_ID,\n" +
            "       c.NAME       as C_NAME,\n" +
            "       c.CODE       as C_CODE,\n" +
            "       C.CREATED_AT as C_CREATED_AT,\n" +
            "       C.UPDATED_AT as C_UPDATED_AT\n" +
            "from DECLINE_REASON r\n" +
            "       join DECLINE_CATEGORY c on r.DECLINE_CATEGORY_ID = c.ID\n";

    @Select(SELECT_SQL)
    @ResultMap("DeclineCategoryReasonMapping")
    List<DeclineReason> findAll();

    @Select(SELECT_SQL + "where r.ID = #{id}")
    @Results(id = "DeclineCategoryReasonMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "timeout", column = "TIMEOUT"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "category.id", column = "C_ID"),
            @Result(property = "category.createdAt", column = "C_CREATED_AT"),
            @Result(property = "category.updatedAt", column = "C_UPDATED_AT"),
            @Result(property = "category.name", column = "C_NAME"),
            @Result(property = "category.code", column = "C_CODE"),
    })
    DeclineReason findById(Integer id);

    @Select(SELECT_SQL + "where exists(\n" +
            "              select * from SKILL_GROUP_DECLINE_REASON where DECLINE_REASON_ID = r.ID and SKILL_GROUP_ID = #{id}\n" +
            "          )")
    @ResultMap("DeclineCategoryReasonMapping")
    List<DeclineReason> findBySkillGroupId(Integer skillGroupId);

    @Select("SELECT * FROM DECLINE_REASON where ID in (#{ids})")
    @Lang(MybatisExtendedLanguageDriver.class)
    Set<Integer> findByIds(@Param("ids") Set<Integer> ids);

    @Update("UPDATE DECLINE_REASON\n" +
            "set TIMEOUT    = #{timeout, jdbcType = INTEGER},\n" +
            "    UPDATED_AT = #{updatedAt, jdbcType=TIMESTAMP}\n" +
            "where ID = #{id, jdbcType = INTEGER}")
    void setTimeOut(@Param("id") Integer id,
                    @Param("timeout") Integer timeout,
                    @Param("updatedAt") LocalDateTime updatedAt);

}
