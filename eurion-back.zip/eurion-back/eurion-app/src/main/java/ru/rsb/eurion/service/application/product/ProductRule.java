package ru.rsb.eurion.service.application.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.SkillGroup;

import javax.validation.constraints.DecimalMax;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class ProductRule {

    private Integer id;

    @JsonIgnore
    private ProductType productType;

    @JsonIgnore
    private SkillGroup skillGroup;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal beginAmount;

    @JsonSerialize(using = MoneySerializer.class)
    private BigDecimal endAmount;

    @DecimalMax(value = "1.0")
    private BigDecimal pti;

    private LocalDateTime updatedAt;

    private LocalDateTime createdAt;

}
