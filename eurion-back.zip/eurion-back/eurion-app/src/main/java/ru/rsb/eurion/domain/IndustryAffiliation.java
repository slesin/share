package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Отраслевая принадлежность
 */
@Setter
@Getter
public class IndustryAffiliation {
    private Integer id;
    private String name;
}
