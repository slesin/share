package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.ApplicationVersionDao;
import ru.rsb.eurion.domain.Application;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationVersion;
import ru.rsb.eurion.domain.ApplicationVersionInfo;
import ru.rsb.eurion.domain.CallHistory;
import ru.rsb.eurion.domain.FieldComment;
import ru.rsb.eurion.domain.FormConclusion;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.service.phone.history.CallHistoryService;
import ru.rsb.eurion.service.util.JsonService;

import javax.annotation.Nullable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Service
@Transactional
public class ApplicationVersionService {

    private static final TypeReference<List<FormDefinition>> TYPE_REF_FORM_DEFINITIONS =
            new TypeReference<List<FormDefinition>>() {
            };
    private static final TypeReference<List<FormConclusion>> TYPE_REF_FORM_CONCLUSIONS =
            new TypeReference<List<FormConclusion>>() {
            };
    private static final TypeReference<Map<String, String>> TYPE_REF_FIELD_COMMENTS =
            new TypeReference<Map<String, String>>() {
            };

    private ApplicationVersionDao dao;
    private final ApplicationVersionDao applicationVersionDao;
    private final ApplicationVersionMapper applicationVersionMapper;
    private final JsonTransformer jsonTransformer;
    private final JsonService jsonService;
    private final CallHistoryService callHistoryService;
    private final FieldCommentDao fieldCommentDao;

    public Application findById(Long appVersionId) {
        ApplicationVersion appVersion = dao.findById(appVersionId);
        JsonNode jsonNode = jsonTransformer.readTree(appVersion.getData());
        Application application = new Application();
        application.setId(appVersion.getApplicationId());
        application.setStatus(appVersion.getStatus());
        application.setCreated(appVersion.getCreatedAt());
        application.setData(jsonNode);
        application.setVersion(appVersion.getVersion());
        if (!StringUtils.isEmpty(appVersion.getFormDefinitions())) {
            List<FormDefinition> formDefinitions = jsonService.parse(appVersion.getFormDefinitions(), TYPE_REF_FORM_DEFINITIONS);
            application.setFormDefinitions(formDefinitions);
        }

        if (!StringUtils.isEmpty(appVersion.getFormConclusions())) {
            List<FormConclusion> formConclusions = jsonService.parse(appVersion.getFormConclusions(), TYPE_REF_FORM_CONCLUSIONS);
            application.setFormConclusions(formConclusions);
        }

        application.setProcessStatusCode(appVersion.getStatusCategoryCode());
        application.setReadonly(true);
        application.setUserId(appVersion.getUserId());

        LocalDateTime startDate = appVersion.getVersionInterval().getStart();
        LocalDateTime endDate = appVersion.getVersionInterval().getEnd();
        List<CallHistory> callHistories = callHistoryService.getCallHistoryByInterval(appVersion.getBlankId(), startDate, endDate);
        application.setCallHistoryList(callHistories);
        application.setVersionInterval(appVersion.getVersionInterval());

        if (!StringUtils.isEmpty(appVersion.getIncomeInfo())) {
            JsonNode incomeInfoJsonNode = jsonTransformer.readTree(appVersion.getIncomeInfo());
            application.setIncomeInfo(incomeInfoJsonNode);
        }

        if (!StringUtils.isEmpty(appVersion.getFieldComment())) {
            Map<String, String> fieldComments = jsonService.parse(appVersion.getFieldComment(), TYPE_REF_FIELD_COMMENTS);
            application.setFieldComments(fieldComments);
        }

        return application;
    }

    public List<ApplicationVersionInfo> getVersionInfo(Long applicationId) {
        return applicationVersionDao.getVersionInfo(applicationId);
    }

    public void create(ApplicationVersion appVersion) {
        dao.create(appVersion);
    }

    public void saveVersion(ApplicationEntity appEntity) {
        ApplicationVersion applicationVersion = new ApplicationVersion();
        applicationVersionMapper.mapToApplicationVersion(appEntity, applicationVersion);
        applicationVersion.setVersion(LocalDateTime.now());
        Map<String, String> fieldComments = fieldCommentDao.findByApplicationId(appEntity.getId()).stream()
                .collect(Collectors.toMap(FieldComment::getName, FieldComment::getCommentText));
        String fieldCommentsString = "";
        try {
            fieldCommentsString = jsonTransformer.writeAsString(fieldComments);
        } catch (JsonProcessingException e) {
            log.error("Get field comments error, application id {}", appEntity.getId());
        }
        applicationVersion.setFieldComment(fieldCommentsString);
        applicationVersionDao.create(applicationVersion);
    }

    @Nullable
    public Application findLastByAppId(Integer appId) {
        ApplicationVersion appVersion = dao.findLastByAppId(appId);
        if (appVersion != null) {
            JsonNode jsonNode = jsonTransformer.readTree(appVersion.getData());
            Application application = new Application();
            application.setId(appVersion.getApplicationId());
            application.setBlankId(appVersion.getBlankId());
            application.setStatus(appVersion.getStatus());
            application.setCreated(appVersion.getCreatedAt());
            application.setData(jsonNode);
            application.setVersion(appVersion.getVersion());
            application.setProcessStatusCode(appVersion.getStatusCategoryCode());
            application.setReadonly(true);
            application.setUserId(appVersion.getUserId());
            application.setVersionInterval(appVersion.getVersionInterval());
            return application;
        }
        return null;
    }
}
