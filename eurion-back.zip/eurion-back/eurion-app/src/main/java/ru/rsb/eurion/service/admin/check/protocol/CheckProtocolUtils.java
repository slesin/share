package ru.rsb.eurion.service.admin.check.protocol;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import ru.rsb.eurion.domain.Application;
import ru.rsb.eurion.domain.FormConclusion;
import ru.rsb.eurion.domain.FormDefinition;

import java.util.List;
import java.util.stream.Collectors;

import static ru.rsb.eurion.domain.CheckItemKind.REQUEST_DOCUMENT;
import static ru.rsb.eurion.domain.CheckItemType.REQUEST;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class CheckProtocolUtils {

    public static boolean checkFillCheckList(Application application) {
        List<FormDefinition> definitions = application.getFormDefinitions();
        int amountCheck = definitions.stream()
                .flatMap(formDefinition -> formDefinition.getCheckItemDefinitions()
                        .stream()
                        .filter(checkItemDefinition -> checkItemDefinition.getKind() != REQUEST_DOCUMENT))
                .collect(Collectors.toList())
                .size();

        List<FormConclusion> conclusions = application.getFormConclusions();
        int amountCompleteCheck = conclusions.stream()
                .flatMap(formConclusion -> formConclusion.getCheckItemConclusions()
                        .stream()
                        .filter(checkItemConclusion -> checkItemConclusion.getSelectedItemId() != null
                                && checkItemConclusion.getSelectedItemType() != null
                                && checkItemConclusion.getSelectedItemType() != REQUEST))
                .collect(Collectors.toList())
                .size();
        return amountCheck == amountCompleteCheck;
    }
}
