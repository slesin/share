package ru.rsb.eurion.service.application.flow.api;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import javax.annotation.Nullable;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class FlowAPI {
    public static final String START_MESSAGE_NAME = "newRtdmApplicationMessage";
    public static final String OPERATOR_READY_MESSAGE = "operatorReadyMessage";
    public static final String CHANGE_OPERATOR_MESSAGE = "changeOperatorMessage";
    public static final String RETURN_INTO_QUEUE_MESSAGE = "returnIntoQueueMessage";
    public static final String RETURN_FROM_RECOUNT_MESSAGE = "returnedFromRecountMessage";
    public static final String FIND_APPLICATION_MESSAGE = "findApplicationMessage";
    public static final String APPLICATION_DEFINITION_KEY = ProcessDefinitionKey.APPLICATION.getValue();

    /**
     * Ожиданием, пока пользователь не возьмет заявку в работу
     */
    public static final String OPERATOR_TAKE_IN_WORK_TASK = "operatorTakeInWork";
    public static final String WORK_WITH_APPLICATION_TASK = "workWithApplication";
    public static final String POSTPONE_TASK = "postponeTask";

    public static final String APPLICATION_ID_VAR = "applicationId";
    public static final String APPLICATION_ESISTS_VAR = "applicationExists";
    public static final String POSTPONED_UNTIL_VAR = "postponedUntil";
    /**
     * Пользователь, которму назначена заявка
     */
    public static final String USER_ID_VAR = "userId";
    public static final String WITH_TIME_OUT_VAR = "withTimeOut";
    public static final String TIME_OUT_TYPE_VAR = "timeOutType";
    public static final String PREVIOUS_USER_ID_VAR = "previousUserId";
    public static final String CURRENT_USER_NAME_VAR = "currentUserName";
    public static final String REASSIGN_CAUSE = "reassignCause";

    public static final String APPLICATION_FORM_KEY = "applicationForm_v_1";
    public static final String APPLICATION_AUTHOR_FORM_KEY = "applicationAuthorForm";

    public static final String SAVE_OUTCOME = "save";
    public static final String ACCEPT_OUTCOME = "approve";
    public static final String REJECT_OUTCOME = "reject";
    public static final String RECALC_OUTCOME = "recount";
    public static final String FRAUD_OUTCOME = "fraud";
    public static final String POSTPONE_OUTCOME = "postpone";
    public static final String REWORK_OUTCOME = "rework";
    /**
     * Коментарий к решению
     */
    public static final String DECISION_COMMENT_VAR = "decisionComment";

    @Nullable
    public static String idToBusinessKey(@Nullable Integer id) {
        return id != null ? Integer.toString(id) : null;
    }
}
