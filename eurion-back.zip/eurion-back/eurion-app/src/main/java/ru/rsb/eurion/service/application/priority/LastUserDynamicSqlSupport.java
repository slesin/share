package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;

public class LastUserDynamicSqlSupport {
    public static final LastUserTable LAST_USER_TABLE = new LastUserTable();

    public static final SqlColumn<Integer> ID = LAST_USER_TABLE.column("ID", JDBCType.INTEGER);
    public static final SqlColumn<String> USER_FULL_NAME = LAST_USER_TABLE.column("FULL_NAME", JDBCType.VARCHAR);

    private static final class LastUserTable extends SqlTable {
        LastUserTable() {
            super("APP_USER");
        }
    }
}
