package ru.rsb.eurion.service.application;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.FieldComment;

import java.util.List;

@Mapper
public interface FieldCommentDao {
    String UPDATE_SQL = "merge into FIELD_COMMENT s\n" +
            "using dual v\n" +
            "on (s.APPLICATION_ID = #{comment.applicationId} and s.FIELD_NAME = #{comment.name})\n" +
            "when matched then update set COMMENT_TEXT = #{comment.commentText, jdbcType=CLOB}, UPDATED_AT = #{comment.updatedAt}\n" +
            "    when not matched then insert (APPLICATION_ID, FIELD_NAME, COMMENT_TEXT, CREATED_AT, UPDATED_AT)\n" +
            "    values (#{comment.applicationId}, #{comment.name}, #{comment.commentText}, #{comment.createdAt}, " +
            "#{comment.updatedAt})";

    String BASE_SELECT_SQL = "select * from FIELD_COMMENT where APPLICATION_ID = #{applicationId}\n";

    String DELETE_SQL = "delete from FIELD_COMMENT where APPLICATION_ID = #{applicationId, jdbcType=BIGINT} " +
            "and FIELD_NAME = #{name, jdbcType=VARCHAR}";

    @Update(UPDATE_SQL)
    void createOrUpdate(@Param("comment") FieldComment entity);

    @Select(BASE_SELECT_SQL + "order by FIELD_NAME")
    @Results(id = "fieldCommentMapping", value = {
            @Result(property = "applicationId", column = "APPLICATION_ID"),
            @Result(property = "name", column = "FIELD_NAME"),
            @Result(property = "commentText", column = "COMMENT_TEXT"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT")
    })
    List<FieldComment> findByApplicationId(@Param("applicationId") Long applicationId);

    @Delete(DELETE_SQL)
    void delete(FieldComment entity);
}
