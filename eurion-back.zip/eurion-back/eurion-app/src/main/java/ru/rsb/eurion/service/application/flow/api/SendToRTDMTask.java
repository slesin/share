package ru.rsb.eurion.service.application.flow.api;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.service.application.ApplicationDao;
import ru.rsb.eurion.service.underwriting.ApplicationTransportService;

@Service("sendRTDM")
@Transactional
@Slf4j
@AllArgsConstructor
public class SendToRTDMTask {

    private final ApplicationTransportService applicationTransportService;
    private final ApplicationDao applicationDao;

    @SuppressWarnings("unused")
    public void execute(Long applicationId) {
        ApplicationEntity entity = applicationDao.findById(applicationId);
        if (entity == null) {
            throw new IllegalStateException("Application is not found: id=" + applicationId);
        }
        applicationTransportService.sendToRTDM(entity);
        log.info("Application is sent to RTDM: id={}", applicationId);
    }
}
