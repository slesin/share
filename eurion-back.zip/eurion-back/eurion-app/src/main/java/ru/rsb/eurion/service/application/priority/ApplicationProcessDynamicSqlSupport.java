package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;

import java.sql.JDBCType;

public class ApplicationProcessDynamicSqlSupport {
    public static final ApplicationProcessTable APPLICATION_PROCESS_TABLE = new ApplicationProcessTable();

    public static final SqlColumn<Long> ID = APPLICATION_PROCESS_TABLE.column("APPLICATION_ID", JDBCType.BIGINT);
    public static final SqlColumn<ProcessDefinitionKey> PROCESS_NAME = APPLICATION_PROCESS_TABLE.column("PROCESS_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<ProcessDefinitionKey> APPLICATION_ID = APPLICATION_PROCESS_TABLE.column("APPLICATION_ID", JDBCType.VARCHAR);

    private static final class ApplicationProcessTable extends SqlTable {
        ApplicationProcessTable() {
            super("APPLICATION_PROCESS");
        }
    }
}
