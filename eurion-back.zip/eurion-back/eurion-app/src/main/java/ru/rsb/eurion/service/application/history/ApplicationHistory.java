package ru.rsb.eurion.service.application.history;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class ApplicationHistory {
    /**
     * Идентификатор заявки
     */
    private Integer applicationId;
    /**
     * Дата редактирования
     */
    private LocalDateTime updatedAt;
    /**
     * Источник редактирования
     */
    private String source;
    /**
     * Тип изменения
     */
    private String type;
    /**
     * Путь к полю
     */
    private String fieldPath;
    /**
     * Старое значение
     */
    private String oldValue;
    /**
     * Новое значение
     */
    private String newValue;
}
