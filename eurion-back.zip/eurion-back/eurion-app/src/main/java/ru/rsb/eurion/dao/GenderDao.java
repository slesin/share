package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.Gender;

import java.util.List;

@Mapper
public interface GenderDao {

    @Select("select " +
            "  IND, " +
            "  NAME, " +
            "  SCORIND, " +
            "  DATECHANGE, " +
            "  ACTIV, " +
            "  IDCOUNTRY, " +
            "  CODEID " +
            "from CLIENT_GENDER")
    @Results(id = "clientGenderMapping", value = {
            @Result(property = "id", column = "IND"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "scoringId", column = "SCORIND"),
            @Result(property = "updatedAt", column = "DATECHANGE"),
            @Result(property = "active", column = "ACTIV"),
            @Result(property = "countryId", column = "IDCOUNTRY"),
            @Result(property = "codeId", column = "CODEID")
    })
    List<Gender> findAll();

    @Select("select * from CLIENT_GENDER where IND = #{id}")
    @ResultMap("clientGenderMapping")
    Gender findById(Integer id);
}
