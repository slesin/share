package ru.rsb.eurion.service.admin.users.subdivision;


import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(of = {"id", "value"})
@EqualsAndHashCode
public class OrgItem {

    private Integer id;

    private Integer parentId;

    private String value;

    private boolean canRename;

    private boolean canMove;

    private boolean canEditChild;

    private OrgItemType orgItemType;

    private Integer orderIdx;
}
