package ru.rsb.eurion.service.admin.users.status;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.UserStatus;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserStatusAndRole implements Serializable {
    private UserStatus status;
    private Role role;
}
