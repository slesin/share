package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreditSaleChannel extends BasicReference {
    private String code;
    private short priority;
    private boolean enabled;
}
