package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

/**
 * Паспорт
 */
@Getter
@Setter
public class Passport {
    /**
     * Имя
     */
    private String firstName;
    /**
     * Фамилия
     */
    private String lastName;
    /**
     * Отчество
     */
    private String middleName;
    /**
     * Пол
     */
    private Integer sexId;
    /**
     * Дата рождения
     */
    private LocalDate birthDate;
    /**
     * Место рождения
     */
    private String birthPlace;
    /**
     * Серия паспорта
     */
    private String passportSeries;
    /**
     * Номер паспорта
     */
    private String passportNumber;
    /**
     * Код подразделения
     */
    private String passportIssueSubdivisionCode;
    /**
     * Дата выдачи
     */
    private LocalDate passportIssueDate;
    /**
     * Кем выдан паспорт
     */
    private String passportIssueSubdivision;
    /**
     * Гражданство
     */
    private Integer citizenshipId;
}
