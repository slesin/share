package ru.rsb.eurion.service.application;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.service.util.JsonService;

@Service
@Transactional
public class ApplicationListProvider extends BaseApplicationListProvider {
    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    public ApplicationListProvider(ApplicationDao dao, JsonService jsonService) {
        super(dao, jsonService);
    }
}
