package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Канал привлечения заявки
 */
@Getter
@Setter
public class InboundChannel extends BasicForm {
}
