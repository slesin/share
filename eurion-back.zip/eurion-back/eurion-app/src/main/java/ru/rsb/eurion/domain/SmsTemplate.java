package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SmsTemplate extends BasicReference {
}
