package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import javax.annotation.Nullable;

@Getter
@Setter
public class CheckItemConclusion {
    private Integer id;
    @Nullable
    private CheckItemType selectedItemType;
    @Nullable
    private Integer selectedItemId;
    @Nullable
    private String remark;
}
