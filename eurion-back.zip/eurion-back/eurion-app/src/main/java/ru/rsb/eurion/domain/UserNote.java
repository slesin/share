package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class UserNote {

    private Long id;

    private Long applicationId;

    private Integer userId;

    private String note;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private LocalDateTime version;

}
