package ru.rsb.eurion.service.admin.users;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserStatusHistory;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;
import ru.rsb.eurion.service.admin.users.status.UserStatusSkillDTO;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * @author sergius on 9/10/18.
 */
@Mapper
public interface UserDao {

    String BASE_SELECT_SQL = "select u.ID,\n" +
            "       u.CREATED_AT,\n" +
            "       u.UPDATED_AT,\n" +
            "       u.USERNAME,\n" +
            "       u.FULL_NAME,\n" +
            "       u.EXTENDED_NAME,\n" +
            "       u.PHOTO,\n" +
            "       u.BIRTH_DATE,\n" +
            "       u.PERSONNEL_NUMBER,\n" +
            "       u.LIMIT,\n" +
            "       u.DISABLED_AT,\n" +
            "       u.LOTUS_ADDRESS,\n" +
            "       u.DIVISION,\n" +
            "       u.INNER_PHONE_NUMBER,\n" +
            "       u.DOMAIN,\n" +
            "       u.PRIMARY_PHONE_TYPE,\n" +
            "       u.HIDDEN_PHONE_NUMBER,\n" +
            "       u.SUBDIVISION_ID,\n" +
            "       u.HAS_UPDATE_LIMIT_PERMISSION,\n" +
            "       u.DIVISION_ID,\n" +
            "       s.ID          as S_ID,\n" +
            "       s.FULL_NAME   as S_NAME,\n" +
            "       us.ID         as US_ID,\n" +
            "       us.NAME       as US_NAME,\n" +
            "       us.CODE       as US_CODE,\n" +
            "       us.ORDER_NUM  as US_ORDER_NUM,\n" +
            "       sh.ID as SH_ID,\n" +
            "       sh.SESSION_ID as SH_SESSION_ID,\n" +
            "       sh.ROLE_ID as SH_ROLE_ID,\n" +
            "       sh.UPDATED_AT as SH_UPDATED_AT\n" +
            "from APP_USER u\n" +
            "       left join APP_USER s on u.SUPERVISOR_ID = s.ID\n" +
            "       left join USER_STATUS_HISTORY sh on u.STATUS_HISTORY_ID = sh.ID\n" +
            "       left join USER_STATUS US on sh.STATUS_ID = us.ID\n";

    String SUBDIVISION_SELECT_SQL = "select * from(\n" +
            "select u.ID,\n" +
            "       u.CREATED_AT,\n" +
            "       u.UPDATED_AT,\n" +
            "       u.USERNAME,\n" +
            "       u.FULL_NAME,\n" +
            "       u.EXTENDED_NAME,\n" +
            "       u.PHOTO,\n" +
            "       u.BIRTH_DATE,\n" +
            "       u.PERSONNEL_NUMBER,\n" +
            "       u.LIMIT,\n" +
            "       u.DISABLED_AT,\n" +
            "       u.LOTUS_ADDRESS,\n" +
            "       u.DIVISION,\n" +
            "       u.INNER_PHONE_NUMBER,\n" +
            "       u.DOMAIN,\n" +
            "       u.PRIMARY_PHONE_TYPE,\n" +
            "       u.HIDDEN_PHONE_NUMBER,\n" +
            "       u.SUBDIVISION_ID,\n" +
            "       s.ID          as S_ID,\n" +
            "       s.FULL_NAME   as S_NAME,\n" +
            "       us.ID         as US_ID,\n" +
            "       us.NAME       as US_NAME,\n" +
            "       us.CODE       as US_CODE,\n" +
            "       us.ORDER_NUM  as US_ORDER_NUM,\n" +
            "       sh.ID as SH_ID,\n" +
            "       sh.SESSION_ID as SH_SESSION_ID,\n" +
            "       sh.ROLE_ID as SH_ROLE_ID,\n" +
            "       sh.UPDATED_AT as SH_UPDATED_AT,\n" +
            "       decode(aur.ROLE_ID, 'SUPERVISOR', 1, 0) as IS_SUPERVISOR,\n" +
            "       (select count(*) from app_user where SUPERVISOR_ID = u.id)  OPERATORS_AMOUNT\n" +
            "from APP_USER u\n" +
            "         left join APP_USER s on u.SUPERVISOR_ID = s.ID\n" +
            "         left join USER_STATUS_HISTORY sh on u.STATUS_HISTORY_ID = sh.ID\n" +
            "         left join USER_STATUS US on sh.STATUS_ID = us.ID\n" +
            "         left join APP_USER_ROLE aur on u.ID = aur.USER_ID and aur.ROLE_ID = 'SUPERVISOR')";

    String BASE_SUGGESTION_SQL = "select u.ID,\n" +
            "       u.CREATED_AT,\n" +
            "       u.UPDATED_AT,\n" +
            "       u.USERNAME,\n" +
            "       u.FULL_NAME,\n" +
            "       u.BIRTH_DATE,\n" +
            "       u.PERSONNEL_NUMBER,\n" +
            "       u.LIMIT,\n" +
            "       u.LOTUS_ADDRESS,\n" +
            "       u.DIVISION,\n" +
            "       u.INNER_PHONE_NUMBER,\n" +
            "       u.DISABLED_AT,\n" +
            "       u.DOMAIN\n" +
            "from APP_USER u\n" +
            "       join APP_USER_ROLE aur on u.ID = aur.USER_ID and aur.ROLE_ID = #{role, jdbcType = VARCHAR}\n" +
            "where u.DISABLED_AT is null and (lower(u.FULL_NAME) like #{query} or lower(u.PERSONNEL_NUMBER) like #{query}) and\n" +
            "    not exists (select 1 from APP_USER_ROLE where USER_ID = u.ID and ROLE_ID = #{excludeRole, jdbcType = VARCHAR})";

    String BASE_SUGGESTION_SQL_ALL_USERS = "select ID, " +
            "       CREATED_AT, " +
            "       UPDATED_AT, " +
            "       USERNAME, " +
            "       FULL_NAME, " +
            "       BIRTH_DATE, " +
            "       PERSONNEL_NUMBER, " +
            "       LIMIT, " +
            "       LOTUS_ADDRESS," +
            "       DIVISION,\n" +
            "       INNER_PHONE_NUMBER,\n" +
            "       DISABLED_AT,\n" +
            "       DOMAIN" +
            " from APP_USER " +
            " where DISABLED_AT is null " +
            " and (lower(FULL_NAME) like #{query} or lower(PERSONNEL_NUMBER) like #{query})";

    String USERS_BY_SKILL_GROUP_SQL =
            " JOIN APP_USER_SKILL_GROUP ausg ON u.ID = ausg.USER_ID " +
                    " JOIN SKILL_GROUP sg ON ausg.GROUP_ID = sg.ID " +
                    " WHERE sg.ID = #{skillGroupId} " +
                    " order by u.FULL_NAME ";

    String UPDATE_SQL = "update APP_USER\n" +
            "set USERNAME                    = #{username, jdbcType = VARCHAR},\n" +
            "    FULL_NAME                   = #{name, jdbcType = VARCHAR},\n" +
            "    EXTENDED_NAME               = #{extendedName, jdbcType = VARCHAR},\n" +
            "    BIRTH_DATE                  = #{birthDate, jdbcType = DATE},\n" +
            "    PERSONNEL_NUMBER            = #{personnelNumber, jdbcType = VARCHAR},\n" +
            "    LIMIT                       = #{limit, jdbcType = INTEGER},\n" +
            "    SUPERVISOR_ID               = #{supervisor.id, jdbcType = INTEGER},\n" +
            "    UPDATED_AT                  = #{updatedAt, jdbcType = DATE},\n" +
            "    PHOTO                       = #{photo, jdbcType = BLOB},\n" +
            "    LOTUS_ADDRESS               = #{lotusAddress, jdbcType = VARCHAR},\n" +
            "    DIVISION                    = #{division, jdbcType = VARCHAR},\n" +
            "    INNER_PHONE_NUMBER          = #{innerPhoneNumber, jdbcType = VARCHAR},\n" +
            "    HIDDEN_PHONE_NUMBER         = #{hiddenPhoneNumber, jdbcType = VARCHAR},\n" +
            "    PRIMARY_PHONE_TYPE          = #{primaryPhoneType, jdbcType = VARCHAR},\n" +
            "    DOMAIN                      = #{domain, jdbcType = VARCHAR},\n" +
            "    HAS_UPDATE_LIMIT_PERMISSION = #{hasUpdateLimitPermission, jdbcType = VARCHAR},\n" +
            "    SUBDIVISION_ID              = #{subdivisionId, jdbcType = INTEGER}\n" +
            "where ID = #{id}";

    String FIND_USER_TO_ASSIGN_SQL = "select u.ID,\n" +
            "       u.CREATED_AT,\n" +
            "       u.UPDATED_AT,\n" +
            "       u.USERNAME,\n" +
            "       u.FULL_NAME,\n" +
            "       u.EXTENDED_NAME,\n" +
            "       u.LIMIT,\n" +
            "       u.DISABLED_AT,\n" +
            "       sh.ID         as SH_ID,\n" +
            "       sh.ROLE_ID    as SH_ROLE_ID,\n" +
            "       sh.UPDATED_AT as SH_UPDATED_AT,\n" +
            "       ash.LAST_COMPLETE_STATUS\n" +
            "from APP_USER u\n" +
            "         left join USER_STATUS_HISTORY sh on u.STATUS_HISTORY_ID = sh.ID\n" +
            "         left join USER_STATUS US on sh.STATUS_ID = us.ID\n" +
            "         left join (select USER_ID,\n" +
            "                           max(UPDATED_AT) AS LAST_COMPLETE_STATUS\n" +
            "                    from APPLICATION_STATUS_HISTORY\n" +
            "                    where STATUS_CODE in ('RECOUNT', 'COMPLETED', 'REWORK')\n" +
            "                    group by USER_ID) ash on ash.USER_ID = u.ID\n" +
            "where us.CODE = 'WORK'\n" +
            "  and sh.ROLE_ID = 'UNDERWRITER'\n" +
            "  and u.DISABLED_AT is null\n" +
            "  and sh.UPDATED_AT + numToDSInterval(#{userStatusTimeout, jdbcType=INTEGER}, 'second') < #{currentTime, jdbcType=TIMESTAMP} \n" +
            "  and" +
            " (select count(*)\n" +
            "       from APPLICATION a\n" +
            "       where a.USER_ID = u.ID\n" +
            "         and a.DONE_AT is null\n" +
            "         and a.STATUS_CATEGORY_CODE in ('ASSIGNED', 'IN_WORK')) = 0\n" +
            "  and (LAST_COMPLETE_STATUS is null or\n" +
            "       LAST_COMPLETE_STATUS + numToDSInterval(#{appStatusTimeout, jdbcType=INTEGER}, 'second') < #{currentTime, jdbcType=TIMESTAMP})\n" +
            "order by ash.LAST_COMPLETE_STATUS nulls first";

    String SELECT_BY_SUBDIVISION = "select u.ID,\n" +
            "       u.CREATED_AT,\n" +
            "       u.UPDATED_AT,\n" +
            "       u.USERNAME,\n" +
            "       u.FULL_NAME,\n" +
            "       u.EXTENDED_NAME,\n" +
            "       u.PHOTO,\n" +
            "       u.BIRTH_DATE,\n" +
            "       u.PERSONNEL_NUMBER,\n" +
            "       u.LIMIT,\n" +
            "       u.DISABLED_AT,\n" +
            "       u.LOTUS_ADDRESS,\n" +
            "       u.DIVISION,\n" +
            "       u.INNER_PHONE_NUMBER,\n" +
            "       u.DOMAIN,\n" +
            "       u.PRIMARY_PHONE_TYPE,\n" +
            "       u.HIDDEN_PHONE_NUMBER,\n" +
            "       u.SUBDIVISION_ID,\n" +
            "       u.HAS_UPDATE_LIMIT_PERMISSION,\n" +
            "       s.ID          as S_ID,\n" +
            "       s.FULL_NAME   as S_NAME,\n" +
            "       us.ID         as US_ID,\n" +
            "       us.NAME       as US_NAME,\n" +
            "       us.CODE       as US_CODE,\n" +
            "       us.ORDER_NUM  as US_ORDER_NUM,\n" +
            "       sh.ID         as SH_ID,\n" +
            "       sh.SESSION_ID as SH_SESSION_ID,\n" +
            "       sh.ROLE_ID    as SH_ROLE_ID,\n" +
            "       sh.UPDATED_AT as SH_UPDATED_AT,\n" +
            "       decode(aur.ROLE_ID, 'SUPERVISOR', 1, 0) as IS_SUPERVISOR\n" +
            "from APP_USER u\n" +
            "         left join APP_USER s on u.SUPERVISOR_ID = s.ID\n" +
            "         left join USER_STATUS_HISTORY sh on u.STATUS_HISTORY_ID = sh.ID\n" +
            "         left join USER_STATUS US on sh.STATUS_ID = us.ID\n" +
            "         left join APP_USER_ROLE aur on u.ID = aur.USER_ID and aur.ROLE_ID = 'SUPERVISOR'\n" +
            "         join (select ID\n" +
            "               from SUBDIVISION\n" +
            "               start with id = #{subdivisionId, jdbcType = INTEGER}\n" +
            "               connect by prior id = parent_id) d on d.ID = u.SUBDIVISION_ID";

    @Select(BASE_SELECT_SQL + USERS_BY_SKILL_GROUP_SQL)
    @ResultMap("userMapping")
    List<User> findBySkillGroupId(@Param("skillGroupId") Integer id);

    @Select(BASE_SELECT_SQL + "where lower(u.USERNAME) = lower(#{username})")
    @Results(id = "userMapping",
            value = {
                    @Result(property = "id", column = "ID"),
                    @Result(property = "createdAt", column = "CREATED_AT"),
                    @Result(property = "updatedAt", column = "UPDATED_AT"),
                    @Result(property = "username", column = "USERNAME"),
                    @Result(property = "name", column = "FULL_NAME"),
                    @Result(property = "extendedName", column = "EXTENDED_NAME"),
                    @Result(property = "photo", column = "PHOTO"),
                    @Result(property = "birthDate", column = "BIRTH_DATE"),
                    @Result(property = "personnelNumber", column = "PERSONNEL_NUMBER"),
                    @Result(property = "lotusAddress", column = "LOTUS_ADDRESS"),
                    @Result(property = "limit", column = "LIMIT"),
                    @Result(property = "disabledAt", column = "DISABLED_AT"),
                    @Result(property = "division", column = "DIVISION"),
                    @Result(property = "innerPhoneNumber", column = "INNER_PHONE_NUMBER"),
                    @Result(property = "domain", column = "DOMAIN"),
                    @Result(property = "supervisor.id", column = "S_ID"),
                    @Result(property = "supervisor.name", column = "S_NAME"),
                    @Result(property = "roles", many = @Many(select = "listByUserId", fetchType = FetchType.LAZY),
                            column = "ID"),
                    @Result(property = "operators", many = @Many(select = "listOperators", fetchType = FetchType.LAZY),
                            column = "ID"),
                    @Result(property = "statusHistory.id", column = "SH_ID"),
                    @Result(property = "statusHistory.role", column = "SH_ROLE_ID"),
                    @Result(property = "statusHistory.sessionId", column = "SH_SESSION_ID"),
                    @Result(property = "statusHistory.updatedAt", column = "SH_UPDATED_AT"),

                    @Result(property = "statusHistory.status.id", column = "US_ID"),
                    @Result(property = "statusHistory.status.name", column = "US_NAME"),
                    @Result(property = "statusHistory.status.code", column = "US_CODE"),
                    @Result(property = "statusHistory.status.orderNum", column = "US_ORDER_NUM"),
                    @Result(property = "skillGroupIds", many = @Many(select = "listSkillGroup",
                            fetchType = FetchType.LAZY), column = "ID"),
                    @Result(property = "primaryPhoneType", column = "PRIMARY_PHONE_TYPE"),
                    @Result(property = "hiddenPhoneNumber", column = "HIDDEN_PHONE_NUMBER"),
                    @Result(property = "subdivisionId", column = "SUBDIVISION_ID"),
                    @Result(property = "hasRoleSupervisor", column = "IS_SUPERVISOR"),
                    @Result(property = "operatorsAmount", column = "OPERATORS_AMOUNT"),
                    @Result(property = "hasUpdateLimitPermission", column = "HAS_UPDATE_LIMIT_PERMISSION"),
                    @Result(property = "divisionId", column = "DIVISION_ID")
            })
    User findByUsername(@Param("username") String login);

    @Select(BASE_SELECT_SQL + "where u.ID = #{id, jdbcType=INTEGER}")
    @ResultMap("userMapping")
    @Nullable
    User findById(@Param("id") Integer id);

    @Select(BASE_SELECT_SQL + "where u.ID in (#{ids})")
    @ResultMap("userMapping")
    @Lang(MybatisExtendedLanguageDriver.class)
    List<User> findByIds(@Param("ids") Set<Integer> ids);

    @Select(BASE_SELECT_SQL + "where u.SUPERVISOR_ID = #{supervisorId}")
    @ResultMap("userMapping")
    List<User> listOperators(@Param("supervisorId") Integer supervisorId);

    /**
     * Used by {@link #findByUsername(String)}
     */
    @SuppressWarnings("unused")
    @Select("select ur.ROLE_ID from APP_USER_ROLE ur where ur.USER_ID = #{user_id}")
    Set<Role> listByUserId(@Param("user_id") Integer userId);

    @Insert("insert into APP_USER (USERNAME, FULL_NAME, EXTENDED_NAME, BIRTH_DATE, PERSONNEL_NUMBER, LIMIT, SUPERVISOR_ID, " +
            " PHOTO, LOTUS_ADDRESS, DIVISION, INNER_PHONE_NUMBER, CREATED_AT, UPDATED_AT, DOMAIN, PRIMARY_PHONE_TYPE, SUBDIVISION_ID)\n" +
            "values (#{username},\n" +
            "        #{name,jdbcType=VARCHAR},\n" +
            "        #{extendedName,jdbcType=VARCHAR},\n" +
            "        #{birthDate,jdbcType=DATE},\n" +
            "        #{personnelNumber,jdbcType=VARCHAR},\n" +
            "        #{limit,jdbcType=NUMERIC},\n" +
            "        #{supervisor.id,jdbcType=INTEGER},\n" +
            "        #{photo,jdbcType=BLOB},\n" +
            "        #{lotusAddress,jdbcType=VARCHAR},\n" +
            "        #{division,jdbcType=VARCHAR},\n" +
            "        #{innerPhoneNumber,jdbcType=VARCHAR},\n" +
            "        #{createdAt,jdbcType=TIMESTAMP},\n" +
            "        #{createdAt,jdbcType=TIMESTAMP},\n" +
            "        #{domain,jdbcType=VARCHAR},\n" +
            "        #{primaryPhoneType,jdbcType=VARCHAR},\n" +
            "        #{subdivisionId, jdbcType=INTEGER})")
    @SelectKey(
            keyProperty = "id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_app_user.currval AS id from dual"}
    )
    void insert(User user);

    @Update(UPDATE_SQL)
    void update(User user);

    @Select("select ROLE_ID from APP_USER_ROLE where USER_ID = #{user.id}")
    Set<Role> listRoles(@Param("user") User user);

    @Select("select USER_ID, ROLE_ID from APP_USER_ROLE where USER_ID in (#{idList})")
    @Lang(MybatisExtendedLanguageDriver.class)
    @Results({
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "role", column = "ROLE_ID")
    })
    List<RoleAssociation> listRolesForList(@Param("idList") List<Integer> users);

    @Insert("insert into APP_USER_ROLE(USER_ID, ROLE_ID) values (#{user.id}, #{role})")
    void addRole(@Param("user") User user, @Param("role") Role role);

    @Insert("insert into APP_USER_SKILL_GROUP(USER_ID, GROUP_ID) values (#{user.id}, #{skillGroup.id})")
    void addUserToSkillGroup(@Param("skillGroup") SkillGroup skillGroup, @Param("user") User user);

    @Delete("delete from APP_USER_SKILL_GROUP where USER_ID = #{user.id} and GROUP_ID = #{skillGroup.id}")
    void deleteUserFromSkillGroup(@Param("skillGroup") SkillGroup skillGroup, @Param("user") User user);

    @Delete("delete from APP_USER_ROLE where USER_ID = #{user.id} and ROLE_ID = #{role}")
    void deleteRole(@Param("user") User user, @Param("role") Role role);

    @Update("update APP_USER set DISABLED_AT = #{disabledAt,jdbcType=DATE}, " +
            "UPDATED_AT = #{updatedAt,jdbcType=DATE} where ID in (#{ids})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void disable(@Param("ids") Set<Integer> ids,
                 @Param("disabledAt") LocalDateTime disabledAt,
                 @Param("updatedAt") LocalDateTime updatedAt);

    @Select(BASE_SELECT_SQL + " where s.DISABLED_AT is null order by u.USERNAME")
    @ResultMap("userMapping")
    List<User> list();

    @Select(SUBDIVISION_SELECT_SQL + " where DISABLED_AT is null order by USERNAME")
    @ResultMap("userMapping")
    List<User> listForSubdivision();

    @Select(BASE_SUGGESTION_SQL + " order by u.USERNAME")
    @ResultMap("userMapping")
    List<User> suggest(@Param("role") Role role,
                       @Param("query") String query,
                       @Param("excludeRole") Role excludeRole);

    @Select(BASE_SUGGESTION_SQL + " and u.id != #{userId} order by u.USERNAME")
    @ResultMap("userMapping")
    List<User> suggestWithoutUser(@Param("role") Role role,
                                  @Param("userId") Integer userId,
                                  @Param("query") String query,
                                  @Param("excludeRole") Role excludeRole);

    @Select(BASE_SUGGESTION_SQL_ALL_USERS + " order by USERNAME")
    @ResultMap("userMapping")
    List<User> suggestByQuery(@Param("query") String query);

    @Update("update APP_USER\n" +
            "set SUPERVISOR_ID  = #{supervisorId,jdbcType= INTEGER},\n" +
            "    SUBDIVISION_ID = #{subdivisionId, jdbcType= INTEGER},\n" +
            "    UPDATED_AT     = #{updatedAt,jdbcType=DATE}\n" +
            "where ID in (#{ids})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void setSupervisorAndSubdivision(@Param("ids") Set<Integer> ids,
                                     @Param("supervisorId") Integer supervisorId,
                                     @Param("subdivisionId") Integer subdivisionId,
                                     @Param("updatedAt") LocalDateTime updatedAt);

    @Update("update APP_USER set SUPERVISOR_ID = null, UPDATED_AT = #{updatedAt,jdbcType=DATE} " +
            "where SUPERVISOR_ID = #{supervisorId}")
    void cleanSupervisor(@Param("supervisorId") Integer supervisorId,
                         @Param("updatedAt") LocalDateTime updatedAt);

    /**
     * Used by {@link #listAllActiveUserWithSkillGroup(Integer supervisorId)}
     */
    @SuppressWarnings("unused")
    @Select("select GROUP_ID\n" +
            "from APP_USER_SKILL_GROUP\n" +
            "where USER_ID = #{user_id}")
    Set<Integer> listSkillGroup(@Param("user_id") Integer userId);

    @Select("select USER_ID, GROUP_ID\n" +
            "from APP_USER_SKILL_GROUP\n" +
            "where USER_ID in (#{idList})")
    @Results({
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "skillGroupId", column = "GROUP_ID")
    })
    @Lang(MybatisExtendedLanguageDriver.class)
    List<SkillGroupAssociation> listSkillGroupsForList(@Param("idList") Collection<Integer> idList);

    /**
     * Used by {@link #listAllActiveUserWithSkillGroup(Integer supervisorId)}
     */
    @Select("select NAME from USER_STATUS where ID = #{status_id}")
    @SuppressWarnings("unused")
    String getUserStatusName(@Param("status_id") Integer status_id);

    @Select("select u.ID,\n" +
            "       u.FULL_NAME,\n" +
            "       decode(SUPERVISOR_ID, #{supervisorId}, 1, 0) as BELONG_CURRENT_SUPERVISOR\n" +
            "    from APP_USER u\n" +
            "    join APP_USER_ROLE aur on u.ID = aur.USER_ID and aur.ROLE_ID = 'UNDERWRITER' and SUPERVISOR_ID is not null\n" +
            "    where DISABLED_AT is null")
    @Results(value = {
            @Result(property = "userId", column = "ID"),
            @Result(property = "userName", column = "FULL_NAME"),
            @Result(property = "skillGroupIdList", many = @Many(select = "listSkillGroup", fetchType = FetchType.EAGER), column = "ID"),
            @Result(property = "userStatusName", column = "status_id", one = @One(select = "getUserStatusName", fetchType = FetchType.EAGER)),
            @Result(property = "belongCurrentSupervisor", column = "BELONG_CURRENT_SUPERVISOR"),
    })
    List<UserStatusSkillDTO> listAllActiveUserWithSkillGroup(@Param("supervisorId") Integer supervisorId);

    @Update("update APP_USER set STATUS_HISTORY_ID = #{statusHistory.id} where ID = #{id}")
    void updateHistory(@Param("id") Integer userId, @Param("statusHistory") UserStatusHistory statusHistory);

    @Select({"select u.ID\n" +
            "from APP_USER u\n" +
            "       join USER_STATUS_HISTORY h on u.STATUS_HISTORY_ID = h.ID\n" +
            "       join USER_STATUS st on h.STATUS_ID = st.ID\n" +
            "where st.CODE = 'WORK'\n" +
            "  and h.ROLE_ID = 'UNDERWRITER'\n" +
            "  and exists(select *\n" +
            "             from APP_USER_SKILL_GROUP ug\n" +
            "                    join APPLICATION a on ug.GROUP_ID = a.SKILL_GROUP_ID\n" +
            "             where ug.USER_ID = u.ID\n" +
            "               and a.ID = #{appId} and (u.LIMIT >= #{amountSkipLimit, jdbcType=NUMERIC} or u.LIMIT >= a.REQUESTED_CREDIT_AMOUNT))\n" +
            "    order by h.UPDATED_AT\n" +
            "    fetch first row only"})
    Integer findFreeOperatorIdFor(@Param("appId") Integer applicationId, @Param("amountSkipLimit") BigDecimal amountSkipLimit);

    @Select({"select u.ID\n" +
            "from APP_USER u\n" +
            "         join USER_STATUS_HISTORY h on u.STATUS_HISTORY_ID = h.ID\n" +
            "         join USER_STATUS st on h.STATUS_ID = st.ID\n" +
            "where st.CODE != 'ABSENT'\n" +
            "  and h.ROLE_ID = 'UNDERWRITER'\n" +
            "  and u.DIVISION_ID IN (#{divisionIds})\n" +
            "  and exists(select *\n" +
            "             from APP_USER_SKILL_GROUP ug\n" +
            "                      join APPLICATION a on ug.GROUP_ID = a.SKILL_GROUP_ID\n" +
            "             where ug.USER_ID = u.ID\n" +
            "               and a.ID = #{appId} and (u.LIMIT >= #{amountSkipLimit, jdbcType=NUMERIC} or u.LIMIT >= a.REQUESTED_CREDIT_AMOUNT))\n" +
            "order by h.UPDATED_AT\n" +
            "fetch first row only"})
    @Lang(MybatisExtendedLanguageDriver.class)
    Integer findFreeOperatorIdByDivision(@Param("appId") Long applicationId,
                                         @Param("amountSkipLimit") BigDecimal amountSkipLimit,
                                         @Param("divisionIds") List<Long> divisionIds);

    @Select(BASE_SELECT_SQL + "where u.UPDATED_AT < #{dateTime, jdbcType=TIMESTAMP}")
    @ResultMap("userMapping")
    List<User> findByUpdatedAtLessThan(@Param("dateTime") LocalDateTime dateTime);

    @Select(BASE_SELECT_SQL + "where u.DISABLED_AT is null order by u.FULL_NAME")
    @ResultMap("userMapping")
    List<User> listActive();

    @Select(BASE_SELECT_SQL + "where u.DISABLED_AT is null\n" +
            "  and exists(\n" +
            "        select *\n" +
            "        from APPLICATION a\n" +
            "               join APP_USER_SKILL_GROUP usg on a.SKILL_GROUP_ID = usg.GROUP_ID\n" +
            "        where a.id = #{applicationId}\n" +
            "          and usg.USER_ID = u.ID and (u.LIMIT >= #{amountSkipLimit, jdbcType=NUMERIC} or u.LIMIT >= a.REQUESTED_CREDIT_AMOUNT)) \n" +
            "order by u.FULL_NAME")
    @ResultMap("userMapping")
    List<User> listActiveFor(@Nonnull @Param("applicationId") Integer applicationId, @Param("amountSkipLimit") BigDecimal amountSkipLimit);

    @Select("select id\n" +
            "from APP_USER\n" +
            "       join APP_USER_ROLE aur on APP_USER.ID = aur.USER_ID\n" +
            "where ROLE_ID = #{role, jdbcType=VARCHAR}")
    Set<Integer> findUsersIdByRole(@Param("role") Role role);

    @Select(FIND_USER_TO_ASSIGN_SQL)
    List<User> findFreeUsers(@Param("currentTime") LocalDateTime currentTime,
                             @Param("appStatusTimeout") Integer appStatusTimeout,
                             @Param("userStatusTimeout") Integer userStatusTimeout);

    @Select(BASE_SELECT_SQL + "where u.ID in (#{ids})\n" +
            "order by u.FULL_NAME")
    @ResultMap("userMapping")
    @Lang(MybatisExtendedLanguageDriver.class)
    List<User> listByIds(@Param("ids") Set<Integer> ids);

    @Select(FIND_USER_TO_ASSIGN_SQL)
    @Results(value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "fullName", column = "EXTENDED_NAME"),
            @Result(property = "username", column = "USERNAME"),
            @Result(property = "lastCompleteStatus", column = "LAST_COMPLETE_STATUS"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "limit", column = "LIMIT"),
    })
    List<FreeUserInfo> getFreeUserInfo(@Param("currentTime") LocalDateTime currentTime,
                                       @Param("appStatusTimeout") Integer appStatusTimeout,
                                       @Param("userStatusTimeout") Integer userStatusTimeout);

    @Select("select coalesce(decode(USER_SKILL_GROUP, null, null, USER_ID), decode(SUPER_SKILL_GROUP, null, null, SUPERVISOR_ID))\n" +
            "from (\n" +
            "         select u.ID            as USER_ID,\n" +
            "                U.SUPERVISOR_ID as SUPERVISOR_ID,\n" +
            "                usg.GROUP_ID    as USER_SKILL_GROUP,\n" +
            "                ssg.GROUP_ID    as SUPER_SKILL_GROUP\n" +
            "         from application a\n" +
            "                  join CHECK_CONCLUSION_HISTORY cch on cch.APPLICATION_ID = a.id\n" +
            "                  join APP_USER u on u.id = cch.USER_ID\n" +
            "                  left join APP_USER_SKILL_GROUP usg on usg.USER_ID = u.id and usg.GROUP_ID = #{skillGroupId, jdbcType=INTEGER}\n" +
            "                  left join APP_USER s on s.id = u.SUPERVISOR_ID\n" +
            "                  left join APP_USER_SKILL_GROUP ssg on ssg.USER_ID = s.id and ssg.GROUP_ID = #{skillGroupId,jdbcType=INTEGER}\n" +
            "         where CLIENT_ID = #{clientId, jdbcType= INTEGER}\n" +
            "           and DECISION_MAKER = 'UNDERWRITING'\n" +
            "         order by cch.CREATED_AT desc\n" +
            "         fetch first row only)")
    @Nullable
    Integer getUserIdByClientIdAndSkillGroup(@Param("clientId") Integer clientId,
                                             @Param("skillGroupId") Integer skillGroupId);

    @Update("update APP_USER\n" +
            "set SUBDIVISION_ID = #{subdivisionId}\n" +
            "where id in (select id from app_user where id = #{supervisorId} or SUPERVISOR_ID = #{supervisorId})")
    void updateSubdivision(@Param("supervisorId") Integer supervisorId, @Param("subdivisionId") Integer subdivisionId);

    @Select(SELECT_BY_SUBDIVISION + " where u.DISABLED_AT is null " +
            "and u.SUBDIVISION_ID <> #{excludeSubId, jdbcType = INTEGER} order by u.USERNAME")
    @ResultMap("userMapping")
    List<User> listBySubdivision(@Param("subdivisionId") Integer subdivisionId,
                                 @Param("excludeSubId") Integer excludeSubId);

    @Select("select u.ID\n" +
            "from APP_USER u\n" +
            "where exists(\n" +
            "              select * from APP_USER_ROLE ur where ur.USER_ID = u.ID and ROLE_ID in (#{role})\n" +
            "          )")
    @Lang(MybatisExtendedLanguageDriver.class)
    List<Integer> listIdWithRoles(@NotEmpty @Param("role") List<Role> roles);
}
