package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.Education;

import java.util.List;

@Mapper
public interface EducationDao {

    @Select("select " +
            "  IND, " +
            "  NAME, " +
            "  SCORIND, " +
            "  DATECHANGE, " +
            "  ACTIV, " +
            "  IDCOUNTRY, " +
            "  CODEID " +
            "from EDUCATION")
    @Results(id = "educationMapping", value = {
            @Result(property = "id", column = "IND"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "scoringId", column = "SCORIND"),
            @Result(property = "updatedAt", column = "DATECHANGE"),
            @Result(property = "active", column = "ACTIV"),
            @Result(property = "countryId", column = "IDCOUNTRY"),
            @Result(property = "codeId", column = "CODEID")
    })
    List<Education> findAll();

    @Select("select * from EDUCATION where IND = #{id}")
    @ResultMap("educationMapping")
    Education findById(Integer id);
}
