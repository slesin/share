package ru.rsb.eurion.service.application;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.Application;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;

@Getter
@Setter
public class PostponeRequest {
    @NotNull
    @Valid
    private Application application;

    /**
     * Тип отсрочки работы над заявкой
     */
    @NotNull
    private PostponeKind kind;

    /**
     * Время в часовом поясе клиента
     */
    private ZonedDateTime toDate;

    /**
     * Кол-во минут, на которая откладывается заявка (не более 4 часов в текущей постановке)
     */
    private Integer minutes;

    private String comment;

    public enum PostponeKind {
        PERIOD,

        TO_DATE
    }
}
