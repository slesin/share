package ru.rsb.eurion;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import javax.annotation.Nonnull;
import java.io.IOException;

import static java.nio.charset.StandardCharsets.UTF_8;

@Component
@Slf4j
public class CustomClientHttpRequestInterceptor implements ClientHttpRequestInterceptor {

    @Nonnull
    @Override
    public ClientHttpResponse intercept(@Nonnull HttpRequest request,
                                        @Nonnull byte[] bytes,
                                        @Nonnull ClientHttpRequestExecution execution) throws IOException {
        log.debug("Client request:{} {}\n{}", request.getMethod(), request.getURI(), new String(bytes, UTF_8));
        ClientHttpResponse response = execution.execute(request, bytes);
        log.debug("Client response: {}", response.getStatusCode());
        String responseBody = StreamUtils.copyToString(response.getBody(), UTF_8);
        log.trace("Body:\n{}", responseBody);
        return response;
    }
}
