package ru.rsb.eurion.service.check.protocol.history.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Column {

    private String value;

    private Integer idx;
}
