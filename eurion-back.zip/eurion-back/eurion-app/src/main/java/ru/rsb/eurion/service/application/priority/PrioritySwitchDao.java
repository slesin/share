package ru.rsb.eurion.service.application.priority;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.priority.PrioritySwitch;

@Mapper
public interface PrioritySwitchDao {
    @Select({"select IS_REVERSE, COUNTER from PRIORITY_SWITCH for update"})
    @Results({
            @Result(column = "IS_REVERSE", property = "reverse"),
            @Result(column = "COUNTER", property = "counter")
    })
    PrioritySwitch loadWithLock();

    @Update("update PRIORITY_SWITCH set IS_REVERSE = #{switch.reverse}, COUNTER = #{switch.counter}")
    void update(@Param("switch") PrioritySwitch prioritySwitch);
}
