package ru.rsb.eurion.service.application.history;

public enum ExternalSystem {
    FRONT,
    PO_CREDIT
}
