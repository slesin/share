package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class DeclineCategory extends BasicReference {
    private String code;

    private List<DeclineReason> declineReasons;
}
