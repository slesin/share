package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Свойства из заявки, влияющие на приоритет заявки
 */
@Getter
@Setter
public class ApplicationPriorityAttributes {
    private String applicationRegionCode;
    private String clientKladrCode;
    private BigDecimal creditAmount;
    private Integer saleChannelId;
    private Integer attractionChannelId;
    private Long cardTypeId;
    private Integer skillGroupId;
    private LocalDate monthlyPaymentDate;
}
