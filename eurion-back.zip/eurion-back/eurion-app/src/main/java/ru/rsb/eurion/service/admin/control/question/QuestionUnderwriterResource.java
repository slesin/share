package ru.rsb.eurion.service.admin.control.question;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Context;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;
import ru.rsb.eurion.domain.ControlQuestion;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.ResultWrapper;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Slf4j
@AllArgsConstructor
@RequestMapping(path = EurionApplication.API_BASE + "/question", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
public class QuestionUnderwriterResource {

    private final QuestionUnderwriterService questionUnderwriterService;

    @PostMapping("/ask")
    public ResultWrapper<List<ControlQuestion>> ask(@Context HttpServletRequest request) throws BusinessException {
        Integer userId = AuthUtil.loggedUser().getId();
        String sessionId = AuthUtil.getSessionId(request.getSession());
        List<ControlQuestion> questionList = questionUnderwriterService.getQuestions(userId, sessionId, request);
        return ResultWrapper.of(questionList);
    }

    @PostMapping("/{questionId}/answer/{answerId}")
    public void answer(@PathVariable Integer questionId, @PathVariable Integer answerId,
                       @Context HttpServletRequest request) throws BusinessException {
        Integer userId = AuthUtil.loggedUser().getId();
        String sessionId = AuthUtil.getSessionId(request.getSession());
        questionUnderwriterService.saveAnswer(userId, sessionId, request, questionId, answerId);
    }

    @PostMapping("/mayEnter/{role}")
    public ResultWrapper<Boolean> mayEnter(@PathVariable String role,
                                           @Context HttpServletRequest request) throws BusinessException {
        if (questionUnderwriterService.noNeedToLogin(role)) {
            return ResultWrapper.of(true);
        }
        Integer userId = AuthUtil.loggedUser().getId();
        String sessionId = AuthUtil.getSessionId(request.getSession());
        boolean mayEnter = questionUnderwriterService.mayEnter(userId, sessionId, request);
        return ResultWrapper.of(mayEnter);
    }
}
