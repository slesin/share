package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface SocialStatusDao {

    @Select("select " +
            "  C_SOCSTATUS, " +
            "  NAME, " +
            "  SITE_VISIBLE " +
            "from SOCIAL_STATUS order by C_SOCSTATUS")
    @Results(id = "socialStatusMapping", value = {
            @Result(property = "id", column = "C_SOCSTATUS"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "isSiteVisible", column = "SITE_VISIBLE"),
    })
    List<SocialStatus> findAll();

    @Select("select * from SOCIAL_STATUS where C_SOCSTATUS = #{id}")
    @ResultMap("socialStatusMapping")
    SocialStatus findById(Integer id);
}
