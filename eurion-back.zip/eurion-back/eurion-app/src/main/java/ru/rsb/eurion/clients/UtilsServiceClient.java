package ru.rsb.eurion.clients;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import ru.rsb.eurion.service.admin.users.upd.BaseEisClient;
import ru.rsb.eurion.service.check.protocol.history.dto.Column;
import ru.rsb.eurion.service.check.protocol.history.dto.ColumnDefinition;
import ru.rsb.eurion.service.check.protocol.history.dto.Columns;
import ru.rsb.eurion.service.check.protocol.history.dto.Data;
import ru.rsb.eurion.service.check.protocol.history.dto.ProcedureParam;
import ru.rsb.eurion.service.check.protocol.history.dto.ProcedureRequest;
import ru.rsb.eurion.service.check.protocol.history.dto.ProcedureResponse;
import ru.rsb.eurion.service.check.protocol.history.dto.ResultSet;
import ru.rsb.eurion.service.check.protocol.history.dto.Row;
import ru.rsb.eurion.settings.EisConfig;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@AllArgsConstructor
@Service
public class UtilsServiceClient extends BaseEisClient {
    public static final DateTimeFormatter ISO_LOCAL_DATE_TIME = new DateTimeFormatterBuilder()
            .parseCaseInsensitive()
            .append(DateTimeFormatter.ISO_LOCAL_DATE)
            .appendLiteral(' ')
            .append(DateTimeFormatter.ISO_LOCAL_TIME)
            .toFormatter();

    private final EisConfig eisConfig;

    public Stream<DataRow> executeProcedure(@Nonnull String procedureName, @Nonnull ProcedureParam... params) {
        ProcedureRequest request = new ProcedureRequest();
        request.setProcedure(procedureName);
        request.setParams(
                Stream.of(params)
                        .collect(Collectors.toList())
        );
        ProcedureResponse response =
                executePost(ProcedureResponse.class, eisConfig.getEisExecuteProcedureJsonUrl(), request, MediaType.APPLICATION_JSON, Collections.emptyMap());

        if (!response.getResultSet().isEmpty()) {
            ResultSet resultSet = response.getResultSet().get(0);
            Map<String, Integer> columnIdx = Optional.ofNullable(resultSet.getColumns())
                    .map(Columns::getColumn)
                    .map(List::stream)
                    .map(stream ->
                            stream.collect(Collectors.toMap(ColumnDefinition::getValue, ColumnDefinition::getIdx)))
                    .orElseGet(Collections::emptyMap);


            return Optional.ofNullable(resultSet.getData())
                    .map(Data::getRows)
                    .map(rows -> rows.stream()
                            .map(row -> new DataRow(row, columnIdx))
                    )
                    .orElse(Stream.empty());

        }

        return Stream.empty();
    }


    @AllArgsConstructor(access = AccessLevel.PRIVATE)
    public static class DataRow {
        private final Row target;
        private final Map<String, Integer> columnIdx;

        @Nullable
        public String getString(@Nonnull String name) {
            Integer idx = findIndex(name);
            return Optional.ofNullable(idx)
                    .flatMap(index -> target.getColumns().stream()
                            .filter(column -> Objects.equals(idx, column.getIdx()))
                            .findFirst())
                    .map(Column::getValue)
                    .orElse(null);
        }

        @Nullable
        public LocalDateTime getLocalDateTime(@Nonnull String name) {
            String value = getString(name);
            return !StringUtils.isBlank(value) ?
                    LocalDateTime.parse(value, UtilsServiceClient.ISO_LOCAL_DATE_TIME) : null;
        }

        @Nullable
        public Integer getInt(@Nonnull String name) {
            String value = getString(name);
            return !StringUtils.isBlank(value) ? Integer.parseInt(value) : null;
        }

        @Nullable
        public BigDecimal getBigDecimal(String name) {
            String value = getString(name);
            return !StringUtils.isBlank(value) ? new BigDecimal(value) : null;
        }

        @Nullable
        private Integer findIndex(String name) {
            Integer idx = columnIdx.get(name);
            if (idx == null) {
                // пробуем найти case insensitive
                Map.Entry<String, Integer> foundEntry = columnIdx.entrySet().stream()
                        .filter(entry -> name.equalsIgnoreCase(entry.getKey()))
                        .findFirst()
                        .orElse(null);
                if (foundEntry == null) {
                    return null;
                }
                idx = foundEntry.getValue();
            }
            return idx;
        }
    }
}
