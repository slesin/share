package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.service.phone.PhoneDetail;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface PhoneDetailDao {

    String BASE_SQL = "select\n" +
            "  ID,\n" +
            "  CLIENT_ID,\n" +
            "  SOURCE_TYPE_ID,\n" +
            "  PHONE_TYPE_ID,\n" +
            "  PREFIX,\n" +
            "  PHONE_NUMBER,\n" +
            "  CREATED_AT,\n" +
            "  UPDATED_AT,\n" +
            "  DISABLED_AT,\n" +
            "  REMARK\n" +
            "from PHONE_DETAIL ";

    @Select(BASE_SQL + "where CLIENT_ID = #{clientId, jdbcType=INTEGER}")
    @Results(id = "phoneDetailMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "clientId", column = "CLIENT_ID"),
            @Result(property = "sourceTypeId", column = "SOURCE_TYPE_ID"),
            @Result(property = "typeId", column = "PHONE_TYPE_ID"),
            @Result(property = "prefix", column = "PREFIX"),
            @Result(property = "number", column = "PHONE_NUMBER"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "remark", column = "REMARK")
    })
    List<PhoneDetail> listByClientId(@Param("clientId") Integer clientId);

    @Insert("INSERT INTO PHONE_DETAIL (CLIENT_ID, SOURCE_TYPE_ID, PHONE_TYPE_ID, PREFIX, PHONE_NUMBER, CREATED_AT, REMARK)\n" +
            "VALUES (#{clientId, jdbcType=INTEGER},\n" +
            "        #{phoneDetail.sourceTypeId, jdbcType=VARCHAR},\n" +
            "        #{phoneDetail.typeId, jdbcType=VARCHAR},\n" +
            "        #{phoneDetail.prefix, jdbcType=VARCHAR},\n" +
            "        #{phoneDetail.number, jdbcType=VARCHAR},\n" +
            "        #{phoneDetail.createdAt, jdbcType = TIMESTAMP},\n" +
            "        #{phoneDetail.remark, jdbcType = VARCHAR})")
    @SelectKey(
            keyProperty = "phoneDetail.id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_phone_detail.currval AS id from dual"}
    )
    void create(@Param("clientId") Integer clientId,
                @Param("phoneDetail") PhoneDetail phoneDetail,
                @Param("createdAt") LocalDateTime createdAt);

    @Select(BASE_SQL + "where ID = #{id} AND DISABLED_AT IS NULL")
    @ResultMap("phoneDetailMapping")
    PhoneDetail findOne(@Param("id") Integer id);

    @Update("UPDATE PHONE_DETAIL SET DISABLED_AT = #{disabledAt}   WHERE ID = #{id}")
    void delete(@Param("id") Integer id, @Param("disabledAt") LocalDateTime disabledAt);

    @Update("UPDATE PHONE_DETAIL\n" +
            "SET SOURCE_TYPE_ID = #{phoneDetail.sourceTypeId, jdbcType=INTEGER},\n" +
            "  PHONE_TYPE_ID    = #{phoneDetail.typeId, jdbcType=VARCHAR},\n" +
            "  PREFIX           = #{phoneDetail.prefix, jdbcType=VARCHAR},\n" +
            "  PHONE_NUMBER     = #{phoneDetail.number, jdbcType=VARCHAR},\n" +
            "  UPDATED_AT       = #{updatedAt, jdbcType=TIMESTAMP},\n" +
            "  REMARK           = #{phoneDetail.remark, jdbcType=VARCHAR}\n" +
            "WHERE ID = #{phoneDetail.id} AND CLIENT_ID = #{phoneDetail.clientId}")
    void update(@Param("phoneDetail") PhoneDetail phoneDetail,
                @Param("updatedAt") LocalDateTime localDateTime);
}
