package ru.rsb.eurion.service.application.priority.handler;

import org.springframework.stereotype.Component;
import ru.rsb.eurion.service.application.priority.ApplicationIdxDynamicSqlSupport;

import static ru.rsb.eurion.service.application.priority.ApplicationPriorityService.PRIORITY_HANDLER_PREFIX;

@Component(PRIORITY_HANDLER_PREFIX + "OUT_OF_PHONE_TIME")
public class OutOfPhoneTimePriorityParameterHandler extends SimplePriorityParameterHandler {

    public OutOfPhoneTimePriorityParameterHandler() {
        super(ApplicationIdxDynamicSqlSupport.IS_OUT_OF_DIAL_TIME);
    }
}
