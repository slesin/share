package ru.rsb.eurion.service.application;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationIdx;
import ru.rsb.eurion.domain.ApplicationPriorityAttributes;
import ru.rsb.eurion.rtdm.application.AddApplicationRequest;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ApplicationViewMapper {

    @Mappings({
            @Mapping(source = "client.clientId", target = "clientId"),
            @Mapping(source = "requestInfo.rtdmId", target = "rtdmId"),
            @Mapping(source = "client.passport.lastName", target = "lastName"),
            @Mapping(source = "client.passport.firstName", target = "firstName"),
            @Mapping(source = "client.passport.middleName", target = "middleName"),
            @Mapping(source = "client.novel", target = "novel"),
            @Mapping(source = "product.blankId", target = "blankId"),
            @Mapping(source = "client.passport.birthDate", target = "birthDate"),
            @Mapping(source = "product.creditAmount", target = "creditAmount"),
            @Mapping(source = "client.homeAddress.regionCode", target = "clientRegionCode"),
            @Mapping(source = "client.passport.passportNumber", target = "passportNumber"),
            @Mapping(source = "client.passport.passportSeries", target = "passportSeries"),
            @Mapping(source = "product.productType", target = "productType"),
            @Mapping(source = "requestInfo.saleChannelId", target = "creditSaleChannelId"),
            @Mapping(source = "requestInfo.regionCode", target = "applicationRegionCode"),
            @Mapping(source = "contact.mobilePhone", target = "mobilePhone"),
            @Mapping(source = "requestInfo.branchId", target = "branchId"),
            @Mapping(source = "requestInfo.attractionChannelId", target = "creditAttractionChannelId"),
            @Mapping(source = "product.reqCreditAmount", target = "requestedCreditAmount"),
            @Mapping(source = "requestInfo.requestedBranchName", target = "requestedBranchName"),
            @Mapping(source = "client.homeAddress.region", target = "clientRegion"),
            @Mapping(source = "requestInfo.branchName", target = "branchName"),
            @Mapping(source = "product.creditType", target = "creditType"),
            @Mapping(source = "requestInfo.authorFullName", target = "authorFullName"),
            @Mapping(source = "requestInfo.authorId", target = "authorId")
    })
    void mapToApplicationEntity(AddApplicationRequest request, @MappingTarget ApplicationEntity target);

    @Mappings({
            @Mapping(source = "requestInfo.regionCode", target = "applicationRegionCode"),
            @Mapping(source = "client.homeAddress.regionCode", target = "clientKladrCode"),
            @Mapping(source = "product.creditAmount", target = "creditAmount"),
            @Mapping(source = "requestInfo.saleChannelId", target = "saleChannelId"),
            @Mapping(source = "requestInfo.attractionChannelId", target = "attractionChannelId"),
            @Mapping(source = "product.cardTypeId", target = "cardTypeId"),
            @Mapping(source = "requestInfo.skillGroupId", target = "skillGroupId"),
            @Mapping(source = "product.monthlyPaymentDate", target = "monthlyPaymentDate")
    })
    ApplicationPriorityAttributes mapToPriority(AddApplicationRequest request);

    @Mappings({
            @Mapping(source = "id", target = "id"),
            @Mapping(source = "createdAt", target = "createDate"),
            @Mapping(source = "rtdmPriority.id", target = "rtdmPriority"),
            @Mapping(target = "skillGroup", source = "skillGroup.priority"),
            @Mapping(target = "regionAppPriority", source = "regionAppPriority"),
            @Mapping(target = "regionClientPriority", source = "regionClientPriority"),
            @Mapping(target = "amountPriority", source = "amountPriority"),
            @Mapping(target = "supervisorPriority", source = "supervisorPriority"),
            @Mapping(target = "channelPriority", source = "channelPriority"),
            @Mapping(target = "attractChannelPriority", source = "attractChannelPriority"),
            @Mapping(target = "productPriority", source = "productPriority"),
            @Mapping(target = "novel", source = "novel"),
            @Mapping(target = "fraudReturn", source = "fraudReturn"),
            @Mapping(target = "suspensiveTerms", source = "suspensiveTerms"),
            @Mapping(target = "outOfDialTime", source = "outOfDialTime"),
            @Mapping(source = "monthlyPaymentDate", target = "monthlyPaymentDate")
    })
    ApplicationIdx mapToIndex(ApplicationEntity entity);
}
