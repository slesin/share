package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Страна
 */
@Setter
@Getter
public class Country extends BasicReference {

    private String countryCode;

    private boolean active;

    private String isoCode;
}
