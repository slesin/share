package ru.rsb.eurion;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import ru.rsb.eurion.settings.AppConfig;

import java.time.Duration;
import java.util.Collections;

@RequiredArgsConstructor
@Configuration
public class RestTemplateConfig {

    private final AppConfig appConfig;

    @Bean
    public RestTemplate getRestTemplate(RestTemplateBuilder restTemplateBuilder,
                                        CustomClientHttpRequestInterceptor customClientHttpRequestInterceptor) {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        BufferingClientHttpRequestFactory factory = new BufferingClientHttpRequestFactory(requestFactory);
        requestFactory.setOutputStreaming(false);

        return restTemplateBuilder
                .interceptors(Collections.singletonList(customClientHttpRequestInterceptor))
                .setReadTimeout(Duration.ofMillis(appConfig.getEisRequestTimeOut()))
                .setConnectTimeout(Duration.ofMillis(appConfig.getEisConnectionTimeOut()))
                .requestFactory(() -> factory)
                .build();
    }
}
