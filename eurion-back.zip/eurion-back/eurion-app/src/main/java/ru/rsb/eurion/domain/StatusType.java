package ru.rsb.eurion.domain;

public enum StatusType {
    WORK,
    ABSENT,
    DINNER,
    BREAK,
    TRAINING,
    MEETING,
    WORK_WITHOUT_APPLICATION
}
