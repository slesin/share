package ru.rsb.eurion.service.application.flow.api;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.flowable.engine.RuntimeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.service.application.ApplicationService;
import ru.rsb.eurion.service.application.history.ApplicationHistoryService;
import ru.rsb.eurion.service.application.priority.ApplicationPriorityService;

import static ru.rsb.eurion.service.application.flow.ApplicationProcessService.DEFAULT_USER_NAME;

@Service("process")
@Transactional
@AllArgsConstructor
@SuppressWarnings("unused")
@Slf4j
public class ProcessManagementService {
    private final ApplicationService applicationService;
    private final RuntimeService runtimeService;
    private final ApplicationHistoryService applicationHistoryService;
    private final ApplicationPriorityService priorityService;

    public void initQueue(Long applicationId) {
        ApplicationEntity entity = applicationService.findById(applicationId);
        log.info("Creating priority index record: {}", entity);
        priorityService.createIndexItem(entity);
        applicationService.setUser(applicationId, null, DEFAULT_USER_NAME);
    }

    public void stop(Integer id) {
        runtimeService.createProcessInstanceQuery()
                .processInstanceBusinessKey(FlowAPI.idToBusinessKey(id))
                .list()
                .forEach(processInstance -> runtimeService.deleteProcessInstance(processInstance.getId(), "restart"));
    }
}
