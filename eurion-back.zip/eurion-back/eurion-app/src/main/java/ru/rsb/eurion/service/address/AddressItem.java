package ru.rsb.eurion.service.address;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddressItem {

    private String name;

    private String guid;

}
