package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Тип продукта
 */
@Getter
@Setter
public class ProductType extends BasicReference {
}
