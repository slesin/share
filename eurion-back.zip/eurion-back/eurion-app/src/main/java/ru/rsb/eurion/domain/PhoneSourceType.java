package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.BasicReference;

/**
 * Тип источника телефона
 */
@Setter
@Getter
public class PhoneSourceType extends BasicReference {

    private Boolean inner;

}