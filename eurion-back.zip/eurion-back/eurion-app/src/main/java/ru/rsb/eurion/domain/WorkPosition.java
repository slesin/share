package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Должность
 */
@Setter
@Getter
public class WorkPosition extends BasicReference {

    private Integer scoringId;

    private boolean active;

    private Integer countryId;

    private Integer codeId;
}
