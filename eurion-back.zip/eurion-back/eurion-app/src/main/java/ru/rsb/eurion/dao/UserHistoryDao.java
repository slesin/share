package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.UserHistory;
import ru.rsb.eurion.service.admin.users.history.UseHistoryView;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface UserHistoryDao {

    String BASE_SELECT_SQL = "select uh.USER_ID,\n" +
            "       u.FULL_NAME,\n" +
            "       DECODE(uh.PROPERTY_NAME, 'skillGroupIds', 'Skill-группы', 'roles', 'Права', 'supervisor', 'Супервайзер', 'limit',\n" +
            "              'Лимит', 'hasUpdateLimitPermission', 'Расчет лимита', 'subdivisionId', 'Подразделение', 'UNKNOWN') AS PROPERTY_NAME,\n" +
            "       uh.OLD_VALUE,\n" +
            "       uh.NEW_VALUE,\n" +
            "       uh.ACTION_USER_ID as ACTION_USER_ID,\n" +
            "       au.FULL_NAME      as ACTION_USER_FULL_NAME,\n" +
            "       uh.UPDATED_AT\n" +
            "from USER_HISTORY uh\n" +
            "         left join app_user u on uh.USER_ID = u.ID\n" +
            "         left join app_user au on uh.ACTION_USER_ID = au.ID\n" +
            "where uh.UPDATED_AT between #{beginDate} and #{endDate}\n" +
            "order by uh.UPDATED_AT desc\n" +
            "    offset #{offset} rows\n" +
            "fetch first #{limit} rows only";

    @Insert("insert into USER_HISTORY (USER_ID, ACTION_USER_ID, PROPERTY_NAME, OLD_VALUE, NEW_VALUE, UPDATED_AT)\n" +
            "values (#{userHistory.userId, jdbcType = INTEGER},\n" +
            "    #{userHistory.actionUserId, jdbcType = INTEGER},\n" +
            "    #{userHistory.propertyName, jdbcType = VARCHAR},\n" +
            "    #{userHistory.oldValue, jdbcType = VARCHAR},\n" +
            "    #{userHistory.newValue, jdbcType = VARCHAR},\n" +
            "    #{userHistory.updatedAt, jdbcType = TIMESTAMP})")
    @SelectKey(
            keyProperty = "id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_user_history.currval AS id from dual"}
    )
    void insert(@Param("userHistory") UserHistory userHistory);

    @Select(BASE_SELECT_SQL)
    @Results(value = {
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "userFullName", column = "FULL_NAME"),
            @Result(property = "propertyName", column = "PROPERTY_NAME"),
            @Result(property = "oldValue", column = "OLD_VALUE"),
            @Result(property = "newValue", column = "NEW_VALUE"),
            @Result(property = "actionUserId", column = "ACTION_USER_ID"),
            @Result(property = "userActionFullName", column = "ACTION_USER_FULL_NAME"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
    })
    List<UseHistoryView> list(@Param("beginDate") LocalDateTime beginDate,
                              @Param("endDate") LocalDateTime endDate,
                              @Param("offset") int offset,
                              @Param("limit") int limit);

    @Select("select count(1) from USER_HISTORY where UPDATED_AT between #{beginDate} and #{endDate}")
    int userHistoryTotalCount(@Param("beginDate") LocalDateTime beginDate,
                              @Param("endDate") LocalDateTime endDate);
}
