package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Типы доходов
 */
@Setter
@Getter
public class IncomeType extends BasicReference {
}
