package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.BasicReference;

@Getter
@Setter
public class Department extends BasicReference {
}
