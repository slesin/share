package ru.rsb.eurion.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.admin.skill.group.CheckType;

import java.time.LocalDateTime;

@Setter
@Getter
public class ApplicationStatusHistoryView {

    private Integer rtdmId;

    private Integer blankId;

    private Integer clientId;

    private Integer skillGroupId;

    private String skillGroupName;

    private String actionInStatus;

    private LocalDateTime inputStatusDate;

    private LocalDateTime outputStatusDate;

    String inputUserPersonnelNumber;

    private String inputUserName;

    String outputUserPersonnelNumber;

    private String outputUserName;

    private String decisionComment;

    private String clientFullName;

    private String status;

    @JsonIgnore
    private String declineReason;

    @JsonIgnore
    private String declineCategory;

    private String declineText;

    @JsonIgnore
    private CheckType checkType;
}
