package ru.rsb.eurion.service.admin.users.history;

import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.list.SortDirection;
import ru.rsb.eurion.service.admin.Consts;

import java.time.LocalDate;
import java.util.List;

@RequestMapping(path = Consts.ADMIN_API_BASE + "/users/history", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class UserHistoryResource {
    private final UserHistoryService service;

    @GetMapping
    public PagedResult<UseHistoryView> loadOne(@DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam("beginDate") LocalDate beginDate,
                                               @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam("endDate") LocalDate endDate,
                                               @RequestParam(value = "offset", required = false, defaultValue = "0") int offset,
                                               @RequestParam(value = "limit", required = false, defaultValue = "10") int limit,
                                               @RequestParam(value = "sortBy", required = false, defaultValue = "updatedAt")
                                                       List<UserHistoryService.SortAvailable> sortBy,
                                               @RequestParam(value = "sortDir", required = false, defaultValue = "DESC") List<SortDirection> sortDir) {
        UserHistoryService.UserHistoryPageable pageable =
                new UserHistoryService.UserHistoryPageable(offset, limit, sortBy, sortDir);
        return service.loadUserHistory(beginDate, endDate, pageable);
    }
}
