package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import ru.rsb.eurion.service.application.history.ExternalSystem;

import java.time.LocalDateTime;

@Mapper
public interface ClientReviewHistoryDao {

    @Insert("insert into CLIENT_REVIEW_HISTORY (CLIENT_ID, SYSTEM_NAME, UPDATED_AT, USER_NAME)\n" +
            "values (#{clientId, jdbcType=INTEGER},\n" +
            "        #{externalSystem, jdbcType=VARCHAR},\n" +
            "        #{updatedAt, jdbcType=TIMESTAMP},\n" +
            "        #{userName, jdbcType=VARCHAR})")
    void insert(@Param("clientId") Integer clientId, @Param("externalSystem") ExternalSystem externalSystem,
                @Param("updatedAt") LocalDateTime updatedAt, @Param("userName") String userName);
}
