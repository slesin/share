package ru.rsb.eurion.service.admin.users.subdivision;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(of = {"id", "name"})
@EqualsAndHashCode(of = "id")
public class Subdivision {

    private Integer id;

    private Integer parentId;

    private String name;

    private Integer orderIdx;

}
