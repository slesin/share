package ru.rsb.eurion.service.application.statistics.productivity.dto;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.serializer.FormattedDurationSerializer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalTime;

@Getter
@Setter
public class UserProductivityByTime {

    public static final Duration ZERO_DURATION = Duration.ofMillis(0);
    private Integer userId;

    private String fullName;
    /**
     * Время входа в систему
     */
    private LocalTime loginAt;
    /**
     * Время последнего входа в систему в разрезе суток
     */
    private LocalTime lastLoginAt;
    /**
     * Время выхода из системы
     */
    private LocalTime logoutAt;
    /**
     * Время в статусе "На работе"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration workTime;
    /**
     * Время в статусе "Обед"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration dinnerTime;
    /**
     * Время в статусе "Перерыв"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration breakTime;
    /**
     * Время в статусе "Перерыв"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration meetingTime;
    /**
     * Время в статусе "Обучение"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration trainingTime;
    /**
     * Время в статусе "Нет на работе"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration absentTime;
    /**
     * Время в статусе "Дополнительная работа без заявок"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration additionalWorkWithOutApplicationTime;
    /**
     * Среднее вемя работы с заявкой
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration averageTimePerApplication;
    /**
     * Количество принятых решений (Одобрить, Отказать) по заявка в час
     */
    private BigDecimal applicationDecisionPerHour;
    /**
     * Производительность
     */
    private BigDecimal productivityPercent;
    /**
     * Текущий статус
     */
    private String status;

    public UserProductivityByTime() {
        this.workTime = ZERO_DURATION;
        this.dinnerTime = ZERO_DURATION;
        this.breakTime = ZERO_DURATION;
        this.meetingTime = ZERO_DURATION;
        this.trainingTime = ZERO_DURATION;
        this.absentTime = ZERO_DURATION;
        this.additionalWorkWithOutApplicationTime = ZERO_DURATION;
        this.averageTimePerApplication = ZERO_DURATION;
        this.applicationDecisionPerHour = BigDecimal.ZERO;
        this.productivityPercent = BigDecimal.ZERO;
    }
}
