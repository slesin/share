package ru.rsb.eurion.domain;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Setter
@Getter
@EqualsAndHashCode
public class RoleProductivitySettings {
    /**
     * Идентиикатор роли
     */
    private Integer roleId;
    /**
     * Наименование роли
     */
    private String roleName;
    /**
     * Процент одобрения
     */
    private BigDecimal approvePercent;
    /**
     * Шаг сетки графика
     */
    private Integer stepPercent;
    /**
     * Норма выработки в процентах
     */
    private BigDecimal productionRatePercent;
    /**
     * Норма выработки в час
     */
    private Integer productionRatePerHour;
    /**
     * Дата создания
     */
    @EqualsAndHashCode.Exclude
    private LocalDateTime createdAt;
    /**
     * Дата редактирования
     */
    @EqualsAndHashCode.Exclude
    private LocalDateTime updatedAt;
    /**
     * Дата деактивации
     */
    private LocalDateTime disabledAt;
}
