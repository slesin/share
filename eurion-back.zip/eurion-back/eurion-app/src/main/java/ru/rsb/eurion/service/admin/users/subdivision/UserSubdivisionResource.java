package ru.rsb.eurion.service.admin.users.subdivision;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;

import java.util.Set;

@RequestMapping(path = EurionApplication.API_BASE + "/users/subdivision", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class UserSubdivisionResource {

    private final SubdivisionService service;

    @GetMapping
    public OrgTreeNode getSubdivisionTree() {
        return service.getOrgItemTree();
    }

    @GetMapping(path = "/list")
    public Set<Subdivision> getSubdivisionList() {
        return service.getSubdivisionSet();
    }
}
