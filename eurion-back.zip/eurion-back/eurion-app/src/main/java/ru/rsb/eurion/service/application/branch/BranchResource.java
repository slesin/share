package ru.rsb.eurion.service.application.branch;


import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;

import javax.validation.constraints.NotNull;

@RequestMapping(path = EurionApplication.API_BASE + "/branch")
@RestController
@AllArgsConstructor
public class BranchResource {

    private final BranchService service;

    @GetMapping(path = "/{id}")
    public BranchItem getById(@NotNull @PathVariable("id") Long id) {
        return service.getById(id);
    }

    @GetMapping(path = "/by-external-id/{externalId}")
    public BranchItem getByExternalId(@NotNull @PathVariable("externalId") Long externalId) {
        return service.getByExternalId(externalId);
    }

}
