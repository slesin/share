package ru.rsb.eurion.security;

import lombok.Getter;

@Getter
public class NotFoundInADException extends Exception {
    private final String username;

    public NotFoundInADException(String username) {
        super("User not found in Active Directory: " + username);
        this.username = username;
    }
}
