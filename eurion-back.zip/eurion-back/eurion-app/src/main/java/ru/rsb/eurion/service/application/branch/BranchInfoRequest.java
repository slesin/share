package ru.rsb.eurion.service.application.branch;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BranchInfoRequest {
    /**
     * Необходимо ли получать значения справочников
     */
    private boolean returnReferenceValues;
    /**
     * Доступно для отображения на сайте
     */
    private Integer siteVisible;

}
