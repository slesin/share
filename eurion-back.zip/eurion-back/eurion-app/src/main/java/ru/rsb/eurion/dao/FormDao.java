package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.Form;

import java.util.List;

@Mapper
public interface FormDao {

    @Select("SELECT ID, NAME, CREATED_AT, UPDATED_AT, DISABLED_AT, CODE FROM FORM WHERE ID = #{formId}")
    @Results(id = "formMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "code", column = "CODE")
    })
    @SuppressWarnings("unused")
    Form findById(@Param("formId") Integer formId);

    @Select("SELECT ID, NAME, CREATED_AT, UPDATED_AT, DISABLED_AT, CODE FROM FORM ORDER BY ORDER_IDX")
    @ResultMap("formMapping")
    List<Form> findAll();

    @Select("SELECT ID, NAME, CREATED_AT, UPDATED_AT, DISABLED_AT, CODE FROM FORM WHERE CODE = #{code} ")
    @ResultMap("formMapping")
    Form findByCode(@Param("code") String code);
}
