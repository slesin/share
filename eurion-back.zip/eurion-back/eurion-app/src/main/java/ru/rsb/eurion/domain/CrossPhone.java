package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Пересечения телефонов
 */
@Getter
@Setter
public class CrossPhone {
    /**
     * Тип пересечения
     */
    private String crossType;
    /**
     * Количество клиентов
     */
    private Integer clientCount;
}
