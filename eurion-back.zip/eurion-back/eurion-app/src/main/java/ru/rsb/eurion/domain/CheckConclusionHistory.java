package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.rtdm.application.RtdmDecisionCode;

import java.util.List;
import java.util.Set;

/**
 * Историчные значения протоколов проверок в разрезе смены скилл-групп.
 */
@Getter
@Setter
public class CheckConclusionHistory extends BaseEntity {
    private DecisionMaker decisionMaker;

    private SkillGroup skillGroup;

    /**
     * Описания форм, сериализованные в JSON.
     */
    private String formDefinitions;

    /**
     * Значения форм, сериализованные в JSON
     */
    private String formConclusions;

    /**
     * Решение по заявке
     */
    private ApplicationDecision decision;
    /**
     * Причина принятия решения
     */
    private Set<Integer> declineReasonIds;

    /**
     * Решение по заявке
     */
    private RtdmDecisionCode rtdmDecision;

    /**
     * Текстовое описание о причинах решения по заявке
     */
    private String decisionComment;

    /**
     * Пользователь Андеррайтинга, принявший решение по заявке
     */
    private BasicReference user;

    public enum DecisionMaker {
        RTDM,
        UNDERWRITING,
        AUTHOR,
        VERIFICATION
    }
}
