package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Тип контактов
 */
@Getter
@Setter
public class ContactType extends BasicReference {

}
