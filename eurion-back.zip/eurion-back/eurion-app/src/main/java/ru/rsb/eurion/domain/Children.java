package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Children extends BasicReference {

}
