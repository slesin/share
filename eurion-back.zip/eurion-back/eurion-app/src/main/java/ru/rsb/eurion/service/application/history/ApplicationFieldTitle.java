package ru.rsb.eurion.service.application.history;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.BasicReference;

@Setter
@Getter
public class ApplicationFieldTitle extends BasicReference {
    /**
     * Путь к полю
     */
    private String path;
    /**
     * Имя блока
     */
    private String blockName;
}
