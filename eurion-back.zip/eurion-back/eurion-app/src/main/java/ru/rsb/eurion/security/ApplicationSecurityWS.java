package ru.rsb.eurion.security;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.settings.AppConfig;

import static ru.rsb.eurion.EurionApplication.WS_API_BASE;

@Order(1)
@Component("ws")
@Slf4j
@AllArgsConstructor
public class ApplicationSecurityWS extends WebSecurityConfigurerAdapter {
    private static final String REALM_NAME = "RTDM";
    private static final String WS_MATCHER = WS_API_BASE + "/**";

    private final AuthProviderWS authProviderWS;
    private final AppConfig config;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(authProviderWS);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        if (config.isApplicationProviderAuth()) {
            log.info("Configuring security: {}", WS_MATCHER);
            http.antMatcher(WS_MATCHER)
                    .csrf().disable()
                    .httpBasic()
                    .realmName(REALM_NAME)
                    .and()
                    .requestCache()
                    .disable()
                    .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .and()
                    .authorizeRequests()
                    .antMatchers(WS_API_BASE + "/phone/**").hasAnyAuthority(AuthProviderWS.TELEPHONY_AUTHORITY, AuthProviderWS.EIS_AUTHORITY)
                    .antMatchers(WS_API_BASE + "/**").hasAuthority(AuthProviderWS.RTDM_AUTHORITY)
                    .antMatchers(HttpMethod.POST, "/**").permitAll();
        } else {
            http.antMatcher(WS_MATCHER)
                    .csrf().disable()
                    .anonymous()
                    .principal("anonymous");

        }
    }
}
