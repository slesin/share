package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.CreditSaleChannel;

import java.util.List;

@Mapper
public interface CreditSaleChannelDao {
    String BASE_SELECT_SQL = "select ID, CREATED_AT, UPDATED_AT, NAME, SORT_PRIORITY, ENABLED from CREDIT_SALE_CHANNEL";

    @Select(BASE_SELECT_SQL + " order by ID")
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "priority", column = "SORT_PRIORITY"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "enabled", column = "ENABLED")
    })
    List<CreditSaleChannel> findAll();

    @Update("update CREDIT_SALE_CHANNEL set SORT_PRIORITY = #{priority}, updated_at = current_timestamp where ID = #{id}")
    void updatePriority(CreditSaleChannel creditSaleChannel);

    @Select(BASE_SELECT_SQL + " where ID = #{id,jdbcType=INTEGER}")
    CreditSaleChannel findById(@Param("id") Integer id);
}
