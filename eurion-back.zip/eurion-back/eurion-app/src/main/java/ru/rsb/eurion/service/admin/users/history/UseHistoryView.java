package ru.rsb.eurion.service.admin.users.history;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.UserHistory;

@Getter
@Setter
public class UseHistoryView extends UserHistory {

    @JsonIgnore
    private Integer id;

    private String userFullName;

    private String userActionFullName;
}
