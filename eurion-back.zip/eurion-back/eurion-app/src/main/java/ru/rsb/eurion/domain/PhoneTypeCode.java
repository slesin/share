package ru.rsb.eurion.domain;

public enum PhoneTypeCode {
    WORK,
    HOME,
    CONTACT,
    MOBILE,
    OTHER
}
