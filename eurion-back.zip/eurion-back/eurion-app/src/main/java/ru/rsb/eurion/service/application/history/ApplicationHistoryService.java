package ru.rsb.eurion.service.application.history;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.javers.core.Javers;
import org.javers.core.JaversBuilder;
import org.javers.core.diff.Diff;
import org.javers.core.diff.changetype.ValueChange;
import org.springframework.context.annotation.DependsOn;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.ApplicationFieldTitleDao;
import ru.rsb.eurion.dao.ApplicationStatusHistoryDao;
import ru.rsb.eurion.dao.ChildrenDao;
import ru.rsb.eurion.dao.ClientReviewHistoryDao;
import ru.rsb.eurion.dao.CountryDao;
import ru.rsb.eurion.dao.EducationDao;
import ru.rsb.eurion.dao.GenderDao;
import ru.rsb.eurion.dao.IndustryAffiliationDao;
import ru.rsb.eurion.dao.MaritalStatusDao;
import ru.rsb.eurion.dao.PhoneSourceDao;
import ru.rsb.eurion.dao.PhoneTypeDao;
import ru.rsb.eurion.dao.WorkPeriodDao;
import ru.rsb.eurion.dao.WorkPositionDao;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationStatusHistory;
import ru.rsb.eurion.domain.Children;
import ru.rsb.eurion.domain.Country;
import ru.rsb.eurion.domain.Education;
import ru.rsb.eurion.domain.Gender;
import ru.rsb.eurion.domain.IndustryAffiliation;
import ru.rsb.eurion.domain.MaritalStatus;
import ru.rsb.eurion.domain.PhoneSourceType;
import ru.rsb.eurion.domain.PhoneType;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.WorkPeriod;
import ru.rsb.eurion.domain.WorkPosition;
import ru.rsb.eurion.rtdm.application.AddApplicationRequest;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.admin.skill.group.CheckType;
import ru.rsb.eurion.service.admin.users.UserService;
import ru.rsb.eurion.service.application.ApplicationDao;
import ru.rsb.eurion.service.application.JsonTransformer;
import ru.rsb.eurion.service.application.StatusCode;
import ru.rsb.eurion.service.phone.PhoneDetail;
import ru.rsb.eurion.settings.AppConfig;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import static ru.rsb.eurion.service.application.history.ChangeFieldType.ANY_FIELD;
import static ru.rsb.eurion.service.application.history.ChangeFieldType.DECISION;
import static ru.rsb.eurion.service.application.history.ChangeFieldType.DOCUMENT;
import static ru.rsb.eurion.service.application.history.ChangeFieldType.PHONE;
import static ru.rsb.eurion.service.application.history.ChangeFieldType.RECOUNT;
import static ru.rsb.eurion.service.application.history.ChangeFieldType.SKILL_GROUP;
import static ru.rsb.eurion.service.application.history.ChangeFieldType.STATUS;
import static ru.rsb.eurion.service.application.history.ChangeFieldType.USER;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
@DependsOn("liquibase")
public class ApplicationHistoryService {

    private static final String QUEUE = "Очередь";

    private final ApplicationHistoryDao dao;
    private final ClientReviewHistoryDao clientReviewHistoryDao;
    private final GenderDao genderDao;
    private final CountryDao countryDao;
    private final EducationDao educationDao;
    private final MaritalStatusDao maritalStatusDao;
    private final ApplicationFieldTitleDao applicationFieldDao;
    private final ChildrenDao childrenDao;
    private final IndustryAffiliationDao industryAffiliationDao;
    private final WorkPeriodDao workPeriodDao;
    private final WorkPositionDao workPositionDao;
    private final PhoneTypeDao phoneTypeDao;
    private final PhoneSourceDao phoneSourceDao;
    private final AppConfig config;
    private final JsonTransformer jsonTransformer;
    private final ApplicationStatusHistoryDao applicationStatusHistoryDao;
    private final ApplicationDao applicationDao;
    private final UserService userService;

    private List<String> directoryPath = new ArrayList<>();

    @PostConstruct
    private void init() {
        String fieldPaths = config.getReferenceFieldPaths();
        directoryPath = Arrays.asList(fieldPaths.split(";"));
    }

    @Async
    public void saveApplicationHistory(Long applicationId, JsonNode oldApplication, JsonNode newApplication, String userName)
            throws JsonProcessingException {
        AddApplicationRequest oldRequest = jsonTransformer.treeToValue(oldApplication, AddApplicationRequest.class);
        AddApplicationRequest newRequest = jsonTransformer.treeToValue(newApplication, AddApplicationRequest.class);
        Javers javers = JaversBuilder.javers().build();
        Diff diff = javers.compare(oldRequest, newRequest);
        diff.getChangesByType(ValueChange.class)
                .forEach(valueChange -> handleChangedValues(applicationId, userName, valueChange));
    }

    public void saveUserHistory(Long applicationId, User oldUser, User newUser, String source) {
        if (oldUser != null || newUser != null) {
            String oldUserName = oldUser == null ? QUEUE : oldUser.getUsername();
            String newUserName = newUser == null ? QUEUE : newUser.getUsername();
            if (!Objects.equals(newUserName, oldUserName)) {
                dao.insert(LocalDateTime.now(), applicationId, source, USER, null, oldUserName, newUserName);
            }
        }
    }

    public void saveDecisionHistory(Long applicationId, ApplicationDecision oldDecision,
                                    ApplicationDecision newDecision, String userName) {
        if (oldDecision != newDecision) {
            String oldDecisionString = decisionToString(oldDecision);
            String newDecisionString = decisionToString(newDecision);
            dao.insert(LocalDateTime.now(), applicationId, userName, DECISION, null, oldDecisionString,
                    newDecisionString);
        }
    }

    public void saveStatusHistory(Long applicationId, String oldStatus, String newStatus, String source) {
        if (oldStatus != null && !oldStatus.equals(newStatus)) {
            dao.insert(LocalDateTime.now(), applicationId, source, STATUS, null, oldStatus,
                    newStatus);
        }
    }

    public void saveRecountHistory(Long applicationId, String userName) {
        dao.insert(LocalDateTime.now(), applicationId, userName, RECOUNT, null, null,
                null);
    }

    public void saveAdditionalDocumentHistory(Long applicationId, String username, String oldFileName,
                                              String newFileName, AdditionalDocumentActionType action) {
        String fieldName;
        switch (action) {
            case CREATE:
                fieldName = "/additionalDocument/create";
                break;
            case UPDATE:
                fieldName = "/additionalDocument/update";
                break;
            case DELETE:
                fieldName = "/additionalDocument/delete";
                break;
            default:
                throw new IllegalStateException("Unexpected additional document action type: " + action.toString());
        }
        dao.insert(LocalDateTime.now(), applicationId, username, DOCUMENT, fieldName, oldFileName, newFileName);
    }

    public void saveApplicationStatusHistory(Long applicationId, String userName, String status, StatusCode statusCode,
                                             String decisionComment, Set<Integer> declineIds) {
        ApplicationEntity app = applicationDao.findById(applicationId);
        CheckType checkType = app.getCheckType();
        ApplicationStatusHistory oldHistory = applicationStatusHistoryDao.findOne(applicationId, checkType);
        if (oldHistory == null || oldHistory.getStatusCode() != statusCode) {
            Long nextOrderNumber = oldHistory != null ? oldHistory.getOrderNumber() + 1 : 1L;
            ApplicationStatusHistory newStatusHistory = new ApplicationStatusHistory();
            newStatusHistory.setOrderNumber(nextOrderNumber);
            newStatusHistory.setApplicationId(app.getId());
            newStatusHistory.setRtdmId(app.getRtdmId());
            newStatusHistory.setBlankId(app.getBlankId());
            newStatusHistory.setClientId(app.getClientId());
            newStatusHistory.setSkillGroupId(app.getSkillGroup().getId());
            newStatusHistory.setCheckType(app.getCheckType());
            newStatusHistory.setStatus(status);
            newStatusHistory.setStatusCode(statusCode);
            newStatusHistory.setDecisionComment(decisionComment);
            String clientFullName = app.getLastName() + " " + app.getFirstName() + " " + app.getMiddleName();
            newStatusHistory.setClientFullName(clientFullName);
            LocalDateTime updatedAt = LocalDateTime.now();
            newStatusHistory.setUpdatedAt(updatedAt);
            User user = userService.findByUserName(userName);
            if (user != null) {
                newStatusHistory.setUserId(user.getId());
                newStatusHistory.setUserName(user.getName());
            } else {
                newStatusHistory.setUserName(userName);
            }
            applicationStatusHistoryDao.create(newStatusHistory);
            if (declineIds != null) {
                declineIds.forEach(reasonId -> applicationStatusHistoryDao.addDeclineReason(newStatusHistory.getId(), reasonId));
            }
        }
    }

    public void saveClientReview(Integer clientId, ExternalSystem system) {
        String currentUserName = AuthUtil.loggedUser().getUsername();
        clientReviewHistoryDao.insert(clientId, system, LocalDateTime.now(), currentUserName);
    }

    public List<ApplicationFieldTitle> getApplicationFieldTitle() {
        return applicationFieldDao.getApplicationFieldTitle();
    }

    public void saveClientPhoneHistory(@Nonnull Long applicationId,
                                       @Nullable PhoneDetail oldPhoneDetail,
                                       @Nullable PhoneDetail newPhoneDetail) {
        Javers javers = JaversBuilder.javers().build();

        oldPhoneDetail = oldPhoneDetail != null ? oldPhoneDetail : new PhoneDetail();
        newPhoneDetail = newPhoneDetail != null ? newPhoneDetail : new PhoneDetail();

        Diff diff = javers.compare(oldPhoneDetail, newPhoneDetail);
        String currentUserName = AuthUtil.loggedUser().getUsername();
        diff.getChangesByType(ValueChange.class).forEach(valueChange -> {
                    String oldValue = valueChange.getLeft() != null ? valueChange.getLeft().toString() : null;
                    String newValue = valueChange.getRight() != null ? valueChange.getRight().toString() : null;
                    String fieldPath = getNormalizePhoneDetailPath(valueChange);
                    if (directoryPath.contains(fieldPath)) {
                        oldValue = getReferenceValue(fieldPath, oldValue);
                        newValue = getReferenceValue(fieldPath, newValue);
                    }
                    dao.insert(LocalDateTime.now(), applicationId, currentUserName, PHONE, fieldPath,
                            oldValue, newValue);
                }
        );
    }

    private void handleChangedValues(Long applicationId, String userName, ValueChange valueChange) {
        String fieldPath = getNormalizePath(valueChange);
        ChangeFieldType type = getChangeFieldType(fieldPath);
        String oldValue = valueChange.getLeft() == null ? null : valueChange.getLeft().toString();
        String newValue = valueChange.getRight() == null ? null : valueChange.getRight().toString();
        if (directoryPath.contains(fieldPath)) {
            oldValue = getReferenceValue(fieldPath, oldValue);
            newValue = getReferenceValue(fieldPath, newValue);
        }
        log.debug("changed field: {}, fieldPath: {}, oldValue: {}, newValue {}", valueChange.getPropertyName(),
                fieldPath, oldValue, newValue);
        dao.insert(LocalDateTime.now(), applicationId, userName, type, fieldPath, oldValue, newValue);
    }

    private ChangeFieldType getChangeFieldType(String fieldPath) {
        if (fieldPath.equals("/requestInfo/skillGroupId")) {
            return SKILL_GROUP;
        }
        return ANY_FIELD;
    }

    @Nullable
    private Integer getId(@Nullable String oldValue, String fieldPath) {
        if (oldValue != null) {
            return Integer.valueOf(oldValue);
        }
        log.error("Incorrect reference id for field: " + fieldPath);
        return null;
    }

    @Nullable
    private String getReferenceValueById(String fieldPath, Integer id) {
        switch (fieldPath) {
            case "/client/passport/sexId":
                Gender gender = genderDao.findById(id);
                return gender != null ? gender.getName() : null;
            case "/client/passport/citizenshipId":
                Country country = countryDao.findById(id);
                return country != null ? country.getName() : null;
            case "/client/educationId":
                Education education = educationDao.findById(id);
                return education != null ? education.getName() : null;
            case "/client/maritalStatus/maritalStatus":
                MaritalStatus maritalStatus = maritalStatusDao.findById(id);
                return maritalStatus != null ? maritalStatus.getName() : null;
            case "/client/maritalStatus/childrenAmountRefId":
                Children children = childrenDao.findById(id);
                return children != null ? children.getName() : null;
            case "/job/industryId":
                IndustryAffiliation industryAffiliation = industryAffiliationDao.findById(id);
                return industryAffiliation != null ? industryAffiliation.getName() : null;
            case "/job/experienceId":
            case "/job/currentExperienceId":
                WorkPeriod workPeriod = workPeriodDao.findById(id);
                return workPeriod != null ? workPeriod.getName() : null;
            case "/job/socialStatusId":
                WorkPosition workPosition = workPositionDao.findById(id);
                return workPosition != null ? workPosition.getName() : null;
            case "/phoneDetail/sourceTypeId":
                PhoneSourceType phoneSourceType = phoneSourceDao.findById(id);
                return phoneSourceType != null ? phoneSourceType.getName() : null;
            case "/phoneDetail/typeId":
                PhoneType phoneType = phoneTypeDao.findById(id);
                return phoneType != null ? phoneType.getName() : null;
            default:
                return null;
        }
    }

    private String getReferenceValue(String fieldPath, String value) {
        Integer oldValueId = getId(value, fieldPath);
        return value != null ? getReferenceValueById(fieldPath, oldValueId) : null;
    }

    private String getNormalizePath(ValueChange valueChange) {
        String path = valueChange.getAffectedGlobalId().value()
                .replaceAll("/\\d+|ru.rsb.eurion.rtdm.application.AddApplicationRequest/#", "");
        return "/" + path + "/" + valueChange.getPropertyName();
    }

    private String getNormalizePhoneDetailPath(ValueChange valueChange) {
        return "/phoneDetail/" + valueChange.getPropertyName();
    }

    private String decisionToString(ApplicationDecision oldDecision) {
        return oldDecision != null ? String.valueOf(oldDecision) : "";
    }

}
