package ru.rsb.eurion.service.admin.users.status;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.dao.DurationInSecondsTypeHandler;
import ru.rsb.eurion.domain.LoginLogoutTime;
import ru.rsb.eurion.domain.UserStatus;
import ru.rsb.eurion.domain.UserStatusHistory;
import ru.rsb.eurion.domain.UserTimeInStatus;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;

import javax.annotation.Nullable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Mapper
public interface UserStatusHistoryDao {

    String BASE_SQL = "select h.ID, h.USER_ID, h.STATUS_ID, h.UPDATED_AT, h.ROLE_ID, h.SESSION_ID " +
            "from USER_STATUS_HISTORY h ";

    @Nullable
    @Select(BASE_SQL + "join APP_USER u on h.ID = u.STATUS_HISTORY_ID where h.USER_ID = #{userId}")
    @Results(id = "userStatusHistoryMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "status", one = @One(select = "getUserStatusList", fetchType = FetchType.EAGER),
                    column = "status_id"),
            @Result(property = "role", column = "ROLE_ID"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "sessionId", column = "SESSION_ID")
    })
    UserStatusHistory getCurrentHistory(@Param("userId") Integer userId);

    /**
     * Used in {@link #getCurrentHistory} and others
     */
    @SuppressWarnings("unused")
    @Select("select\n" +
            "  ID,\n" +
            "  NAME,\n" +
            "  CODE,\n" +
            "  ORDER_NUM\n" +
            "from USER_STATUS\n" +
            "where ID = #{id} \n" +
            "order by ORDER_NUM")
    @Results(id = "getUserStatusList", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "orderNum", column = "ORDER_NUM")
    })
    UserStatus getUserStatusList(Integer id);

    @Insert("insert into USER_STATUS_HISTORY(USER_ID, STATUS_ID, ROLE_ID, SESSION_ID, UPDATED_AT) " +
            "VALUES (#{userId}, #{entity.status.id}, #{entity.role}, #{entity.sessionId}, " +
            "coalesce(#{entity.updatedAt, jdbcType=TIMESTAMP}, current_timestamp))")
    @SelectKey(
            keyProperty = "entity.id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_user_status_history.currval AS id from dual"}
    )
    void create(@Param("userId") Integer userId,
                @Param("entity") UserStatusHistory statusHistory);

    @Select("select s.CODE                             as STATUS_CODE,\n" +
            "       s.NAME                             as STATUS_NAME,\n" +
            "       u.FULL_NAME                        as USER_FULL_NAME,\n" +
            "       USER_ID,\n" +
            "       STATUS_ID,\n" +
            "       sum(extract(hour from DURATION) * 60 * 60 +\n" +
            "           extract(minute from DURATION) * 60 +\n" +
            "           round(extract(second from DURATION))\n" +
            "           ) as TIME_IN_STATUS\n" +
            "from (\n" +
            "         select A.USER_ID,\n" +
            "                lead(a.UPDATED_AT) over (order by A.UPDATED_AT) - A.UPDATED_AT as DURATION,\n" +
            "                STATUS_ID\n" +
            "         from (\n" +
            "                  select USER_ID, UPDATED_AT, STATUS_ID\n" +
            "                  from USER_STATUS_HISTORY h\n" +
            "                  where UPDATED_AT between #{beginDate} and #{endDate}\n" +
            "                    and user_id in (#{userIds})\n" +
            "                  union all\n" +
            "                  select USER_ID, updated_at, STATUS_ID\n" +
            "                  from (\n" +
            "                           select USER_ID,\n" +
            "                                  #{endDate}                                                        as updated_at,\n" +
            "                                  h.STATUS_ID,\n" +
            "                                  row_number() over (partition by USER_ID order by UPDATED_AT desc) as rn\n" +
            "                           from USER_STATUS_HISTORY h\n" +
            "                           where USER_ID in (#{userIds})\n" +
            "                       ) UPPER_LIMIT\n" +
            "                  where UPPER_LIMIT.rn = 1\n" +
            "              ) A\n" +
            "         where not (UPDATED_AT > #{endDate})\n" +
            "     ) B\n" +
            "\n" +
            "         join USER_STATUS s on STATUS_ID = s.ID\n" +
            "         join APP_USER u on B.USER_ID = u.ID\n" +
            "group by s.NAME, USER_ID, STATUS_ID, s.CODE, u.FULL_NAME")
    @Results(id = "userTimeInStatus", value = {
            @Result(property = "statusCode", column = "STATUS_CODE"),
            @Result(property = "statusName", column = "STATUS_NAME"),
            @Result(property = "fullName", column = "USER_FULL_NAME"),
            @Result(property = "timeInStatus", column = "TIME_IN_STATUS",
                    typeHandler = DurationInSecondsTypeHandler.class),
            @Result(property = "userId", column = "USER_ID")
    })
    @Lang(MybatisExtendedLanguageDriver.class)
    List<UserTimeInStatus> getUserTimeInStatus(@Param("userIds") Set<Integer> userIds,
                                               @Param("beginDate") LocalDateTime beginDate,
                                               @Param("endDate") LocalDateTime endDat);

    @Select("select h.USER_ID, h.UPDATED_AT, us.CODE\n" +
            "from USER_STATUS_HISTORY h\n" +
            "         left join APP_USER u on h.ID = u.STATUS_HISTORY_ID\n" +
            "         left join USER_STATUS us on h.STATUS_ID = us.ID\n" +
            "where h.USER_ID in (#{userIds})\n" +
            "  and h.UPDATED_AT between #{beginDate} and #{endDate}\n" +
            "  and (h.ID in (select ID\n" +
            "                from USER_STATUS_HISTORY\n" +
            "                where USER_ID = h.USER_ID\n" +
            "                  and STATUS_ID != 2\n" +
            "                  and UPDATED_AT between #{beginDate} and #{endDate}\n" +
            "                order by UPDATED_AT\n" +
            "                fetch first row only)\n" +
            "    or h.ID in (select ID\n" +
            "                from USER_STATUS_HISTORY\n" +
            "                where USER_ID = h.USER_ID\n" +
            "                  and STATUS_ID != 2\n" +
            "                  and UPDATED_AT between #{beginDate} and #{endDate}\n" +
            "                order by UPDATED_AT desc\n" +
            "                fetch first row only)\n" +
            "    or\n" +
            "       h.ID in (select ID\n" +
            "                from USER_STATUS_HISTORY\n" +
            "                where USER_ID = h.USER_ID\n" +
            "                  and STATUS_ID = 2\n" +
            "                  and UPDATED_AT between #{beginDate} and #{endDate}\n" +
            "                order by UPDATED_AT desc\n" +
            "                fetch first row only)\n" +
            "    )\n" +
            "order by h.USER_ID, h.UPDATED_AT")
    @Results(id = "loginLogoutTime", value = {
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "UpdatedAt", column = "UPDATED_AT"),
            @Result(property = "statusCode", column = "CODE")
    })
    @Lang(MybatisExtendedLanguageDriver.class)
    List<LoginLogoutTime> getLoginLogoutTime(@Param("userIds") Set<Integer> userIds,
                                             @Param("beginDate") LocalDateTime beginDate,
                                             @Param("endDate") LocalDateTime endDate);

}
