package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.CommentTemplate;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;

import java.util.List;

@Mapper
public interface CommentTemplateDao {

    String SELECT_SQL = "select CT.ID,\n" +
            "       CT.TEMPLATE,\n" +
            "       CT.SUBJECT_ID,\n" +
            "       CT.CREATED_AT,\n" +
            "       CT.UPDATED_AT\n" +
            "from COMMENT_TEMPLATE CT\n" +
            "left join COMMENT_SUBJECT CS on CS.ID = CT.SUBJECT_ID ";

    @Select(SELECT_SQL)
    @Results(id = "CommentTemplateMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "subjectId", column = "SUBJECT_ID"),
            @Result(property = "template", column = "TEMPLATE"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
    })
    List<CommentTemplate> findAll();

    @Select(SELECT_SQL + "where SUBJECT_ID = #{subjectId, jdbcType = INTEGER}")
    @ResultMap("CommentTemplateMapping")
    List<CommentTemplate> findBySubject(@Param("subjectId") Integer subjectId);

    @Insert("INSERT INTO COMMENT_TEMPLATE (TEMPLATE, SUBJECT_ID, CREATED_AT)\n" +
            "VALUES (#{template.template, jdbcType = VARCHAR},\n" +
            "        #{template.subjectId, jdbcType = INTEGER},\n" +
            "        #{template.createdAt, jdbcType=TIMESTAMP})")
    @SelectKey(
            keyProperty = "template.id",
            before = false,
            resultType = Integer.class,
            statement = {"select seq_comment_template.currval AS id from dual"})
    void create(@Param("template") CommentTemplate template);

    @Update("UPDATE COMMENT_TEMPLATE\n" +
            "SET TEMPLATE   = #{template.template, jdbcType = VARCHAR},\n" +
            "    SUBJECT_ID = #{template.subjectId, jdbcType = INTEGER},\n" +
            "    UPDATED_AT = #{template.updatedAt, jdbcType = TIMESTAMP}\n" +
            "WHERE ID = #{template.id, jdbcType = INTEGER}")
    void update(@Param("template") CommentTemplate template);

    @Delete("DELETE FROM COMMENT_TEMPLATE WHERE ID IN (#{idList})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void delete(@Param("idList") List<Integer> idList);

}
