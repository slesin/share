package ru.rsb.eurion.service.admin.users.subdivision;

public enum OrgItemType {
    USER,
    SUBDIVISION
}
