package ru.rsb.eurion.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ApplicationDecision {
    APPROVED("Одобрено"),
    REJECTED("Отклонено"),
    FRAUD("Подозрение на мошенничество"),
    RECOUNT("Пересчет"),
    REWORK("Доработка");

    private final String decisionText;
}
