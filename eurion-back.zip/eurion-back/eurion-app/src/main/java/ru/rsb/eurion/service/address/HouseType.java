package ru.rsb.eurion.service.address;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum HouseType {
    HOUSE("house"),
    CORPUS("corpus"),
    BUILDING("building");

    private final String value;
}
