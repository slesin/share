package ru.rsb.eurion.service.application.priority.handler;

import lombok.RequiredArgsConstructor;
import org.mybatis.dynamic.sql.SortSpecification;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.priority.PriorityParameter;
import ru.rsb.eurion.domain.priority.SortDirection;
import ru.rsb.eurion.service.application.priority.PriorityParameterHandler;
import ru.rsb.eurion.service.calendar.CalendarService;

import static ru.rsb.eurion.service.application.priority.ApplicationPriorityService.PRIORITY_HANDLER_PREFIX;

@RequiredArgsConstructor
@Component(PRIORITY_HANDLER_PREFIX + "NOW_IS_PHONE_TIME")
public class NowIsPhoneTimePriorityParameterHandler implements PriorityParameterHandler {

    private final CalendarService calendarService;

    @Override
    public SortSpecification apply(PriorityParameter parameter) {
        return new NowIsPhoneTimePriorityParameterHandler.Spec(
                parameter.getDirection() == SortDirection.DESC ^
                        !parameter.isReverse(), calendarService.isTodayHoliday());
    }

    @Override
    public boolean isCommon() {
        return true;
    }

    public class Spec implements SortSpecification {

        private static final String WORK_EXPRESSION = "case when DIAL_TIME = 1 then 1 else 0 end";
        private static final String HOLIDAY_EXPRESSION = "case when HOLIDAY_DIAL_TIME = 1 then 1 else 0 end";
        private final boolean descending;
        private final boolean isTodayHoliday;

        private Spec(boolean descending, boolean isTodayHoliday) {
            this.descending = descending;
            this.isTodayHoliday = isTodayHoliday;
        }

        @Override
        public SortSpecification descending() {
            return new NowIsPhoneTimePriorityParameterHandler.Spec(true, false);
        }

        @Override
        public String aliasOrName() {
            if (isTodayHoliday) {
                return HOLIDAY_EXPRESSION;
            }
            return WORK_EXPRESSION;
        }

        @Override
        public boolean isDescending() {
            return descending;
        }
    }
}

