package ru.rsb.eurion.service.application.statistics.productivity;


import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.admin.users.subdivision.OrgTreeNode;
import ru.rsb.eurion.service.application.statistics.productivity.dto.SkillRoleProductivitySettings;
import ru.rsb.eurion.service.application.statistics.productivity.dto.UserApproveLevelInfo;
import ru.rsb.eurion.service.application.statistics.productivity.dto.UserProductivity;

import javax.validation.constraints.NotNull;

import java.time.LocalDate;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping(path = UserProductivityResource.PATH)
@RestController
@AllArgsConstructor
public class UserProductivityResource {

    public static final String PATH = EurionApplication.API_BASE + "/productivity";
    private final UserProductivityService service;


    @GetMapping(produces = APPLICATION_JSON_VALUE)
    public UserProductivity getProductivity() throws BusinessException {
        return service.getProductivity();
    }

    @GetMapping(path = "/level-of-approval/{skillGroupRoleId}", produces = APPLICATION_JSON_VALUE)
    public UserApproveLevelInfo getLevelOfApproval(@NotNull @PathVariable("skillGroupRoleId") Integer skillGroupRoleId) throws BusinessException {
        return service.getApprovalLevel(skillGroupRoleId);
    }

    @GetMapping(path = "/time-tracking/{subdivisionId}", produces = APPLICATION_JSON_VALUE)
    public OrgTreeNode getUserProductivityByTime(@NotNull @PathVariable("subdivisionId") Integer subdivisionId,
                                                 @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam("reportDate") LocalDate reportDate)
            throws BusinessException {
        return service.getProductivityItemTree(subdivisionId, reportDate);
    }

    @GetMapping(path = "/settings", produces = APPLICATION_JSON_VALUE)
    public SkillRoleProductivitySettings getProductivitySettings() {
        return service.getProductivitySettings();
    }

    @PutMapping(path = "/settings", produces = APPLICATION_JSON_VALUE)
    public SkillRoleProductivitySettings setProductivitySettings(@NotNull @RequestBody SkillRoleProductivitySettings settings) {
        return service.setProductivitySettings(settings);
    }

}
