package ru.rsb.eurion.service.application.statistics;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping(path = ApplicationStatisticsResource.PATH)
@RestController
@AllArgsConstructor
public class ApplicationStatisticsResource {

    public static final String PATH = EurionApplication.API_BASE + "/statistics";
    private final StatisticsService service;

    @GetMapping(path = "/application", produces = APPLICATION_JSON_VALUE)
    public SkillInfoView getApplicationStatistics() {
        return service.getApplicationStatistics();
    }
}
