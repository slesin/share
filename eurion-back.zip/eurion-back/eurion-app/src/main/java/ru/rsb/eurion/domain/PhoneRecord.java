package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Телефон
 */
@Getter
@Setter
public class PhoneRecord {
    /**
     * Источник
     */
    private String source;
    /**
     * Тип телефона
     */
    private String phoneType;
    /**
     * Номер телефона
     */
    private String phoneNumber;
    /**
     * ФИО
     */
    private String fullName;
    /**
     * СВЛ (todo что это?)
     */
    private int svl;
}
