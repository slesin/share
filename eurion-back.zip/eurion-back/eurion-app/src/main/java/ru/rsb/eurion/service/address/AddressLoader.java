package ru.rsb.eurion.service.address;


import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rsb.eurion.clients.UtilsServiceClient;
import ru.rsb.eurion.service.check.protocol.history.dto.ProcedureParam;

import javax.validation.constraints.NotNull;
import java.sql.JDBCType;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@AllArgsConstructor
public class AddressLoader {

    private static final String CITY_PROC_NAME = "bali.dbo.web_f_fias_find";
    private static final String STREET_PROC_NAME = "bali.dbo.web_f_fias_street";
    private static final String HOUSE_PROC_NAME = "bali.dbo.web_f_fias_find_house";

    private final UtilsServiceClient utilsServiceClient;

    public List<TownAddressItem> loadTown(@NotNull String name, @NotNull Integer limit) {
        ProcedureParam paramName = new ProcedureParam("@name", JDBCType.VARCHAR.name(), "IN", name);
        ProcedureParam paramLimit = new ProcedureParam("@lim", JDBCType.INTEGER.name(), "IN", limit.toString());

        Stream<UtilsServiceClient.DataRow> stream = utilsServiceClient.executeProcedure(CITY_PROC_NAME, paramName, paramLimit);
        return stream.map(this::mapCityRow)
                .collect(Collectors.toList());
    }

    public List<StreetAddressItem> loadStreet(@NotNull String name, @NotNull String guid, @NotNull Integer limit) {
        ProcedureParam paramName = new ProcedureParam("@name", JDBCType.VARCHAR.name(), "IN", name);
        ProcedureParam paramGuid = new ProcedureParam("@guid", JDBCType.VARCHAR.name(), "IN", guid);
        ProcedureParam paramLimit = new ProcedureParam("@lim", JDBCType.INTEGER.name(), "IN", limit.toString());

        Stream<UtilsServiceClient.DataRow> stream = utilsServiceClient.executeProcedure(STREET_PROC_NAME, paramName, paramLimit, paramGuid);
        return stream.map(this::mapStreetRow)
                .collect(Collectors.toList());
    }

    public List<HouseAddressItem> loadHouse(@NotNull String name, @NotNull HouseType houseType, @NotNull String guid) {
        ProcedureParam paramName = new ProcedureParam("@name", JDBCType.VARCHAR.name(), "IN", name);
        ProcedureParam paramGuid = new ProcedureParam("@guid", JDBCType.VARCHAR.name(), "IN", guid);
        ProcedureParam paramType = new ProcedureParam("@type", JDBCType.VARCHAR.name(), "IN", houseType.getValue());

        Stream<UtilsServiceClient.DataRow> stream = utilsServiceClient.executeProcedure(HOUSE_PROC_NAME, paramName, paramType, paramGuid);
        return stream.map(this::mapHouseRow)
                .collect(Collectors.toList());
    }

    private TownAddressItem mapCityRow(UtilsServiceClient.DataRow row) {
        TownAddressItem item = new TownAddressItem();
        item.setName(row.getString("name"));
        item.setGuid(row.getString("guid"));
        item.setNameHead(row.getString("name_head"));
        item.setRegion(row.getString("region"));
        item.setDistrict(row.getString("district"));
        item.setTown(row.getString("town"));
        item.setPlace(row.getString("place"));
        return item;
    }

    private StreetAddressItem mapStreetRow(UtilsServiceClient.DataRow row) {
        StreetAddressItem item = new StreetAddressItem();
        item.setName(row.getString("name"));
        item.setGuid(row.getString("guid"));
        return item;
    }

    private HouseAddressItem mapHouseRow(UtilsServiceClient.DataRow row) {
        HouseAddressItem item = new HouseAddressItem();
        item.setName(row.getString("name"));
        item.setGuid(row.getString("guid"));
        item.setCorpus(row.getString("corpus"));
        item.setBuilding(row.getString("building"));
        return item;
    }

}
