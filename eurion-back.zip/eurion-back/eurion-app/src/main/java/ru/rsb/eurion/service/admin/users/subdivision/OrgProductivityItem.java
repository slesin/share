package ru.rsb.eurion.service.admin.users.subdivision;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.serializer.FormattedDurationSerializer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
public class OrgProductivityItem {

    private Integer orgItemId;

    private String fullName;
    /**
     * Время входа в систему
     */
    private LocalTime loginAt;
    /**
     * Время последнего входа в систему в разрезе суток
     */
    private LocalTime lastLoginAt;
    /**
     * Время выхода из системы
     */
    private LocalTime logoutAt;
    /**
     * Время в статусе "На работе"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration workTime;
    /**
     * Время в статусе "Обед"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration dinnerTime;
    /**
     * Время в статусе "Перерыв"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration breakTime;
    /**
     * Время в статусе "Перерыв"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration meetingTime;
    /**
     * Время в статусе "Обучение"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration trainingTime;
    /**
     * Время в статусе "Нет на работе"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration absentTime;
    /**
     * Время в статусе "Дополнительная работа без заявок"
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration additionalWorkWithOutApplicationTime;
    /**
     * Среднее вемя работы с заявкой
     */
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration averageTimePerApplication;
    /**
     * Количество принятых решений (Одобрить, Отказать) по заявка в час
     */
    private BigDecimal applicationDecisionPerHour;
    /**
     * Производительность
     */
    private BigDecimal productivityPercent;
    /**
     * Текущий статус
     */
    private String status;

    public OrgProductivityItem() {
        this.workTime = Duration.ZERO;
        this.dinnerTime = Duration.ZERO;
        this.breakTime = Duration.ZERO;
        this.meetingTime = Duration.ZERO;
        this.trainingTime = Duration.ZERO;
        this.absentTime = Duration.ZERO;
        this.additionalWorkWithOutApplicationTime = Duration.ZERO;
        this.averageTimePerApplication = Duration.ZERO;
        this.applicationDecisionPerHour = BigDecimal.ZERO;
        this.productivityPercent = BigDecimal.ZERO;
    }
}
