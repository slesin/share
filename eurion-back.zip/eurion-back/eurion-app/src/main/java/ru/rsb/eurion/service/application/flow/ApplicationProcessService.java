package ru.rsb.eurion.service.application.flow;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.flowable.common.engine.api.delegate.event.FlowableEngineEventType;
import org.flowable.engine.ManagementService;
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.ProcessEngines;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.repository.ProcessDefinition;
import org.flowable.engine.runtime.Execution;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.form.api.FormDefinition;
import org.flowable.form.api.FormInfo;
import org.flowable.form.api.FormRepositoryService;
import org.flowable.job.api.Job;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.FormData;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.application.flow.api.FlowAPI;
import ru.rsb.eurion.service.application.flow.api.TimeOutType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.PostConstruct;
import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static ru.rsb.eurion.service.application.flow.api.FlowAPI.ACCEPT_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.APPLICATION_DEFINITION_KEY;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.APPLICATION_ESISTS_VAR;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.APPLICATION_ID_VAR;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.CURRENT_USER_NAME_VAR;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.FIND_APPLICATION_MESSAGE;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.FRAUD_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.POSTPONE_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.REASSIGN_CAUSE;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.RECALC_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.REJECT_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.REWORK_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.SAVE_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.START_MESSAGE_NAME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.TIME_OUT_TYPE_VAR;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.USER_ID_VAR;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.WITH_TIME_OUT_VAR;

@Service
@Transactional
@Slf4j
@RequiredArgsConstructor
public class ApplicationProcessService {

    public static final String DEFAULT_USER_NAME = "SYSTEM";
    private static final String INAPPROPRIATE_STATE_ERR_CODE = "inappropriate_state";

    private RuntimeService runtimeService;
    private RepositoryService repositoryService;
    private TaskService taskService;
    private FormRepositoryService formRepositoryService;
    private final ProcessCancelEventListener processCancelEventListener;

    @PostConstruct
    public void init() {
        log.info("Known Application flow processes:");
        List<ProcessDefinition> list = repositoryService.createProcessDefinitionQuery().list();
        list.forEach(def -> log.trace("{}", def));
        // обработка принудительного завершения бизнес-процесса
        if (processCancelEventListener != null) {
            runtimeService.addEventListener(processCancelEventListener, FlowableEngineEventType.PROCESS_CANCELLED);
        }
    }

    public ProcessInstance startApplicationProcessing(Long id, boolean exists) {
        Map<String, Object> variables = new HashMap<>();
        variables.put(APPLICATION_ID_VAR, id);
        variables.put(APPLICATION_ESISTS_VAR, exists);
        variables.put(CURRENT_USER_NAME_VAR, DEFAULT_USER_NAME);
        String businessKey = idToBusinessKey(id);
        return runtimeService.startProcessInstanceByMessage(START_MESSAGE_NAME, businessKey, variables);
    }

    //ToDo Удалить после того, как не останется бизнесс процессов использууюзих этот метод.
    @Deprecated
    public void startFindApplicationForOperator(Integer userId, boolean withTimeOut) {
        Map<String, Object> variables = new HashMap<>();
        variables.put(USER_ID_VAR, userId);
        variables.put(WITH_TIME_OUT_VAR, withTimeOut);
        String businessKey = idToBusinessKey(userId);
        runtimeService.startProcessInstanceByMessage(FIND_APPLICATION_MESSAGE, businessKey, variables);
    }

    public void findApplicationForOperatorByTimeOut(Integer userId, TimeOutType timeOutType) {
        Map<String, Object> variables = new HashMap<>();
        variables.put(USER_ID_VAR, userId);
        variables.put(TIME_OUT_TYPE_VAR, timeOutType);
        String businessKey = idToBusinessKey(userId);
        runtimeService.startProcessInstanceByMessage(FIND_APPLICATION_MESSAGE, businessKey, variables);
    }

    public void kill(long id) {
        String businessKey = idToBusinessKey(id);
        runtimeService.createProcessInstanceQuery()
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .processInstanceBusinessKey(businessKey)
                .list()
                .forEach(p -> runtimeService.deleteProcessInstance(p.getId(), "kill"));
    }

    public void assignApplication(Long applicationId, Integer userId, User previousUser) throws BusinessException {
        // рассматриваем 2 возможные ситуации:
        // 1. Заявка ни на кого не назначена, ожидает свободного оператора, BPMN-процесс остановился на operatorReadyEvent
        // 2. Заявка в работе, уже назначена, BPMN-процесс остановился на какой-либо User Task с boundary message event
        // c именем changeOperatorMessage

        String businessKey = idToBusinessKey(applicationId);
        Map<String, Object> variables = new HashMap<>();
        Integer previousUserId = previousUser != null ? previousUser.getId() : null;
        variables.put(FlowAPI.PREVIOUS_USER_ID_VAR, previousUserId);
        variables.put(FlowAPI.USER_ID_VAR, userId);
        String currentUserName = AuthUtil.loggedUser().getUsername();
        variables.put(CURRENT_USER_NAME_VAR, currentUserName);
        String messageName;

        Execution execution = runtimeService.createExecutionQuery()
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .processInstanceBusinessKey(businessKey, true)
                .messageEventSubscriptionName(FlowAPI.CHANGE_OPERATOR_MESSAGE)
                .singleResult();
        if (execution != null) {
            messageName = FlowAPI.CHANGE_OPERATOR_MESSAGE;
        } else {
            execution = runtimeService.createExecutionQuery()
                    .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                    .processInstanceBusinessKey(businessKey, true)
                    .messageEventSubscriptionName(FlowAPI.OPERATOR_READY_MESSAGE)
                    .singleResult();

            if (execution != null) {
                messageName = FlowAPI.OPERATOR_READY_MESSAGE;
            } else {
                log.warn("Application is not inappropriate state to assign (skipping): id={}", applicationId);
                throw new BusinessException(INAPPROPRIATE_STATE_ERR_CODE, "Заявка не может быть назначена на пользователя");
            }
        }
        runtimeService.messageEventReceived(messageName, execution.getId(), variables);
    }

    /**
     * <p>Взять заявку в работу</p>
     *
     * <p>Необходимые уловия:</p>
     * <ul>
     * <li>Заявка находится на пользователской задаче {@link FlowAPI#OPERATOR_TAKE_IN_WORK_TASK}</li>
     * <li>Заявка назначена пользователю. Ориентируемся на переменную процесса {@link FlowAPI#USER_ID_VAR} </li>
     * </ul>
     *
     * @param id     ID заявки
     * @param userId ID пользователя, который берет в работу
     */
    public void takeInWork(Long id, Integer userId) {
        String businessKey = idToBusinessKey(id);
        Task task = taskService.createTaskQuery()
                .processInstanceBusinessKey(businessKey)
                .taskDefinitionKey(FlowAPI.OPERATOR_TAKE_IN_WORK_TASK)
                .processVariableValueEquals(USER_ID_VAR, userId)
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .singleResult();
        if (task != null) {
            String currentUserName = AuthUtil.loggedUser().getUsername();
            taskService.setVariable(task.getId(), CURRENT_USER_NAME_VAR, currentUserName);
            taskService.complete(task.getId());
        } else {
            Task postponeTask = taskService.createTaskQuery()
                    .processInstanceBusinessKey(businessKey)
                    .taskDefinitionKey(FlowAPI.POSTPONE_TASK)
                    .processVariableValueEquals(USER_ID_VAR, userId)
                    .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                    .singleResult();
            if (postponeTask != null) {
                taskService.complete(postponeTask.getId());
            }
        }
    }

    @Nullable
    public TaskInfo loadTaskInfo(Long id) {
        UserData userData = AuthUtil.currentAuth();
        log.info("app id: {}, userData: {}", id, userData);
        if (userData == null) {
            return null;
        }
        Task task = taskService.createTaskQuery()
                .processInstanceBusinessKey(idToBusinessKey(id))
                .processVariableValueEquals(USER_ID_VAR, userData.getId())
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .singleResult();
        log.info("task: {}", task);
        if (task == null) {
            return null;
        }
        TaskInfo taskInfo = TaskInfo.of(task);
        if (task.getFormKey() != null) {
            FormInfo formInfo = formRepositoryService.getFormModelByKey(task.getFormKey());
            taskInfo.setFormData(FormData.of(formInfo));
        }
        return taskInfo;
    }

    public void applicationFormSave(Long id) throws BusinessException {
        completeApplicationForm(id, SAVE_OUTCOME);
    }

    public void applicationFormApprove(Long id, String decisionComment) throws BusinessException {
        Map<String, Object> variables = Collections.singletonMap(FlowAPI.DECISION_COMMENT_VAR, decisionComment);
        completeApplicationForm(id, ACCEPT_OUTCOME, variables);
    }

    public void applicationFormReject(Long id, String decisionComment) throws BusinessException {
        Map<String, Object> variables = Collections.singletonMap(FlowAPI.DECISION_COMMENT_VAR, decisionComment);
        completeApplicationForm(id, REJECT_OUTCOME, variables);
    }

    public void applicationFormRework(Long id, String decisionComment) throws BusinessException {
        Map<String, Object> variables = Collections.singletonMap(FlowAPI.DECISION_COMMENT_VAR, decisionComment);
        completeApplicationForm(id, REWORK_OUTCOME, variables);
    }

    public void applicationFormRecount(Long id) throws BusinessException {
        completeApplicationForm(id, RECALC_OUTCOME);
    }

    public void applicationFormFraud(Long id) throws BusinessException {
        completeApplicationForm(id, FRAUD_OUTCOME);
    }

    public void applicationFormPostpone(@Nonnull Long id, @Nonnull Duration duration) throws BusinessException {
        Map<String, Object> variables = Collections.singletonMap(FlowAPI.POSTPONED_UNTIL_VAR, duration.toString());
        completeApplicationForm(id, POSTPONE_OUTCOME, variables);
    }

    public boolean isProcessInQueue(long applicationId) {
        Execution execution = findOperatorReadyExecution(applicationId);
        return execution != null;
    }

    public void sendOperatorReadyMessage(Long applicationId, Integer userId) {
        Execution execution = findOperatorReadyExecution(applicationId);
        if (execution == null) {
            log.warn("No active process found with subscription to '{}': id={}",
                    FlowAPI.OPERATOR_READY_MESSAGE, applicationId);
            return;
        }

        Map<String, Object> variables = new HashMap<>();
        variables.put(FlowAPI.USER_ID_VAR, userId);
        variables.put(CURRENT_USER_NAME_VAR, DEFAULT_USER_NAME);

        runtimeService.messageEventReceived(FlowAPI.OPERATOR_READY_MESSAGE, execution.getId(), variables);
    }

    public void returnIntoQueue(@Nonnull Long applicationId) {
        sendMessage(applicationId, FlowAPI.RETURN_INTO_QUEUE_MESSAGE);
    }

    public boolean returnFromRecount(@Nonnull Long applicationId) {
        return sendMessage(applicationId, FlowAPI.RETURN_FROM_RECOUNT_MESSAGE);
    }

    private boolean sendMessage(@Nonnull Long applicationId, String messageName) {
        List<Execution> list = runtimeService.createExecutionQuery()
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .processInstanceBusinessKey(idToBusinessKey(applicationId), true)
                .messageEventSubscriptionName(messageName)
                .list();
        list.forEach(execution ->
                runtimeService.messageEventReceived(messageName, execution.getId()));
        return !list.isEmpty();
    }

    public boolean isProcessNotExists(Long applicationId) {
        String businessKey = idToBusinessKey(applicationId);
        return runtimeService.createExecutionQuery()
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .processInstanceBusinessKey(businessKey, true)
                .listPage(0, 1)
                .isEmpty();
    }

    public void moveDeadLetterJobToExecutableJob(String jobId) {
        ProcessEngine engine = ProcessEngines.getDefaultProcessEngine();
        ManagementService managementService = engine.getManagementService();
        Job job = managementService.createDeadLetterJobQuery()
                .jobId(jobId)
                .singleResult();
        if (job != null) {
            managementService.moveDeadLetterJobToExecutableJob(job.getId(), 10);
        }
    }

    public void setTimerJobRetries(String jobId, int retries) {
        ProcessEngine engine = ProcessEngines.getDefaultProcessEngine();
        ManagementService managementService = engine.getManagementService();
        Job job = managementService.createTimerJobQuery()
                .jobId(jobId)
                .singleResult();
        if (job != null) {
            managementService.setTimerJobRetries(job.getId(), retries);
        }
    }

    public void setReAssignCause(Long id, String cause) {
        Execution execution = runtimeService.createExecutionQuery()
                .processInstanceBusinessKey(idToBusinessKey(id))
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .singleResult();
        if (execution != null) {
            runtimeService.setVariable(execution.getId(), REASSIGN_CAUSE, cause);
        } else {
            log.warn("Execution for id = {} not found.", id);
        }
    }

    public void removeReAssignCause(Long id) {
        Execution execution = runtimeService.createExecutionQuery()
                .processInstanceBusinessKey(idToBusinessKey(id))
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .singleResult();
        if (execution != null) {
            runtimeService.removeVariable(execution.getId(), REASSIGN_CAUSE);
        } else {
            log.warn("Execution for id = {} not found.", id);
        }
    }

    @Nullable
    public String getReAssignCause(Long id) {
        Execution execution = runtimeService.createExecutionQuery()
                .processInstanceBusinessKey(idToBusinessKey(id))
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .singleResult();
        if (execution != null) {
            return (String) runtimeService.getVariable(execution.getId(), REASSIGN_CAUSE);
        } else {
            log.warn("Execution for id = {} not found.", id);
            return null;
        }
    }

    private void completeApplicationForm(Long id, String outcome) throws BusinessException {
        completeApplicationForm(id, outcome, Collections.emptyMap());
    }

    private void completeApplicationForm(Long id, String outcome, Map<String, Object> variables) throws BusinessException {
        UserData loggedUser = AuthUtil.loggedUser();

        Task task = taskService.createTaskQuery()
                .processInstanceBusinessKey(idToBusinessKey(id))
                .processVariableValueEquals(loggedUser.getId())
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .singleResult();

        if (task == null) {
            throw new BusinessException(INAPPROPRIATE_STATE_ERR_CODE, "Недопустимое действие с заявкой");
        }

        FormDefinition formDefinition = formRepositoryService.createFormDefinitionQuery()
                .formDefinitionKey(task.getFormKey())
                .latestVersion()
                .singleResult();

        taskService.completeTaskWithForm(task.getId(), formDefinition.getId(), outcome, variables);
    }

    private String idToBusinessKey(@Nonnull Long id) {
        return Long.toString(id);
    }

    private String idToBusinessKey(@Nonnull Integer id) {
        return Long.toString(id);
    }

    private Execution findOperatorReadyExecution(long applicationId) {
        return runtimeService.createExecutionQuery()
                .processDefinitionKey(APPLICATION_DEFINITION_KEY)
                .messageEventSubscriptionName(FlowAPI.OPERATOR_READY_MESSAGE)
                .processInstanceBusinessKey(idToBusinessKey(applicationId), true)
                .singleResult();
    }

    // using setter for test purpose
    @Autowired
    public void setRuntimeService(RuntimeService runtimeService) {
        this.runtimeService = runtimeService;
    }

    // using setter for test purpose
    @Autowired
    public void setRepositoryService(RepositoryService repositoryService) {
        this.repositoryService = repositoryService;
    }

    // using setter for test purpose
    @Autowired
    public void setTaskService(TaskService taskService) {
        this.taskService = taskService;
    }

    // using setter for test purpose
    @Autowired
    public void setFormRepositoryService(FormRepositoryService formRepositoryService) {
        this.formRepositoryService = formRepositoryService;
    }

}
