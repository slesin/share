package ru.rsb.eurion.service.application;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import ru.rsb.eurion.service.phone.autodialer.AutoDialerStatus;

@Getter
@Setter
@ToString
public class UserMessage {
    private Integer userId;
    private UserEvent event;
    private String text;
    private Long appId;
    private Integer blankId;
    private AutoDialerStatus autoDialerStatus;

    public enum UserEvent {
        RETURN_FROM_RECALC,
        LOGOUT,
        HIGH_RTMD_PRIORITY_ASSIGNED,
        RETURN_FROM_POSTPONE,
        INCOMING_CALL,
        AUTO_DIALER_STATUS
    }
}
