package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.ContactType;

import java.util.List;

@Mapper
public interface ContactTypeDao {

    @Select("select " +
            "  ID, " +
            "  NAME, " +
            "  CREATED_AT, " +
            "  UPDATED_AT," +
            "  DISABLED_AT " +
            "from CONTACT_TYPE")
    @Results(id = "phoneSourceMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<ContactType> findAll();

    @Select("select * from CONTACT_TYPE where ID = #{id}")
    ContactType findById(Integer id);
}
