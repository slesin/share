package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ObjectReference;
import ru.rsb.eurion.rtdm.application.CreditParametersType;
import ru.rsb.eurion.rtdm.application.RtdmDecision;
import ru.rsb.eurion.rtdm.application.RtdmRequest;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.FieldValidationException;
import ru.rsb.eurion.service.ResultWrapper;
import ru.rsb.eurion.service.Utils;

import javax.annotation.Nonnull;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_XML_VALUE;
import static org.springframework.http.MediaType.TEXT_XML_VALUE;
import static ru.rsb.eurion.EurionApplication.WS_API_BASE;
import static ru.rsb.eurion.service.ResultType.ERROR;

/**
 * Предоставляет API для RTDM для принятия на рассмотрение кредитных завок нашей системой.
 */
@RestController
@Slf4j
@AllArgsConstructor
public class ApplicationReceiverResource {
    static final String BAD_FORMAT_CODE = "BAD_FORMAT";
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
    private static final String APPLICATION_NODE = "application";
    private static final String BASE_PATH = WS_API_BASE + "/application";

    private final Utils utils;
    private final JsonTransformer jsonTransformer;
    private final ApplicationService applicationService;
    private final RtdmDecisionService rtdmDecisionService;

    public static JsonNode extractApplicationNode(JsonNode jsonNode) {
        JsonNode applicationNode = jsonNode.get(APPLICATION_NODE);
        cleanupEmptyStringValue((ObjectNode) applicationNode);
        return applicationNode;
    }

    @SuppressFBWarnings("UC_USELESS_OBJECT")
    public static void cleanupEmptyStringValue(ObjectNode jsonNode) {
        Iterator<String> iterator = jsonNode.fieldNames();
        List<String> emptyFields = new ArrayList<>();
        while (iterator.hasNext()) {
            String fieldName = iterator.next();
            JsonNode node = jsonNode.get(fieldName);
            if (node.getNodeType() == JsonNodeType.STRING && "".equals(node.textValue())) {
                emptyFields.add(fieldName);
            } else if (node.getNodeType() == JsonNodeType.OBJECT) {
                cleanupEmptyStringValue((ObjectNode) node);
            }
        }
        emptyFields.forEach(name -> jsonNode.replace(name, NullNode.getInstance()));
    }

    @Nonnull
    @PostMapping(path = BASE_PATH, consumes = {TEXT_XML_VALUE, APPLICATION_XML_VALUE}, produces = APPLICATION_XML_VALUE)
    public ResponseEntity<ResultWrapper<?>> acceptApplication(@Nonnull InputStream inputStream) throws IOException {
        try {
            byte[] bytes = IOUtils.toByteArray(inputStream);
            String sourceXml = new String(bytes, StandardCharsets.UTF_8);
            JsonNode jsonNode = jsonTransformer.readXmlTree(new ByteArrayInputStream(bytes));
            if (log.isTraceEnabled()) {
                log.trace("Source XML: {}", sourceXml);
                log.trace("JSON:\n{}", jsonNode);
            }
            cleanupEmptyStringValue((ObjectNode) jsonNode);
            RtdmRequest request = jsonTransformer.treeToValue(jsonNode, RtdmRequest.class);
            utils.validate(request);
            JsonNode applicationNode = extractApplicationNode(jsonNode);
            ApplicationEntity entity = applicationService.acceptApplication(applicationNode, request, sourceXml);
            return ResponseEntity.ok(ResultWrapper.of(new ObjectReference(entity.getId())));
        } catch (JsonProcessingException | FieldValidationException e) {
            log.info("Wrong input application data: {}", e.getMessage());
            log.debug("", e);
            return ResponseEntity.badRequest()
                    .body(ResultWrapper.of(ERROR, BAD_FORMAT_CODE, e.getMessage()));
        } catch (RuntimeException e) {
            log.error("Internal error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResultWrapper.of(ERROR, INTERNAL_SERVER_ERROR, e.getMessage()));
        }
    }

    @PatchMapping(path = BASE_PATH + "/{rtdmId}/credit-parameters")
    public void patchCreditParameters(@PathVariable("rtdmId") Integer rtdmId,
                                      @NotNull @RequestBody CreditParametersType request) throws BusinessException {
        log.info("Credit parameters are updated from RTDM: rtdmId={}", rtdmId);
        request.getCreditInfoItem().forEach(item -> log.debug("Product({}, '{}'), creditAmount={}",
                item.getProduct().getId(), item.getProduct().getName(), item.getCreditAmount()));
        applicationService.patchCreditParameters(rtdmId, request);
    }

    @PostMapping(path = BASE_PATH + "/{rtdmId}/decision", consumes = {TEXT_XML_VALUE, APPLICATION_XML_VALUE})
    public void makeDecision(@Nonnull @PathVariable("rtdmId") Integer rtdmId,
                             @Nonnull @NotNull @Valid @RequestBody RtdmDecision decision) {
        log.info("Decision is obtained from RTDM: rtdmId={}, code={}, date={}, cause='{}'", rtdmId,
                decision.getDecision(), decision.getDate(), decision.getCause());
        rtdmDecisionService.handle(rtdmId, decision);
    }
}
