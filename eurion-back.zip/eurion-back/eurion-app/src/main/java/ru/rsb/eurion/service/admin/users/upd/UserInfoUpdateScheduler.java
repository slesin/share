package ru.rsb.eurion.service.admin.users.upd;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.SchedulerLock;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.service.admin.users.UserDao;
import ru.rsb.eurion.service.admin.users.UserInfoLoader;
import ru.rsb.eurion.service.admin.users.upd.PersonnelNumberData.PersonnelNumbersItem;
import ru.rsb.eurion.settings.AppConfig;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Slf4j
@AllArgsConstructor
public class UserInfoUpdateScheduler {

    private final UserDao userDao;
    private final PersonnelNumberServiceClient personnelNumberServiceClient;
    private final UserInfoLoader userInfoLoader;
    private final Environment environment;
    private final AppConfig config;

    @Scheduled(cron = "${app.schedule.user-info.cron}")
    @SchedulerLock(name = "userInfoUpdate", lockAtMostForString = "${app.schedule.user-info.lock-expire}")
    public void doUpdateUsers() {

        log.debug("Scheduled task: userInfoUpdate");

        // получаем список пользователей, с устаревшими данными
        Duration duration = environment.getRequiredProperty("app.schedule.user-info.expire", Duration.class);
        LocalDateTime temporal = LocalDateTime.now().minus(duration);
        List<User> list = userDao.findByUpdatedAtLessThan(temporal);

        // отдельно получаем данные по номерам телефонов сотрудников,
        // потому что лотусовская процедура возвращает некорректные данные
        if (list.isEmpty()) {
            log.debug("No user to update");
            return;
        }

        int batchSize = config.getUsersForUpdateCount();
        int startIdx = 0;
        int endIdx;
        while (startIdx < list.size()) {
            endIdx = Math.min(startIdx + batchSize, list.size());
            doUpdate(list.subList(startIdx, endIdx));
            startIdx = endIdx;
        }
    }

    @Transactional
    public void doUpdate(List<User> list) {
        Map<String, String> personnelNumbersMap = personnelNumberServiceClient.findAll()
                .stream()
                .collect(Collectors.toMap(PersonnelNumbersItem::getLogin,
                        PersonnelNumbersItem::getNumber, (s, s2) -> s));

        list.forEach(user -> {
            userInfoLoader.loadInfo(user, personnelNumbersMap);
            user.setUpdatedAt(LocalDateTime.now());
            userDao.update(user);
        });
    }
}
