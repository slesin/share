package ru.rsb.eurion.service.application.statistics;

import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Setter
@Getter
public class SkillGroupView {

    private String skillGroupName;
    private Integer groupId;
    private Map<ApplicationViewStatus, Integer> amounts = new HashMap<>();
}
