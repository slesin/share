package ru.rsb.eurion.service.application.history;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.list.Pageable;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.list.SortDirection;
import ru.rsb.eurion.service.TimeUtils;

import javax.annotation.Nonnull;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
@AllArgsConstructor
public class ApplicationHistoryListProvider {
    private final ApplicationHistoryDao dao;

    public PagedResult<ApplicationHistory> listByApplicationId(@Nonnull AppHistoryPageable pageable,
                                                               @Nonnull Integer applicationId,
                                                               LocalDateTime startDate,
                                                               LocalDateTime endDate) {
        startDate = startDate == null ? TimeUtils.getMinLocalDateTime() : startDate;
        endDate = endDate == null ? LocalDateTime.now() : endDate;
        List<ApplicationHistory> list = mainQuery(pageable, applicationId, startDate, endDate);
        int count = dao.countByApplicationId(applicationId, startDate, endDate);
        return new PagedResult<>(pageable.getOffset(), count, list);
    }

    private List<ApplicationHistory> mainQuery(@Nonnull AppHistoryPageable pageable,
                                               @Nonnull Integer applicationId, LocalDateTime startDate, LocalDateTime endDate) {
        SortDirection sortDirection = pageable.getSortDir().isEmpty() ? SortDirection.DESC : pageable.getSortDir().get(0);
        SortAvailable sort = pageable.getSortBy().isEmpty() ? SortAvailable.UPDATED_AT : pageable.getSortBy().get(0);
        if (sort == SortAvailable.UPDATED_AT) {
            if (sortDirection == SortDirection.DESC) {
                return dao.listByApplicationIdOrderByUpdatedAtDesc(
                        applicationId, pageable.getOffset(), pageable.getLimit(), startDate, endDate);
            }
            return dao.listByApplicationIdOrderByUpdatedAtAsc(
                    applicationId, pageable.getOffset(), pageable.getLimit(), startDate, endDate);
        }
        return dao.listByApplicationIdOrderByUpdatedAtDesc(
                applicationId, pageable.getOffset(), pageable.getLimit(), startDate, endDate);

    }

    public enum SortAvailable {
        UPDATED_AT
    }

    static class AppHistoryPageable extends Pageable<SortAvailable> {
    }

    @Getter
    @Setter
    public static class FilterSpec {
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime startDate;

        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime endDate;
    }
}
