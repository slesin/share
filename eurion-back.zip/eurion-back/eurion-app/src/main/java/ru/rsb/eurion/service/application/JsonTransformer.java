package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.TreeNode;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.JsonConfig;

import java.io.IOException;
import java.io.InputStream;

@Component
public class JsonTransformer {

    private final ObjectMapper objectMapper;
    private final XmlMapper xmlMapper;

    public JsonTransformer(@Qualifier(JsonConfig.QUALIFIER) ObjectMapper objectMapper,
                           @Qualifier(JsonConfig.QUALIFIER_XML) XmlMapper xmlMapper) {
        this.objectMapper = objectMapper;
        this.xmlMapper = xmlMapper;
    }

    public <T> T treeToValue(TreeNode jsonNode, Class<T> clazz) throws JsonProcessingException {
        return objectMapper.treeToValue(jsonNode, clazz);
    }

    public JsonNode readTree(String data) {
        try {
            return objectMapper.readTree(data);
        } catch (IOException e) {
            throw new IllegalStateException("Incorrect input json: " + data, e);
        }
    }

    public JsonNode readTree(InputStream inputStream) {
        try {
            return objectMapper.readTree(inputStream);
        } catch (IOException e) {
            throw new IllegalStateException("Incorrect input json: " + inputStream, e);
        }
    }

    public JsonNode readXmlTree(InputStream inputStream) throws IOException {
        return xmlMapper.readTree(inputStream);
    }

    public String writeAsString(Object object) throws JsonProcessingException {
        return objectMapper.writeValueAsString(object);
    }

    public <T> T read(String json, Class<T> clazz) throws IOException {
        return objectMapper.readValue(json, clazz);
    }

    public String jsonToXml(String json, boolean stripRoot) throws IOException {
        JsonNode jsonNode = objectMapper.readTree(json);
        return jsonToXml(jsonNode, stripRoot);
    }

    public String jsonToXml(JsonNode jsonNode) throws JsonProcessingException {
        return jsonToXml(jsonNode, true);
    }

    private String jsonToXml(JsonNode jsonNode, boolean stripRoot) throws JsonProcessingException {
        String xml = xmlMapper.writeValueAsString(jsonNode);
        return stripRoot ? xml
                .replace("<ObjectNode>", "")
                .replace("</ObjectNode>", "") : xml;
    }

    public JsonNode writeAsTree(Object value) {
        return objectMapper.valueToTree(value);
    }
}
