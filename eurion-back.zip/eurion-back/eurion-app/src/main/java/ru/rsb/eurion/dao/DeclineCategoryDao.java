package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.DeclineCategory;

import java.util.List;

@Mapper
public interface DeclineCategoryDao {

    String BASE_SELECT_SQL = "select ID, CREATED_AT, UPDATED_AT, CODE, NAME from DECLINE_CATEGORY ";

    @Select(BASE_SELECT_SQL + " order by ORDER_NUMBER")
    @Results(id = "declineCategoryMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "code", column = "CODE")
    })
    List<DeclineCategory> findAll();
}
