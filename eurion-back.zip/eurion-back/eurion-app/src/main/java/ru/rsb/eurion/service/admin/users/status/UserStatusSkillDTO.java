package ru.rsb.eurion.service.admin.users.status;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class UserStatusSkillDTO {

    Integer userId;

    String userName;

    String userStatusName;

    List<Integer> skillGroupIdList;

    /**
     * Признак того, что пользователь пренадлежит супервизору
     */
    boolean belongCurrentSupervisor;
}
