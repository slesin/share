package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Предложение по кредиту
 */
@Getter
@Setter
public class LoanProposal {
    // todo что тут за поля??
    /**
     * Тип кредита
     */
    public String type;
    /**
     * Наименование продукта
     */
    public String productName;
    /**
     * Процентная ставка
     */
    public BigDecimal rate;
    /**
     * Сумма кредита
     */
    public BigDecimal amount;
    /**
     * Срок кредита
     */
    private Integer period;
    /**
     * Платёж по кредиту
     */
    private BigDecimal payment;
}
