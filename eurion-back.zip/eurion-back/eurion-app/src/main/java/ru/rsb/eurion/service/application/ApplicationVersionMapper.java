package ru.rsb.eurion.service.application;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationVersion;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ApplicationVersionMapper {

    @Mappings({
            @Mapping(source = "id", target = "applicationId"),
            @Mapping(source = "blankId", target = "blankId"),
            @Mapping(source = "status", target = "status"),
            @Mapping(source = "statusCategoryCode", target = "statusCategoryCode"),
            @Mapping(source = "data", target = "data"),
            @Mapping(source = "formDefinitions", target = "formDefinitions"),
            @Mapping(source = "formConclusions", target = "formConclusions"),
            @Mapping(source = "user.id", target = "userId"),
            @Mapping(source = "fraudReturn", target = "fraudReturn"),
            @Mapping(source = "skillGroup.id", target = "skillGroupId")
    })
    void mapToApplicationVersion(ApplicationEntity appEntity, @MappingTarget ApplicationVersion appVersion);
}
