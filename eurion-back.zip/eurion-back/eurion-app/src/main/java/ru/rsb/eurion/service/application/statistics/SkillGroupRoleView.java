package ru.rsb.eurion.service.application.statistics;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Setter
@Getter
public class SkillGroupRoleView {

    private String skillGroupRoleName;
    private List<SkillGroupView> skillGroupViews;
    private Map<ApplicationViewStatus, Integer> amounts = new HashMap<>();

    public List<SkillGroupView> getSkillGroupViews() {
        if (skillGroupViews == null) {
            skillGroupViews = new ArrayList<>();
        }
        return skillGroupViews;
    }
}
