package ru.rsb.eurion.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.javers.core.metamodel.annotation.DiffIgnore;
import ru.rsb.eurion.domain.serializer.PhotoDeserializer;
import ru.rsb.eurion.domain.serializer.PhotoSerializer;

import javax.validation.constraints.NotEmpty;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Пользователь
 */
@Getter
@Setter
@JsonIgnoreProperties("handler")
@EqualsAndHashCode(of = "personnelNumber", callSuper = false)
@SuppressFBWarnings("EI_EXPOSE_REP")
public class User extends BasicReference {
    /**
     * Имя пользователя
     */
    @NotEmpty
    private String username;

    /**
     * ФИО полное
     */
    @DiffIgnore
    private String extendedName;
    /**
     * Роли пользователя
     */
    private Set<Role> roles;
    /**
     * Фотография пользователя
     */
    @JsonSerialize(using = PhotoSerializer.class)
    @JsonDeserialize(using = PhotoDeserializer.class)
    @DiffIgnore
    private byte[] photo;
    /**
     * Дата рождения
     */
    @DiffIgnore
    private LocalDate birthDate;
    /**
     * Табельный номер
     */
    @DiffIgnore
    private String personnelNumber;
    /**
     * Лимит
     */
    private BigDecimal limit;
    /**
     * Супервизор
     */
    private BasicReference supervisor;
    /**
     * Статус
     */
    @DiffIgnore
    private UserStatusHistory statusHistory;
    /**
     * Операторы (для супервайзора)
     */
    @DiffIgnore
    private Set<User> operators;
    /**
     * Адрес пользователя в "Лотусе"
     */
    @DiffIgnore
    private String lotusAddress;
    /**
     * Skill-группы
     */
    private List<SkillGroup> skillGroups;

    /**
     * Внутренний номер телефона сотрудника (Лотус)
     */
    @DiffIgnore
    private String innerPhoneNumber;

    /**
     * Внутренний номер телефона сотрудника (Лотус)
     */
    @DiffIgnore
    private PrimaryPhoneType primaryPhoneType;

    /**
     * Скрытый номер телефона сотрудника (БД.Лайт верификация)
     */
    @DiffIgnore
    private String hiddenPhoneNumber;

    /**
     * Подразделение, в котором работает сотрудник
     */
    @DiffIgnore
    private String division;
    /**
     * Домен пользователя
     */
    @DiffIgnore
    private UserDomain domain;

    public Set<Role> getRoles() {
        if (roles == null) {
            roles = new HashSet<>();
        }
        return roles;
    }

    private Set<Integer> skillGroupIds;
    /**
     * Подразделение пользователя
     */
    private int subdivisionId;
    /**
     * Идентификатор подразделения пользователя из Лотуса
     */
    private String divisionId;

    private boolean hasRoleSupervisor;

    private int operatorsAmount;
    /**
     * Доступ к снятию ограничений при расчета лимита
     */
    private boolean hasUpdateLimitPermission;

    public Set<User> getOperators() {
        if (operators == null) {
            operators = new HashSet<>();
        }
        return operators;
    }

    public Set<Integer> getSkillGroupIds() {
        if (skillGroupIds == null) {
            skillGroupIds = new HashSet<>();
        }
        return skillGroupIds;
    }

    public byte[] getPhoto() {
        return photo != null ? photo.clone() : null;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo != null ? photo.clone() : null;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                "} " + super.toString();
    }
}