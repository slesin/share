package ru.rsb.eurion.mybatis;

import org.mybatis.dynamic.sql.BindableColumn;
import org.mybatis.dynamic.sql.render.TableAliasCalculator;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;

import java.sql.JDBCType;
import java.util.Optional;

public class LiteralDecisionComment implements BindableColumn<String> {

    private static final String renderScript = " decode(AP.PROCESS_NAME, '%s', A.DECISION_COMMENT, APS.DECISION_COMMENT) as DECISION_COMMENT";

    private static final LiteralDecisionComment INSTANCE = new LiteralDecisionComment();

    public static LiteralDecisionComment getInstance() {
        return INSTANCE;
    }

    @Override
    public Optional<String> alias() {
        return Optional.empty();
    }

    @Override
    public BindableColumn<String> as(String s) {
        return null;
    }

    @Override
    public String renderWithTableAlias(TableAliasCalculator tableAliasCalculator) {
        return String.format(renderScript, ProcessDefinitionKey.APPLICATION);
    }

    @Override
    public Optional<JDBCType> jdbcType() {
        return Optional.empty();
    }

    @Override
    public Optional<String> typeHandler() {
        return Optional.empty();
    }
}
