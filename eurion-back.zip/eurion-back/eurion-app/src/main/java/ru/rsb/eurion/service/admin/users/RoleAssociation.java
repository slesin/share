package ru.rsb.eurion.service.admin.users;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.Role;

@Getter
@Setter
public class RoleAssociation {
    private Integer userId;
    private Role role;
}
