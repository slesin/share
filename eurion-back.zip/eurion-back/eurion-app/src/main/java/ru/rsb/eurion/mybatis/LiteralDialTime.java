package ru.rsb.eurion.mybatis;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import org.mybatis.dynamic.sql.BindableColumn;
import org.mybatis.dynamic.sql.render.TableAliasCalculator;
import ru.rsb.eurion.service.TimeUtils;
import ru.rsb.eurion.service.ref.RegionService;

import java.sql.JDBCType;
import java.time.LocalTime;
import java.util.Optional;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class LiteralDialTime implements BindableColumn<String> {

    private static final String renderScript = " (SELECT CASE WHEN currentTime <= #{minutesInDay}\n" +
            "  THEN currentTime\n" +
            "        ELSE currentTime - #{minutesInDay} END AS result\n" +
            " FROM (SELECT (RAW_OFFSET - #{serverRawOffset}) * 60 + #{currentDateInMin} AS currentTime\n" +
            "       FROM dual)) ";

    private static final LiteralDialTime INSTANCE = new LiteralDialTime();

    public static LiteralDialTime getInstance() {
        return INSTANCE;
    }

    @Override
    public Optional<String> alias() {
        return Optional.empty();
    }

    @Override
    public BindableColumn<String> as(String alias) {
        return this;
    }

    @Override
    public Optional<JDBCType> jdbcType() {
        return Optional.of(JDBCType.VARCHAR);
    }

    @Override
    public Optional<String> typeHandler() {
        return Optional.empty();
    }

    @Override
    public String renderWithTableAlias(TableAliasCalculator tableAliasCalculator) {
        Integer currentDateInMin = TimeUtils.timeToMinutes(LocalTime.now());
        Integer serverOffset = RegionService.getServerRawOffset();
        return renderScript.replace("#{currentDateInMin}", String.valueOf(currentDateInMin))
                .replace("#{serverRawOffset}", String.valueOf(serverOffset))
                .replace("#{minutesInDay}", String.valueOf(TimeUtils.minutesInDay));
    }
}
