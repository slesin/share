package ru.rsb.eurion.service.admin.users.subdivision;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import ru.rsb.eurion.domain.serializer.FormattedDurationSerializer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.List;

@Getter
@Setter
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@ToString(of = {"id", "value"})
public class OrgTreeNode {
    private Integer id;
    private Integer parentId;
    private String value;
    private boolean canRename;
    private boolean canMove;
    private boolean canEditChild;
    private OrgItemType orgItemType;
    private Integer orderIdx;
    private Integer inWork;
    private Integer inPostpone;
    private Integer fullAmount;
    private Integer summaryApprovePercent;
    private Integer approveAmount;
    private LocalTime loginAt;
    private LocalTime lastLoginAt;
    private LocalTime logoutAt;
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration workTime;
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration dinnerTime;
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration breakTime;
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration meetingTime;
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration trainingTime;
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration absentTime;
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration additionalWorkWithOutApplicationTime;
    @JsonSerialize(using = FormattedDurationSerializer.class)
    private Duration averageTimePerApplication;
    private BigDecimal applicationDecisionPerHour;
    private BigDecimal productivityPercent;
    private String status;
    private List<OrgTreeNode> data;

    public OrgTreeNode(OrgItem orgItem, OrgStatisticItem statisticItem, OrgProductivityItem orgProductivityItem) {
        this.id = orgItem.getId();
        this.parentId = orgItem.getParentId();
        this.value = orgItem.getValue();
        this.canRename = orgItem.isCanRename();
        this.canMove = orgItem.isCanMove();
        this.canEditChild = orgItem.isCanEditChild();
        this.orgItemType = orgItem.getOrgItemType();
        this.orderIdx = orgItem.getOrderIdx();
        this.inWork = statisticItem.getInWork();
        this.inPostpone = statisticItem.getInPostpone();
        this.fullAmount = statisticItem.getFullAmount();
        this.summaryApprovePercent = statisticItem.getApprovePercent();
        this.approveAmount = statisticItem.getApproveAmount();
        this.loginAt = orgProductivityItem.getLoginAt();
        this.lastLoginAt = orgProductivityItem.getLastLoginAt();
        this.logoutAt = orgProductivityItem.getLogoutAt();
        this.workTime = orgProductivityItem.getWorkTime();
        this.breakTime = orgProductivityItem.getBreakTime();
        this.dinnerTime = orgProductivityItem.getDinnerTime();
        this.meetingTime = orgProductivityItem.getMeetingTime();
        this.trainingTime = orgProductivityItem.getTrainingTime();
        this.absentTime = orgProductivityItem.getAbsentTime();
        this.additionalWorkWithOutApplicationTime = orgProductivityItem.getAdditionalWorkWithOutApplicationTime();
        this.averageTimePerApplication = orgProductivityItem.getAverageTimePerApplication();
        this.applicationDecisionPerHour = orgProductivityItem.getApplicationDecisionPerHour();
        this.productivityPercent = orgProductivityItem.getProductivityPercent();
        this.status = orgProductivityItem.getStatus();
        this.data = new LinkedList<>();
    }

    public OrgTreeNode(OrgStructureData item) {
        this(item.getOrgItem(), item.getOrgStatisticItem(), item.getOrgProductivityItem());
    }

    public OrgTreeNode addChild(OrgStructureData child) {
        OrgTreeNode childNode = new OrgTreeNode(child);
        this.data.add(childNode);
        return childNode;
    }

}