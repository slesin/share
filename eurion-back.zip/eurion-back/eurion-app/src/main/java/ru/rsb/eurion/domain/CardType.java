package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Тип карты
 */
@Getter
@Setter
public class CardType extends BasicReference {
}
