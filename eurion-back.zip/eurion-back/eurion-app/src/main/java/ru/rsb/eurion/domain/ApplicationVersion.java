package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.application.StatusCode;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Getter
@Setter
public class ApplicationVersion extends BaseEntity {

    private Long blankId;

    private Long applicationId;

    private String status;

    private StatusCode statusCategoryCode;

    @NotNull
    private String data;

    private String fieldComment;

    private String formDefinitions;

    private String formConclusions;

    private String incomeInfo;

    private Integer userId;

    private boolean fraudReturn;

    private LocalDateTime version;

    private Integer skillGroupId;

    private VersionInterval versionInterval;
}
