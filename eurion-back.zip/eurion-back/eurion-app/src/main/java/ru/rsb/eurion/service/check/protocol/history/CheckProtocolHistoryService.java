package ru.rsb.eurion.service.check.protocol.history;


import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.clients.UtilsServiceClient;
import ru.rsb.eurion.service.check.protocol.history.dto.ProcedureParam;
import ru.rsb.eurion.settings.AppConfig;

import java.sql.JDBCType;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Service
@Transactional
public class CheckProtocolHistoryService {

    private final UtilsServiceClient client;
    private final AppConfig appConfig;

    public List<CheckHistory> getHistory(Integer clientId) {
        ProcedureParam clientParam = new ProcedureParam("client_id",
                JDBCType.NUMERIC.toString(), "IN", String.valueOf(clientId));
        ProcedureParam cursorParam = new ProcedureParam("cursor",
                JDBCType.REF_CURSOR.toString(), "OUT", null);

        return client.executeProcedure(appConfig.getCreditBlankProcedureName(), clientParam, cursorParam)
                .map(this::mapCheckHistory)
                .collect(Collectors.toList());
    }

    private CheckHistory mapCheckHistory(UtilsServiceClient.DataRow dataRow) {
        CheckHistory history = new CheckHistory();
        history.setBlankId(dataRow.getInt("ID_BLANK"));
        history.setSkillGroupId(dataRow.getInt("ID_ROLE"));
        history.setDeclineCategoryName(dataRow.getString("NAME_CHECK"));
        history.setDeclineReasonName(dataRow.getString("NAME_CHECK_1"));
        history.setResult(dataRow.getString("NAME_RESULT"));
        history.setResultDate(dataRow.getLocalDateTime("DATA_RESULT"));
        history.setComment(dataRow.getString("RESULT_COMMENT"));
        history.setFullName(dataRow.getString("FIO"));
        history.setIncome(dataRow.getBigDecimal("INCOME"));
        history.setCode(dataRow.getString("CODE"));
        return history;
    }
}
