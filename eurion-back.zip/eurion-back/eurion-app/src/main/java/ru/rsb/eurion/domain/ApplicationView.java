package ru.rsb.eurion.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.rtdm.application.CreditType;
import ru.rsb.eurion.service.admin.skill.group.CheckType;
import ru.rsb.eurion.service.application.StatusCode;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Getter
@Setter
public class ApplicationView {
    /**
     * Уникальный идентификатор
     */
    private Long id;

    /**
     * Дата создания
     */
    private LocalDateTime createdAt;

    /**
     * Дата редактирования
     */
    private LocalDateTime updatedAt;

    /**
     * Дата деактивации
     */
    private LocalDateTime disabledAt;

    public boolean isDisabled() {
        return disabledAt != null;
    }

    private Integer rtdmId;
    private Integer clientId;
    private String lastName;
    private String firstName;
    private String middleName;
    private String status;
    private StatusCode statusCode;
    private LocalDateTime statusUpdatedAt;
    private Integer blankId;
    private LocalDate birthDate;
    private BigDecimal creditAmount;
    private BigDecimal requestedCreditAmount;
    private String clientRegionCode;
    private String skillGroupName;
    private Integer skillGroupId;
    private String skillGroupRole;
    private String passportNumber;
    private String passportSeries;
    private String productType;
    private String creditSaleChannelId;
    private String applicationRegionCode;
    private String mobilePhone;
    private String lastUserName;
    private String branchId;
    private BasicReference user;

    private Short skillGroupPriority;
    private LocalTime beginPhoneTime;
    private LocalTime endPhoneTime;
    private LocalDateTime suspendTime;
    private Short supervisorPriority;
    private Short rtdmPriority;
    private Short regionClientPriority;
    private Short regionAppPriority;
    private Short amountPriority;
    private Short channelPriority;
    private Short attractChannelPriority;
    private Short productPriority;
    private Boolean novel;
    private Boolean fraudReturn;
    private Boolean suspensiveTerms;
    private Boolean outOfDialTime;
    private Boolean dialTime;
    private Boolean holidayDialTime;
    private Integer leftToDialTime;
    private Integer leftToHolidayDialTime;
    private Integer lastUserId;
    private Integer fillPercent;
    private String processStatus;
    private String processUserName;
    private String processTitle;
    private String decisionComment;
    private CheckType checkType;
    private CreditType creditType;
    private String authorFullName;
    /**
     * Наименование супервизора которым была назначена заявка
     */
    private String assignBySupervisor;
    /**
     * Дата до наступления которой отложена заявка
     */
    //ToDo просетать, когда будет реализован механизм отложенных заявок
    private LocalTime delayedTo;
    /**
     * Наименование канала продаж
     */
    private String creditSaleChannelName;
    /**
     * Наименование канала привлечения
     */
    private String creditAttractChannelName;
    /**
     * Кол-во часов +/- к мск по региону клиента
     */
    private String clientRegionRawOffSet;
    /**
     * Наименование отделения, запрошенного клиентом
     */
    private String requestedBranchName;
    /**
     * Наименование отделения, в котором была заведена заявка
     */
    private String branchName;
    /**
     * Регион клиента
     */
    private String clientRegion;
    /**
     * Приоритет RTDM
     */
    private RtdmPriority rtdmPriorityView;
    /**
     * Комментарий к отложенным
     */
    private String postponeComment;

    @JsonIgnore
    private String formDefinitions;
    @JsonIgnore
    private String formConclusions;

    @JsonProperty
    @SuppressWarnings("unused")
    public String getFullName() {
        return Stream.of(lastName, firstName, middleName)
                .filter(Objects::nonNull)
                .collect(Collectors.joining(" "));
    }
}
