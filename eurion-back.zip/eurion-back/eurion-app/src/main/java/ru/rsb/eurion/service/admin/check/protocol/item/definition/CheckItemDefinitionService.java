package ru.rsb.eurion.service.admin.check.protocol.item.definition;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.CheckItemDefinition;
import ru.rsb.eurion.domain.CheckItemElement;
import ru.rsb.eurion.domain.CheckItemKind;
import ru.rsb.eurion.domain.CheckItemType;
import ru.rsb.eurion.domain.CheckItemValue;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.CollectionUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static ru.rsb.eurion.service.DaoHelper.execWithSQLCheck;

@Service
@Transactional
@AllArgsConstructor
@Slf4j
public class CheckItemDefinitionService {

    private static final String DUPLICATE_MSG = "Данный элемент протокола проверки уже существует";

    private final CheckItemDefinitionDao dao;

    public CheckItemDefinition findOne(Integer id) {
        return dao.findOne(id);
    }

    public List<CheckItemDefinition> list() {
        return dao.list();
    }

    public CheckItemDefinition create(CheckItemDefinition checkItemDefinition) throws BusinessException {
        validateElementByType(checkItemDefinition);
        LocalDateTime now = LocalDateTime.now();
        checkItemDefinition.setCreatedAt(now);
        checkItemDefinition.setUpdatedAt(now);
        execWithSQLCheck(() -> dao.create(checkItemDefinition), DUPLICATE_MSG);
        for (CheckItemElement checkItemElement : checkItemDefinition.getItems()) {
            dao.createCheckItemElement(checkItemDefinition.getId(), checkItemElement, now);
            for (CheckItemValue checkItemValue : checkItemElement.getItemValueList()) {
                setResultCode(checkItemDefinition, checkItemValue);
                dao.createCheckItemValue(checkItemElement.getId(), checkItemValue, now);
            }
        }
        return dao.findOne(checkItemDefinition.getId());
    }

    public CheckItemDefinition update(CheckItemDefinition checkItemDefinition) {
        validateElementByType(checkItemDefinition);
        CheckItemDefinition oldItemDefinition = findOne(checkItemDefinition.getId());
        checkItemDefinition.setUpdatedAt(LocalDateTime.now());
        dao.updateCheckItemDefinition(checkItemDefinition);
        mergeItemElement(oldItemDefinition.getItems(), checkItemDefinition.getItems(), checkItemDefinition);
        return findOne(checkItemDefinition.getId());
    }

    public List<CheckItemDefinition> updateMultiple(List<CheckItemDefinition> checkItemDefinitions) {
        List<CheckItemDefinition> updatedDefinitions = new ArrayList<>();
        for (CheckItemDefinition definition : checkItemDefinitions) {
            CheckItemDefinition updatedDefinition = update(definition);
            updatedDefinitions.add(updatedDefinition);
        }
        return updatedDefinitions;
    }

    public void enable(Integer id) {
        dao.enableCheckItemDefinition(id, LocalDateTime.now());
    }

    public void disable(Integer id) {
        dao.disableCheckItemDefinition(id, LocalDateTime.now());
    }

    public void enableMultiple(List<Integer> ids) {
        if (ids.isEmpty()) {
            return;
        }
        dao.enableCheckItemDefinitionList(ids, LocalDateTime.now());
    }

    public void disableMultiple(List<Integer> ids) {
        if (ids.isEmpty()) {
            return;
        }
        dao.disableCheckItemDefinitionList(ids, LocalDateTime.now());
    }

    public void delete(Integer id) throws BusinessException {
        UserData userData = AuthUtil.loggedUser();
        CheckItemDefinition definition = dao.findOne(id);
        for (CheckItemElement element : definition.getItems()) {
            deleteCheckItemElement(definition, element);
        }
        try {
            dao.deleteCheckItemDefinition(id);
        } catch (DataIntegrityViolationException e) {
            throw new BusinessException("check_definition", "Перед удалением протокола проверки, необходимо отвязать его от формы.");
        }
        log.info("CheckItemDefinition was deleted: id: {}, name: {}, code: {}, user id: {}", id, definition.getName(), definition.getCode(), userData.getId());
    }

    private void mergeItemElement(List<CheckItemElement> oldElement, List<CheckItemElement> newElement,
                                  CheckItemDefinition checkItemDefinition) {
        CollectionUtils.mergeList(oldElement, newElement, CheckItemElement::getId,
                checkItemElement -> {
                    dao.createCheckItemElement(checkItemDefinition.getId(), checkItemElement, LocalDateTime.now());
                    for (CheckItemValue checkItemValue : checkItemElement.getItemValueList()) {
                        setResultCode(checkItemDefinition, checkItemValue);
                        dao.createCheckItemValue(checkItemElement.getId(), checkItemValue, LocalDateTime.now());
                    }
                    return checkItemElement;
                },
                checkItemElement ->
                        deleteCheckItemElement(checkItemDefinition, checkItemElement),
                (oldValue, newValue) -> {
                    dao.updateCheckItemElement(newValue, LocalDateTime.now());
                    mergeItemValue(oldValue.getItemValueList(), newValue.getItemValueList(), newValue.getId(), checkItemDefinition);
                });
    }

    private void mergeItemValue(List<CheckItemValue> oldItemValue, List<CheckItemValue> newItemValue,
                                Integer checkItemElementId, CheckItemDefinition checkItemDefinition) {
        CollectionUtils.mergeList(oldItemValue, newItemValue, BasicReference::getId,
                checkItemValue -> {
                    setResultCode(checkItemDefinition, checkItemValue);
                    dao.createCheckItemValue(checkItemElementId, checkItemValue, LocalDateTime.now());
                    return checkItemValue;
                },
                checkItemValue ->
                        deleteCheckItemValue(checkItemDefinition, checkItemValue),
                (oldValue, newValue) -> {
                    setResultCode(checkItemDefinition, newValue);
                    dao.updateCheckItemValue(newValue, LocalDateTime.now());
                });
    }

    private void deleteCheckItemElement(CheckItemDefinition checkItemDefinition, CheckItemElement checkItemElement) {
        checkItemElement.getItemValueList().forEach(value -> deleteCheckItemValue(checkItemDefinition, value));
        dao.deleteCheckItemElement(checkItemElement.getId());
        UserData userData = AuthUtil.loggedUser();
        log.info("CheckItemElement was deleted: id: {}, name: {}, type: {},  CheckItemDefinition id: {}, " +
                        "CheckItemDefinition name: {}, user id: {}", checkItemElement.getId(), checkItemElement.getName(),
                checkItemElement.getCheckItemType(), checkItemDefinition.getId(), checkItemDefinition.getName(), userData.getId());
    }

    private void deleteCheckItemValue(CheckItemDefinition checkItemDefinition, CheckItemValue checkItemValue) {
        dao.deleteCheckItemValue(checkItemValue.getId());
        UserData userData = AuthUtil.loggedUser();
        log.info("CheckItemValue was deleted: id: {}, name: {}, code: {},  CheckItemDefinition id: {}, " +
                        "CheckItemDefinition name: {}, user id: {}", checkItemValue.getId(), checkItemValue.getName(),
                checkItemValue.getCode(), checkItemDefinition.getId(), checkItemDefinition.getName(), userData.getId());
    }

    private void setResultCode(CheckItemDefinition checkItemDefinition, CheckItemValue checkItemValue) {
        checkItemValue.setResultCode(checkItemDefinition.getCode() + "." + checkItemValue.getCode());
    }

    private void validateElementByType(CheckItemDefinition checkItemDefinition) {
        CheckItemKind kind = checkItemDefinition.getKind();
        List<CheckItemElement> items;
        switch (kind) {
            case REQUEST_DOCUMENT:
                items = checkItemDefinition.getItems().stream()
                        .filter(item -> item.getCheckItemType() != CheckItemType.REQUEST)
                        .collect(Collectors.toList());
                check(items);
                break;
            case CHECK:
                items = checkItemDefinition.getItems().stream()
                        .filter(item -> item.getCheckItemType() != CheckItemType.YES && item.getCheckItemType() != CheckItemType.NO &&
                                item.getCheckItemType() != CheckItemType.REWORK)
                        .collect(Collectors.toList());
                check(items);
                break;
            case RATING:
                items = checkItemDefinition.getItems().stream()
                        .filter(item -> item.getCheckItemType() != CheckItemType.RATING)
                        .collect(Collectors.toList());
                check(items);
                break;
            default:
                break;
        }
    }

    private void check(List<CheckItemElement> items) {
        if (items.size() > 0) {
            throw new IllegalStateException("CheckItemElement's has not compatible type");
        }
    }
}
