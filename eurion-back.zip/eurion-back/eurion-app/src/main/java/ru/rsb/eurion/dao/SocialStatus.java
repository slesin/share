package ru.rsb.eurion.dao;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.BasicReference;

/**
 * Социальный статус
 */
@Getter
@Setter
public class SocialStatus extends BasicReference {

    boolean isSiteVisible;
}
