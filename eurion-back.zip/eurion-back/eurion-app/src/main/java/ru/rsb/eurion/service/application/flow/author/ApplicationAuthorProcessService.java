package ru.rsb.eurion.service.application.flow.author;

import lombok.extern.slf4j.Slf4j;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.runtime.Execution;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.form.api.FormDefinition;
import org.flowable.form.api.FormInfo;
import org.flowable.form.api.FormRepositoryService;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.FormData;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.application.flow.TaskInfo;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static ru.rsb.eurion.service.application.flow.api.FlowAPI.ACCEPT_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.OPERATOR_TAKE_IN_WORK_TASK;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.REJECT_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.REWORK_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.SAVE_OUTCOME;
import static ru.rsb.eurion.service.application.flow.api.FlowAPI.WORK_WITH_APPLICATION_TASK;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.APPLICATION_ID;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.DECISION;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.DECISION_COMMENT;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.DECLINE_REASON_IDS;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.DEFAULT_USER_NAME;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.PROCESS_NAME;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.RETURN_INTO_QUEUE_MESSAGE;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.USER_ID;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.USER_INT_ID;
import static ru.rsb.eurion.service.application.flow.author.FlowAPI.idToBusinessKey;

@Service
@Transactional
@Slf4j
public class ApplicationAuthorProcessService {

    private static final String INAPPROPRIATE_STATE_ERR_CODE = "inappropriate_state";

    private RuntimeService runtimeService;
    private TaskService taskService;
    private FormRepositoryService formRepositoryService;

    public ProcessInstance startApplicationProcessing(Long id, ProcessDefinitionKey processDefinitionKey) {
        Map<String, Object> variables = new HashMap<>();
        variables.put(APPLICATION_ID, id);
        variables.put(USER_ID, DEFAULT_USER_NAME);
        variables.put(PROCESS_NAME, processDefinitionKey);
        String businessKey = idToBusinessKey(id);
        return runtimeService.startProcessInstanceByKey(processDefinitionKey.getValue(), businessKey, variables);
    }

    public void takeInWork(Long id, ProcessDefinitionKey definitionKey) {
        UserData loggedUser = AuthUtil.loggedUser();
        String businessKey = idToBusinessKey(id);
        Task task = taskService.createTaskQuery()
                .processDefinitionKey(definitionKey.getValue())
                .processInstanceBusinessKey(businessKey)
                .taskDefinitionKey(OPERATOR_TAKE_IN_WORK_TASK)
                .singleResult();
        if (task != null) {
            Map<String, Object> variables = new HashMap<>();
            variables.put(USER_ID, loggedUser.getUsername());
            variables.put(USER_INT_ID, loggedUser.getId());
            taskService.complete(task.getId(), variables);
        }
    }

    public void workComplete(Long id, ProcessDefinitionKey definitionKey, String outcome, Map<String, Object> variables) throws BusinessException {
        UserData loggedUser = AuthUtil.loggedUser();
        String businessKey = idToBusinessKey(id);

        Task task = taskService.createTaskQuery()
                .processDefinitionKey(definitionKey.getValue())
                .processInstanceBusinessKey(businessKey)
                .taskDefinitionKey(WORK_WITH_APPLICATION_TASK)
                .processVariableValueEquals(USER_INT_ID, loggedUser.getId())
                .singleResult();

        if (task == null) {
            throw new BusinessException(INAPPROPRIATE_STATE_ERR_CODE, "Недопустимое действие с заявкой");
        }

        FormDefinition formDefinition = formRepositoryService.createFormDefinitionQuery()
                .formDefinitionKey(task.getFormKey())
                .latestVersion()
                .singleResult();

        taskService.completeTaskWithForm(task.getId(), formDefinition.getId(), outcome, null, variables);
    }

    public void kill(long id, ProcessDefinitionKey processDefinitionKey) {
        String businessKey = idToBusinessKey(id);
        runtimeService.createProcessInstanceQuery()
                .processDefinitionKey(processDefinitionKey.getValue())
                .processInstanceBusinessKey(businessKey)
                .list()
                .forEach(p -> runtimeService.deleteProcessInstance(p.getId(), "kill"));
    }

    public void returnIntoQueue(@Nonnull Long applicationId) {
        sendMessage(applicationId, RETURN_INTO_QUEUE_MESSAGE);
    }

    public void applicationFormSave(Long id, ProcessDefinitionKey definitionKey) throws BusinessException {
        workComplete(id, definitionKey, SAVE_OUTCOME, null);
    }

    public void applicationApprove(Long id, ProcessDefinitionKey definitionKey, String decisionComment) throws BusinessException {
        Map<String, Object> variables = getVariables(ApplicationDecision.APPROVED, null, decisionComment);
        workComplete(id, definitionKey, ACCEPT_OUTCOME, variables);
    }

    public void applicationReject(Long id, ProcessDefinitionKey definitionKey, String decisionComment, Set<Integer> declineReasonIds) throws BusinessException {
        Map<String, Object> variables = getVariables(ApplicationDecision.REJECTED, declineReasonIds, decisionComment);
        workComplete(id, definitionKey, REJECT_OUTCOME, variables);
    }

    public void applicationRework(Long id, ProcessDefinitionKey definitionKey, String decisionComment, Set<Integer> declineReasonIds) throws BusinessException {
        Map<String, Object> variables = getVariables(ApplicationDecision.REWORK, declineReasonIds, decisionComment);
        workComplete(id, definitionKey, REWORK_OUTCOME, variables);
    }

    @Nullable
    public TaskInfo loadTaskInfo(Long id) {
        UserData userData = AuthUtil.currentAuth();
        log.info("app id: {}, userData: {}", id, userData);
        if (userData == null) {
            return null;
        }
        Task task = taskService.createTaskQuery()
                .processInstanceBusinessKey(idToBusinessKey(id))
                .processVariableValueEquals(USER_INT_ID, userData.getId())
                .processDefinitionKey(ProcessDefinitionKey.APPLICATION_VERIFIER.getValue())
                .singleResult();
        log.info("task: {}", task);
        if (task == null) {
            return null;
        }
        TaskInfo taskInfo = TaskInfo.of(task);
        if (task.getFormKey() != null) {
            FormInfo formInfo = formRepositoryService.getFormModelByKey(task.getFormKey());
            taskInfo.setFormData(FormData.of(formInfo));
        }
        return taskInfo;
    }

    private void sendMessage(@Nonnull Long applicationId, String messageName) {
        List<Execution> list = runtimeService.createExecutionQuery()
                .processInstanceBusinessKey(idToBusinessKey(applicationId), true)
                .messageEventSubscriptionName(messageName)
                .list();
        list.forEach(execution ->
                runtimeService.messageEventReceived(messageName, execution.getId()));
    }

    private Map<String, Object> getVariables(ApplicationDecision decision, Set<Integer> declineReasonIds, String decisionComment) {
        Map<String, Object> variables = new HashMap<>();
        variables.put(DECISION, decision);
        if (declineReasonIds != null && !declineReasonIds.isEmpty()) {
            variables.put(DECLINE_REASON_IDS, declineReasonIds);
        } else {
            variables.put(DECLINE_REASON_IDS, Collections.emptySet());
        }
        variables.put(DECISION_COMMENT, decisionComment);
        return variables;
    }

    // using setter for test purpose
    @Autowired
    public void setRuntimeService(RuntimeService runtimeService) {
        this.runtimeService = runtimeService;
    }

    // using setter for test purpose
    @Autowired
    public void setTaskService(TaskService taskService) {
        this.taskService = taskService;
    }

    // using setter for test purpose
    @Autowired
    public void setFormRepositoryService(FormRepositoryService formRepositoryService) {
        this.formRepositoryService = formRepositoryService;
    }
}
