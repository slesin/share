package ru.rsb.eurion.service.admin.users;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.service.admin.Consts;

import javax.annotation.Nullable;
import java.util.List;

/**
 * @author sergius on 9/13/18.
 */
@RequestMapping(path = Consts.SUPERVISOR_API_BASE + "/users", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class SupervisorUsersResource {

    private final UserService service;

    @PostMapping(path = "/list")
    public List<UserView> list(@Nullable @RequestParam(value = "applicationId", required = false) Integer applicationId) {
        return service.listActive(applicationId);
    }

    @GetMapping(path = "/free")
    public List<FreeUserInfo> list() {
        return service.getFreeUsersInfo();
    }

}
