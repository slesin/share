package ru.rsb.eurion.service.application.history;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.CheckConclusionHistory;
import ru.rsb.eurion.domain.DeclineReason;

import java.util.List;
import java.util.Set;

import static ru.rsb.eurion.domain.CheckConclusionHistory.DecisionMaker;

@Mapper
public interface CheckConclusionHistoryDao {
    String INSERT_SQL = "insert into CHECK_CONCLUSION_HISTORY(SKILL_GROUP_ID,\n" +
            "                                     APPLICATION_ID,\n" +
            "                                     FORM_DEFINITIONS,\n" +
            "                                     FORM_CONCLUSIONS,\n" +
            "                                     DECISION_MAKER,\n" +
            "                                     DECISION,\n" +
            "                                     RTDM_DECISION,\n" +
            "                                     DECISION_COMMENT,\n" +
            "                                     USER_ID,\n" +
            "                                     CREATED_AT)\n" +
            "values (#{history.skillGroup.id, jdbcType = INTEGER},\n" +
            "        #{applicationId, jdbcType = BIGINT},\n" +
            "        #{history.formDefinitions, jdbcType = CLOB},\n" +
            "        #{history.formConclusions, jdbcType = CLOB},\n" +
            "        #{history.decisionMaker, jdbcType = VARCHAR},\n" +
            "        #{history.decision, jdbcType = VARCHAR},\n" +
            "        #{history.rtdmDecision, jdbcType = VARCHAR},\n" +
            "        #{history.decisionComment, jdbcType = CLOB},\n" +
            "        #{history.user.id, jdbcType = INTEGER},\n" +
            "        #{history.createdAt, jdbcType = TIMESTAMP})";

    String BASE_SELECT = "select h.ID,\n" +
            "       h.CREATED_AT,\n" +
            "       h.UPDATED_AT,\n" +
            "       h.APPLICATION_ID,\n" +
            "       h.FORM_DEFINITIONS,\n" +
            "       h.FORM_CONCLUSIONS,\n" +
            "       h.SKILL_GROUP_ID,\n" +
            "       h.DECISION_MAKER,\n" +
            "       h.DECISION,\n" +
            "       h.DECISION_COMMENT,\n" +
            "       h.RTDM_DECISION,\n" +
            "       h.DECLINE_REASON_ID,\n" +
            "       sg.NAME       as SKILL_GROUP_NAME,\n" +
            "       sg.CREATED_AT as SKILL_GROUP_CREATED_AT,\n" +
            "       sg.UPDATED_AT as SKILL_GROUP_UPDATED_AT,\n" +
            "       h.USER_ID,\n" +
            "       u.FULL_NAME as USER_NAME\n" +
            "from CHECK_CONCLUSION_HISTORY h\n" +
            "       join SKILL_GROUP sg on h.SKILL_GROUP_ID = sg.ID\n" +
            "       left join APP_USER u on h.USER_ID = u.ID\n";

    String BASE_LIST_SELECT = BASE_SELECT + "where APPLICATION_ID = #{applicationId}";

    String UND_CLIENT_LIST_SELECT = "select h.ID,\n" +
            "       h.CREATED_AT,\n" +
            "       h.UPDATED_AT,\n" +
            "       h.APPLICATION_ID,\n" +
            "       h.FORM_DEFINITIONS,\n" +
            "       h.FORM_CONCLUSIONS,\n" +
            "       h.SKILL_GROUP_ID,\n" +
            "       h.DECISION_MAKER,\n" +
            "       h.DECISION,\n" +
            "       h.DECISION_COMMENT,\n" +
            "       h.RTDM_DECISION,\n" +
            "       h.DECLINE_REASON_ID,\n" +
            "       sg.NAME       as SKILL_GROUP_NAME,\n" +
            "       sg.CREATED_AT as SKILL_GROUP_CREATED_AT,\n" +
            "       sg.UPDATED_AT as SKILL_GROUP_UPDATED_AT,\n" +
            "       h.USER_ID,\n" +
            "       u.FULL_NAME as USER_NAME,\n" +
            "       a.BLANK_ID\n" +
            "from CHECK_CONCLUSION_HISTORY h\n" +
            "       join SKILL_GROUP sg on h.SKILL_GROUP_ID = sg.ID\n" +
            "       left join APP_USER u on h.USER_ID = u.ID\n" +
            "       join APPLICATION a on h.APPLICATION_ID = a.ID\n" +
            "where a.CLIENT_ID = #{clientId} and h.DECISION_MAKER = #{decisionMaker, jdbcType=VARCHAR} AND (h.DECISION IS NULL OR h.DECISION <> 'RECOUNT')";

    @Insert(INSERT_SQL)
    @SelectKey(
            keyProperty = "history.id",
            before = false,
            resultType = Long.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_check_conclusion_history.currval AS id from dual"}
    )
    void create(@Param("applicationId") Long applicationId, @Param("history") CheckConclusionHistory history);

    @Select(BASE_LIST_SELECT + " and (DECISION is not null or RTDM_DECISION is not null) order by h.UPDATED_AT asc\noffset #{offset} rows fetch first #{limit} rows only")
    @Results(id = "checkConclusionHistoryViewMapping", value = {
            @Result(column = "ID", property = "id"),
            @Result(column = "CREATED_AT", property = "createdAt"),
            @Result(column = "UPDATED_AT", property = "updatedAt"),
            @Result(column = "SKILL_GROUP_ID", property = "skillGroup.id"),
            @Result(column = "SKILL_GROUP_NAME", property = "skillGroup.name"),
            @Result(column = "DECISION_MAKER", property = "decisionMaker"),
            @Result(column = "DECISION", property = "decision"),
            @Result(column = "DECISION_COMMENT", property = "decisionComment"),
            @Result(column = "RTDM_DECISION", property = "rtdmDecision"),
            @Result(property = "declineReasons", many = @Many(select = "listDeclineReasonByConclusionId", fetchType = FetchType.EAGER),
                    column = "ID"),
            @Result(column = "USER_ID", property = "user.id"),
            @Result(column = "USER_NAME", property = "user.name"),
            @Result(column = "FORM_DEFINITIONS", property = "formDefinitionsJson"),
            @Result(column = "FORM_CONCLUSIONS", property = "formConclusionsJson")
    })
    List<CheckConclusionHistoryView> listByApplicationIdPageOrderByUpdatedAtAsc(
            @Param("applicationId") Long applicationId, @Param("offset") int offset, @Param("limit") int limit);

    @Select(BASE_LIST_SELECT + " and (DECISION is not null or RTDM_DECISION is not null) order by h.UPDATED_AT desc\noffset #{offset} rows fetch first #{limit} rows only")
    @ResultMap("checkConclusionHistoryViewMapping")
    List<CheckConclusionHistoryView> listByApplicationIdPageOrderByUpdatedAtDesc(
            @Param("applicationId") Long applicationId, @Param("offset") int offset, @Param("limit") int limit);

    @Select("select count(*) from CHECK_CONCLUSION_HISTORY where APPLICATION_ID = #{applicationId}")
    int countByApplicationId(@Param("applicationId") Long id);

    @Select(UND_CLIENT_LIST_SELECT + " order by h.UPDATED_AT desc\noffset #{offset} rows fetch first #{limit} rows only")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "CREATED_AT", property = "createdAt"),
            @Result(column = "UPDATED_AT", property = "updatedAt"),
            @Result(column = "SKILL_GROUP_ID", property = "skillGroup.id"),
            @Result(column = "SKILL_GROUP_NAME", property = "skillGroup.name"),
            @Result(column = "DECISION_MAKER", property = "decisionMaker"),
            @Result(column = "DECISION", property = "decision"),
            @Result(column = "DECISION_COMMENT", property = "decisionComment"),
            @Result(column = "RTDM_DECISION", property = "rtdmDecision"),
            @Result(column = "DECLINE_REASON_NAME", property = "declineReason"),
            @Result(property = "declineReasons", many = @Many(select = "listDeclineReasonByConclusionId", fetchType = FetchType.EAGER),
                    column = "ID"),
            @Result(column = "USER_ID", property = "user.id"),
            @Result(column = "USER_NAME", property = "user.name"),
            @Result(column = "BLANK_ID", property = "blankId")
    })
    List<CheckConclusionHistoryViewExt> listByClientIdPageOrderByUpdatedAtDesc(
            @Param("clientId") Integer clientId,
            @Param("offset") int offset,
            @Param("limit") int limit,
            @Param("decisionMaker") DecisionMaker decisionMaker);

    @Select("select count(*)\n" +
            "from CHECK_CONCLUSION_HISTORY h\n" +
            "       join APPLICATION a on h.APPLICATION_ID = a.ID\n" +
            "where a.CLIENT_ID = #{clientId} and h.DECISION_MAKER = #{decisionMaker, jdbcType=VARCHAR} and h.DECISION <> 'RECOUNT'")
    int countByClientId(@Param("clientId") Integer clientId,
                        @Param("decisionMaker") DecisionMaker decisionMaker);

    @Select("select DECLINE_REASON_ID\n" +
            "from CONCLUSION_REASON\n" +
            "where CHECK_CONCLUSION_ID = (select id\n" +
            "                             from CHECK_CONCLUSION_HISTORY\n" +
            "                             where APPLICATION_ID = #{appId, jdbcType = BIGINT} and DECISION_MAKER in ('UNDERWRITING', 'VERIFICATION', 'AUTHOR')\n" +
            "                             order by CREATED_AT desc\n" +
            "                             fetch first row only)")
    Set<Integer> listDeclineReason(@Param("appId") Long applicationId);

    @Insert("insert into CONCLUSION_REASON(CHECK_CONCLUSION_ID,DECLINE_REASON_ID)\n" +
            "values (#{checkConclusionId, jdbcType = BIGINT}, #{declineReasonId, jdbcType = INTEGER})")
    void addDeclineReason(@Param("checkConclusionId") Long checkConclusionId,
                          @Param("declineReasonId") Integer declineReasonId);

    @SuppressWarnings("unused")
    @Select("select dr.id,\n" +
            "       dr.CREATED_AT,\n" +
            "       dr.UPDATED_AT,\n" +
            "       dr.CODE,\n" +
            "       dr.NAME,\n" +
            "       dr.DECLINE_CATEGORY_ID,\n" +
            "       dc.ID         as C_ID,\n" +
            "       dc.NAME       as C_NAME,\n" +
            "       dc.CODE       as C_CODE,\n" +
            "       dc.CREATED_AT as C_CREATED_AT,\n" +
            "       dc.UPDATED_AT as C_UPDATED_AT\n" +
            "from CONCLUSION_REASON\n" +
            "       left join DECLINE_REASON dr on DECLINE_REASON_ID = dr.ID\n" +
            "       left join DECLINE_CATEGORY dc on dr.DECLINE_CATEGORY_ID = dc.ID\n" +
            "where check_conclusion_id = #{checkConclusionId}")
    @Results(id = "DeclineCategoryReasonMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "category.id", column = "C_ID"),
            @Result(property = "category.createdAt", column = "C_CREATED_AT"),
            @Result(property = "category.updatedAt", column = "C_UPDATED_AT"),
            @Result(property = "category.name", column = "C_NAME"),
            @Result(property = "category.code", column = "C_CODE")
    })
    List<DeclineReason> listDeclineReasonByConclusionId(@Param("checkConclusionId") Long checkConclusionId);
}
