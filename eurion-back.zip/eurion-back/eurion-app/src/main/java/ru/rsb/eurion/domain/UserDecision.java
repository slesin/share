package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserDecision {

    private Integer userId;

    private String fullName;

    private Integer decisionCount;

}
