package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * История взаимоотношений с банком
 */
@Getter
@Setter
public class HistoryOfRelationsWithBankForm extends BasicForm {
    /**
     * Договора клиента (действующие и закрытые)
     */
    private List<Contract> contractList;
    /**
     * История обращения за кредитами
     */
    private List<LoanApplicationHistoryItem> applicationHistory;
}
