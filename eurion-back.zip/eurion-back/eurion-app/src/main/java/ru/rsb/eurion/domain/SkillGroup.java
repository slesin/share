package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.admin.skill.group.CheckType;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Skill группа
 */
@Getter
@Setter
public class SkillGroup extends BasicReference {
    /**
     * SLA этапа
     */
    private Duration stageSla;
    /**
     * SLA сотрудника
     */
    private Duration employeeSla;
    /**
     * Сотрудники
     */
    private List<User> users;
    /**
     * Настройки форм для скилл-групп
     */
    @NotNull
    @Valid
    private List<FormDefinition> formDefinitions;

    /**
     * Тип проверки
     */
    private CheckType checkType;

    /**
     * Идентификатор роли
     */
    private Integer roleId;

    private boolean enabled = true;

    private short priority;

    /**
     *  Требуется пересчет при изменении паспортных данных
     */
    private boolean isRecount;

    public List<User> getUsers() {
        if (users == null) {
            users = new ArrayList<>();
        }
        return users;
    }
}
