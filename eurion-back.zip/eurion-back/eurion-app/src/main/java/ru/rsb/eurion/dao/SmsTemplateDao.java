package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.SmsTemplate;

import java.util.List;

@Mapper
public interface SmsTemplateDao {

    String BASE_SQL = "SELECT ID,\n" +
            "       NAME,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT\n" +
            "FROM SMS_TEMPLATE ";

    @Select(BASE_SQL)
    @Results(id = "smsTemplate", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT")
    })
    List<SmsTemplate> list();

    @Select(BASE_SQL + "where id = #{id , jdbcType = INTEGER}")
    SmsTemplate findById(@Param("id") Integer id);
}
