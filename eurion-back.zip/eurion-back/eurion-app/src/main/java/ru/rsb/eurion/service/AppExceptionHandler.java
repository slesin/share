package ru.rsb.eurion.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

import static ru.rsb.eurion.service.ResultType.ERROR;

@ControllerAdvice
@RestController
@Slf4j
public class AppExceptionHandler {
    private static final String NON_VALID_CODE = "NON_VALID";

    @ExceptionHandler(BusinessException.class)
    public final ResponseEntity<ResultWrapper<?>> handleUserNotFoundException(BusinessException ex) {
        log.debug("", ex);
        ResultWrapper<?> resultWrapper = ResultWrapper.of(ERROR, ex.getCode(), ex.getMessage());
        return new ResponseEntity<>(resultWrapper, HttpStatus.OK);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResultWrapper<?>> processValidationError(MethodArgumentNotValidException ex) {
        log.debug("Validation error", ex);
        log.trace("", ex);
        BindingResult result = ex.getBindingResult();
        List<ResultWrapper.Violation> violations = result.getFieldErrors().stream()
                .map(fieldError -> {
                    ResultWrapper.Violation violation = new ResultWrapper.Violation(fieldError.getCode(),
                            fieldError.getField(), fieldError.getDefaultMessage());
                    log.debug("{}", violation);
                    return violation;
                })
                .collect(Collectors.toList());
        ResultWrapper<?> resultWrapper = ResultWrapper.of(ERROR, NON_VALID_CODE, null);
        resultWrapper.getOutcome().setViolations(violations);
        return new ResponseEntity<>(resultWrapper, HttpStatus.OK);
    }

    @ExceptionHandler(FieldValidationException.class)
    public final ResponseEntity<ResultWrapper<?>> handleUserNotFoundException(FieldValidationException e) {
        log.debug("", e);

        List<ResultWrapper.Violation> list = e.getViolations().stream()
                .map(violation -> {
                    ResultWrapper.Violation result = new ResultWrapper.Violation();
                    if (violation.getConstraintDescriptor() != null) {
                        String simpleName = violation.getConstraintDescriptor()
                                .getAnnotation().annotationType().getSimpleName();
                        result.setCode(simpleName);
                    }
                    result.setMessage(violation.getMessage());
                    result.setPath(violation.getPropertyPath().toString());
                    log.debug("{}", result);
                    return result;
                })
                .collect(Collectors.toList());
        ResultWrapper<?> resultWrapper = ResultWrapper.of(ERROR, NON_VALID_CODE, e.getMessage());
        resultWrapper.getOutcome().setViolations(list);
        return new ResponseEntity<>(resultWrapper, HttpStatus.OK);
    }

    @ExceptionHandler(ClientRequestException.class)
    public ResponseEntity<ErrorResponse> handleClientRequestException(ClientRequestException e) {
        log.info("Client error: {}", e.getMessage());
        log.debug("", e);
        return ResponseEntity.badRequest()
                .contentType(MediaType.APPLICATION_JSON)
                .body(new ErrorResponse(e.getMessage()));
    }
}
