package ru.rsb.eurion.service.application.flow.api;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.StatusType;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.service.admin.users.UserDao;
import ru.rsb.eurion.service.application.ApplicationDao;
import ru.rsb.eurion.domain.Department;
import ru.rsb.eurion.dao.DepartmentDao;
import ru.rsb.eurion.settings.AppConfig;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.math.BigDecimal;
import java.util.List;

@Service("db")
@Transactional
@AllArgsConstructor
@SuppressWarnings("unused")
public class DbService {

    private final ApplicationDao dao;
    private final UserDao userDao;
    private final AppConfig appConfig;
    private final DepartmentDao departmentDao;

    public boolean applicationExists(Integer applicationId) {
        return dao.exists(applicationId);
    }

    public int countByOperator(Integer userId) {
        return dao.countByUserId(userId, ProcessDefinitionKey.APPLICATION);
    }

    @Nullable
    public Integer findFreeOperatorId(Integer applicationId) {
        BigDecimal amountSkipLimit = appConfig.getAmountSkipLimit();
        return userDao.findFreeOperatorIdFor(applicationId, amountSkipLimit);
    }

    @Nonnull
    public Integer loadOperatorId(Long applicationId) {
        ApplicationEntity entity = dao.findById(applicationId);
        if (entity == null) {
            throw new IllegalStateException("Application is not found");
        }
        if (entity.getUser() == null) {
            throw new IllegalStateException("Application has no owner");
        }
        return entity.getUser().getId();
    }

    @Nullable
    public Integer loadOperatorIdByClientId(Long applicationId) {
        ApplicationEntity app = dao.findById(applicationId);
        Integer clientId = app.getClientId();
        Integer skillGroupId = app.getSkillGroup().getId();
        Integer userId = userDao.getUserIdByClientIdAndSkillGroup(clientId, skillGroupId);
        User user = userDao.findById(userId);
        if (user == null) {
            return null;
        }
        boolean isUserWork = isUserWork(user);
        return isUserWork ? userId : null;
    }

    @Nullable
    public Integer findOperatorForPostpone(Long applicationId) {
        ApplicationEntity app = dao.findById(applicationId);
        User previousUser = app.getUser();
        String divisionId = previousUser.getDivisionId();
        if (divisionId == null) {
            return null;
        }
        Department department = departmentDao.findDepartmentByDivisionId(divisionId);
        if (department == null) {
            return null;
        }
        List<Long> ids = departmentDao.findDivisionIdsByDepartmentId(department.getId());
        BigDecimal amountSkipLimit = appConfig.getAmountSkipLimit();
        return userDao.findFreeOperatorIdByDivision(applicationId, amountSkipLimit, ids);
    }

    private boolean isUserWork(User user) {
        StatusType currentUserStatus = user.getStatusHistory().getStatus().getCode();
        return user.getStatusHistory() != null && StatusType.ABSENT != currentUserStatus;
    }
}
