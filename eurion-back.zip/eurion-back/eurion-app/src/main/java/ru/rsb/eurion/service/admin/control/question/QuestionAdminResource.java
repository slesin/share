package ru.rsb.eurion.service.admin.control.question;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import ru.rsb.eurion.domain.ControlQuestion;
import ru.rsb.eurion.service.ResultWrapper;
import ru.rsb.eurion.service.admin.Consts;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.List;
import java.util.Set;

@RequestMapping(path = Consts.ADMIN_API_BASE + "/question", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class QuestionAdminResource {

    private final QuestionAdminService service;

    @GetMapping
    public List<ControlQuestion> getAllQuestions() {
        return service.getAllQuestions();
    }

    @PostMapping
    public ResultWrapper<ControlQuestion> createQuestion(@NotNull @Valid @RequestBody ControlQuestion question) {
        ControlQuestion created = service.createQuestion(question);
        return ResultWrapper.of(created);
    }

    @PostMapping("/disable/{status}")
    public ResultWrapper<List<ControlQuestion>> disableQuestion(@NotNull @PathVariable boolean status,
                                                                @NotNull @RequestBody Set<Integer> ids) {
        if (ids.isEmpty()) {
            return ResultWrapper.of(Collections.emptyList());
        }
        List<ControlQuestion> list = service.disableQuestions(ids, status);
        return ResultWrapper.of(list);
    }

    @PutMapping("/update")
    public ResultWrapper<ControlQuestion> updateQuestion(@RequestBody ControlQuestion question) {
        ControlQuestion updated = service.updateQuestion(question);
        return ResultWrapper.of(updated);
    }

}
