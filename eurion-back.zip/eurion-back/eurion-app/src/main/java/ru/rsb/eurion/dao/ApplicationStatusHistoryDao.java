package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.ApplicationStatusHistory;
import ru.rsb.eurion.domain.ApplicationStatusHistoryView;
import ru.rsb.eurion.service.admin.skill.group.CheckType;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface ApplicationStatusHistoryDao {

    String BASE_SQL = "select" +
            "       ID,\n" +
            "       RTDM_ID,\n" +
            "       BLANK_ID,\n" +
            "       CLIENT_ID,\n" +
            "       SKILL_GROUP_ID,\n" +
            "       CHECK_TYPE,\n" +
            "       STATUS_CODE,\n" +
            "       STATUS,\n" +
            "       APPLICATION_ID,\n" +
            "       USER_ID,\n" +
            "       USER_NAME,\n" +
            "       ORDER_NUMBER,\n" +
            "       UPDATED_AT,\n" +
            "       DECISION_COMMENT\n" +
            "from APPLICATION_STATUS_HISTORY\n";

    String VIEW_SELECT_SQL = "select RTDM_ID,\n" +
            "       BLANK_ID,\n" +
            "       CLIENT_ID,\n" +
            "       SKILL_GROUP_ID,\n" +
            "       SKILL_GROUP_NAME,\n" +
            "       ACTION_IN_STATUS,\n" +
            "       INPUT_STATUS_DATE,\n" +
            "       OUTPUT_STATUS_DATE,\n" +
            "       INPUT_USER_PERSONNEL_NUMBER,\n" +
            "       INPUT_USER_NAME,\n" +
            "       OUTPUT_USER_PERSONNEL_NUMBER,\n" +
            "       OUTPUT_USER_NAME,\n" +
            "       DECISION_COMMENT,\n" +
            "       CLIENT_FULL_NAME,\n" +
            "       CHECK_TYPE_TITLE,\n" +
            "       STATUS,\n" +
            "       DECLINE_CATEGORY,\n" +
            "       DECLINE_REASON\n" +
            "from APPLICATION_STATUS_VIEW\n";

    @Select(BASE_SQL + "where APPLICATION_ID = #{appId, jdbcType=BIGINT } order by ORDER_NUMBER")
    @Results(id = "appStatusHistoryMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "rtdmId", column = "RTDM_ID"),
            @Result(property = "blankId", column = "BLANK_ID"),
            @Result(property = "clientId", column = "CLIENT_ID"),
            @Result(property = "skillGroupId", column = "SKILL_GROUP_ID"),
            @Result(property = "checkType", column = "CHECK_TYPE"),
            @Result(property = "statusCode", column = "STATUS_CODE"),
            @Result(property = "status", column = "STATUS"),
            @Result(property = "applicationId", column = "APPLICATION_ID"),
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "userName", column = "USER_NAME"),
            @Result(property = "orderNumber", column = "ORDER_NUMBER"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "decisionComment", column = "DECISION_COMMENT")
    })
    List<ApplicationStatusHistory> findAll();

    @Select(BASE_SQL + "WHERE APPLICATION_ID = #{appId, jdbcType=BIGINT} and CHECK_TYPE = #{checkType, jdbcType = VARCHAR}\n" +
            "order by ORDER_NUMBER desc\n" +
            "fetch first row only")
    @ResultMap("appStatusHistoryMapping")
    ApplicationStatusHistory findOne(@Param("appId") Long appId, @Param("checkType") CheckType checkType);

    @Insert("insert into APPLICATION_STATUS_HISTORY(RTDM_ID,\n" +
            "                                       BLANK_ID,\n" +
            "                                       CLIENT_ID,\n" +
            "                                       SKILL_GROUP_ID,\n" +
            "                                       CHECK_TYPE,\n" +
            "                                       STATUS_CODE,\n" +
            "                                       STATUS,\n" +
            "                                       APPLICATION_ID,\n" +
            "                                       USER_ID,\n" +
            "                                       USER_NAME,\n" +
            "                                       ORDER_NUMBER,\n" +
            "                                       UPDATED_AT,\n" +
            "                                       DECISION_COMMENT,\n" +
            "                                       CLIENT_FULL_NAME)\n" +
            "values (#{statusHistory.rtdmId,jdbcType = BIGINT},\n" +
            "        #{statusHistory.blankId, jdbcType = BIGINT},\n" +
            "        #{statusHistory.clientId, jdbcType = INTEGER},\n" +
            "        #{statusHistory.skillGroupId, jdbcType = INTEGER},\n" +
            "        #{statusHistory.checkType,jdbcType = VARCHAR},\n" +
            "        #{statusHistory.statusCode, jdbcType = VARCHAR},\n" +
            "        #{statusHistory.status, jdbcType = VARCHAR},\n" +
            "        #{statusHistory.applicationId, jdbcType = BIGINT},\n" +
            "        #{statusHistory.userId, jdbcType = INTEGER},\n" +
            "        #{statusHistory.userName, jdbcType = VARCHAR},\n" +
            "        #{statusHistory.orderNumber, jdbcType = INTEGER},\n" +
            "        #{statusHistory.updatedAt, jdbcType = TIMESTAMP},\n" +
            "        #{statusHistory.decisionComment, jdbcType = VARCHAR},\n" +
            "        #{statusHistory.clientFullName, jdbcType = VARCHAR})\n")
    @SelectKey(
            keyProperty = "statusHistory.id",
            before = false,
            resultType = Long.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_application_status_history.currval AS id from dual"}
    )
    void create(@Param("statusHistory") ApplicationStatusHistory statusHistory);

    @Select(VIEW_SELECT_SQL + "where APPLICATION_ID = #{appId, jdbcType = BIGINT}\n" +
            "  and INPUT_STATUS_DATE between #{startDate, jdbcType=TIMESTAMP} and #{endDate, jdbcType=TIMESTAMP}\n" +
            "order by INPUT_STATUS_DATE asc\n" +
            "    offset #{offset} rows\n" +
            "fetch first #{limit} rows only\n")
    @Results(id = "appStatusHistoryViewMapping", value = {
            @Result(property = "rtdmId", column = "RTDM_ID"),
            @Result(property = "blankId", column = "BLANK_ID"),
            @Result(property = "clientId", column = "CLIENT_ID"),
            @Result(property = "skillGroupId", column = "SKILL_GROUP_ID"),
            @Result(property = "skillGroupName", column = "SKILL_GROUP_NAME"),
            @Result(property = "actionInStatus", column = "ACTION_IN_STATUS"),
            @Result(property = "inputStatusDate", column = "INPUT_STATUS_DATE"),
            @Result(property = "outputStatusDate", column = "OUTPUT_STATUS_DATE"),
            @Result(property = "inputUserPersonnelNumber", column = "INPUT_USER_PERSONNEL_NUMBER"),
            @Result(property = "inputUserName", column = "INPUT_USER_NAME"),
            @Result(property = "outputUserPersonnelNumber", column = "OUTPUT_USER_PERSONNEL_NUMBER"),
            @Result(property = "outputUserName", column = "OUTPUT_USER_NAME"),
            @Result(property = "decisionComment", column = "DECISION_COMMENT"),
            @Result(property = "clientFullName", column = "CLIENT_FULL_NAME"),
            @Result(property = "status", column = "STATUS"),
            @Result(property = "declineReason", column = "DECLINE_REASON"),
            @Result(property = "declineCategory", column = "DECLINE_CATEGORY"),
            @Result(property = "checkType", column = "CHECK_TYPE")
    })
    List<ApplicationStatusHistoryView> listByApplicationIdInOrderByUpdatedAtAsc(@Param("appId") Integer appId,
                                                                                @Param("offset") int offset,
                                                                                @Param("limit") int limit,
                                                                                @Param("startDate") LocalDateTime startDate,
                                                                                @Param("endDate") LocalDateTime endDate);

    @Select(VIEW_SELECT_SQL + "where APPLICATION_ID = #{appId, jdbcType = BIGINT}\n" +
            "and INPUT_STATUS_DATE between #{startDate, jdbcType=TIMESTAMP} and #{endDate, jdbcType=TIMESTAMP}\n" +
            "order by INPUT_STATUS_DATE desc\n" +
            "    offset #{offset} rows fetch first #{limit} rows only\n")
    @ResultMap("appStatusHistoryViewMapping")
    List<ApplicationStatusHistoryView> listByApplicationIdInOrderByUpdatedAtDesc(@Param("appId") Integer appId,
                                                                                 @Param("offset") int offset,
                                                                                 @Param("limit") int limit,
                                                                                 @Param("startDate") LocalDateTime startDate,
                                                                                 @Param("endDate") LocalDateTime endDate);

    @Select("select count(*)\n" +
            "from APPLICATION_STATUS_VIEW\n" +
            "where APPLICATION_ID = #{appId, jdbcType = BIGINT}\n" +
            "and INPUT_STATUS_DATE between #{startDate, jdbcType=TIMESTAMP} and #{endDate, jdbcType=TIMESTAMP}")
    int countByApplicationId(@Param("appId") Integer applicationId,
                             @Param("startDate") LocalDateTime startDate,
                             @Param("endDate") LocalDateTime endDate);

    @Insert("insert into STATUS_REASON(STATUS_HISTORY_ID, DECLINE_REASON_ID)\n" +
            "values (#{statusHistoryId, jdbcType = BIGINT}, #{declineReasonId, jdbcType = INTEGER})")
    void addDeclineReason(@Param("statusHistoryId") Long statusHistoryId,
                          @Param("declineReasonId") Integer declineReasonId);
}
