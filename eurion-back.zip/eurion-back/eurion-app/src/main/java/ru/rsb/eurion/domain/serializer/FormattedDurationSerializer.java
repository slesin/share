package ru.rsb.eurion.domain.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.springframework.boot.jackson.JsonComponent;

import java.io.IOException;
import java.time.Duration;

@JsonComponent
public class FormattedDurationSerializer extends JsonSerializer<Duration> {
    private static final String FORMAT = "HH:mm:ss";

    @Override
    public void serialize(Duration duration, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        String formattedValue = DurationFormatUtils.formatDuration(duration.toMillis(), FORMAT);
        jsonGenerator.writeString(formattedValue);
    }
}