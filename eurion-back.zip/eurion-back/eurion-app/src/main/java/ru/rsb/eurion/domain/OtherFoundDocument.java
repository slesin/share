package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

/**
 * Иные ФИО и паспорта Клиента (совпадения?)
 */
@Getter
@Setter
public class OtherFoundDocument {
    /**
     * ФИО
     */
    private String fullName;
    /**
     * Паспорт
     */
    private String passport;
    /**
     * Источник
     */
    private String source;
    /**
     * Дата (todo получения???)
     */
    private LocalDate date;
}
