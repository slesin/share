package ru.rsb.eurion.domain;


import lombok.Getter;
import lombok.Setter;

/**
 * Семейное положение
 */
@Getter
@Setter
public class MaritalStatus extends BasicReference {

    private Integer scoringId;

    private boolean active;

    private Integer countryId;

    private Integer codeId;
}
