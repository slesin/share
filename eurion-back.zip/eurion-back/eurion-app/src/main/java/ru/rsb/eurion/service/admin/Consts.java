package ru.rsb.eurion.service.admin;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import ru.rsb.eurion.EurionApplication;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class Consts {
    public static final String ADMIN_API_BASE = EurionApplication.API_BASE + "/admin";
    public static final String SUPERVISOR_API_BASE = EurionApplication.API_BASE + "/supervisor";
    public static final String UNDERWRITER_API_BASE = EurionApplication.API_BASE + "/underwriter";
    public static final String AUTHOR_USER_API_BASE = EurionApplication.API_BASE + "/author";
    public static final String VERIFIER_API_BASE = EurionApplication.API_BASE + "/verifier";
    public static final String REF_BASE = EurionApplication.API_BASE + "/ref";
}
