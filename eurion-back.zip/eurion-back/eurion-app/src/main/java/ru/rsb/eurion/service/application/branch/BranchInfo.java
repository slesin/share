package ru.rsb.eurion.service.application.branch;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class BranchInfo {

    List<BranchItem> branches;

    public List<BranchItem> getBranches() {
        if (branches == null) {
            branches = new ArrayList<>();
        }
        return branches;
    }
}
