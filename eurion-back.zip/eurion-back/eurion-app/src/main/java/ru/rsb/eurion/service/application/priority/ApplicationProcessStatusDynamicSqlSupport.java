package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;
import ru.rsb.eurion.service.application.StatusCode;

import java.sql.JDBCType;
import java.time.LocalDateTime;

public class ApplicationProcessStatusDynamicSqlSupport {
    public static final ApplicationProcessTable APPLICATION_PROCESS_STATUS_TABLE = new ApplicationProcessStatusDynamicSqlSupport.ApplicationProcessTable();

    public static final SqlColumn<Long> APPLICATION_ID = APPLICATION_PROCESS_STATUS_TABLE.column("APPLICATION_ID", JDBCType.BIGINT);
    public static final SqlColumn<String> PROCESS_STATUS = APPLICATION_PROCESS_STATUS_TABLE.column("STATUS", JDBCType.VARCHAR);
    public static final SqlColumn<String> PROCESS_DECISION = APPLICATION_PROCESS_STATUS_TABLE.column("DECISION", JDBCType.VARCHAR);
    public static final SqlColumn<String> PROCESS_USER_NAME = APPLICATION_PROCESS_STATUS_TABLE.column("USER_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<StatusCode> PROCESS_CATEGORY_CODE = APPLICATION_PROCESS_STATUS_TABLE.column("CATEGORY_CODE", JDBCType.VARCHAR);
    public static final SqlColumn<LocalDateTime> PROCESS_DONE_AT = APPLICATION_PROCESS_STATUS_TABLE.column("DONE_AT", JDBCType.TIMESTAMP);
    public static final SqlColumn<Integer> USER_ID = APPLICATION_PROCESS_STATUS_TABLE.column("USER_ID", JDBCType.INTEGER);
    public static final SqlColumn<String> PROCESS_NAME = APPLICATION_PROCESS_STATUS_TABLE.column("PROCESS_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<LocalDateTime> PROCESS_STATUS_UPDATED_AT = APPLICATION_PROCESS_STATUS_TABLE.column("UPDATED_AT", JDBCType.TIMESTAMP);

    private static final class ApplicationProcessTable extends SqlTable {
        ApplicationProcessTable() {
            super("APPLICATION_PROCESS_STATUS");
        }
    }
}
