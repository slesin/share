package ru.rsb.eurion.service.admin.users;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.LotusUserInfo;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.service.admin.users.upd.PersonnelNumberData;
import ru.rsb.eurion.service.admin.users.upd.PersonnelNumberServiceClient;
import ru.rsb.eurion.service.admin.users.upd.PersonnelServiceClient;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotNull;
import javax.xml.bind.DatatypeConverter;
import java.time.LocalDate;
import java.time.Month;
import java.util.Map;
import java.util.stream.Collectors;

import static ru.rsb.eurion.utils.StringUtils.initial;

@Component
@AllArgsConstructor
@Slf4j
public class UserInfoLoader {

    private final PersonnelServiceClient personnelServiceClient;
    private final PersonnelNumberServiceClient personnelNumberServiceClient;

    public LotusUserInfo getLotusUserInfo(@Nonnull String personnelNumber, @NotNull String userName) {
        Map<String, String> personnelNumbersMap = getPersonalNumberMap();
        LotusUserInfo lotusUserInfo = personnelServiceClient.getLotusUserInfo(personnelNumber);
        String hidePhone = personnelNumbersMap.get(userName);
        lotusUserInfo.setHiddenPhoneNumber(hidePhone);
        return lotusUserInfo;
    }

    public LotusUserInfo getLotusUserInfoAndUpdateUser(User user) {
        Map<String, String> personnelNumbersMap = getPersonalNumberMap();
        LotusUserInfo lotusUserInfo = personnelServiceClient.getLotusUserInfo(user.getPersonnelNumber());
        String hidePhone = personnelNumbersMap.get(user.getUsername());
        lotusUserInfo.setHiddenPhoneNumber(hidePhone);
        loadInfo(user, personnelNumbersMap);
        return lotusUserInfo;
    }

    public void loadInfo(@Nonnull User user) {
        Map<String, String> personnelNumbersMap = getPersonalNumberMap();
        loadInfo(user, personnelNumbersMap);
    }

    public void loadInfo(@Nonnull User user, @Nonnull Map<String, String> personnelNumbersMap) {
        log.debug("Updating user info: {}", user);
        updateFromLotus(user);
        String hiddenPhoneNumber = personnelNumbersMap.get(user.getUsername());
        if (!StringUtils.isEmpty(hiddenPhoneNumber)) {
            user.setHiddenPhoneNumber(hiddenPhoneNumber);
        }

    }

    private void updateFromLotus(User user) {
        LotusUserInfo userInfo;
        try {
            userInfo = personnelServiceClient.getLotusUserInfo(user.getPersonnelNumber());
        } catch (Exception e) {
            log.error("Failed to get user from Lotus: {}", user);
            return;
        }
        if ("Dismissed".equals(userInfo.getStatus())) {
            log.debug("User info is not found in Lotus: {}", user);
            return;
        }
        map(userInfo, user);
        log.debug("User inf is updated successfully: {}", user);
    }

    private void map(LotusUserInfo userInfo, User user) {
        String briefName = userInfo.getLastName() + " " +
                initial(userInfo.getFirstName()) + initial(userInfo.getMiddleName());
        user.setName(briefName);
        String extendedName = userInfo.getLastName() +
                blankPrefixedString(userInfo.getFirstName()) + (blankPrefixedString(userInfo.getMiddleName()));
        user.setExtendedName(extendedName);
        user.setLotusAddress(userInfo.getAddress());
        String innerPhoneNumber = userInfo.getExtension();
        if (!StringUtils.isEmpty(innerPhoneNumber)) {
            user.setInnerPhoneNumber(innerPhoneNumber);
        }
        if (userInfo.getPhoto() != null) {
            user.setPhoto(DatatypeConverter.parseBase64Binary(userInfo.getPhoto().trim()));
        }
        updateUserBirthDayAndMonth(user, userInfo);
        user.setDivision(userInfo.getDivision());
        user.setDivisionId(userInfo.getDivisionId());
    }

    private String blankPrefixedString(String firstName) {
        return firstName != null ? " " + firstName : "";
    }

    private void updateUserBirthDayAndMonth(User user, LotusUserInfo userInfo) {
        LocalDate currentBirthDate = user.getBirthDate() != null ?
                user.getBirthDate() : LocalDate.of(1970, Month.JANUARY, 1);

        int year = currentBirthDate.getYear();
        int month = userInfo.getBirthMonth() > 0 ? userInfo.getBirthMonth() : currentBirthDate.getMonthValue();
        int day = userInfo.getBirthDay() > 0 ? userInfo.getBirthDay() : currentBirthDate.getDayOfMonth();

        LocalDate newBirthDate = LocalDate.of(year, month, day);
        user.setBirthDate(newBirthDate);
    }

    private Map<String, String> getPersonalNumberMap() {
        return personnelNumberServiceClient.findAll()
                .stream()
                .collect(Collectors.toMap(PersonnelNumberData.PersonnelNumbersItem::getLogin,
                        PersonnelNumberData.PersonnelNumbersItem::getNumber, (s, s2) -> s));
    }
}
