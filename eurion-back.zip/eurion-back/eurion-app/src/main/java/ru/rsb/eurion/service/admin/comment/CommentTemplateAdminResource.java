package ru.rsb.eurion.service.admin.comment;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.CommentTemplate;
import ru.rsb.eurion.service.admin.Consts;
import ru.rsb.eurion.service.comment.CommentTemplateService;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@RequestMapping(path = Consts.ADMIN_API_BASE + "/application/comment/template", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class CommentTemplateAdminResource {

    private final CommentTemplateService service;

    @PostMapping(path = "/create")
    public CommentTemplate create(@NotNull @Valid @RequestBody CommentTemplate commentTemplate) {
        return service.create(commentTemplate);
    }

    @PostMapping(path = "/update")
    public CommentTemplate update(@NotNull @Valid @RequestBody CommentTemplate reasonTemplate) {
        return service.update(reasonTemplate);
    }

    @PostMapping("/delete")
    public void delete(@RequestBody @NotNull List<Integer> ids) {
        service.delete(ids);
    }

}
