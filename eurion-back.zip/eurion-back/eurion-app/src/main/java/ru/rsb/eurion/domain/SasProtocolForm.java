package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Протокол проверки клиента в SAS
 */
@Getter
@Setter
public class SasProtocolForm extends BasicForm {
    /**
     * Тип клиента (todo справочник???)
     */
    private ClientType clientType;
    /**
     * Максимально возможный СЕВ (средняя ежемесячная выплата)
     */
    private BigDecimal maximumSevAmount;
    /**
     * Максимально возможный СЗЛ (средний затратный лимит)
     */
    private BigDecimal maximumSzlAmount;
    /**
     * Причины из SAS
     */
    private List<String> causeList;
    /**
     * Сигналы из SAS
     */
    private List<String> signalList;
}
