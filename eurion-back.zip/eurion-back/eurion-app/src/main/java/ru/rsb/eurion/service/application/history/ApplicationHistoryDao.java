package ru.rsb.eurion.service.application.history;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.SummaryStatusReport;
import ru.rsb.eurion.domain.UserApproveLevel;
import ru.rsb.eurion.domain.UserDecision;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;
import ru.rsb.eurion.service.report.OperativeReportData;
import ru.rsb.eurion.service.report.dto.DecisionInfo;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Mapper
public interface ApplicationHistoryDao {

    String BASE_SELECT_SQL = "select ID,\n" +
            "       APPLICATION_ID,\n" +
            "       UPDATED_AT,\n" +
            "       SOURCE,\n" +
            "       TYPE,\n" +
            "       FIELD_PATH,\n" +
            "       NEW_VALUE,\n" +
            "       OLD_VALUE\n" +
            "from APPLICATION_HISTORY\n";

    @Insert("insert into APPLICATION_HISTORY (UPDATED_AT, APPLICATION_ID, SOURCE, TYPE, FIELD_PATH, OLD_VALUE, NEW_VALUE)\n" +
            "values (#{updatedAt, jdbcType=TIMESTAMP},\n" +
            "        #{applicationId, jdbcType=INTEGER},\n" +
            "        #{source, jdbcType=VARCHAR},\n" +
            "        #{type, jdbcType=VARCHAR},\n" +
            "        #{fieldPath, jdbcType=VARCHAR},\n" +
            "        #{oldValue, jdbcType=VARCHAR},\n" +
            "        #{newValue, jdbcType=VARCHAR})")
    void insert(@Param("updatedAt") LocalDateTime updatedAt,
                @Param("applicationId") Long applicationId,
                @Param("source") String source,
                @Param("type") ChangeFieldType type,
                @Param("fieldPath") String fieldName,
                @Param("oldValue") String oldValue,
                @Param("newValue") String newValue);

    @Select(BASE_SELECT_SQL + "where APPLICATION_ID = #{applicationId, jdbcType=INTEGER}\n" +
            "and (TYPE != 'ANY_FIELD' " +
            "or FIELD_PATH in (select PATH from APPLICATION_FIELD_TITLE))\n" +
            "  and TYPE != 'STATUS'\n" +
            "  and UPDATED_AT between #{startDate, jdbcType=TIMESTAMP} and #{endDate, jdbcType=TIMESTAMP}\n" +
            "order by UPDATED_AT desc\n" +
            "offset #{offset} rows\n" +
            "fetch first #{limit} rows only")
    @Results(id = "applicationHistoryMapping", value = {
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "source", column = "SOURCE"),
            @Result(property = "type", column = "TYPE"),
            @Result(property = "fieldPath", column = "FIELD_PATH"),
            @Result(property = "oldValue", column = "OLD_VALUE"),
            @Result(property = "newValue", column = "NEW_VALUE"),
            @Result(property = "applicationId", column = "APPLICATION_ID"),
    })
    List<ApplicationHistory> listByApplicationIdOrderByUpdatedAtDesc(
            @Param("applicationId") Integer applicationId,
            @Param("offset") int offset,
            @Param("limit") int limit,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate);

    @Select(BASE_SELECT_SQL + "where APPLICATION_ID = #{applicationId, jdbcType=INTEGER}\n" +
            "  and TYPE != 'STATUS'\n" +
            "and UPDATED_AT between #{startDate, jdbcType=TIMESTAMP} and #{endDate, jdbcType=TIMESTAMP}\n" +
            "order by UPDATED_AT asc\n" +
            "offset #{offset} rows\n" +
            "fetch first #{limit} rows only")
    @ResultMap("applicationHistoryMapping")
    List<ApplicationHistory> listByApplicationIdOrderByUpdatedAtAsc(
            @Param("applicationId") Integer applicationId,
            @Param("offset") int offset, @Param("limit") int limit,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate);

    @Select("select count(*)\n" +
            "from APPLICATION_HISTORY\n" +
            "where APPLICATION_ID = #{applicationId, jdbcType=INTEGER}\n" +
            "  and (TYPE != 'ANY_FIELD' or FIELD_PATH in (select PATH from APPLICATION_FIELD_TITLE))\n" +
            "  and TYPE != 'STATUS'\n" +
            "  and UPDATED_AT between #{startDate, jdbcType=TIMESTAMP} and #{endDate, jdbcType=TIMESTAMP}")
    int countByApplicationId(@Param("applicationId") Integer applicationId,
                             @Param("startDate") LocalDateTime startDate,
                             @Param("endDate") LocalDateTime endDate);

    String DECISION_INFO_SQL = "select IS_SUPERVISOR,\n" +
            "       APPROVED_COUNT,\n" +
            "       REJECTED_COUNT,\n" +
            "       POSTPONE_COUNT,\n" +
            "       IN_WORK_COUNT,\n" +
            "       USER_ID,\n" +
            "       case\n" +
            "           when APPROVED_COUNT = 0 then 0\n" +
            "           else round(APPROVED_COUNT / (APPROVED_COUNT + REJECTED_COUNT) * 100, 0) end as APPROVE_PERCENT\n" +
            "from (\n" +
            "         select IS_SUPERVISOR,\n" +
            "                SUM(APPROVED_COUNT) as APPROVED_COUNT,\n" +
            "                SUM(REJECTED_COUNT) as REJECTED_COUNT,\n" +
            "                SUM(POSTPONE_COUNT) as POSTPONE_COUNT,\n" +
            "                SUM(IN_WORK_COUNT)  as IN_WORK_COUNT,\n" +
            "                USER_ID\n" +
            "         from (select decode(ROLE_ID, 'SUPERVISOR', 1, 0)                             as IS_SUPERVISOR,\n" +
            "                      count(case when STATUS = 'Одобрено' then 1 end)                 as APPROVED_COUNT,\n" +
            "                      count(case when STATUS = 'Отклонено' then 1 end)                as REJECTED_COUNT,\n" +
            "                      count(case when STATUS = 'Отложено' then 1 end)                 as POSTPONE_COUNT,\n" +
            "                      count(case when STATUS in ('В работе', 'Назначено') then 1 end) as IN_WORK_COUNT,\n" +
            "                      USER_ID,\n" +
            "                      ROLE_ID\n" +
            "               from (select APH.STATUS      as STATUS,\n" +
            "                            u.SUPERVISOR_ID as SUPERVISOR_ID,\n" +
            "                            u.ID            as USER_ID,\n" +
            "                            usr.ROLE_ID     as ROLE_ID\n" +
            "                     from APPLICATION_STATUS_HISTORY APH\n" +
            "                              left join APP_USER u on APH.USER_ID = u.ID\n" +
            "                              left join APP_USER us on u.SUPERVISOR_ID = us.ID\n" +
            "                              left join APP_USER_ROLE usr on u.ID = usr.USER_ID and usr.ROLE_ID = 'SUPERVISOR'\n" +
            "                     where APH.UPDATED_AT between #{beginDate} and #{endDate}" +
            "                       and CHECK_TYPE = 'UNDERWRITING'\n" +
            "                       and STATUS_CODE = 'COMPLETED'\n" +
            "                       and APH.STATUS in ('Отклонено', 'Одобрено')\n" +
            "                       and APH.USER_ID is not null\n" +
            "                       and APH.USER_NAME != 'RTDM'\n" +
            "                     union all\n" +
            "                     select a.STATUS,\n" +
            "                            u.SUPERVISOR_ID as SUPERVISOR_ID,\n" +
            "                            u.ID            as USER_ID,\n" +
            "                            usr.ROLE_ID     as ROLE_ID\n" +
            "                     from Application a\n" +
            "                              left join APP_USER u on a.USER_ID = u.ID\n" +
            "                              left join APP_USER us on u.SUPERVISOR_ID = us.ID\n" +
            "                              left join APP_USER_ROLE usr on u.ID = usr.USER_ID and usr.ROLE_ID = 'SUPERVISOR'\n" +
            "                     where a.CHECK_TYPE = 'UNDERWRITING'\n" +
            "                       and a.STATUS in ('Отложено', 'В работе', 'Назначено')\n" +
            "                       and a.USER_ID is not null\n" +
            "                       and a.DONE_AT is null)\n" +
            "               group by STATUS, SUPERVISOR_ID, ROLE_ID, USER_ID, ROLE_ID)\n" +
            "         group by IS_SUPERVISOR, USER_ID)";

    @Select(DECISION_INFO_SQL)
    @Results({
            @Result(column = "USER_ID", property = "userId"),
            @Result(column = "APPROVED_COUNT", property = "approveAmount"),
            @Result(column = "REJECTED_COUNT", property = "rejectAmount"),
            @Result(column = "IS_SUPERVISOR", property = "isSupervisor"),
            @Result(column = "IN_WORK_COUNT", property = "inWorkCount"),
            @Result(column = "POSTPONE_COUNT", property = "postponeCount"),
            @Result(column = "APPROVE_PERCENT", property = "approvePercent")
    })
    List<DecisionInfo> getDecisionInfo(@Param("beginDate") LocalDateTime beginDate,
                                       @Param("endDate") LocalDateTime endDate);

    String SUMMARY_BY_USER_SQL = "select APPROVED_COUNT,\n" +
            "       REJECTED_COUNT,\n" +
            "       (select count(1)\n" +
            "        from application\n" +
            "        where DONE_AT is null\n" +
            "          and CHECK_TYPE = 'UNDERWRITING'\n" +
            "          and USER_ID = #{userId, jdbcType = INTEGER}\n" +
            "          and STATUS_CATEGORY_CODE in ('IN_WORK', 'ASSIGNED', 'POSTPONED')) as IN_WORK_COUNT\n" +
            "from (select count(case when STATUS = 'Одобрено' then 1 end)  as APPROVED_COUNT,\n" +
            "             count(case when STATUS = 'Отклонено' then 1 end) as REJECTED_COUNT\n" +
            "      from APPLICATION_STATUS_HISTORY a\n" +
            "             left join APP_USER u on a.USER_ID = u.ID\n" +
            "      where a.UPDATED_AT between #{beginDate} and #{endDate}\n" +
            "        and CHECK_TYPE = 'UNDERWRITING'\n" +
            "        and STATUS_CODE = 'COMPLETED'\n" +
            "        and a.USER_ID = #{userId, jdbcType = INTEGER})";

    @Select(SUMMARY_BY_USER_SQL)
    @Results({
            @Result(column = "APPROVED_COUNT", property = "approvedCount"),
            @Result(column = "REJECTED_COUNT", property = "rejectedCount"),
            @Result(column = "IN_WORK_COUNT", property = "inWorkCount")
    })
    OperativeReportData.SummaryDecision getSummaryByUserId(@Param("beginDate") LocalDateTime beginDate,
                                                           @Param("endDate") LocalDateTime endDate,
                                                           @Param("userId") Integer userId);

    String SUMMARY_DECISION_BY_USER_SQL =
            "select u.FULL_NAME,\n" +
                    "       u.ID,\n" +
                    "       count(\n" +
                    "               case\n" +
                    "                   when STATUS in ('Одобрено', 'Отклонено')\n" +
                    "                       and h.CHECK_TYPE = 'UNDERWRITING'\n" +
                    "                       and h.STATUS_CODE = 'COMPLETED'\n" +
                    "                       and h.UPDATED_AT between #{beginDate} and #{endDate}\n" +
                    "                       then 1 end) as DECISION_COUNT\n" +
                    "from APP_USER u\n" +
                    "         left join APPLICATION_STATUS_HISTORY h on h.USER_ID = u.ID\n" +
                    "where u.id in (#{userIds})\n" +
                    "group by u.USERNAME, u.FULL_NAME, u.ID\n" +
                    "order by u.FULL_NAME";

    @Select(SUMMARY_DECISION_BY_USER_SQL)
    @Results({
            @Result(column = "ID", property = "userId"),
            @Result(column = "FULL_NAME", property = "fullName"),
            @Result(column = "DECISION_COUNT", property = "decisionCount")
    })
    @Lang(MybatisExtendedLanguageDriver.class)
    List<UserDecision> getSummaryDecisionByUserIds(@Param("beginDate") LocalDateTime beginDate,
                                                   @Param("endDate") LocalDateTime endDate,
                                                   @Param("userIds") Set<Integer> userIds);

    String SUMMARY_APPROVE_BY_USER_SQL =
            "select case\n" +
                    "           when APPROVE_COUNT = 0 then 0\n" +
                    "           else round(APPROVE_COUNT / (APPROVE_COUNT + DECLINE_COUNT) * 100, 0) end as APPROVE_PERCENT,\n" +
                    "       FULL_NAME,\n" +
                    "       STEP_PERCENT,\n" +
                    "       PLANNED_APPROVE_PERCENT,\n" +
                    "       PRODUCTION_RATE_PERCENT\n" +
                    "from (\n" +
                    "         Select u.FULL_NAME,\n" +
                    "                count(case when STATUS in ('Одобрено') then 1 end)  as APPROVE_COUNT,\n" +
                    "                count(case when STATUS in ('Отклонено') then 1 end) as DECLINE_COUNT,\n" +
                    "                s.STEP_PERCENT                                      as STEP_PERCENT,\n" +
                    "                s.PRODUCTION_RATE_PERCENT                           as PRODUCTION_RATE_PERCENT,\n" +
                    "                s.APPROVE_PERCENT                                   as PLANNED_APPROVE_PERCENT\n" +
                    "         from APP_USER u\n" +
                    "                  left join (select a.USER_ID as USER_ID,\n" +
                    "                                    a.STATUS\n" +
                    "                             from APPLICATION_STATUS_HISTORY a\n" +
                    "                             left join SKILL_GROUP sg on sg.ID = a.SKILL_GROUP_ID\n" +
                    "                             where a.UPDATED_AT between #{beginDate} and #{endDate}\n" +
                    "                               and a.CHECK_TYPE = 'UNDERWRITING'\n" +
                    "                               and STATUS_CODE = 'COMPLETED'\n" +
                    "                               and a.STATUS in ('Одобрено', 'Отклонено')\n" +
                    "                               and sg.ROLE_ID = #{skillGroupRoleId, jdbcType = INTEGER}\n" +
                    "         ) B on B.USER_ID = u.ID\n" +
                    "                  left join PRODUCTIVITY_SETTINGS s on s.ROLE_ID = #{skillGroupRoleId, jdbcType = INTEGER}\n" +
                    "         where u.ID in (#{userIds})\n" +
                    "         group by USERNAME, FULL_NAME, s.APPROVE_PERCENT, STEP_PERCENT, PRODUCTION_RATE_PERCENT, u.Id\n" +
                    "         order by FULL_NAME)";

    @Select(SUMMARY_APPROVE_BY_USER_SQL)
    @Results({
            @Result(column = "FULL_NAME", property = "fullName"),
            @Result(column = "APPROVE_PERCENT", property = "approvePercent"),
            @Result(column = "STEP_PERCENT", property = "stepPercent"),
            @Result(column = "PLANNED_APPROVE_PERCENT", property = "plannedApprovePercent"),
            @Result(column = "PRODUCTION_RATE_PERCENT", property = "productionRatePercent")
    })
    @Lang(MybatisExtendedLanguageDriver.class)
    List<UserApproveLevel> getSummaryApproveByUserIds(@Param("beginDate") LocalDateTime beginDate,
                                                      @Param("endDate") LocalDateTime endDate,
                                                      @Param("userIds") Set<Integer> userIds,
                                                      @Param("skillGroupRoleId") Integer skillGroupRoleId);

    String SUMMARY_APPROVE_BY_CREDIT_TYPE = "select ALL_INCOME,\n" +
            "       IN_QUEUE,\n" +
            "       IN_WORK,\n" +
            "       RECOUNT,\n" +
            "       REWORK,\n" +
            "       REVIEWED,\n" +
            "       APPROVED,\n" +
            "       case\n" +
            "           when APPROVED = 0 then 0\n" +
            "           else round(APPROVED / (REVIEWED) * 100, 1) end as APPROVE_PERCENT,\n" +
            "       CREDIT_TYPE\n" +
            "from (select SUM(ALL_INCOME) as ALL_INCOME,\n" +
            "             SUM(IN_QUEUE)   as IN_QUEUE,\n" +
            "             SUM(IN_WORK)    as IN_WORK,\n" +
            "             SUM(RECOUNT)    as RECOUNT,\n" +
            "             SUM(REWORK)     as REWORK,\n" +
            "             SUM(REVIEWED)   as REVIEWED,\n" +
            "             SUM(APPROVED)   as APPROVED,\n" +
            "             CREDIT_TYPE\n" +
            "      from (select count(case when STATUS = 'Одобрено' then 1 end)                             as APPROVED,\n" +
            "                   count(case when STATUS in ('В работе', 'Назначено', 'Отложено') then 1 end) as IN_WORK,\n" +
            "                   count(case when STATUS = 'В очереди' then 1 end)                            as IN_QUEUE,\n" +
            "                   count(case when STATUS = 'Доработка' then 1 end)                            as REWORK,\n" +
            "                   count(case when STATUS = 'Пересчет' then 1 end)                             as RECOUNT,\n" +
            "                   count(case when STATUS in ('Одобрено', 'Отклонено') then 1 end)             as REVIEWED,\n" +
            "                   count(case when CREATED_AT > #{beginDate} then 1 end)                       as ALL_INCOME,\n" +
            "                   decode(CREDIT_TYPE,\n" +
            "                          'Docs', 'POS',\n" +
            "                          'PIL', 'PIL',\n" +
            "                          'POS', 'POS',\n" +
            "                          'DIRECT_SALE', 'DS',\n" +
            "                          'CROSS_SALE', 'DS',\n" +
            "                          'ZAYAVKA', 'DS', 'UNKNOWN')               AS CREDIT_TYPE\n" +
            "            from (select APH.STATUS                                  as STATUS,\n" +
            "                         decode(s.ROLE_ID, 1, 'Docs', a.CREDIT_TYPE) AS CREDIT_TYPE,\n" +
            "                         a.CREATED_AT                                as CREATED_AT\n" +
            "                  from APPLICATION_STATUS_HISTORY APH\n" +
            "                           left join APPLICATION a ON APH.APPLICATION_ID = a.ID\n" +
            "                           left join SKILL_GROUP s ON a.SKILL_GROUP_ID = s.ID\n" +
            "                  where APH.UPDATED_AT between #{beginDate} and #{endDate}\n" +
            "                    and APH.CHECK_TYPE = 'UNDERWRITING'\n" +
            "                    and APH.STATUS_CODE = 'COMPLETED'\n" +
            "                    and APH.STATUS in ('Отклонено', 'Одобрено', 'Доработка', 'Отклонено')\n" +
            "                    and APH.USER_NAME != 'RTDM'\n" +
            "                  union all\n" +
            "                  select a.STATUS                                    as STATUS,\n" +
            "                      decode(s.ROLE_ID, 1, 'Docs', a.CREDIT_TYPE) AS CREDIT_TYPE,\n" +
            "                      a.CREATED_AT                                as CREATED_AT\n" +
            "                  from Application a\n" +
            "                      left join SKILL_GROUP s ON a.SKILL_GROUP_ID = s.ID\n" +
            "                  where a.CHECK_TYPE = 'UNDERWRITING'\n" +
            "                    and a.STATUS in ('Отложено', 'В работе', 'Назначено', 'В очереди', 'Пересчет')\n" +
            "                    and a.DONE_AT is null)\n" +
            "            group by STATUS, CREDIT_TYPE, CREATED_AT)\n" +
            "      group by CREDIT_TYPE)\n" +
            "order by case\n" +
            "             when CREDIT_TYPE = 'PIL' then 1\n" +
            "             when CREDIT_TYPE = 'DS' then 2\n" +
            "             when CREDIT_TYPE = 'POS' then 3\n" +
            "             when CREDIT_TYPE = 'Docs' then 4\n" +
            "             else 5\n" +
            "             end";

    @Select(SUMMARY_APPROVE_BY_CREDIT_TYPE)
    @Results({
            @Result(column = "ALL_INCOME", property = "income"),
            @Result(column = "IN_QUEUE", property = "inQueue"),
            @Result(column = "IN_WORK", property = "inWork"),
            @Result(column = "RECOUNT", property = "recount"),
            @Result(column = "REWORK", property = "rework"),
            @Result(column = "REVIEWED", property = "reviewed"),
            @Result(column = "APPROVED", property = "approve"),
            @Result(column = "APPROVE_PERCENT", property = "approveLevel"),
            @Result(column = "CREDIT_TYPE", property = "creditType")
    })
    List<SummaryStatusReport> getSummaryStatusByCreditType(@Param("beginDate") LocalDateTime beginDate,
                                                           @Param("endDate") LocalDateTime endDate);
}
