package ru.rsb.eurion.service.admin.users.upd;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;
import ru.rsb.eurion.domain.LotusUserInfo;
import ru.rsb.eurion.settings.EisConfig;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Map;

@Repository
@AllArgsConstructor
public class PersonnelServiceClient extends BaseEisClient {

    private final EisConfig eisConfig;

    public LotusUserInfo getLotusUserInfo(@Nonnull String personnelNumber) {
        Map<String, String> parameters = Collections.singletonMap("personnelNumber", personnelNumber);
        return executeGet(LotusUserInfo.class, eisConfig.getPersonnelServiceUrl(), parameters);
    }
}
