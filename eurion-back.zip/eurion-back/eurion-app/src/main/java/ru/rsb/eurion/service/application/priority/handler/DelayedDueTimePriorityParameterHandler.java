package ru.rsb.eurion.service.application.priority.handler;

import org.mybatis.dynamic.sql.SortSpecification;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.priority.PriorityParameter;
import ru.rsb.eurion.domain.priority.SortDirection;
import ru.rsb.eurion.service.application.priority.PriorityParameterHandler;

import static ru.rsb.eurion.service.application.priority.ApplicationPriorityService.PRIORITY_HANDLER_PREFIX;

@Component(PRIORITY_HANDLER_PREFIX + "DELAYED_DUE_TIME")
public class DelayedDueTimePriorityParameterHandler implements PriorityParameterHandler {

    @Override
    public SortSpecification apply(PriorityParameter parameter) {
        return new Spec(parameter.getDirection() == SortDirection.DESC ^ !parameter.isReverse());
    }

    @Override
    public boolean isCommon() {
        return true;
    }

    public static class Spec implements SortSpecification {
        private static final String EXPRESSION =
                "case when IDX.SUSPEND_TIME > current_timestamp then 1 else 0 end";
        private final boolean descending;

        private Spec(boolean descending) {
            this.descending = descending;
        }

        @Override
        public SortSpecification descending() {
            return new Spec(true);
        }

        @Override
        public String aliasOrName() {
            return EXPRESSION;
        }

        @Override
        public boolean isDescending() {
            return descending;
        }
    }
}
