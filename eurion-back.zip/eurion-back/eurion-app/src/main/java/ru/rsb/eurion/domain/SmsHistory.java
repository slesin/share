package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class SmsHistory {

    private Integer id;

    private Long blankId;

    private String phoneNumber;

    private String messageId;

    private Integer messageTemplateId;

    private LocalDateTime createdAt;
}
