package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.service.phone.autodialer.AutoDialerStatus;

import javax.annotation.Nonnull;
import java.util.List;

@Service
@AllArgsConstructor
@Slf4j
public class NotificationService {
    private final SimpMessagingTemplate messagingTemplate;

    public void sendCloseEvent(@Nonnull @NonNull Long id,
                               @Nonnull @NonNull String reason,
                               @Nonnull @NonNull Integer userId) {
        ApplicationMessage message = new ApplicationMessage(id, reason, userId);
        messagingTemplate.convertAndSend("/topic/application/" + id, message);
    }

    public void sendReturnFormRecountEvent(ApplicationEntity entity) {
        User user = entity.getUser();
        if (user != null) {
            UserMessage.UserEvent event = UserMessage.UserEvent.RETURN_FROM_RECALC;
            String msg = "Заявка возвращена с пересчета: id=" + entity.getBlankId();
            mapAndSend(entity, user, event, msg);
            log.info("Notification of returning from recount is sent to user: {}", user);
        }
    }

    public void onHighRtdmPriorityApplication(ApplicationEntity entity) {
        User user = entity.getUser();
        if (user != null) {
            UserMessage.UserEvent event = UserMessage.UserEvent.HIGH_RTMD_PRIORITY_ASSIGNED;
            String priorityName = entity.getRtdmPriority() != null ? entity.getRtdmPriority().getName() : "";
            String msg = String.format("На Вас назначена заявка %s-%s", entity.getBlankId(), priorityName);
            mapAndSend(entity, user, event, msg);
            log.info("Notification of high RTDM priority is sent to user: {}", user);
        }
    }

    public void sendMassCallEvent(Long applicationId, AutoDialerStatus autoDialerStatus, Integer userId) {
        UserMessage message = new UserMessage();
        message.setUserId(userId);
        message.setEvent(UserMessage.UserEvent.AUTO_DIALER_STATUS);
        message.setAppId(applicationId);
        message.setAutoDialerStatus(autoDialerStatus);
        messagingTemplate.convertAndSend("/topic/user/" + userId, message);
    }

    public void doNotification(@Nonnull ApplicationEntity entity,
                               @Nonnull UserMessage.UserEvent event,
                               @Nonnull String message) {
        User user = entity.getUser();
        if (user != null) {
            mapAndSend(entity, user, event, message);
            log.info("Notification '{}' is sent to user: {}", event, user);
        }
    }

    @Async
    public void onIncomingCall(List<Integer> userIdList) {
        UserMessage message = new UserMessage();
        message.setEvent(UserMessage.UserEvent.INCOMING_CALL);
        message.setText("Поступил телефонный звонок от клиента");
        userIdList.forEach(userId -> {
            try {
                messagingTemplate.convertAndSend("/topic/user/" + userId, message);
            } catch (RuntimeException e) {
                log.error("Error sending notification about incoming call to userId={}", userId);
                log.error("", e);
            }
        });
    }

    private void mapAndSend(@Nonnull ApplicationEntity entity,
                            @Nonnull User user,
                            @Nonnull UserMessage.UserEvent event,
                            @Nonnull String msg) {
        msg = msg.replace("%BLANK_ID%", "" + entity.getBlankId());

        UserMessage message = new UserMessage();
        message.setUserId(user.getId());
        message.setEvent(event);
        message.setText(msg);
        message.setAppId(entity.getId());
        message.setBlankId(entity.getBlankId());
        messagingTemplate.convertAndSend("/topic/user/" + user.getId(), message);
    }
}
