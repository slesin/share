package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Справочник результата обзвона
 */
@Getter
@Setter
public class CallResult extends BasicReference {
    /**
     * Идентификатор типа контакта
     */
    Integer contactTypeId;
}
