package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Контрольный вопрос
 */
@Getter
@Setter
public class ControlQuestion extends BasicReference {

    /**
     * Ответы
     */
    private List<ControlQuestionAnswer> answers;
}
