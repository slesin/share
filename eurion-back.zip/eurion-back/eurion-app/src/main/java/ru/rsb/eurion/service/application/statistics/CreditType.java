package ru.rsb.eurion.service.application.statistics;

public enum CreditType {
    POS,
    PIL,
    DS,
    UNKNOWN
}
