package ru.rsb.eurion.service.application.branch;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BranchItem {
    private Long id;

    private Long externalId;

    private String metro;

    private String region;

    private String cityType;

    private String cityName;

    private String streetType;

    private String streetName;

    private String house;

    private Boolean officeAvailable;

    private String latitude;

    private String longitude;

    private String phone;

    private String landmark;
}
