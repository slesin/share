package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import org.flowable.form.api.FormInfo;
import org.flowable.form.api.FormModel;
import org.flowable.form.model.FormOutcome;
import org.flowable.form.model.SimpleFormModel;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
public class FormData {
    private String name;
    private String key;
    private String description;
    private List<FormOutcome> outcomes;

    public static FormData of(FormInfo info) {
        if (info == null) {
            return null;
        }

        FormData data = new FormData();
        data.setName(info.getName());
        data.setKey(info.getKey());
        data.setDescription(info.getDescription());

        FormModel formModel = info.getFormModel();
        if (formModel instanceof SimpleFormModel) {
            SimpleFormModel model = (SimpleFormModel) formModel;
            data.setOutcomes(new ArrayList<>(model.getOutcomes()));
        }
        return data;
    }

    public List<FormOutcome> getOutcomes() {
        if (outcomes == null) {
            outcomes = new ArrayList<>();
        }
        return outcomes;
    }
}
