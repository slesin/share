package ru.rsb.eurion.service.admin.users.status;

import lombok.AllArgsConstructor;
import org.mapstruct.Context;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.domain.UserStatus;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.settings.SessionConfig;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import java.util.List;

@RequestMapping(path = EurionApplication.API_BASE + "/users/status", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class UserStatusResource {

    private final UserStatusService service;
    private final SessionConfig sessionConfig;
    private final UserStatusFacade facade;

    //TODO remove after front's merge
    @GetMapping(path = "/current")
    public UserStatus getUserStatus() {
        UserData user = AuthUtil.loggedUser();
        return service.getStatus(user.getId());
    }

    @GetMapping(path = "/current-with-role")
    public UserStatusAndRole getUserStatusAndRole() {
        return service.getCurrentStatusAndRole();
    }

    @PutMapping(path = "/{role}")
    public UserData setUserStatus(@Nullable @RequestBody(required = false) UserStatus userStatus,
                                  @NotNull @PathVariable("role") Role role,
                                  @Context HttpServletRequest httpRequest) {
        UserStatusAndRole userStatusAndRole = facade.setUserStatusAndRole(userStatus, role);
        userStatus = userStatusAndRole.getStatus();
        if (Role.UNDERWRITER == role && UserStatusService.DEFAULT_ENTER_STATUS == userStatus.getCode()) {
            AuthUtil.setSessionTimeout(httpRequest.getSession(), sessionConfig.getUnderwriterSessionTimeout());
        } else {
            AuthUtil.setSessionTimeout(httpRequest.getSession(), sessionConfig.getDefaultSessionTimeout());
        }
        return AuthUtil.loggedUser();
    }

    @GetMapping
    public List<UserStatus> getStatusList() {
        return service.getStatusList();
    }

    /**
     * Метод получения списка пользователей со скилгруппами для "Домашней страницы. Супервайзера"
     */
    @GetMapping("/skill/{supervisorId}")
    public List<UserStatusSkillDTO> getAllUserWithStatusAndSkill(@NotNull @PathVariable("supervisorId") Integer supervisorId) {
        return service.getAllUsersWithStatusAndSkillGroup(supervisorId);
    }
}
