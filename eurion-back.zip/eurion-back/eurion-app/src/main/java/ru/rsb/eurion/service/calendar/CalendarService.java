package ru.rsb.eurion.service.calendar;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.rsb.eis.api.calendar.CalendarFault;
import ru.rsb.eis.api.calendar.CalendarWS;
import ru.rsb.eis.api.calendar.GetCalendarRequest;
import ru.rsb.eis.api.calendar.GetCalendarResponse;

import javax.annotation.Nullable;
import java.time.LocalDate;
import java.util.function.Supplier;

@Slf4j
@RequiredArgsConstructor
@Service
public class CalendarService {

    private final Supplier<CalendarWS> calendarWSWSSupplier;
    private boolean isTodayHoliday;


    public boolean isTodayHoliday() {
        return isTodayHoliday;
    }

    @Scheduled(cron = "${app.schedule.holiday_calendar.cron}")
    private void updateCalendar() {
        GetCalendarResponse calendar = getCalendar();
        if (calendar != null) {
            log.info("Calendar was updated.");
            LocalDate currentDate = LocalDate.now();
            calendar.getHolidays().forEach(holiday -> {
                if (holiday.getMonth() == currentDate.getMonthValue() && holiday.getDay() == currentDate.getDayOfMonth()) {
                    isTodayHoliday = true;
                }
            });
        }
    }

    @Nullable
    private GetCalendarResponse getCalendar() {
        CalendarWS port = calendarWSWSSupplier.get();
        try {
            GetCalendarRequest request = new GetCalendarRequest();
            request.setYear(LocalDate.now().getYear());
            return port.getCalendar(request);
        } catch (CalendarFault calendarFault) {
            log.error("", calendarFault);
        }
        return null;
    }
}
