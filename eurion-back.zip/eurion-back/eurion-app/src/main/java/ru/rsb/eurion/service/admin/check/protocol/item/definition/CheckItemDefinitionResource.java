package ru.rsb.eurion.service.admin.check.protocol.item.definition;


import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.CheckItemDefinition;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.ResultWrapper;
import ru.rsb.eurion.service.admin.Consts;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping(path = Consts.ADMIN_API_BASE + "/item-definition", produces = APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class CheckItemDefinitionResource {

    private final CheckItemDefinitionService service;

    @GetMapping("/{id}")
    public CheckItemDefinition findOne(@PathVariable("id") Integer id) {
        return service.findOne(id);
    }

    @PostMapping(consumes = APPLICATION_JSON_VALUE)
    public ResultWrapper<CheckItemDefinition> create(@NotNull @Valid @RequestBody CheckItemDefinition checkItemDefinition)
            throws BusinessException {
        CheckItemDefinition created = service.create(checkItemDefinition);
        return ResultWrapper.of(created);
    }

    @PutMapping(path = "/update", consumes = APPLICATION_JSON_VALUE)
    public ResultWrapper<CheckItemDefinition> update(@NotNull @Valid @RequestBody CheckItemDefinition checkItemDefinition) {
        CheckItemDefinition updated = service.update(checkItemDefinition);
        return ResultWrapper.of(updated);
    }

    @PutMapping(path = "/updateMany", consumes = APPLICATION_JSON_VALUE)
    public ResultWrapper<List<CheckItemDefinition>> update(@NotNull @Valid @RequestBody List<CheckItemDefinition> checkItemDefinitions) {
        List<CheckItemDefinition> updated = service.updateMultiple(checkItemDefinitions);
        return ResultWrapper.of(updated);
    }

    @GetMapping
    public ResultWrapper<List<CheckItemDefinition>> list() {
        List<CheckItemDefinition> checkItemDefinitions = service.list();
        return ResultWrapper.of(checkItemDefinitions);
    }

    @PostMapping(path = "/disable/{id}")
    public ResultWrapper<?> disable(@PathVariable("id") Integer id) {
        service.disable(id);
        return ResultWrapper.OK_EMPTY;
    }

    @PostMapping(path = "/disable")
    public ResultWrapper<?> disableMultiple(@RequestBody List<Integer> ids) {
        service.disableMultiple(ids);
        return ResultWrapper.OK_EMPTY;
    }

    @PostMapping(path = "/enable/{id}")
    public ResultWrapper<?> activate(@PathVariable("id") Integer id) {
        service.enable(id);
        return ResultWrapper.OK_EMPTY;
    }

    @PostMapping(path = "/enable")
    public ResultWrapper<?> enableMultiple(@RequestBody List<Integer> ids) {
        service.enableMultiple(ids);
        return ResultWrapper.OK_EMPTY;
    }

    @DeleteMapping(path = "/delete/{id}")
    public ResultWrapper<?> delete(@PathVariable("id") Integer id) throws BusinessException {
        service.delete(id);
        return ResultWrapper.OK_EMPTY;
    }

}
