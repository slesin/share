package ru.rsb.eurion.service.admin.skill.group;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.CheckItemDefinition;
import ru.rsb.eurion.domain.DeclineCategory;
import ru.rsb.eurion.domain.Form;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.domain.SkillGroupRole;
import ru.rsb.eurion.domain.User;

import javax.annotation.Nonnull;
import java.util.List;

@Getter
@Setter
@Builder
public class SkillGroupAggragate {
    @Nonnull
    private final SkillGroup skillGroup;

    /**
     * GET /api/ref/skill-group-role
     */
    @Nonnull
    private final List<SkillGroupRole> skillGroupRoles;

    /**
     * GET /api/ref/decline-category
     */
    @Nonnull
    private final List<DeclineCategory> allDeclineCategories;

    /**
     * GET /api/admin/skill-group/decline-category/{id}
     */
    @Nonnull
    private final List<DeclineCategory> declineCategories;

    /**
     * GET /api/admin/form-definition/skill-group/{id}
     */
    @Nonnull
    private final List<FormDefinition> formDefinitions;

    /**
     * GET /api/ref/form
     */
    @Nonnull
    private final List<Form> allForms;

    /**
     * GET /api/admin/skill-group/skill-group-users/{id}
     */
    @Nonnull
    private final List<User> members;

    /**
     * GET /api/admin/item-definition
     */
    @Nonnull
    private final List<CheckItemDefinition> allCheckItemDefinitions;
}
