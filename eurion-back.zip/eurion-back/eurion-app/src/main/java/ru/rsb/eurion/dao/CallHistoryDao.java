package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.CallHistory;

import javax.annotation.Nullable;
import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface CallHistoryDao {

    String BASE_SQL = "select\n" +
            "  ch.ID,\n" +
            "  ch.CLIENT_ID,\n" +
            "  ch.PHONE_DETAIL_ID,\n" +
            "  ch.CALL_DATE,\n" +
            "  ch.CALL_DONE,\n" +
            "  ch.HOUSEHOLD_INCOME,\n" +
            "  ch.CREATED_AT,\n" +
            "  ch.ACTION_ID,\n" +
            "  ch.PHONE_NUMBER,\n" +
            "  ch.CONTACT_FORBIDDEN,\n" +
            "  ch.HOUSEHOLD,\n" +
            "  ch.RESULT_ID,\n" +
            "  ch.CONTACT_TYPE_ID,\n" +
            "  ch.PHONE_TYPE_ID,\n" +
            "  ch.BLANK_ID,\n" +
            "  pt.CODE,\n" +
            "  ch.REMARK,\n" +
            "  ch.OTHER_PHONE_SOURCE,\n" +
            "  ch.USER_ID\n" +
            "from CALL_HISTORY ch\n" +
            "  join PHONE_TYPE pt on ch.PHONE_TYPE_ID = pt.ID\n";

    @Select(BASE_SQL + "where BLANK_ID = #{blankId, jdbcType=INTEGER} order by CREATED_AT desc")
    @Results(id = "callHistoryMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "clientId", column = "CLIENT_ID"),
            @Result(property = "phoneDetailId", column = "PHONE_DETAIL_ID"),
            @Result(property = "callDate", column = "CALL_DATE"),
            @Result(property = "callDone", column = "CALL_DONE"),
            @Result(property = "householdIncome", column = "HOUSEHOLD_INCOME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "actionId", column = "ACTION_ID"),
            @Result(property = "phoneNumber", column = "PHONE_NUMBER"),
            @Result(property = "contactForbidden", column = "CONTACT_FORBIDDEN"),
            @Result(property = "hasHouseholdIncome", column = "HOUSEHOLD"),
            @Result(property = "callResultId", column = "RESULT_ID"),
            @Result(property = "contactTypeId", column = "CONTACT_TYPE_ID"),
            @Result(property = "phoneTypeId", column = "PHONE_TYPE_ID"),
            @Result(property = "blankId", column = "BLANK_ID"),
            @Result(property = "phoneTypeCode", column = "CODE"),
            @Result(property = "remark", column = "REMARK"),
            @Result(property = "otherPhoneSource", column = "OTHER_PHONE_SOURCE"),
            @Result(property = "userId", column = "USER_ID"),
    })
    List<CallHistory> listByBlankId(@Param("blankId") Integer blankId);

    @Select(BASE_SQL + "where BLANK_ID = #{blankId, jdbcType=BIGINT}\n" +
            "and ch.CREATED_AT between #{startDate} " +
            "and #{endDate} order by CREATED_AT desc")
    @ResultMap("callHistoryMapping")
    List<CallHistory> listByBlankIdAndInterval(@Param("blankId") Long blankId,
                                               @Param("startDate") LocalDateTime startDate,
                                               @Param("endDate") LocalDateTime endDate);

    @Insert("insert into CALL_HISTORY(CLIENT_ID,\n" +
            "                         PHONE_DETAIL_ID,\n" +
            "                         CALL_DATE,\n" +
            "                         CALL_DONE,\n" +
            "                         HOUSEHOLD_INCOME,\n" +
            "                         CREATED_AT,\n" +
            "                         ACTION_ID,\n" +
            "                         PHONE_NUMBER,\n" +
            "                         PHONE_TYPE_ID,\n" +
            "                         BLANK_ID,\n" +
            "                         REMARK,\n" +
            "                         OTHER_PHONE_SOURCE," +
            "                         USER_ID)\n" +
            "values (#{clientId, jdbcType = INTEGER},\n" +
            "    #{callHistory.phoneDetailId, jdbcType = VARCHAR},\n" +
            "    #{callHistory.callDate, jdbcType = VARCHAR},\n" +
            "    #{callHistory.callDone, jdbcType = VARCHAR},\n" +
            "    #{callHistory.hasHouseholdIncome, jdbcType = VARCHAR},\n" +
            "    #{createdAt, jdbcType = TIMESTAMP},\n" +
            "    #{callHistory.actionId, jdbcType = VARCHAR},\n" +
            "    #{callHistory.phoneNumber, jdbcType = VARCHAR},\n" +
            "    #{callHistory.phoneTypeId, jdbcType = INTEGER},\n" +
            "    #{callHistory.blankId, jdbcType = INTEGER},\n" +
            "    #{callHistory.remark, jdbcType = VARCHAR},\n" +
            "    #{callHistory.otherPhoneSource, jdbcType = VARCHAR}," +
            "    #{callHistory.userId, jdbcType = INTEGER})")
    @SelectKey(
            keyProperty = "callHistory.id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_call_history.currval AS id from dual"}
    )
    void create(@Param("clientId") Integer clientId,
                @Param("callHistory") CallHistory callHistory,
                @Param("createdAt") LocalDateTime createdAt);

    @Update("update CALL_HISTORY\n" +
            "set\n" +
            "  CALL_DONE         = #{callHistory.callDone, jdbcType=VARCHAR},\n" +
            "  HOUSEHOLD_INCOME  = #{callHistory.householdIncome, jdbcType=VARCHAR},\n" +
            "  CONTACT_FORBIDDEN = #{callHistory.contactForbidden, jdbcType=INTEGER},\n" +
            "  RESULT_ID         = #{callHistory.callResultId, jdbcType=INTEGER},\n" +
            "  CONTACT_TYPE_ID   = #{callHistory.contactTypeId, jdbcType=INTEGER},\n" +
            "  HOUSEHOLD         = #{callHistory.hasHouseholdIncome, jdbcType=INTEGER},\n" +
            "  REMARK            = #{callHistory.remark, jdbcType=VARCHAR}\n" +
            "where ID = #{callHistory.id}")
    void update(@Param("callHistory") CallHistory callHistory);

    @Select(BASE_SQL + "where USER_ID = #{userId} order by CALL_DATE desc fetch first 1 row only")
    @Nullable
    CallHistory getLastOneByUserId(Integer id);
}
