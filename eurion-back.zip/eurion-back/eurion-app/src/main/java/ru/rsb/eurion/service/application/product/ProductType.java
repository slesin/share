package ru.rsb.eurion.service.application.product;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.BasicReference;

@Getter
@Setter
public class ProductType extends BasicReference {

    private Integer id;

    private String name;

}
