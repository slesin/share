package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.RoleProductivitySettings;

import java.math.BigDecimal;
import java.util.List;

@Mapper
public interface ProductivitySettingsDao {

    String BASE_SELECT_SQL = "select ps.ROLE_ID,\n" +
            "       sgr.NAME,\n" +
            "       ps.APPROVE_PERCENT,\n" +
            "       ps.STEP_PERCENT,\n" +
            "       ps.PRODUCTION_RATE_PERCENT,\n" +
            "       ps.PRODUCTION_RATE_PER_HOUR,\n" +
            "       ps.CREATED_AT,\n" +
            "       ps.UPDATED_AT,\n" +
            "       ps.DISABLED_AT\n" +
            "from PRODUCTIVITY_SETTINGS ps\n" +
            "       join SKILL_GROUP_ROLE sgr on ps.ROLE_ID = sgr.ID\n";

    @Select(BASE_SELECT_SQL)
    @Results(id = "productivitySettings", value = {
            @Result(property = "roleId", column = "ROLE_ID"),
            @Result(property = "roleName", column = "NAME"),
            @Result(property = "approvePercent", column = "APPROVE_PERCENT"),
            @Result(property = "stepPercent", column = "STEP_PERCENT"),
            @Result(property = "productionRatePercent", column = "PRODUCTION_RATE_PERCENT"),
            @Result(property = "productionRatePerHour", column = "PRODUCTION_RATE_PER_HOUR"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<RoleProductivitySettings> list();

    @Insert("insert into PRODUCTIVITY_SETTINGS (ROLE_ID,\n" +
            "                                   APPROVE_PERCENT,\n" +
            "                                   STEP_PERCENT,\n" +
            "                                   PRODUCTION_RATE_PERCENT,\n" +
            "                                   PRODUCTION_RATE_PER_HOUR,\n" +
            "                                   CREATED_AT,\n" +
            "                                   UPDATED_AT,\n" +
            "                                   DISABLED_AT)\n" +
            "values (#{settings.roleId, jdbcType=INTEGER},\n" +
            "        #{settings.approvePercent, jdbcType=NUMERIC},\n" +
            "        #{settings.stepPercent, jdbcType=NUMERIC},\n" +
            "        #{settings.productionRatePercent, jdbcType=NUMERIC},\n" +
            "        #{settings.productionRatePerHour, jdbcType=INTEGER},\n" +
            "        #{settings.createdAt, jdbcType=TIMESTAMP},\n" +
            "        #{settings.updatedAt, jdbcType=TIMESTAMP},\n" +
            "        #{settings.disabledAt, jdbcType=TIMESTAMP})")
    void create(@Param("settings") RoleProductivitySettings settings);

    @Update("update PRODUCTIVITY_SETTINGS\n" +
            "set APPROVE_PERCENT          = #{settings.approvePercent,jdbcType=NUMERIC},\n" +
            "    STEP_PERCENT             = #{settings.stepPercent, jdbcType=INTEGER},\n" +
            "    PRODUCTION_RATE_PERCENT  = #{settings.productionRatePercent,jdbcType=NUMERIC},\n" +
            "    PRODUCTION_RATE_PER_HOUR = #{settings.productionRatePerHour,jdbcType=INTEGER},\n" +
            "    CREATED_AT               = #{settings.createdAt, jdbcType=TIMESTAMP},\n" +
            "    UPDATED_AT               = #{settings.updatedAt, jdbcType=TIMESTAMP},\n" +
            "    DISABLED_AT              = #{settings.disabledAt, jdbcType=TIMESTAMP}\n" +
            "where ROLE_ID = #{settings.roleId, jdbcType=INTEGER}")
    void update(@Param("settings") RoleProductivitySettings settings);

}
