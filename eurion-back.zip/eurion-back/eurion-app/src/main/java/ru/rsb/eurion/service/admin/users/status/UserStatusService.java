package ru.rsb.eurion.service.admin.users.status;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.DependsOn;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.StatusType;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.domain.UserStatus;
import ru.rsb.eurion.domain.UserStatusHistory;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.admin.users.UserDao;
import ru.rsb.eurion.service.application.NotFoundException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor
@Service
@Transactional
@DependsOn("liquibase")
public class UserStatusService {
    static final StatusType DEFAULT_ENTER_STATUS = StatusType.WORK;
    private static final StatusType DEFAULT_EXIT_STATUS = StatusType.ABSENT;

    private final UserStatusDao userStatusDao;
    private final UserDao userDao;
    private final UserStatusHistoryDao userStatusHistoryDao;
    private final UserStatusHistoryMapper userStatusHistoryMapper;

    @Getter
    private UserStatus defaultEnterStatus;

    @Getter
    private UserStatus defaultExitStatus;

    @PostConstruct
    public void init() {
        Optional<UserStatus> enterStatus = userStatusDao.getUserStatusList()
                .stream()
                .filter(userStatus -> userStatus.getCode() == DEFAULT_ENTER_STATUS)
                .findFirst();
        this.defaultEnterStatus = enterStatus.orElseThrow(
                () -> new IllegalArgumentException("Cannot find user status with code " + DEFAULT_ENTER_STATUS));

        Optional<UserStatus> exitStatus = userStatusDao.getUserStatusList()
                .stream()
                .filter(userStatus -> userStatus.getCode() == DEFAULT_EXIT_STATUS)
                .findFirst();
        this.defaultExitStatus = exitStatus.orElseThrow(
                () -> new IllegalArgumentException("Cannot find user status with code " + DEFAULT_EXIT_STATUS));

    }

    public void setUserStatusAndRole(Integer userId, UserStatus userStatus, @Nullable Role role, String sessionId) {
        User user = userDao.findById(userId);
        if (user == null) {
            throw new NotFoundException(userId);
        }
        if (role != null && !user.getRoles().contains(role)) {
            throw new AccessDeniedException("User has no role: user=" + user + ", role=" + role);
        }

        Role effectiveRole = getEffectiveRole(role, user);

        UserStatusHistory statusHistory = new UserStatusHistory();
        statusHistory.setRole(effectiveRole);
        statusHistory.setStatus(userStatus);
        statusHistory.setUpdatedAt(LocalDateTime.now());
        statusHistory.setSessionId(sessionId);
        log.info("create userStatusHistory = {}", statusHistory);
        userStatusHistoryDao.create(userId, statusHistory);
        userDao.updateHistory(userId, statusHistory);
    }

    private Role getEffectiveRole(@Nullable Role role, User user) {
        if (role != null) {
            return role;
        }

        if (user.getStatusHistory() != null) {
            return user.getStatusHistory().getRole();
        }

        return user.getRoles()
                .stream()
                .findFirst()
                .orElseThrow(() -> new AccessDeniedException("User has no any role: user=" + user));
    }

    @Nonnull
    public UserStatus getStatus(Integer userId) {
        UserStatusHistory currentHistory = userStatusHistoryDao.getCurrentHistory(userId);
        return currentHistory != null ? currentHistory.getStatus() : getDefaultExitStatus();
    }

    @Nonnull
    public UserStatusAndRole getCurrentStatusAndRole() {
        UserData userData = AuthUtil.loggedUser();
        return getCurrentStatusAndRole(userData.getId());
    }

    @Nonnull
    public UserStatusAndRole getCurrentStatusAndRole(@Nonnull Integer userId) {
        User user = userDao.findById(userId);
        if (user == null) {
            throw new IllegalStateException("Current user is not found in DB");
        }
        UserStatusHistory currentHistory = user.getStatusHistory();
        if (currentHistory != null) {
            return userStatusHistoryMapper.mapToDto(currentHistory);
        } else {
            UserStatusAndRole result = new UserStatusAndRole();
            result.setStatus(getDefaultExitStatus());
            Role role = user.getRoles().stream().findFirst()
                    .orElseThrow(() -> new AccessDeniedException("User has no any role: " + user));
            result.setRole(role);
            return result;
        }
    }

    @Nonnull
    public List<UserStatus> getStatusList() {
        return userStatusDao.getUserStatusList();
    }

    @Nullable
    public UserStatus getUserStatusByCode(StatusType code) {
        return userStatusDao.getUserStatusByCode(code);
    }

    public List<UserStatusSkillDTO> getAllUsersWithStatusAndSkillGroup(Integer supervisorId) {
        return userDao.listAllActiveUserWithSkillGroup(supervisorId);
    }
}
