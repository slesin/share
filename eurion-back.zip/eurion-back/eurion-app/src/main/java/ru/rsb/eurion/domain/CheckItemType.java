package ru.rsb.eurion.domain;

public enum CheckItemType {
    NO,
    YES,
    REWORK,
    RATING,
    REQUEST
}
