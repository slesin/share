package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.ExpenseType;

import java.util.List;

@Mapper
public interface ExpenseTypeDao {

    String BASE_SELECT_SQL = "select ID, NAME, CREATED_AT, UPDATED_AT, DISABLED_AT, ORDER_NUMBER from EXPENSE_TYPE";

    @Select(BASE_SELECT_SQL + " where DISABLED_AT is null ORDER BY ORDER_NUMBER")
    @Results(id = "expenseTypeMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<ExpenseType> findAll();

    @Select(BASE_SELECT_SQL + " where ID = #{id}")
    @ResultMap("expenseTypeMapping")
    ExpenseType findById(Integer id);
}
