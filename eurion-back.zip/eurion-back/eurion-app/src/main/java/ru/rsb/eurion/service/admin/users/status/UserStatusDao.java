package ru.rsb.eurion.service.admin.users.status;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.StatusType;
import ru.rsb.eurion.domain.UserStatus;

import java.util.List;

@Mapper
public interface UserStatusDao {

    @Select("select\n" +
            "  sh.USER_ID,\n" +
            "  s.ID,\n" +
            "  s.NAME,\n" +
            "  s.CODE,\n" +
            "  s.ORDER_NUM,\n" +
            "  sh.UPDATED_AT\n" +
            "from USER_STATUS_HISTORY sh\n" +
            "  left join USER_STATUS s on sh.STATUS_ID = s.ID\n" +
            "where sh.USER_ID = #{userId}\n" +
            "order by sh.UPDATED_AT desc\n" +
            "fetch first row only")
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "orderNum", column = "ORDER_NUM")
    })
    UserStatus getUserStatusByUserId(@Param("userId") Integer userId);

    @Select("select\n" +
            "  ID,\n" +
            "  NAME,\n" +
            "  CODE,\n" +
            "  ORDER_NUM\n" +
            "from USER_STATUS\n" +
            "order by ORDER_NUM")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "orderNum", column = "ORDER_NUM")
    })
    List<UserStatus> getUserStatusList();

    @Select("select ID, CODE, ORDER_NUM from user_status where CODE = #{statusType}")
    UserStatus getUserStatusByCode(@Param("statusType") StatusType statusType);

}
