package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Связный (пересекающийся) адрес
 */
@Getter
@Setter
class CrossAddress {
    /**
     * Тип пересечения
     */
    private String crossType;
    /**
     * Количество клиентов
     */
    private Integer clientCount;
    /**
     * Связанные клиенты
     */
    private List<CrossClient> crossClientList;
}
