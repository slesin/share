package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Ответ
 */
@Getter
@Setter
public class ControlQuestionAnswer extends BasicReference {

    /**
     * Флаг правильности ответа (true - да, false - нет)
     */
    private boolean correct;
}
