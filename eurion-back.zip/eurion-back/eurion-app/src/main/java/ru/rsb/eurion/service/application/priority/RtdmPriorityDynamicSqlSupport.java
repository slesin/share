package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;
import java.time.LocalDateTime;

public class RtdmPriorityDynamicSqlSupport {
    public static final RtdmPriorityTable RTDM_PRIORITY_TABLE = new RtdmPriorityTable();

    public static final SqlColumn<Integer> ID = RTDM_PRIORITY_TABLE.column("ID", JDBCType.INTEGER);
    public static final SqlColumn<String> NAME = RTDM_PRIORITY_TABLE.column("NAME", JDBCType.VARCHAR);
    public static final SqlColumn<LocalDateTime> CREATED_AT = RTDM_PRIORITY_TABLE.column("CREATED_AT", JDBCType.TIMESTAMP);
    public static final SqlColumn<LocalDateTime> UPDATED_AT = RTDM_PRIORITY_TABLE.column("UPDATED_AT", JDBCType.TIMESTAMP);
    public static final SqlColumn<Boolean> IS_NEED_NOTIFICATION = RTDM_PRIORITY_TABLE.column("IS_NEED_NOTIFICATION", JDBCType.BOOLEAN);
    public static final SqlColumn<Boolean> IS_WARNING = RTDM_PRIORITY_TABLE.column("IS_WARNING", JDBCType.BOOLEAN);


    private static final class RtdmPriorityTable extends SqlTable {
        RtdmPriorityTable() {
            super("RTDM_PRIORITY");
        }
    }
}
