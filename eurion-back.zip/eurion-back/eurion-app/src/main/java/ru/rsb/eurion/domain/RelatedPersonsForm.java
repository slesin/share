package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class RelatedPersonsForm extends BasicForm {
    /**
     * Ссылка на граф взаимосвязей из AFS
     */
    private String relatedGraphLink;
    /**
     * Список ссылок на социальные сети
     */
    private List<Social> socialList;
}
