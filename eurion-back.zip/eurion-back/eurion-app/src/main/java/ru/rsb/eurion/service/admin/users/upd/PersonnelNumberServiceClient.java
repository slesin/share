package ru.rsb.eurion.service.admin.users.upd;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;
import ru.rsb.eurion.service.admin.users.upd.PersonnelNumberData.PersonnelNumbersItem;
import ru.rsb.eurion.settings.EisConfig;

import java.util.List;

@Repository
@AllArgsConstructor
public class PersonnelNumberServiceClient extends BaseEisClient {

    private final EisConfig eisConfig;

    public List<PersonnelNumbersItem> findAll() {
        PersonnelNumberData data = executeGet(PersonnelNumberData.class, eisConfig.getPersonnelNumbersServiceUrl());
        return data.getPersonnelNumbersList().getPersonnelNumbersItem();
    }
}
