package ru.rsb.eurion.service.application.flow.author;

import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.DeclineReasonDao;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.CheckConclusionHistory;
import ru.rsb.eurion.service.application.ApplicationProcessStatusService;
import ru.rsb.eurion.service.application.ApplicationService;
import ru.rsb.eurion.service.application.StatusCode;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.application.history.ApplicationHistoryService;
import ru.rsb.eurion.service.application.history.CheckConclusionHistoryService;

import javax.annotation.Nonnull;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Set;

import static ru.rsb.eurion.domain.CheckConclusionHistory.DecisionMaker;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION_AUTHOR;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.valueOf;

@SuppressWarnings("unused")
@Service("authorStatusTask")
@Transactional
@Slf4j
@AllArgsConstructor
public class SetupStatusTask {

    private final ApplicationProcessStatusService applicationProcessStatusService;
    private final ApplicationHistoryService applicationHistoryService;
    private final CheckConclusionHistoryService checkConclusionHistoryService;
    private final ApplicationService applicationService;
    private final DeclineReasonDao declineReasonDao;

    public void setup(@NonNull @Nonnull Long applicationId,
                      @NonNull @Nonnull String status,
                      @NonNull @Nonnull String userId,
                      @NotNull @Nonnull String processName,
                      @NotNull @Nonnull Integer userIntId) {
        this.setup(applicationId, status, userId, null, null, null, processName, userIntId);
    }

    public void setup(@NonNull @Nonnull Long applicationId,
                      @NonNull @Nonnull String status,
                      @NonNull @Nonnull String userId,
                      String decision,
                      Set<Integer> declineReasonIds,
                      String decisionComment,
                      @NotNull @Nonnull String processName,
                      @NotNull @Nonnull Integer userIntId) {
        ApplicationDecision newDecision = null;
        if (decision != null) {
            newDecision = ApplicationDecision.valueOf(decision);
        }
        StatusCode category = getCategory(status);
        ProcessDefinitionKey process = valueOf(processName);
        LocalDateTime doneAt = category == StatusCode.COMPLETED ? LocalDateTime.now() : null;
        String authorId = category == StatusCode.QUEUE ? null : userId;
        applicationProcessStatusService.updateStatus(applicationId, status, category, authorId, newDecision, doneAt,
                process, decisionComment, userIntId);
        applicationHistoryService.saveApplicationStatusHistory(applicationId, userId, status, category, decisionComment, declineReasonIds);
        if (category == StatusCode.COMPLETED) {
            saveCheckConclusion(applicationId, status, category, authorId, newDecision, doneAt,
                    process, declineReasonIds, decisionComment, userIntId, process);
        }
    }

    private void saveCheckConclusion(Long applicationId, String status, StatusCode statusCode, String userName,
                                     ApplicationDecision decision, LocalDateTime doneAt, ProcessDefinitionKey processName,
                                     Set<Integer> declineReasonIds, String decisionComment, Integer userId, ProcessDefinitionKey process) {
        ApplicationEntity entity = applicationService.findById(applicationId);
        CheckConclusionHistory history = new CheckConclusionHistory();
        history.setSkillGroup(entity.getSkillGroup());
        history.setFormDefinitions(entity.getFormDefinitions());
        history.setFormConclusions(entity.getFormConclusions());
        history.setCreatedAt(LocalDateTime.now());
        DecisionMaker decisionMaker = process == APPLICATION_AUTHOR ? DecisionMaker.AUTHOR : DecisionMaker.VERIFICATION;
        history.setDecisionMaker(decisionMaker);
        history.setDeclineReasonIds(declineReasonIds);
        history.setDecision(decision);
        history.setDecisionComment(decisionComment);
        if (userId != null) {
            BasicReference user = new BasicReference();
            user.setId(userId);
            history.setUser(user);
        }
        checkConclusionHistoryService.addHistoryRecord(applicationId, history);
    }

    private StatusCode getCategory(@NonNull @Nonnull String status) {
        StatusCode category;
        switch (status) {
            case "Новая":
                category = StatusCode.NEW;
                break;
            case "В очереди":
                category = StatusCode.QUEUE;
                break;
            case "В работе":
                category = StatusCode.IN_WORK;
                break;
            case "Одобрено":
            case "Отклонено":
            case "Доработка":
                category = StatusCode.COMPLETED;
                break;
            default:
                category = StatusCode.NEW;
        }
        return category;
    }
}
