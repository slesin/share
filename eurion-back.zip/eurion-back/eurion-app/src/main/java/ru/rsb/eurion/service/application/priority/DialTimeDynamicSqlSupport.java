package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;

public class DialTimeDynamicSqlSupport {

    public static final DialTimeTable DIAL_TIME_TABLE = new DialTimeTable();

    public static final SqlColumn<Boolean> ID = DIAL_TIME_TABLE.column("ID", JDBCType.INTEGER);
    public static final SqlColumn<Boolean> IS_ENABLED = DIAL_TIME_TABLE.column("IS_ENABLED", JDBCType.BOOLEAN);
    public static final SqlColumn<Boolean> IS_HOLIDAY_ENABLED = DIAL_TIME_TABLE.column("IS_HOLIDAY_ENABLED", JDBCType.BOOLEAN);

    private static final class DialTimeTable extends SqlTable {
        DialTimeTable() {
            super("DIAL_TIME");
        }
    }
}
