package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Блок адреса на форме
 */
@Getter
@Setter
public class AddressFormBlock {
    /**
     * Адрес
     */
    private Address address;
    /**
     * Иные адреса
     */
    private List<Address> otherAddresses;
    /**
     * Пересечения адреса
     */
    private List<CrossAddress> crossAddressList;
}
