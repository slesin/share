package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Образование
 */
@Setter
@Getter
public class Education extends BasicReference {

    private Integer scoringId;

    private boolean active;

    private Integer countryId;

    private Integer codeId;
}
