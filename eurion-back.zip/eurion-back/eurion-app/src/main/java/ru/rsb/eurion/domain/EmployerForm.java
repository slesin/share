package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Форма Работодатель
 */
@Getter
@Setter
public class EmployerForm extends BasicForm {

    /**
     * Основное место работы
     */
    private Job job;
    /**
     * Социальный статус
     */
    private SocialStatus socialStatus;
    /**
     * Проверка по Контур-Фокус пройдена (true - да, false - нет)
     */
    private boolean checkedByCounterFocus;
    /**
     * Проверка по SAS пройдена (true - да, false - нет)
     */
    private boolean checkedBySas;
    /**
     * Проверка по данным ЦБ пройдена (true - да, false - нет)
     */
    private boolean checkedByCbr;
    /**
     * Бюджетник (true - да, false - нет)
     */
    private boolean stateEmployee;
    /**
     * Ссылка на Контур-Фокус
     */
    private String counterFocusLink;
    /**
     * Фактический адрес работы
     */
    private Address actualAddress;
    /**
     * Юридический адрес работы
     */
    private Address legalAddress;
    /**
     * Должность
     */
    private String position;
    /**
     * Ежемесячный доход
     */
    private BigDecimal monthlyIncome;
    /**
     * Стаж на текущем месте работы, лет
     */
    private Integer currentJobSeniority;
    /**
     * Общий стаж, лет
     */
    private Integer overallSeniority;
    /**
     * Предыдущие места работы
     */
    private List<Object> previousJobs;
    /**
     * Иные телефоны работодателя
     */
    private List<OtherEmployerPhone> otherPhones;
    /**
     * Рабочие телефоны
     */
    private List<PhoneRecord> phoneRecords;
    /**
     * Пересечения телефонов
     */
    private List<CrossPhone> crossPhones;
    /**
     * Журналы прозвонов и результатов
     */
    private List<CallJournal> callJournals;
    /**
     * Рейтинг доверия - работодатель
     */
    private Integer trustRating;

}
