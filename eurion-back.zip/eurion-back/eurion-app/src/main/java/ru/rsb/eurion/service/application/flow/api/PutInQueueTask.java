package ru.rsb.eurion.service.application.flow.api;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.service.application.ApplicationService;
import ru.rsb.eurion.service.application.priority.ApplicationPriorityService;

@Service("putInQueueTask")
@Transactional
@Slf4j
@AllArgsConstructor
public class PutInQueueTask {

    private final ApplicationService service;
    private final ApplicationPriorityService priorityService;

    @SuppressWarnings("unused")
    public void queueUp(Long applicationId) {
        ApplicationEntity entity = service.findById(applicationId);
        log.info("Creating priority index record: {}", entity);
        priorityService.createIndexItem(entity);
    }
}
