package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import org.javers.core.metamodel.annotation.DiffIgnore;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlTransient;

@Getter
@Setter
public class CheckItemValue extends BasicReference {
    private Integer orderNumber;
    private boolean stopFactor;
    @NotNull
    private String code;
    @XmlTransient
    @DiffIgnore
    private String resultCode;
}
