package ru.rsb.eurion.service.admin.users;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class FreeUserInfo {

    private Integer id;

    private String username;

    private String fullName;

    private BigDecimal limit;

    private LocalDateTime lastCompleteStatus;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

}
