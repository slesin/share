package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.Department;

import java.util.List;

@Mapper
public interface DepartmentDao {

    @Select("select id,\n" +
            "       NAME,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT,\n" +
            "       DISABLED_AT\n" +
            "from DEPARTMENT ")
    @Results(id = "departmentMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<Department> list();

    @Select("select d.ID,\n" +
            "       d.NAME,\n" +
            "       d.UPDATED_AT,\n" +
            "       d.CREATED_AT,\n" +
            "       d.DISABLED_AT\n" +
            "from DEPARTMENT_DIVISION dd\n" +
            "join DEPARTMENT d ON d.ID = dd.department_id\n" +
            "where DIVISION_ID = #{divisionId, jdbcType = BIGINT}")
    @ResultMap("departmentMapping")
    Department findDepartmentByDivisionId(@Param("divisionId") String divisionId);

    @Select("select DIVISION_ID\n" +
            "from DEPARTMENT_DIVISION\n" +
            "where DEPARTMENT_ID = #{departmentId, jdbcType = INTEGER}")
    List<Long> findDivisionIdsByDepartmentId(@Param("departmentId") Integer departmentId);

}
