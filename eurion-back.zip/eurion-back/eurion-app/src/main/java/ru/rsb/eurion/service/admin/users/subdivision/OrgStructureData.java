package ru.rsb.eurion.service.admin.users.subdivision;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString(of = "orgItem")
@Getter
@Setter
public class OrgStructureData {

    private OrgItem orgItem;

    private OrgStatisticItem orgStatisticItem;

    private OrgProductivityItem orgProductivityItem;

    public OrgItem getOrgItem() {
        return orgItem;
    }

    public OrgStatisticItem getOrgStatisticItem() {
        return orgStatisticItem != null ? orgStatisticItem : new OrgStatisticItem();
    }

    public OrgProductivityItem getOrgProductivityItem() {
        return orgProductivityItem != null ? orgProductivityItem : new OrgProductivityItem();
    }
}
