package ru.rsb.eurion.service.application;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.RtdmDecisionEntity;

import javax.annotation.Nonnull;
import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface RtdmDecisionDao {
    String INSERT_SQL = "insert into RTDM_DECISION (APPLICATION_ID, DECISION_CODE, DECISION_TIME, REASON_TEXT, CREATED_AT)\n" +
            "values (#{applicationId},\n" +
            "#{decision.decisionCode},\n" +
            "#{decision.date}, \n" +
            "#{decision.cause},\n" +
            "#{decision.createdAt ,jdbcType=TIMESTAMP})";

    String SELECT_SQL_BASE = "select ID, DECISION_CODE, DECISION_TIME, REASON_TEXT, CREATED_AT\n" +
            "from RTDM_DECISION\n";

    @Insert(INSERT_SQL)
    @SelectKey(
            keyProperty = "id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_rtdm_decision.currval AS id from dual"}
    )
    void create(@Param("applicationId") Long applicationId, @Param("decision") RtdmDecisionEntity entity);

    @Nonnull
    @Select(SELECT_SQL_BASE + "where APPLICATION_ID = #{applicationId}\n" +
            "and CREATED_AT between #{startDate, jdbcType=TIMESTAMP} and #{endDate, jdbcType=TIMESTAMP}\n" +
            "order by CREATED_AT desc")
    @Results(id = "rtdmDecisionEntityMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "decisionCode", column = "DECISION_CODE"),
            @Result(property = "date", column = "DECISION_TIME"),
            @Result(property = "cause", column = "REASON_TEXT"),
            @Result(property = "createdAt", column = "CREATED_AT"),
    })
    List<RtdmDecisionEntity> list(@Param("applicationId") Long applicationId,
                                  @Param("startDate") LocalDateTime startDate,
                                  @Param("endDate") LocalDateTime endDate);
}
