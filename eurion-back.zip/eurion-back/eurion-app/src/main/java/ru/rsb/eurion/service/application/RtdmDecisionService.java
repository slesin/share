package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.CheckConclusionHistory;
import ru.rsb.eurion.domain.RtdmDecisionEntity;
import ru.rsb.eurion.rtdm.application.RtdmDecision;
import ru.rsb.eurion.rtdm.application.RtdmDecisionCode;
import ru.rsb.eurion.service.TimeUtils;
import ru.rsb.eurion.service.application.flow.ApplicationProcessService;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.application.flow.author.ApplicationAuthorProcessService;
import ru.rsb.eurion.service.application.history.ApplicationHistoryService;
import ru.rsb.eurion.service.application.history.CheckConclusionHistoryService;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
@Slf4j
@AllArgsConstructor
public class RtdmDecisionService {
    private static final Map<RtdmDecisionCode, String> MSG_MAP;

    static {
        HashMap<RtdmDecisionCode, String> map = new HashMap<>();
        map.put(RtdmDecisionCode.REVOKE, "Отозвано");
        map.put(RtdmDecisionCode.ACCEPT, "Одобрено");
        map.put(RtdmDecisionCode.REJECT, "Отклонено");
        MSG_MAP = map;
    }

    private ApplicationDao applicationDao;
    private RtdmDecisionDao rtdmDecisionDao;
    private ApplicationProcessService applicationProcessService;
    private ApplicationAuthorProcessService authorProcessService;
    private NotificationService notificationService;
    private CheckConclusionHistoryService checkConclusionHistoryService;
    private ApplicationProcessStatusService applicationProcessStatusService;
    private ApplicationHistoryService applicationHistoryService;

    @Nonnull
    public static String convertDecisionToStatusText(RtdmDecisionCode decision) {
        String text = convertDecisionToStatusTextReal(decision);
        return text != null ? text : "Неизвестно";
    }

    @Nullable
    public static String convertDecisionToStatusTextReal(RtdmDecisionCode decision) {
        return MSG_MAP.get(decision);
    }

    @Nonnull
    public List<RtdmDecisionEntity> listRtdmDecisionHistory(Long id, LocalDateTime startDate, LocalDateTime endDate) {
        startDate = startDate == null ? TimeUtils.getMinLocalDateTime() : startDate;
        endDate = endDate == null ? LocalDateTime.now() : endDate;
        return rtdmDecisionDao.list(id, startDate, endDate);
    }

    public void handle(@Nonnull Integer rtdmId, @Nonnull RtdmDecision decision) {
        List<ApplicationEntity> list = applicationDao.findByRtdmId(rtdmId);
        if (list.isEmpty()) {
            throw new NotFoundException(rtdmId);
        }
        list.forEach(entity -> {
            switch (entity.getProcessName()) {
                case APPLICATION:
                    setupDecision(entity, decision);
                    break;
                case APPLICATION_AUTHOR:
                    setupAuthorDecision(entity, decision, ProcessDefinitionKey.APPLICATION_AUTHOR);
                    break;
                case APPLICATION_VERIFIER:
                    setupAuthorDecision(entity, decision, ProcessDefinitionKey.APPLICATION_VERIFIER);
                    break;
                default:
                    throw new IllegalStateException("Process for application not found.");
            }
        });
    }

    private void setupDecision(ApplicationEntity entity, @Nonnull RtdmDecision decision) {
        // любое решение от RTDM приводит к прерыванию бизнес-процесса заявки
        applicationProcessService.kill(entity.getId());

        // делаем запись в таблицу истории
        createRtdmDecisionHistoryRecord(decision, entity.getId());
        checkConclusionHistoryService.addHistoryRecordWithDecision(entity, CheckConclusionHistory.DecisionMaker.RTDM, Collections.emptySet(), decision);

        // обновляем статус заявки
        String statusText = convertDecisionToStatusText(decision.getDecision());
        updateApplicationStatus(entity, statusText);

        if (entity.getUser() != null) {
            String reason = "По заявке принято решениена стороне RTDM: " + statusText;
            try {
                notificationService.sendCloseEvent(entity.getId(), reason, entity.getUser().getId());
            } catch (MessagingException e) {
                log.warn("", e);
            }
        }
    }

    private void setupAuthorDecision(ApplicationEntity entity, @Nonnull RtdmDecision decision, ProcessDefinitionKey definitionKey) {
        authorProcessService.kill(entity.getId(), definitionKey);
        String userId = ru.rsb.eurion.service.application.flow.author.FlowAPI.RTDM;
        createRtdmDecisionHistoryRecord(decision, entity.getId());
        checkConclusionHistoryService.addHistoryRecordWithDecision(entity, CheckConclusionHistory.DecisionMaker.RTDM, Collections.emptySet(), decision);
        String statusText = convertDecisionToStatusText(decision.getDecision());
        LocalDateTime now = LocalDateTime.now();
        applicationProcessStatusService.updateStatus(entity.getId(), statusText, StatusCode.COMPLETED, userId,
                entity.getProcessDecision(), now, entity.getProcessName(), null, null);
        applicationHistoryService.saveApplicationStatusHistory(entity.getId(), userId, statusText, StatusCode.COMPLETED,
                null, Collections.emptySet());
        //ToDo notification
    }

    private void createRtdmDecisionHistoryRecord(@Nonnull RtdmDecision decision, @Nonnull Long applicationId) {
        RtdmDecisionEntity decisionEntity = new RtdmDecisionEntity();
        decisionEntity.setDecisionCode(decision.getDecision());
        decisionEntity.setDate(decision.getDate());
        decisionEntity.setCause(decision.getCause());
        decisionEntity.setCreatedAt(LocalDateTime.now());
        rtdmDecisionDao.create(applicationId, decisionEntity);
    }

    private void updateApplicationStatus(@Nonnull ApplicationEntity entity, String statusText) {
        entity.setStatus(statusText);
        entity.setStatusCategoryCode(StatusCode.COMPLETED);
        LocalDateTime now = LocalDateTime.now();
        entity.setUpdatedAt(now);
        entity.setDoneAt(now);
        applicationDao.update(entity);
    }
}
