package ru.rsb.eurion.service.admin.process;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.proxy.annotation.Post;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.service.admin.Consts;
import ru.rsb.eurion.service.application.ApplicationDao;
import ru.rsb.eurion.service.application.flow.ApplicationProcessService;

import javax.validation.constraints.NotNull;

@Slf4j
@RequestMapping(path = Consts.ADMIN_API_BASE + "/process", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class ApplicationProcessResource {

    private final ApplicationProcessService applicationProcessService;
    private final ApplicationDao dao;

    @DeleteMapping("/delete/{id}")
    public void deleteApplicationProcess(@NotNull @PathVariable Long id) {
        log.info("delete app and kill process with id = {}", id);
        dao.delete(id);
        applicationProcessService.kill(id);
    }

    @PostMapping("/move-dead-letter-job-to-executable-job/{jobId}")
    public void restartInitAssignApplicationTimer(@NotNull @PathVariable String jobId) {
        applicationProcessService.moveDeadLetterJobToExecutableJob(jobId);
    }

    @PostMapping("/set-timer-job-retries/{jobId}/{retries}")
    public void setTimerJobRetries(@NotNull @PathVariable String jobId, @NotNull @PathVariable int retries) {
        applicationProcessService.setTimerJobRetries(jobId, retries);
    }
}
