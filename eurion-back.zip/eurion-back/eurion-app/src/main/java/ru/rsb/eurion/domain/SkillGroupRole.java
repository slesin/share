package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Роль скилл-группы
 */
@Getter
@Setter
public class SkillGroupRole extends BasicReference {
}
