package ru.rsb.eurion.service.application.history;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckConclusionHistoryViewExt extends CheckConclusionHistoryView {
    private Integer blankId;
}
