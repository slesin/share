package ru.rsb.eurion.service.agent.comments;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;

@Getter
@Setter
public class AgentComment {
    private Long clientId;
    private Long blankId;
    private String text;
    private String parentTheme;
    private String theme;
    private String userFullName;
    private Long userId;
    private LocalDate changeDate;
    private String commentType;

    public String getFullTheme() {
        StringBuilder sb = new StringBuilder();
        if (!StringUtils.isBlank(parentTheme)) {
            sb.append(parentTheme);
        }
        if (!StringUtils.isBlank(parentTheme) && !StringUtils.isBlank(theme)) {
            sb.append("/");
        }
        if (!StringUtils.isBlank(theme)) {
            sb.append(theme);
        }
        return !StringUtils.isBlank(sb.toString()) ? sb.toString() : null;
    }
}