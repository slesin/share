package ru.rsb.eurion.service.admin.priority;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.priority.PriorityConfig;
import ru.rsb.eurion.domain.priority.ProductSortPriorityView;
import ru.rsb.eurion.domain.priority.UpdatePriorityConfig;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.ResultWrapper;
import ru.rsb.eurion.service.admin.Consts;

import javax.annotation.Nullable;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@RequestMapping(path = Consts.ADMIN_API_BASE + "/priority-config", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class PriorityResource {

    private final PriorityConfigService service;

    @GetMapping
    public PriorityConfig readConfig() {
        return service.read();
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResultWrapper<?> updatePriorityConfig(@NotNull @Valid @RequestBody UpdatePriorityConfig config) throws BusinessException {
        service.write(config);
        return ResultWrapper.OK_EMPTY;
    }

    /**
     * <p>Отдельный ресурс для постраничой выборки списка приоретизации по банковскому продукту</p>
     *
     * @param offset       смещение в списке
     * @param limit        количество элементов в списке
     * @param searchString строка поиска; поиск ведется по неполному вхождению строки
     * @return список элементов
     */
    @GetMapping(path = "/product")
    public PagedResult<ProductSortPriorityView> listProductPriorities(
            @Min(0) @RequestParam(value = "offset", defaultValue = "0") int offset,
            @Min(1) @Max(100) @RequestParam(value = "limit", defaultValue = "25") int limit,
            @Nullable @RequestParam(value = "searchString", required = false) String searchString
    ) {
        return service.listProductPriority(offset, limit, searchString);
    }
}
