package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TemplatePlaceholder extends BasicReference {
    private String remark;
}