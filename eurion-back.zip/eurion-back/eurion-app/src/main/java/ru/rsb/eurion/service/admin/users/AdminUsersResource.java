package ru.rsb.eurion.service.admin.users;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.LotusUserInfo;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserDomain;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.ResultWrapper;
import ru.rsb.eurion.service.admin.Consts;
import ru.rsb.eurion.service.admin.users.subdivision.OrgItem;
import ru.rsb.eurion.service.admin.users.subdivision.OrgTreeNode;
import ru.rsb.eurion.service.admin.users.subdivision.SubdivisionService;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

/**
 * @author sergius on 9/13/18.
 */
@RequestMapping(path = Consts.ADMIN_API_BASE + "/users", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
@Slf4j
public class AdminUsersResource {

    private final UserService service;
    private final UserInfoLoader userInfoLoader;
    private final SubdivisionService userSubdivisionService;

    @PostMapping(path = "/list")
    public List<UserView> list() {
        return service.list();
    }

    @GetMapping(path = "/single/{id}")
    public User findById(@PathVariable("id") Integer id) {
        return service.findById(id);
    }

    /**
     * Info about one user by ID
     *
     * @param id user ID
     * @return User object or null if not found
     */
    @GetMapping(path = "/{id}")
    public User loadOne(@PathVariable("id") Integer id) {
        return service.findByIdFromAD(id);
    }

    @PostMapping(path = "{supervisorId}/operators")
    public List<User> listOperators(@PathVariable("supervisorId") Integer supervisorId) {
        return service.listOperators(supervisorId);
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResultWrapper<User> createUser(@NotNull @Valid @RequestBody User user) throws BusinessException {
        User created = service.create(user);
        return ResultWrapper.of(created);
    }

    @PutMapping(path = "/{id}")
    public ResultWrapper<User> updateUser(@PathVariable("id") Integer id,
                                          @NotNull @Valid @RequestBody User user) throws BusinessException {
        User updatedUser = service.update(id, user);
        return ResultWrapper.of(updatedUser);
    }

    @PostMapping(path = "/deactivate", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<User> deactivate(@NotNull @RequestBody Set<Integer> ids) {
        return service.deactivate(ids);
    }

    @PostMapping(path = "/activate", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<User> activate(@NotNull @RequestBody Set<Integer> ids) {
        return service.activate(ids);
    }

    @PostMapping(path = "/suggest/{role}")
    public List<User> suggest(@NotNull @PathVariable("role") Role role,
                              @Nullable @RequestParam("userId") Integer userId,
                              @NotNull @RequestParam("query") String query,
                              @Nullable @RequestParam("excludeRole") Role excludeRole) {
        return service.suggest(role, userId, query, excludeRole);
    }

    @PostMapping(path = "/suggest")
    public List<User> suggest(@NotNull @RequestParam("query") String query) {
        return service.suggest(query);
    }

    @PostMapping(path = "/activeDirectorySuggest")
    public Set<User> activeDirectorySuggest(@NotNull @RequestParam("query") String query,
                                            @NotNull @RequestParam("userDomain") UserDomain userDomain) {
        return service.activeDirectorySuggest(query, userDomain);
    }

    @GetMapping(path = "/getLotusUserInfo")
    public LotusUserInfo getLotusUserInfo(@NotNull @Nonnull @RequestParam("personnelNumber") String personnelNumber,
                                          @NotNull @Nonnull @RequestParam("userName") String userName,
                                          @NotNull @Nonnull @RequestParam("isNeedUserUpdate") Boolean isNeedUpdate) {
        if (isNeedUpdate) {
            User user = service.findByUserName(userName);
            if (user != null) {
                LotusUserInfo info = userInfoLoader.getLotusUserInfoAndUpdateUser(user);
                service.update(user);
                return info;
            }
            log.warn("Cannot update a non-existing user.");
            return userInfoLoader.getLotusUserInfo(personnelNumber, userName);
        }
        return userInfoLoader.getLotusUserInfo(personnelNumber, userName);
    }

    @PutMapping(path = "/subdivision/update")
    public OrgTreeNode updateSubdivision(@RequestBody OrgItem orgItem) {
        userSubdivisionService.updateSubdivision(orgItem);
        return userSubdivisionService.getOrgItemTree();
    }

    @PostMapping(path = "/subdivision/delete")
    public OrgTreeNode deleteSubdivisions(@RequestBody OrgItem orgItem) {
        userSubdivisionService.delete(orgItem);
        return userSubdivisionService.getOrgItemTree();
    }

}
