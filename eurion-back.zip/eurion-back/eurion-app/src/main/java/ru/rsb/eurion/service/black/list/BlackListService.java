package ru.rsb.eurion.service.black.list;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.service.admin.users.upd.BaseEisClient;
import ru.rsb.eurion.settings.EisConfig;

import java.util.HashMap;
import java.util.Map;

@RequiredArgsConstructor
@Service
@Transactional
public class BlackListService extends BaseEisClient {

    private final EisConfig eisConfig;

    public byte[] getBlackList(Integer clientId, Integer listType) {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("clientId", clientId.toString());
        parameters.put("commentType", listType.toString());
        return executeGet(byte[].class, eisConfig.getBlackListServiceUrl(), parameters);
    }

}
