package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.admin.skill.group.CheckType;
import ru.rsb.eurion.service.application.StatusCode;

import java.time.LocalDateTime;

@Setter
@Getter
public class ApplicationStatusHistory {

    private Long id;

    private Long applicationId;

    private Integer rtdmId;

    private Integer blankId;

    private Integer clientId;

    private Integer skillGroupId;

    private CheckType checkType;

    private StatusCode statusCode;

    private String status;

    private LocalDateTime updatedAt;

    private Integer userId;

    private String userName;

    private Long orderNumber;

    private String decisionComment;

    private String clientFullName;

}
