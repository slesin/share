package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Продукт банка
 */
@Getter
@Setter
public class Product {
    /**
     * Тип кредита
     */
    public String type;
    /**
     * Наименование продукта
     */
    public String productName;
    /**
     * Процентная ставка
     */
    public BigDecimal rate;
}
