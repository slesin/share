package ru.rsb.eurion.domain.priority;

public enum SortDirection {
    ASC, DESC
}
