package ru.rsb.eurion.service.application.history;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.ApplicationStatusHistoryDao;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.ApplicationStatusHistoryView;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.list.SortDirection;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.TimeUtils;
import ru.rsb.eurion.service.admin.skill.group.CheckType;

import javax.annotation.Nonnull;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Transactional
@AllArgsConstructor
public class ApplicationStatusHistoryListProvider {

    private final ApplicationStatusHistoryDao dao;

    public PagedResult<ApplicationStatusHistoryView> listByApplicationId(@Nonnull ApplicationHistoryListProvider.AppHistoryPageable pageable,
                                                                         @Nonnull Integer applicationId, LocalDateTime startDate,
                                                                         LocalDateTime endDate) {
        startDate = startDate == null ? TimeUtils.getMinLocalDateTime() : startDate;
        endDate = endDate == null ? LocalDateTime.now() : endDate;
        List<ApplicationStatusHistoryView> list = mainQuery(pageable, applicationId, startDate, endDate);
        int count = dao.countByApplicationId(applicationId, startDate, endDate);
        return new PagedResult<>(pageable.getOffset(), count, list);
    }

    private List<ApplicationStatusHistoryView> mainQuery(@Nonnull ApplicationHistoryListProvider.AppHistoryPageable pageable,
                                                         @Nonnull Integer applicationId, LocalDateTime startDate, LocalDateTime endDate) {
        SortDirection sortDirection = pageable.getSortDir().isEmpty() ? SortDirection.ASC : pageable.getSortDir().get(0);
        ApplicationHistoryListProvider.SortAvailable sort = pageable.getSortBy().isEmpty() ? ApplicationHistoryListProvider.SortAvailable.UPDATED_AT : pageable.getSortBy().get(0);
        if (sort == ApplicationHistoryListProvider.SortAvailable.UPDATED_AT) {
            if (sortDirection == SortDirection.DESC) {
                return getResult(() -> dao.listByApplicationIdInOrderByUpdatedAtDesc(
                        applicationId, pageable.getOffset(), pageable.getLimit(), startDate, endDate));
            }
            return getResult(() -> dao.listByApplicationIdInOrderByUpdatedAtAsc(
                    applicationId, pageable.getOffset(), pageable.getLimit(), startDate, endDate));
        }
        return getResult(() -> dao.listByApplicationIdInOrderByUpdatedAtDesc(
                applicationId, pageable.getOffset(), pageable.getLimit(), startDate, endDate));
    }

    private List<ApplicationStatusHistoryView> getResult(Supplier<List<ApplicationStatusHistoryView>> listSupplier) {
        Set<Role> roles = AuthUtil.loggedUser().getRoles();
        boolean onlyAuthorRole = roles.size() == 1 && roles.contains(Role.AUTHORIZED);
        List<ApplicationStatusHistoryView> statusHistoryViews = listSupplier.get();
        statusHistoryViews.forEach(item -> {
            boolean hideDeclineText = onlyAuthorRole && item.getCheckType() != CheckType.AUTHOR && item.getStatus().equals(ApplicationDecision.REJECTED.getDecisionText());
            if (!hideDeclineText) {
                List<String> stringList = Stream.of(item.getDeclineCategory(), item.getDeclineReason())
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList());
                String declineText = StringUtils.join(stringList, "; ");
                item.setDeclineText(declineText);
            }
        });
        return statusHistoryViews;
    }

    @Getter
    @Setter
    public static class FilterSpec {
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime startDate;

        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private LocalDateTime endDate;
    }

}
