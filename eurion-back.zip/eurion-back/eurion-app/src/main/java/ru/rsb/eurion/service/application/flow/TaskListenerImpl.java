package ru.rsb.eurion.service.application.flow;

import lombok.extern.slf4j.Slf4j;
import org.flowable.engine.delegate.TaskListener;
import org.flowable.task.service.delegate.DelegateTask;
import org.springframework.stereotype.Component;

@Component("myTaskListener")
@Slf4j
public class TaskListenerImpl implements TaskListener {
    @Override
    public void notify(DelegateTask delegateTask) {
        log.info("Task listener: form={}", delegateTask.getFormKey());
    }
}
