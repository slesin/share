package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.flowable.form.model.FormOutcome;
import org.flowable.spring.boot.app.App;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.rtdm.application.CreditInfoItemType;
import ru.rsb.eurion.dao.DeclineReasonDao;
import ru.rsb.eurion.domain.Application;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationVersionInfo;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.CallHistory;
import ru.rsb.eurion.domain.CheckConclusionHistory.DecisionMaker;
import ru.rsb.eurion.domain.DecisionRequest;
import ru.rsb.eurion.domain.FieldComment;
import ru.rsb.eurion.domain.FormConclusion;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.rtdm.application.AddApplicationRequest;
import ru.rsb.eurion.rtdm.application.CreditParametersType;
import ru.rsb.eurion.rtdm.application.RtdmRequest;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.CollectionUtils;
import ru.rsb.eurion.service.FieldValidationException;
import ru.rsb.eurion.service.TimeUtils;
import ru.rsb.eurion.service.admin.check.protocol.CheckProtocolUtils;
import ru.rsb.eurion.service.admin.check.protocol.form.definition.FormDefinitionService;
import ru.rsb.eurion.service.admin.skill.group.CheckType;
import ru.rsb.eurion.service.admin.skill.group.SkillGroupService;
import ru.rsb.eurion.service.admin.users.UserService;
import ru.rsb.eurion.service.application.flow.ApplicationProcessService;
import ru.rsb.eurion.service.application.flow.TaskInfo;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.application.flow.author.ApplicationAuthorProcessService;
import ru.rsb.eurion.service.application.history.ApplicationHistoryService;
import ru.rsb.eurion.service.application.history.CheckConclusionHistoryService;
import ru.rsb.eurion.service.application.priority.ApplicationIdxDao;
import ru.rsb.eurion.service.calendar.CalendarService;
import ru.rsb.eurion.service.credit.CreditParametersService;
import ru.rsb.eurion.service.document.requested.RequestedDocumentService;
import ru.rsb.eurion.service.phone.history.CallHistoryService;
import ru.rsb.eurion.service.ref.RegionService;
import ru.rsb.eurion.service.util.JsonService;
import ru.rsb.eurion.settings.AppConfig;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static ru.rsb.eurion.domain.ApplicationDecision.APPROVED;
import static ru.rsb.eurion.service.application.StatusCode.COMPLETED;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION_AUTHOR;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION_VERIFIER;

/**
 * @author sergius on 9/14/18.
 */
@Slf4j
@AllArgsConstructor
@Service
@Transactional
public class ApplicationService {
    private static final Consumer<ApplicationEntity> EMPTY_CONSUMER = entity -> {
    };
    private static final String REVOKE_REASON = "Заявка назначена на другого пользователя";
    private static final String RTDM_USERNAME = "RTDM";

    private final ApplicationMappingService mappingService;
    private final ApplicationDao dao;
    private final DeclineReasonDao declineReasonDao;
    private final JsonTransformer jsonTransformer;
    private final JsonService jsonService;
    private final FormDefinitionService formDefinitionService;
    private final ApplicationProcessService applicationProcessService;
    private final UserService userService;
    private final ApplicationHistoryService applicationHistoryService;
    private final AppConfig config;
    private final CreditParametersService creditParametersService;
    private final CallHistoryService callHistoryService;
    private final NotificationService notificationService;
    private final CheckConclusionHistoryService checkConclusionHistoryService;
    private final ApplicationIdxDao applicationIdxDao;
    private final FieldCommentDao fieldCommentDao;
    private final SkillGroupService skillGroupService;
    private final ApplicationAuthorProcessService applicationAuthorProcessService;
    private final RequestedDocumentService requestedDocumentService;
    private final CalendarService calendarService;
    private final ApplicationVersionService applicationVersionService;


    public ApplicationEntity acceptApplication(@Nonnull JsonNode applicationNode,
                                               @Nonnull RtdmRequest request, String sourceXml) {
        Integer blankId = request.getApplication().getProduct().getBlankId();
        ApplicationEntity entity = dao.findEntityByBlankId(blankId);
        if (entity == null) {
            ApplicationEntity newEntity = createNewEntity();
            fillEntity(applicationNode, request, newEntity, sourceXml);
            dao.create(newEntity);
            createProcess(false, newEntity.getId(), newEntity, false);
            return newEntity;
        }
        // смену скилл-группы обязательно обработать ДО мэппинга из запроса, иначе затрем данные
        boolean skillGroupModified = handleSkillGroupModified(request, entity);
        JsonNode oldAppData = jsonTransformer.readTree(entity.getData());
        fillEntity(applicationNode, request, entity, sourceXml);
        JsonNode newAppData = jsonTransformer.readTree(entity.getData());
        entity.setVersion(LocalDateTime.now());
        saveUpdates(entity);
        saveApplicationHistory(entity.getId(), oldAppData, newAppData);
        createProcess(true, entity.getId(), entity, skillGroupModified);
        return entity;
    }

    private void createProcess(boolean isApplicationExist, Long applicationId, ApplicationEntity entity, boolean skillGroupModified) {
        switch (entity.getCheckType()) {
            case AUTHOR:
                killAllProcess(applicationId);
                setProcessName(isApplicationExist, applicationId, APPLICATION_AUTHOR);
                applicationHistoryService.saveApplicationStatusHistory(entity.getId(), RTDM_USERNAME, "Новая",
                        StatusCode.NEW, null, Collections.emptySet());
                applicationAuthorProcessService.startApplicationProcessing(applicationId, APPLICATION_AUTHOR);
                break;
            case UNDERWRITING:
                applicationAuthorProcessService.kill(applicationId, APPLICATION_AUTHOR);
                setProcessName(isApplicationExist, applicationId, APPLICATION);
                createUnderwriterProcess(applicationId, isApplicationExist, entity, skillGroupModified);
                break;
            case VERIFICATION:
                killAllProcess(applicationId);
                setProcessName(isApplicationExist, applicationId, APPLICATION_VERIFIER);
                applicationHistoryService.saveApplicationStatusHistory(entity.getId(), RTDM_USERNAME, "Новая",
                        StatusCode.NEW, null, Collections.emptySet());
                applicationAuthorProcessService.startApplicationProcessing(applicationId, APPLICATION_VERIFIER);
                break;
            default:
                throw new IllegalStateException("Incorrect check type.");
        }
    }

    private void killAllProcess(Long applicationId) {
        applicationProcessService.kill(applicationId);
        applicationAuthorProcessService.kill(applicationId, APPLICATION_AUTHOR);
        applicationAuthorProcessService.kill(applicationId, APPLICATION_VERIFIER);
    }

    private void setProcessName(boolean isApplicationExist, Long applicationId, ProcessDefinitionKey processName) {
        if (isApplicationExist) {
            dao.updateProcessName(applicationId, processName);
        } else {
            dao.addProcessName(applicationId, processName);
        }
    }

    private void createUnderwriterProcess(Long applicationId, boolean isApplicationExist, ApplicationEntity entity, boolean skillGroupModified) {
        StatusCode statusCode = entity.getStatusCategoryCode();
        if (isApplicationExist && statusCode != null) {
            switch (statusCode) {
                case RECOUNT:
                    if (skillGroupModified) {
                        // Отзыв заявки с текущего бизнес-процесса, отправка по бизнес-процессу
                        restartBusinessProcess(entity);
                    } else {
                        // отправляем сообщение о получении
                        applicationProcessService.returnFromRecount(entity.getId());
                        sendRecountNotification(entity);
                    }
                    break;
                case COMPLETED:
                case QUEUE:
                    restartBusinessProcess(entity);
                    break;
                default:
                    if (skillGroupModified) {
                        // Отзыв заявки с текущего бизнес-процесса, отправка по бизнес-процессу
                        restartBusinessProcess(entity);
                    }
                    break;
            }
        } else {
            applicationHistoryService.saveApplicationStatusHistory(applicationId, RTDM_USERNAME, "Новая", StatusCode.NEW,
                    null, Collections.emptySet());
            applicationProcessService.startApplicationProcessing(applicationId, false);
        }
    }

    public void updateApplication(@Nonnull Long id,
                                  @Nonnull Application application,
                                  @Nonnull Consumer<ApplicationEntity> entityConsumer,
                                  ProcessDefinitionKey processDefinitionKey) throws JsonProcessingException, BusinessException {
        ApplicationEntity entity = findApplicationById(id, true);
        Pair<Boolean, TaskInfo> pair;
        switch (processDefinitionKey) {
            case APPLICATION:
                pair = takeReadonlyAndTaskInfo(entity);
                checkNotReadOnly(pair);
                doUpdate(id, application, entityConsumer, entity);
                applicationProcessService.applicationFormSave(id);
                break;
            case APPLICATION_VERIFIER:
                pair = takeReadonlyAndTaskInfoForVerifier(entity);
                checkNotReadOnly(pair);
                doUpdate(id, application, entityConsumer, entity);
                applicationAuthorProcessService.applicationFormSave(id, processDefinitionKey);
                break;
            default:
                throw new IllegalStateException("Illegal processDefinitionKey: " + processDefinitionKey);
        }
    }

    /**
     * Открытие заявки без взятия в работу
     *
     * @param id ID заявки
     * @return агрегированные данные по заявке
     */
    @Nonnull
    public Application getApplicationWithOutTakeInWork(@Nonnull Long id) {
        return getApplication(id, false);
    }

    /**
     * Открытие заявки co взятием в работу
     *
     * @param id ID заявки
     * @return агрегированные данные по заявке
     */
    @Nonnull
    public Application getApplicationWithTakeInWork(@Nonnull Long id) {
        return getApplication(id, true);
    }

    @Nonnull
    public Application getApplication(@Nonnull Long id, boolean takeInWork) {
        // проверяем, что в результате выполнения ru.rsb.eurion.service.application.flow.ApplicationProcessService.takeInWork
        // заявка действительно была назначена на текущего пользователя
        UserData userData = AuthUtil.loggedUser();

        // при открытии заявки, назначенной на пользователя, берем ее в работу
        if (takeInWork) {
            applicationProcessService.takeInWork(id, userData.getId());
        }
        ApplicationEntity applicationEntity = findByIdWithPhoneTime(id);
        JsonNode jsonNode = jsonTransformer.readTree(applicationEntity.getData());
        Application application = new Application();
        application.setId(applicationEntity.getId());
        application.setStatus(applicationEntity.getStatus());
        application.setCreated(applicationEntity.getCreatedAt());
        application.setData(jsonNode);
        application.setVersion(applicationEntity.getVersion());
        List<FormDefinition> formDefinitions = getFormDefinitions(applicationEntity);
        application.setFormDefinitions(formDefinitions);
        List<FormConclusion> formConclusions = getFormConclusions(applicationEntity);
        application.setFormConclusions(formConclusions);
        application.setProcessStatusCode(applicationEntity.getStatusCategoryCode());
        application.setPhoneTime(applicationEntity.isPhoneTime());
        application.setSkillGroup(applicationEntity.getSkillGroup());

        Pair<Boolean, TaskInfo> pair = takeReadonlyAndTaskInfo(applicationEntity);
        boolean readonly = pair.getLeft();
        application.setReadonly(readonly);
        application.setTaskInfo(pair.getRight());

        application.setUserId(applicationEntity.getUser() != null ? applicationEntity.getUser().getId() : null);
        List<CallHistory> callHistories = callHistoryService.getCallHistory(applicationEntity.getBlankId());
        application.setCallHistoryList(callHistories);

        if (!StringUtils.isEmpty(applicationEntity.getIncomeInfo())) {
            JsonNode incomeInfoJsonNode = jsonTransformer.readTree(applicationEntity.getIncomeInfo());
            application.setIncomeInfo(incomeInfoJsonNode);
        }

        Map<String, String> fieldComments = fieldCommentDao.findByApplicationId(id).stream()
                .collect(Collectors.toMap(FieldComment::getName, FieldComment::getCommentText));
        application.setFieldComments(fieldComments);

        boolean fraud = takeFraudFlag(applicationEntity);
        application.setFraud(fraud);
        application.setRtdmPriority(applicationEntity.getRtdmPriority());
        List<ApplicationVersionInfo> versionInfos = applicationVersionService.getVersionInfo(applicationEntity.getId());
        application.setVersionInfos(versionInfos);
        return application;
    }

    @Nonnull
    public ApplicationEntity findById(@Nonnull Long id) {
        return findApplicationById(id);
    }

    public String approve(@Nonnull Long id, ApplicationDto applicationDto) throws JsonProcessingException, BusinessException {
        Consumer<ApplicationEntity> entityConsumer = takeDecisionConsumer(applicationDto, APPROVED);
        boolean isCheckListFill = CheckProtocolUtils.checkFillCheckList(applicationDto.getApplication());
        if (!isCheckListFill) {
            throw new BusinessException("check_list", "Не все чек-листы заполнены.");
        }
        updateApplication(id, applicationDto.getApplication(), entityConsumer, APPLICATION);
        String decisionComment = applicationDto.getDecisionRequest().getComment();
        applicationProcessService.applicationFormApprove(id, decisionComment);
        return applicationProcessService.getReAssignCause(id);
    }

    public void reject(@Nonnull Long id, ApplicationDto applicationDto) throws JsonProcessingException, BusinessException {
        Consumer<ApplicationEntity> entityConsumer = takeDecisionConsumer(applicationDto, ApplicationDecision.REJECTED);
        updateApplication(id, applicationDto.getApplication(), entityConsumer, APPLICATION);
        String decisionComment = applicationDto.getDecisionRequest().getComment();
        applicationProcessService.applicationFormReject(id, decisionComment);
    }

    public void rework(@Nonnull Long id, ApplicationDto applicationDto) throws JsonProcessingException, BusinessException {
        Consumer<ApplicationEntity> entityConsumer = takeDecisionConsumer(applicationDto, ApplicationDecision.REWORK);
        updateApplication(id, applicationDto.getApplication(), entityConsumer, APPLICATION);
        String decisionComment = applicationDto.getDecisionRequest().getComment();
        applicationProcessService.applicationFormRework(id, decisionComment);
    }

    public void recount(@Nonnull Long id, ApplicationDto applicationDto) throws JsonProcessingException, BusinessException {
        ApplicationEntity entity = dao.findById(applicationDto.getApplication().getId());
        boolean isRecountPossible = isRecountPossible(entity);
        if (!isRecountPossible) {
            throw new BusinessException("recount", "Пересчет недоступен для данной заявки");
        }
        if (!entity.getSkillGroup().isRecount()) {
            throw new BusinessException("recount", "Пересчет недоступен для данной скилл-группы");
        }
        Consumer<ApplicationEntity> entityConsumer = takeDecisionConsumer(applicationDto, ApplicationDecision.RECOUNT);
        updateApplication(id, applicationDto.getApplication(), entityConsumer, APPLICATION);
        String userName = AuthUtil.loggedUser().getUsername();
        applicationHistoryService.saveRecountHistory(id, userName);
        applicationProcessService.applicationFormRecount(id);
    }

    public void authorReject(@Nonnull Long id, ApplicationDto applicationDto, ProcessDefinitionKey definitionKey) throws BusinessException, JsonProcessingException {
        UserData loggedUser = AuthUtil.loggedUser();
        Integer userId = loggedUser.getId();
        if (definitionKey == ProcessDefinitionKey.APPLICATION_VERIFIER) {
            updateApplication(id, applicationDto.getApplication(), EMPTY_CONSUMER, definitionKey);
        }
        updateRequestDocument(id, definitionKey, userId);
        DecisionRequest decision = applicationDto.getDecisionRequest();
        applicationAuthorProcessService.applicationReject(id, definitionKey, decision.getComment(), decision.getDeclineIds());
    }

    public void authorApprove(@Nonnull Long id, ApplicationDto applicationDto, ProcessDefinitionKey definitionKey) throws BusinessException, JsonProcessingException {
        UserData loggedUser = AuthUtil.loggedUser();
        Integer userId = loggedUser.getId();
        if (definitionKey == ProcessDefinitionKey.APPLICATION_VERIFIER) {
            boolean isCheckListFill = CheckProtocolUtils.checkFillCheckList(applicationDto.getApplication());
            if (!isCheckListFill) {
                throw new BusinessException("check_list", "Не все чек-листы заполнены.");
            }
            updateApplication(id, applicationDto.getApplication(), EMPTY_CONSUMER, definitionKey);
        }
        updateRequestDocument(id, definitionKey, userId);
        DecisionRequest decision = applicationDto.getDecisionRequest();
        applicationAuthorProcessService.applicationApprove(id, definitionKey, decision.getComment());
    }

    public void authorRework(@Nonnull Long id, ApplicationDto applicationDto, ProcessDefinitionKey definitionKey) throws BusinessException, JsonProcessingException {
        if (definitionKey == ProcessDefinitionKey.APPLICATION_VERIFIER) {
            updateApplication(id, applicationDto.getApplication(), EMPTY_CONSUMER, definitionKey);
        }
        DecisionRequest decision = applicationDto.getDecisionRequest();
        applicationAuthorProcessService.applicationRework(id, definitionKey, decision.getComment(), decision.getDeclineIds());
    }

    public void authorReturnIntoQueue(@Nonnull Long id) {
        applicationAuthorProcessService.returnIntoQueue(id);
    }

    public void postpone(@Nonnull Long id, @Nonnull PostponeRequest request) throws BusinessException {
        Duration duration;
        if (request.getKind() == PostponeRequest.PostponeKind.PERIOD) {
            if (request.getMinutes() == null) {
                throw new BusinessException("invalid_toDate", "Необходимо указать, на какое время откладывается задача");
            }
            duration = Duration.ofMinutes(request.getMinutes());
        } else {
            if (request.getToDate() == null) {
                throw new BusinessException("invalid_toDate", "Необходимо указать время возвращения в работу");
            }
            duration = Duration.between(ZonedDateTime.now(), request.getToDate());
            if (duration.isNegative()) {
                throw new BusinessException("invalid_toDate", "Время в прошлом недопустимо");
            }
        }
        ApplicationEntity entity = dao.findById(id);
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime suspendTime = now.plus(duration);
        entity.setSuspendTime(suspendTime);
        entity.setPostponeComment(request.getComment());
        saveUpdates(entity);
        applicationProcessService.applicationFormPostpone(id, duration);
    }

    public void fraud(@Nonnull Long id, ApplicationDto applicationDto) throws BusinessException {
        String userName = AuthUtil.loggedUser().getUsername();
        ApplicationEntity entity = findById(id);
        setupStatusDecision(entity, ApplicationDecision.FRAUD, applicationDto.getDecisionRequest(), userName);
        applicationProcessService.applicationFormFraud(id);
    }

    public void assignToUser(Long id, Integer userId) throws BusinessException {
        User user = userService.findById(userId);
        if (user == null) {
            throw new NotFoundException(userId);
        }
        ApplicationEntity applicationEntity = findApplicationById(id, true);
        User previousUser = applicationEntity.getUser();
        applicationProcessService.assignApplication(applicationEntity.getId(), user.getId(), previousUser);
        if (previousUser != null) {
            // убеждаемся, что пользователь сменился
            ApplicationEntity updated = findApplicationById(id, true);
            User currentUser = updated.getUser();
            if (currentUser == null || !currentUser.getId().equals(previousUser.getId())) {
                try {
                    notificationService.sendCloseEvent(updated.getId(), REVOKE_REASON, previousUser.getId());
                } catch (MessagingException e) {
                    log.warn("", e);
                }
            }
        }
    }

    public void setUser(Long id, User user, String source) {
        Integer userId = user == null ? null : user.getId();
        ApplicationEntity entity = findById(id);
        User currentUser = entity.getUser();
        dao.setUser(id, userId);
        applicationHistoryService.saveUserHistory(id, currentUser, user, source);
    }

    public void setDone(Long id, LocalDateTime doneAt) {
        dao.setDone(id, doneAt);
    }

    public void updateStatus(Long applicationId, String status, StatusCode category, String assignBySupervisor) {
        LocalDateTime updatedAt = LocalDateTime.now();
        dao.updateStatus(applicationId, status, category, updatedAt, assignBySupervisor);
    }

    public void returnIntoQueue(@Nonnull Long applicationId) {
        applicationProcessService.returnIntoQueue(applicationId);
    }

    public Application getApplicationByProcessName(Long id, Set<ProcessDefinitionKey> processNames) {
        ApplicationEntity applicationEntity = findApplicationByProcess(id, processNames);
        JsonNode jsonNode = jsonTransformer.readTree(applicationEntity.getData());
        Application application = new Application();
        application.setId(applicationEntity.getId());
        application.setProcessStatus(applicationEntity.getProcessStatus());
        application.setProcessUserName(applicationEntity.getProcessUserName());
        application.setProcessStatusCode(applicationEntity.getProcessStatusCode());
        application.setCreated(applicationEntity.getCreatedAt());
        application.setProcessStatusCode(application.getProcessStatusCode());
        application.setProcessStatus(application.getStatus());
        application.setData(jsonNode);
        return application;
    }

    public Application getApplicationByProcessNameWithCheckList(Long id, Set<ProcessDefinitionKey> processNames) {
        ApplicationEntity applicationEntity = findApplicationByProcess(id, processNames);
        JsonNode jsonNode = jsonTransformer.readTree(applicationEntity.getData());
        Application application = new Application();
        application.setId(applicationEntity.getId());
        application.setVersion(applicationEntity.getVersion());
        application.setProcessStatus(applicationEntity.getProcessStatus());
        application.setProcessUserName(applicationEntity.getProcessUserName());
        application.setProcessStatusCode(applicationEntity.getProcessStatusCode());
        application.setCreated(applicationEntity.getCreatedAt());
        application.setProcessStatusCode(application.getProcessStatusCode());
        application.setProcessStatus(application.getStatus());
        application.setData(jsonNode);
        List<FormDefinition> formDefinitions = getFormDefinitions(applicationEntity);
        application.setFormDefinitions(formDefinitions);
        List<FormConclusion> formConclusions = getFormConclusions(applicationEntity);
        application.setFormConclusions(formConclusions);
        Pair<Boolean, TaskInfo> pair = takeReadonlyAndTaskInfoForVerifier(applicationEntity);
        boolean readonly = pair.getLeft();
        application.setReadonly(readonly);
        application.setTaskInfo(pair.getRight());
        return application;
    }

    public void takeInWork(Long id, ProcessDefinitionKey processDefinitionKey) {
        ApplicationEntity applicationEntity = findApplicationById(id, true);
        applicationAuthorProcessService.takeInWork(applicationEntity.getId(), processDefinitionKey);
    }

    @Nullable
    public Application getLastApproveAppData(Long clientId) {
        ApplicationEntity entity = dao.findLastApproveByClientId(clientId);
        if (entity != null) {
            ObjectNode tree = (ObjectNode) jsonTransformer.readTree(entity.getData());
            LocalDateTime timeMinusMonth = LocalDateTime.now().minusMonths(1);
            if (APPROVED != entity.getDecision() || entity.getDoneAt().isBefore(timeMinusMonth)) {
                tree.remove("creditParameters");
            }
            Application application = new Application();
            application.setId(entity.getId());
            application.setData(tree);
            return application;
        }
        return null;
    }

    private boolean handleSkillGroupModified(@Nonnull RtdmRequest request, ApplicationEntity entity) {
        Integer oldSkillGroupId = entity.getSkillGroup().getId();
        Integer newSkillGroupId = request.getApplication().getRequestInfo().getSkillGroupId();
        boolean skillGroupModified = !Objects.equals(oldSkillGroupId, newSkillGroupId);
        if (skillGroupModified) {
            checkConclusionHistoryService.addHistoryRecord(entity, DecisionMaker.RTDM);
            entity.setFormDefinitions(null);
            entity.setFormConclusions(null);
        }
        return skillGroupModified;
    }

    private void restartBusinessProcess(ApplicationEntity entity) {
        applicationProcessService.kill(entity.getId());
        applicationHistoryService.saveApplicationStatusHistory(entity.getId(), RTDM_USERNAME, "Новая", StatusCode.NEW,
                null, Collections.emptySet());
        applicationProcessService.startApplicationProcessing(entity.getId(), true);
    }

    public void patchCreditParameters(@Nonnull Integer rtdmId, @Nonnull CreditParametersType request) throws BusinessException {
        List<ApplicationEntity> list = dao.findByRtdmId(rtdmId);
        for (ApplicationEntity entity : list) {
            patchSingleEntity(request, entity);
        }
    }

    public void clearPersonalData(PagedResult<ApplicationView> pagedResult) {
        pagedResult.getItems().forEach(item -> {
            item.setPassportSeries(null);
            item.setPassportNumber(null);
            item.setBirthDate(null);
            item.setMobilePhone(null);
        });
    }

    private void patchSingleEntity(@Nonnull CreditParametersType request, ApplicationEntity entity) throws BusinessException {
        checkNotFinalDecision(entity);
        JsonNode oldAppData = jsonTransformer.readTree(entity.getData());
        ObjectNode tree = (ObjectNode) jsonTransformer.readTree(entity.getData());
        JsonNode creditParametersNode = jsonTransformer.writeAsTree(request);
        tree.set("creditParameters", creditParametersNode);
        BigDecimal productCreditAmountSum = getCreditAmountSum(request);
        entity.setProductCreditAmountSum(productCreditAmountSum);
        entity.setData(tree.toString());
        LocalDateTime version = LocalDateTime.now();
        entity.setVersion(version);
        saveUpdates(entity);
        saveApplicationHistory(entity.getId(), oldAppData, tree);
        try {
            creditParametersService.sendCreditParameters(request.getCreditInfoItem(), entity.getRtdmId(), version);
        } catch (MessagingException e) {
            log.warn("", e);
        }
    }

    private BigDecimal getCreditAmountSum(CreditParametersType request) {
        List<CreditInfoItemType> creditInfoList = request.getCreditInfoItem();
        List<BigDecimal> creditAmountList = creditInfoList.stream()
                .map(CreditInfoItemType::getCreditAmount)
                .collect(Collectors.toList());
        return creditAmountList.stream()
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private Consumer<ApplicationEntity> takeDecisionConsumer(ApplicationDto applicationDto,
                                                             ApplicationDecision decision) {
        final String userName = AuthUtil.loggedUser().getUsername();
        return entity -> setupStatusDecision(entity, decision, applicationDto.getDecisionRequest(), userName);
    }

    private void saveUpdates(ApplicationEntity entity) {
        entity.setUpdatedAt(LocalDateTime.now());
        dao.update(entity);
    }

    public String getRedirectURL(Integer blankId, String clientId, String host) {
        Long applicationId = dao.findByBlankId(blankId);
        if (applicationId != null) {
            return "redirect:" + host + "/underwriter/" + applicationId;
        }
        return "redirect:" + config.getFrontUrl().replace("${clientId}", clientId);
    }

    public void setupSkillGroup(@Nonnull Long applicationId, @Nonnull SkillGroup newSkillGroup) {
        ApplicationEntity entity = dao.findById(applicationId);
        if (entity.getSkillGroup() != null && entity.getId() != null &&
                !entity.getSkillGroup().getId().equals(newSkillGroup.getId())) {
            checkConclusionHistoryService.addHistoryRecord(entity, DecisionMaker.UNDERWRITING);
            entity.setSkillGroup(newSkillGroup);
            entity.setFormDefinitions(null);
            entity.setFormConclusions(null);
            entity.setUpdatedAt(LocalDateTime.now());
            dao.update(entity);
        }
    }

    public void setupPriority(Long id, boolean enabled) {
        short supervisorPriority = (short) (enabled ? 1 : 0);
        dao.updateSupervisorPriority(id, supervisorPriority);
        applicationIdxDao.updateSupervisorPriority(id, supervisorPriority);
    }

    private void checkVersion(LocalDateTime currentVersion, LocalDateTime newVersion) throws BusinessException {
        if (!currentVersion.isEqual(newVersion)) {
            throw new BusinessException("version", "incorrect version");
        }
    }

    private void mapApplicationToEntity(Application application, ApplicationEntity entity) throws JsonProcessingException {
        AddApplicationRequest applicationRequest =
                jsonTransformer.treeToValue(application.getData(), AddApplicationRequest.class);
        mappingService.mapApplicationRequest(applicationRequest, entity);
        entity.setFormConclusions(jsonService.asJsonString(application.getFormConclusions()));
        String json = application.getData() != null ? application.getData().toString() : null;
        entity.setIncomeInfo(jsonService.asJsonString(application.getIncomeInfo()));
        entity.setData(json);
    }

    private List<FormDefinition> getFormDefinitions(ApplicationEntity applicationEntity) {
        if (applicationEntity.getFormDefinitions() == null) {
            Integer skillGroupId = applicationEntity.getSkillGroup().getId();
            List<FormDefinition> definitions = formDefinitionService.getFormDefinitionList(skillGroupId);
            try {
                String formDefinitions = jsonTransformer.writeAsString(definitions);
                dao.updateFormDefinition(applicationEntity.getId(), formDefinitions, LocalDateTime.now());
            } catch (JsonProcessingException e) {
                throw new IllegalStateException(e);
            }
            return definitions;
        }

        TypeReference<List<FormDefinition>> ref = new TypeReference<List<FormDefinition>>() {
        };
        return jsonService.parse(applicationEntity.getFormDefinitions(), ref);
    }

    private List<FormConclusion> getFormConclusions(ApplicationEntity applicationEntity) {
        if (applicationEntity.getFormConclusions() == null) {
            return Collections.emptyList();
        }

        TypeReference<List<FormConclusion>> ref = new TypeReference<List<FormConclusion>>() {
        };
        return jsonService.parse(applicationEntity.getFormConclusions(), ref);
    }

    private ApplicationEntity createNewEntity() {
        ApplicationEntity entity = new ApplicationEntity();
        LocalDateTime now = LocalDateTime.now();
        entity.setCreatedAt(now);
        entity.setUpdatedAt(now);
        entity.setVersion(now);
        return entity;
    }

    @Nonnull
    private ApplicationEntity findApplicationById(@Nonnull Long id) {
        return findApplicationById(id, false);
    }

    @Nonnull
    private ApplicationEntity findApplicationById(@Nonnull Long id, boolean forUpdate) {
        ApplicationEntity applicationEntity = forUpdate ? dao.findByIdForUpdate(id) : dao.findById(id);
        if (applicationEntity == null) {
            throw new NotFoundException(id);
        }
        return applicationEntity;
    }

    @Nonnull
    private ApplicationEntity findByIdWithPhoneTime(@Nonnull Long id) {
        Integer currentDateInMin = TimeUtils.timeToMinutes(LocalTime.now());
        Integer serverOffset = RegionService.getServerRawOffset();
        Integer minutesInDay = TimeUtils.minutesInDay;
        ApplicationEntity applicationEntity = dao.findByIdWithPhoneTime(id, calendarService.isTodayHoliday(),
                currentDateInMin, serverOffset, minutesInDay);
        if (applicationEntity == null) {
            throw new NotFoundException(id);
        }
        return applicationEntity;
    }

    @Nonnull
    private ApplicationEntity findApplicationByProcess(@Nonnull Long id, Set<ProcessDefinitionKey> processNameList) {
        ApplicationEntity applicationEntity = dao.findByProcess(id, processNameList);
        if (applicationEntity == null) {
            throw new NotFoundException(id);
        }
        return applicationEntity;
    }

    private void doUpdate(@Nonnull Long id, @Nonnull Application application,
                          @Nonnull Consumer<ApplicationEntity> consumer,
                          @Nonnull ApplicationEntity entity) throws JsonProcessingException, BusinessException {
        JsonNode oldAppData = jsonTransformer.readTree(entity.getData());
        checkVersion(entity.getVersion(), application.getVersion());
        mapApplicationToEntity(application, entity);
        consumer.accept(entity);
        LocalDateTime version = LocalDateTime.now();
        entity.setVersion(version);
        saveUpdates(entity);
        if (application.getCallHistoryList() != null && !application.getCallHistoryList().isEmpty()) {
            callHistoryService.update(application.getCallHistoryList());
        }
        String userName = AuthUtil.loggedUser().getUsername();
        applicationHistoryService.saveApplicationHistory(entity.getId(), oldAppData, application.getData(), userName);

        mergeFieldComments(application, entity);
    }

    private void mergeFieldComments(@Nonnull Application application, ApplicationEntity applicationEntity) {
        List<FieldComment> oldFieldComments = fieldCommentDao.findByApplicationId(applicationEntity.getId());
        List<FieldComment> newFieldComments = application.getFieldComments().entrySet().stream()
                .filter(value -> !StringUtils.isEmpty(value.getValue()))
                .map(entry -> mapFieldCommentEntry(entry, applicationEntity.getId()))
                .collect(Collectors.toList());

        CollectionUtils.mergeList(oldFieldComments, newFieldComments, FieldComment::getName,
                fieldComment -> {
                    fieldCommentDao.createOrUpdate(fieldComment);
                    return fieldComment;
                },
                fieldCommentDao::delete,
                (oldValue, newValue) -> fieldCommentDao.createOrUpdate(newValue));
    }

    private FieldComment mapFieldCommentEntry(Map.Entry<String, String> entry, Long applicationId) {
        FieldComment entity = new FieldComment();
        entity.setApplicationId(applicationId);
        entity.setName(entry.getKey());
        entity.setCommentText(entry.getValue());
        LocalDateTime now = LocalDateTime.now();
        entity.setCreatedAt(now);
        entity.setUpdatedAt(now);
        return entity;
    }

    private void checkNotReadOnly(Pair<Boolean, TaskInfo> pair) throws BusinessException {
        boolean readonly = pair.getLeft();
        if (readonly) {
            throw new BusinessException("READONLY", "Заявка только для чтения и не может быть сохранена");
        }
    }

    private void setupStatusDecision(@Nonnull ApplicationEntity entity,
                                     @Nonnull ApplicationDecision decision,
                                     @Nonnull DecisionRequest request,
                                     String userName) {
        ApplicationDecision oldDecision = entity.getDecision();
        entity.setDecision(decision);
        entity.setDecisionComment(request.getComment());
        entity.setPostponeComment("");
        Set<Integer> newReasons = Collections.emptySet();
        if (request.getDeclineIds() != null && !request.getDeclineIds().isEmpty()) {
            Set<Integer> declineIds = request.getDeclineIds();
            newReasons = declineReasonDao.findByIds(declineIds);
            if (newReasons == null || declineIds.isEmpty() || request.getDeclineIds().size() != newReasons.size()) {
                throw new NotFoundException("Decline reasons not found : " + declineIds);
            }
        }
        dao.updateStatusAndDecision(entity);
        applicationHistoryService.saveDecisionHistory(entity.getId(), oldDecision, decision, userName);
        checkConclusionHistoryService.addHistoryRecordWithDecision(entity, DecisionMaker.UNDERWRITING, newReasons, null);
    }

    private void fillEntity(@Nonnull JsonNode applicationNode,
                            @Nonnull RtdmRequest request,
                            @Nonnull ApplicationEntity entity,
                            @Nonnull String sourceXml) {
        mappingService.mapApplicationRequest(request.getApplication(), entity);
        entity.setData(applicationNode.toString());
        LocalDateTime now = LocalDateTime.now();
        entity.setVersion(now);
        entity.setVerifRequestId(request.getVerifRequestId());
        entity.setSourceXml(sourceXml);
        entity.setDecision(null);
        CheckType checkType = getCheckType(request);
        entity.setCheckType(checkType);
        entity.setCreatedAt(now);
        entity.setUpdatedAt(now);
    }

    private Pair<Boolean, TaskInfo> takeReadonlyAndTaskInfo(ApplicationEntity entity) {
        TaskInfo taskInfo = applicationProcessService.loadTaskInfo(entity.getId());
        List<FormOutcome> outcomes = taskInfo != null && taskInfo.getFormData() != null ?
                taskInfo.getFormData().getOutcomes() : Collections.emptyList();
        boolean finalReadonly = outcomes.stream().noneMatch(formOutcome -> formOutcome.getId().equals("save"));
        return Pair.of(finalReadonly, taskInfo);
    }

    private Pair<Boolean, TaskInfo> takeReadonlyAndTaskInfoForVerifier(ApplicationEntity entity) {
        TaskInfo taskInfo = applicationAuthorProcessService.loadTaskInfo(entity.getId());
        List<FormOutcome> outcomes = taskInfo != null && taskInfo.getFormData() != null ?
                taskInfo.getFormData().getOutcomes() : Collections.emptyList();
        boolean finalReadonly = outcomes.stream().noneMatch(formOutcome -> formOutcome.getId().equals("save"));
        return Pair.of(finalReadonly, taskInfo);
    }

    private boolean isRecountPossible(ApplicationEntity entity) {
        TaskInfo taskInfo = applicationProcessService.loadTaskInfo(entity.getId());
        List<FormOutcome> outcomes = taskInfo != null && taskInfo.getFormData() != null ?
                taskInfo.getFormData().getOutcomes() : Collections.emptyList();
        return outcomes.stream().anyMatch(formOutcome -> formOutcome.getId().equals("recalc"));
    }

    private void saveApplicationHistory(Long entityId, JsonNode oldAppData, JsonNode tree) {
        try {
            applicationHistoryService.saveApplicationHistory(entityId, oldAppData, tree, RTDM_USERNAME);
        } catch (JsonProcessingException e) {
            log.error("Save application history error", e);
        }
    }

    private void checkNotFinalDecision(ApplicationEntity entity) throws BusinessException {
        boolean isDecisionFinal = entity.getDecision() == ApplicationDecision.REJECTED ||
                entity.getDecision() == APPROVED || entity.getStatusCategoryCode() == COMPLETED;
        if (isDecisionFinal) {
            throw new BusinessException("FINAL_DECISION", "По заявке имеется финальное решение, итоговые параметры кредита не могут быть изменены");
        }
    }

    private boolean takeFraudFlag(ApplicationEntity applicationEntity) {
        SkillGroup fraudSkillGroupId = skillGroupService.getFirstGroupByCheckType(CheckType.FRAUD);
        return applicationEntity.getSkillGroup() != null &&
                applicationEntity.getSkillGroup().getId().equals(fraudSkillGroupId.getId());
    }

    private void updateRequestDocument(Long applicationId, ProcessDefinitionKey definitionKey, Integer userId) {
        if (definitionKey == ProcessDefinitionKey.APPLICATION_VERIFIER) {
            requestedDocumentService.markAsRequested(applicationId, userId);
        }
    }

    private CheckType getCheckType(RtdmRequest request) {
        ru.rsb.eurion.rtdm.application.CheckType checkType = request.getApplication().getRequestInfo().getSkillGroupCheckType();
        if (checkType == null) {
            // check type is critical to the business process
            throw new FieldValidationException(request, "requestInfo.skillGroupCheckType",
                    "Skill group check type is not found for id= " + request.getApplication().getProduct().getBlankId());
        }
        return CheckType.valueOf(checkType.toString());
    }

    private void sendRecountNotification(ApplicationEntity entity) {
        try {
            notificationService.sendReturnFormRecountEvent(entity);
        } catch (MessagingException e) {
            log.warn("", e);
        }
    }
}
