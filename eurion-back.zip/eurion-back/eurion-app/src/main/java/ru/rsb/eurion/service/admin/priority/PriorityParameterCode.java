package ru.rsb.eurion.service.admin.priority;

public enum PriorityParameterCode {
    SUSPENSIVE_TERMS,
    RTDM,
    SUPERVISOR,
    NOVELTY,
    SKILL_GROUP,
    OUT_OF_PHONE_TIME,
    PHONE_TIME_LEFT,
    NOW_IS_PHONE_TIME,
    REGION_APP,
    REGION_CLIENT,
    AMOUNT,
    CHANNEL,
    ATTRACT_CHANNEL,
    PRODUCT,
    FRAUD_RETURN,
    DELAYED_DUE_TIME,
    SLA,
    CREATED,
    LAST_OPERATOR,
    MONTHLY_PAYMENT_DATE
}
