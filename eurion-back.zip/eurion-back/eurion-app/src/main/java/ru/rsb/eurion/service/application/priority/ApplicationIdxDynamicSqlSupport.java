package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;
import java.time.LocalDate;
import java.time.LocalDateTime;

public final class ApplicationIdxDynamicSqlSupport {
    public static final Table APPLICATION_IDX = new Table();

    public static final SqlColumn<Long> ID = APPLICATION_IDX.column("ID", JDBCType.BIGINT);
    public static final SqlColumn<LocalDateTime> CREATE_DATE = APPLICATION_IDX.column("CREATE_DATE", JDBCType.TIMESTAMP);
    public static final SqlColumn<LocalDateTime> SUSPEND_TIME = APPLICATION_IDX.column("SUSPEND_TIME", JDBCType.TIMESTAMP);
    public static final SqlColumn<Short> SUPERVISOR_PRIORITY = APPLICATION_IDX.column("SUPERVISOR_PRIORITY", JDBCType.SMALLINT);
    public static final SqlColumn<Integer> RTDM_PRIORITY = APPLICATION_IDX.column("RTDM_PRIORITY", JDBCType.INTEGER);
    public static final SqlColumn<Short> SKILL_GROUP_PRIORITY = APPLICATION_IDX.column("SKILL_GROUP_PRIORITY", JDBCType.SMALLINT);
    public static final SqlColumn<Short> REGION_CLIENT_PRIORITY = APPLICATION_IDX.column("REGION_CLIENT_PRIORITY", JDBCType.SMALLINT);
    public static final SqlColumn<Short> REGION_APP_PRIORITY = APPLICATION_IDX.column("REGION_APP_PRIORITY", JDBCType.SMALLINT);
    public static final SqlColumn<Short> AMOUNT_PRIORITY = APPLICATION_IDX.column("AMOUNT_PRIORITY", JDBCType.SMALLINT);
    public static final SqlColumn<Short> CHANNEL_PRIORITY = APPLICATION_IDX.column("CHANNEL_PRIORITY", JDBCType.SMALLINT);
    public static final SqlColumn<Short> ATTRACT_CHANNEL_PRIORITY = APPLICATION_IDX.column("ATTRACT_CHANNEL_PRIORITY", JDBCType.SMALLINT);
    public static final SqlColumn<Short> PRODUCT_PRIORITY = APPLICATION_IDX.column("PRODUCT_PRIORITY", JDBCType.SMALLINT);
    public static final SqlColumn<Boolean> IS_FRAUD_RETURN = APPLICATION_IDX.column("IS_FRAUD_RETURN", JDBCType.BOOLEAN);
    public static final SqlColumn<Boolean> IS_NOVEL = APPLICATION_IDX.column("IS_NOVEL", JDBCType.BOOLEAN);
    public static final SqlColumn<Boolean> IS_SUSPENSIVE_TERMS = APPLICATION_IDX.column("IS_SUSPENSIVE_TERMS", JDBCType.BOOLEAN);
    public static final SqlColumn<Boolean> IS_OUT_OF_DIAL_TIME = APPLICATION_IDX.column("IS_OUT_OF_DIAL_TIME", JDBCType.BOOLEAN);
    public static final SqlColumn<Integer> LAST_USER_ID = APPLICATION_IDX.column("LAST_USER_ID", JDBCType.BOOLEAN);
    public static final SqlColumn<LocalDateTime> DIAL_START_TIME = APPLICATION_IDX.column("DIAL_START_TIME", JDBCType.INTEGER);
    public static final SqlColumn<LocalDateTime> DIAL_END_TIME = APPLICATION_IDX.column("DIAL_END_TIME", JDBCType.INTEGER);
    public static final SqlColumn<LocalDate> MONTHLY_PAYMENT_DATE = APPLICATION_IDX.column("MONTHLY_PAYMENT_DATE", JDBCType.TIMESTAMP);

    private static final class Table extends SqlTable {
        Table() {
            super("APPLICATION_IDX");
        }
    }
}
