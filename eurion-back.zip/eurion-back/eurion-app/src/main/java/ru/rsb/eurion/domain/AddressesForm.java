package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Адреса
 */
@Getter
@Setter
public class AddressesForm extends BasicForm {
    /**
     * Адрес регистрации
     */
    private AddressFormBlock registrationAddress;
    /**
     * Адрес проживания
     */
    private AddressFormBlock residentialAddress;
}
