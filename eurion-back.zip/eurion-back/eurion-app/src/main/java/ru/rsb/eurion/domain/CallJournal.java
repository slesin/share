package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Журнал прозвонов и результатов
 */
@Getter
@Setter
public class CallJournal {
    /**
     * Телефон
     */
    private PhoneRecord phone;
    /**
     * Флаг дозвона (true - дозвон был, false - нет)
     */
    private boolean called;
    /**
     * Вызываемый абонент (с кем был разговор)
     */
    private String callee;
    /**
     * Результат общения
     */
    private CallResult callResult;
    /**
     * Негативный комментарий
     */
    private String negativeRemark;
    /**
     * Домохозяйство (true - да, false - нет)
     */
    private boolean household;
    /**
     * Доход домохозяйства
     */
    private BigDecimal householdIncome;
    /**
     * Запрет контактов
     */
    private boolean prohibitionOfContacts;
}
