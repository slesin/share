package ru.rsb.eurion.dao;

import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;
import ru.rsb.eurion.service.TimeUtils;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;

public class DurationTypeHandler implements TypeHandler {
    @Override
    public void setParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType) {
        throw new IllegalStateException("Not implemented yet");
    }

    @Override
    public Duration getResult(ResultSet rs, String columnName) throws SQLException {
        String str = rs.getString(columnName);
        return convert(str);
    }

    @Override
    public Duration getResult(ResultSet rs, int columnIndex) throws SQLException {
        String str = rs.getString(columnIndex);
        return convert(str);
    }

    @Override
    public Object getResult(CallableStatement cs, int columnIndex) throws SQLException {
        String str = cs.getString(columnIndex);
        return convert(str);
    }

    private Duration convert(String str) {
        return str != null ? TimeUtils.convertOracleIntervalToDuration(str) : null;
    }
}
