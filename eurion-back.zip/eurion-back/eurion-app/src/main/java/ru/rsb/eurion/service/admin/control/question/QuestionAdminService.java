package ru.rsb.eurion.service.admin.control.question;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.ControlQuestion;
import ru.rsb.eurion.domain.ControlQuestionAnswer;
import ru.rsb.eurion.service.CollectionUtils;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Set;

@Service
@Transactional
@AllArgsConstructor
public class QuestionAdminService {

    private QuestionDao dao;

    public ControlQuestion findQuestionById(Integer id) {
        return dao.findQuestionById(id);
    }

    public ControlQuestion createQuestion(ControlQuestion controlQuestion) {
        dao.createQuestion(controlQuestion);
        List<ControlQuestionAnswer> answerList = controlQuestion.getAnswers();
        answerList.forEach(response -> dao.createAnswerByQuestion(controlQuestion, response));
        return findQuestionById(controlQuestion.getId());
    }

    public List<ControlQuestion> disableQuestions(Set<Integer> ids, boolean disable) {
        if (ids.isEmpty()) {
            return Collections.emptyList();
        }

        LocalDateTime disabledAt = disable ? LocalDateTime.now() : null;
        dao.disableQuestions(ids, disabledAt);
        return dao.getQuestions(ids);
    }

    public List<ControlQuestion> getAllQuestions() {
        return dao.getAllQuestions();
    }

    public ControlQuestion updateQuestion(ControlQuestion controlQuestion) {
        controlQuestion.getAnswers()
                .stream()
                .filter(answer -> answer.getId() == null)
                .forEach(answer -> dao.createAnswerByQuestion(controlQuestion, answer));

        ControlQuestion existing = findQuestionById(controlQuestion.getId());
        List<ControlQuestionAnswer> existingAnswers = existing.getAnswers();
        CollectionUtils.mergeList(existingAnswers, controlQuestion.getAnswers(), BasicReference::getId,
                answer -> answer,
                dao::deleteAnswer,
                (oldValue, newValue) -> {
                    oldValue.setName(newValue.getName());
                    oldValue.setCorrect(newValue.isCorrect());
                    oldValue.setUpdatedAt(LocalDateTime.now());
                    dao.updateAnswer(oldValue);
                }
        );
        dao.updateQuestion(controlQuestion);
        return findQuestionById(controlQuestion.getId());
    }

}
