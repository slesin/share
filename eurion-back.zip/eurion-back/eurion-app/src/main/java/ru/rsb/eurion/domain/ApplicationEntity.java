package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.rtdm.application.AddApplicationRequest;
import ru.rsb.eurion.service.admin.skill.group.CheckType;
import ru.rsb.eurion.service.application.StatusCode;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Set;

/**
 * @author sergius on 9/14/18.
 */
@Getter
@Setter
public class ApplicationEntity extends BaseEntity {
    /**
     * ID заявки в КС
     */
    @NotNull
    private Integer blankId;
    @NotNull
    private Integer clientId;
    @NotNull
    private Integer rtdmId;
    @NotNull
    private String data;
    private String status;
    /**
     * Работа с заявкой завершена
     */
    private LocalDateTime doneAt;
    private ApplicationDecision decision;
    private Set<Integer> declineReasonIds;
    private String decisionComment;
    private String lastName;
    private String firstName;
    private String middleName;
    private LocalDate birthDate;
    private BigDecimal creditAmount;
    private BigDecimal requestedCreditAmount;
    private String clientRegionCode;
    private String clientRegion;
    private LocalDateTime statusUpdatedAt;
    private String passportNumber;
    private String passportSeries;
    private String productType;
    private Integer creditSaleChannelId;
    private String applicationRegionCode;
    private String mobilePhone;
    private Integer branchId;
    @NotNull
    private SkillGroup skillGroup;

    private transient AddApplicationRequest source;

    private LocalTime beginPhoneTime;
    private LocalTime endPhoneTime;
    private LocalDateTime suspendTime;

    private short supervisorPriority;
    private short regionClientPriority;
    private short regionAppPriority;
    private short amountPriority;
    private short channelPriority;
    private short attractChannelPriority;
    private short productPriority;
    private LocalDate monthlyPaymentDate;

    private boolean novel;
    private boolean fraudReturn;
    private boolean suspensiveTerms;
    private boolean outOfDialTime;

    private Integer lastUserId;
    private boolean isPhoneTime;

    /**
     * Описания форм, сериализованные в JSON
     */
    private String formDefinitions;

    /**
     * Значения форм, сериализованные в JSON
     */
    private String formConclusions;

    private User user;

    private LocalDateTime version;
    /**
     * Идентификатор канала привлечения из КС
     */
    private Integer creditAttractionChannelId;
    /**
     * Идентификатор запроса RTDM
     */
    private String verifRequestId;

    /**
     * Код статуса
     */
    private StatusCode statusCategoryCode;

    /**
     * Исходный XML от RTDM
     */
    private String sourceXml;
    /**
     * Данные по доходам/расходам
     */
    private String incomeInfo;
    /**
     * Двузначный код региона клиента
     */
    private String shortClientRegionCode;
    /**
     * Тип проверки
     */
    private CheckType checkType;

    private ProcessDefinitionKey processName;

    private String processStatus;

    private String processUserName;

    private StatusCode processStatusCode;

    private ApplicationDecision processDecision;

    private String assignBySupervisor;
    /**
     * Наименование отделения, запрошенного клиентом
     */
    private String requestedBranchName;
    /**
     * Наименование отделения, в котором была заведена заявка
     */
    private String branchName;

    private ru.rsb.eurion.rtdm.application.CreditType CreditType;

    private RtdmPriority rtdmPriority;

    private String authorFullName;

    private String postponeComment;
    /**
     * Сумма итоговых сумм продукта (кредитные параметры)
     */
    private BigDecimal productCreditAmountSum;
    /**
     * Табельный номер сотрудника, который завел заявку
     */
    private Integer authorId;

    @Override
    public Long getId() {
        return super.getId();
    }

    @Override
    public void setId(Long id) {
        super.setId(id);
    }

    @Override
    public String toString() {
        return "ApplicationEntity{" +
                "clientId=" + clientId +
                ", rtdmId=" + rtdmId +
                ", status=" + status +
                ", lastName='" + lastName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                "} " + super.toString();
    }
}
