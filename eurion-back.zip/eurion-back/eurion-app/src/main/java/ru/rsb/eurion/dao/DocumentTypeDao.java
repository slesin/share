package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.DocumentType;

import java.util.List;

@Mapper
public interface DocumentTypeDao {

    String BASE_SELECT_SQL = "select C_DOCUMKIND, STAT, NAME from DOCUMENT_TYPE";

    @Select(BASE_SELECT_SQL + " order by C_DOCUMKIND")
    @Results(id = "documentTypeMapping", value = {
            @Result(property = "id", column = "C_DOCUMKIND"),
            @Result(property = "isDisabled", column = "STAT"),
            @Result(property = "name", column = "NAME")
    })
    List<DocumentType> findAll();

    @Select(BASE_SELECT_SQL + " where C_DOCUMKIND = #{id}")
    @ResultMap("documentTypeMapping")
    DocumentType findById(Integer id);
}
