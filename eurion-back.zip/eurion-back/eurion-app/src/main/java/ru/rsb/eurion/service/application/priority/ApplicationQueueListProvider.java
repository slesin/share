package ru.rsb.eurion.service.application.priority;

import lombok.extern.slf4j.Slf4j;
import org.mybatis.dynamic.sql.BasicColumn;
import org.mybatis.dynamic.sql.SortSpecification;
import org.mybatis.dynamic.sql.render.RenderingStrategy;
import org.mybatis.dynamic.sql.select.QueryExpressionDSL;
import org.mybatis.dynamic.sql.select.SelectDSL;
import org.mybatis.dynamic.sql.select.SelectModel;
import org.mybatis.dynamic.sql.select.join.EqualTo;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.PriorityParameterDao;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.priority.PriorityParameter;
import ru.rsb.eurion.list.Pageable;
import ru.rsb.eurion.list.PageableSelectStatementProvider;
import ru.rsb.eurion.mybatis.LiteralDialTime;
import ru.rsb.eurion.mybatis.LiteralHolidayLeftTime;
import ru.rsb.eurion.mybatis.LiteralLeftTime;
import ru.rsb.eurion.service.application.ApplicationDao;
import ru.rsb.eurion.service.application.BaseApplicationListProvider;
import ru.rsb.eurion.service.util.JsonService;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.AMOUNT_PRIORITY;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.APPLICATION_REGION_CODE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.ATTRACT_CHANNEL_PRIORITY;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.BIRTH_DATE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.BLANK_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.BRANCH_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CHANNEL_PRIORITY;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CLIENT_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CLIENT_REGION;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CREATED_AT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CREDIT_AMOUNT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.CREDIT_SALE_CHANNEL_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.FIRST_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.FORM_CONCLUSIONS;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.FORM_DEFINITIONS;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.IS_FRAUD_RETURN;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.IS_NOVEL;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.IS_OUT_OF_DIAL_TIME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.IS_SUSPENSIVE_TERMS;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.LAST_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.LAST_USER_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.MIDDLE_NAME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.MOBILE_PHONE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.PASSPORT_NUMBER;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.PASSPORT_SERIES;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.PRODUCT_PRIORITY;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.PRODUCT_TYPE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.REGION_APP_PRIORITY;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.REQUESTED_CREDIT_AMOUNT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.RTDM_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.RTDM_PRIORITY;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.SHORT_CLIENT_REGION_CODE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.SKILL_GROUP_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.STATUS;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.STATUS_CODE;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.STATUS_UPDATED_AT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.SUPERVISOR_PRIORITY;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.SUSPEND_TIME;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.UPDATED_AT;
import static ru.rsb.eurion.service.application.priority.ApplicationDynamicSqlSupport.USER_ID;
import static ru.rsb.eurion.service.application.priority.ApplicationPriorityService.PRIORITY_HANDLER_PREFIX;
import static ru.rsb.eurion.service.application.priority.CreditAttractChannelDynamicSupport.CREDIT_ATTRACT_CHANNEL_NAME;
import static ru.rsb.eurion.service.application.priority.CreditSaleChannelDynamicSqlSupport.CREDIT_SALE_CHANNEL_NAME;
import static ru.rsb.eurion.service.application.priority.LastUserDynamicSqlSupport.USER_FULL_NAME;
import static ru.rsb.eurion.service.application.priority.RegionDynamicSqlSupport.RAW_OFFSET;
import static ru.rsb.eurion.service.application.priority.SkillGroupDynamicSqlSupport.SKILL_GROUP_NAME;
import static ru.rsb.eurion.service.application.priority.SkillGroupDynamicSqlSupport.SORT_PRIORITY;
import static ru.rsb.eurion.service.application.priority.SkillGroupDynamicSqlSupport.WORK_GROUP;


@Service
@Transactional
@Slf4j
public class ApplicationQueueListProvider extends BaseApplicationListProvider {

    private final PriorityParameterDao priorityParameterDao;
    private final ApplicationContext context;
    private final SwitchProvider switchProvider;

    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    public ApplicationQueueListProvider(ApplicationDao dao,
                                        JsonService jsonService,
                                        PriorityParameterDao priorityParameterDao,
                                        ApplicationContext context,
                                        SwitchProvider switchProvider) {
        super(dao, jsonService);
        this.priorityParameterDao = priorityParameterDao;
        this.context = context;
        this.switchProvider = switchProvider;
    }

    @Nonnull
    @Override
    protected List<ApplicationView> execMainQuery(@Nonnull FilterSpec filterSpec, Pageable<SortOrder> pageable) {
        // select ... from ... join... where
        BasicColumn[] columns = {ID,
                CLIENT_ID,
                RTDM_ID,
                LAST_NAME,
                FIRST_NAME,
                MIDDLE_NAME,
                BLANK_ID,
                BIRTH_DATE,
                CREDIT_AMOUNT,
                REQUESTED_CREDIT_AMOUNT,
                SHORT_CLIENT_REGION_CODE,
                SKILL_GROUP_ID,
                SKILL_GROUP_NAME.as("SKILL_GROUP_NAME"),
                SORT_PRIORITY,
                STATUS_UPDATED_AT,
                WORK_GROUP.as("SKILL_GROUP_WORK"),
                PASSPORT_NUMBER,
                PASSPORT_SERIES,
                PRODUCT_TYPE,
                CREDIT_SALE_CHANNEL_ID,
                APPLICATION_REGION_CODE,
                MOBILE_PHONE,
                BRANCH_ID,
                USER_FULL_NAME.as("LAST_USER_FULL_NAME"),
                USER_ID,
                UserDynamicSqlSupport.USER_FULL_NAME.as("USER_FULL_NAME"),
                STATUS,
                STATUS_CODE,
                CREATED_AT,
                UPDATED_AT,
                FORM_DEFINITIONS,
                FORM_CONCLUSIONS,
                CREDIT_SALE_CHANNEL_NAME.as("CREDIT_SALE_CHANNEL_NAME"),
                RAW_OFFSET.as("RAW_OFFSET"),
                CREDIT_ATTRACT_CHANNEL_NAME.as("CREDIT_ATTRACT_CHANNEL_NAME"),
                CLIENT_REGION,
                RTDM_PRIORITY,
                SUPERVISOR_PRIORITY,
                IS_NOVEL,
                IS_SUSPENSIVE_TERMS,
                IS_OUT_OF_DIAL_TIME,
                REGION_APP_PRIORITY,
                PRODUCT_PRIORITY,
                IS_FRAUD_RETURN,
                LAST_USER_ID,
                AMOUNT_PRIORITY,
                CHANNEL_PRIORITY,
                ATTRACT_CHANNEL_PRIORITY,
                SUSPEND_TIME,
                ApplicationIdxDynamicSqlSupport.DIAL_START_TIME.as("DIAL_START_TIME"),
                ApplicationIdxDynamicSqlSupport.DIAL_END_TIME,
                DialTimeDynamicSqlSupport.IS_ENABLED.as("DIAL_TIME"),
                DialTimeDynamicSqlSupport.IS_HOLIDAY_ENABLED.as("HOLIDAY_DIAL_TIME"),
                LiteralLeftTime.getInstance(),
                LiteralHolidayLeftTime.getInstance()};

        QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder dsl = buildQuery(filterSpec, columns);

        // order by
        SelectDSL<SelectModel> selectDSL = setupOrder(pageable, dsl);

        SelectStatementProvider selectStatementProvider = selectDSL
                .build()
                .render(RenderingStrategy.MYBATIS3);

        // offset ... fetch first ... rows
        PageableSelectStatementProvider finalStatementProvider =
                new PageableSelectStatementProvider(selectStatementProvider, pageable);

        List<ApplicationView> list = dao.select(finalStatementProvider);
        setFillPercent(list);
        return list;
    }

    @Override
    protected QueryExpressionDSL<SelectModel>.JoinSpecificationFinisher buildFrom(
            @Nonnull QueryExpressionDSL<SelectModel> queryExpressionDSL) {
        return super.buildFrom(queryExpressionDSL)
                .leftJoin(DialTimeDynamicSqlSupport.DIAL_TIME_TABLE)
                .on(LiteralDialTime.getInstance(), new EqualTo(DialTimeDynamicSqlSupport.ID))
                .join(ApplicationIdxDynamicSqlSupport.APPLICATION_IDX, "IDX")
                .on(ApplicationDynamicSqlSupport.ID, new EqualTo(ApplicationIdxDynamicSqlSupport.ID));
    }

    @Nonnull
    @Override
    protected SelectDSL<SelectModel> setupOrder(@Nonnull Pageable<SortOrder> pageable,
                                                @Nonnull QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder dsl) {
        return applyOrderBy(dsl);
    }

    private SelectDSL<SelectModel> applyOrderBy(QueryExpressionDSL<SelectModel>.QueryExpressionWhereBuilder whereBuilder) {
        List<PriorityParameter> parameters = priorityParameterDao.findAllOrdered();
        boolean reverseOrder = switchProvider.takeSwitch();

        List<SortSpecification> specificationList = parameters.stream()
                .peek(parameter -> parameter.setReverse(reverseOrder))
                .filter(PriorityParameter::isEnabled)
                .map(this::mapPriorityParameterToSortSpecification)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        specificationList.add(ApplicationIdxDynamicSqlSupport.ID.as("IDX.ID"));
        SortSpecification[] specifications = specificationList.toArray(new SortSpecification[0]);
        return whereBuilder.orderBy(specifications);
    }

    private SortSpecification mapPriorityParameterToSortSpecification(PriorityParameter parameter) {
        try {
            String name = PRIORITY_HANDLER_PREFIX + parameter.getId();
            PriorityParameterHandler bean = context.getBean(name, PriorityParameterHandler.class);
            if (!bean.isCommon()) {
                return null;
            }
            return bean.apply(parameter);
        } catch (NoSuchBeanDefinitionException e) {
            log.trace("", e);
            return null;
        }
    }
}
