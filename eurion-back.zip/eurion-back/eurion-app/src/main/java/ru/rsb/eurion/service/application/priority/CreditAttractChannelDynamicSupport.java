package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;

public class CreditAttractChannelDynamicSupport {

    public static final CreditAttractChannelTable CREDIT_ATTRACT_CHANNEL_TABLE = new CreditAttractChannelTable();

    public static final SqlColumn<Integer> ID = CREDIT_ATTRACT_CHANNEL_TABLE.column("ID", JDBCType.INTEGER);
    public static final SqlColumn<String> CREDIT_ATTRACT_CHANNEL_NAME = CREDIT_ATTRACT_CHANNEL_TABLE.column("NAME", JDBCType.VARCHAR);

    private static final class CreditAttractChannelTable extends SqlTable {
        CreditAttractChannelTable() {
            super("CREDIT_ATTRACT_CHANNEL");
        }
    }
}
