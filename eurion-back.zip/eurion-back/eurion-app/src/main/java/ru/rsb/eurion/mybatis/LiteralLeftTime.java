package ru.rsb.eurion.mybatis;

import org.mybatis.dynamic.sql.BindableColumn;
import org.mybatis.dynamic.sql.render.TableAliasCalculator;
import ru.rsb.eurion.service.TimeUtils;

import java.sql.JDBCType;
import java.time.LocalTime;
import java.util.Optional;

public class LiteralLeftTime implements BindableColumn<String> {
    private static final String renderScript = " decode(SIGN(#{serverTime} - idx.DIAL_START_TIME),\n" +
            "1, #{minutesInDay}- (#{serverTime} - idx.DIAL_START_TIME),\n" +
            "-1, idx.DIAL_START_TIME - #{serverTime},\n" +
            "#{minutesInDay} - (#{serverTime} - idx.DIAL_START_TIME)) AS LEFT_TIME ";

    private static final LiteralLeftTime INSTANCE = new LiteralLeftTime();

    public static LiteralLeftTime getInstance() {
        return INSTANCE;
    }

    @Override
    public Optional<String> alias() {
        return Optional.empty();
    }

    @Override
    public BindableColumn<String> as(String alias) {
        return this;
    }

    @Override
    public Optional<JDBCType> jdbcType() {
        return Optional.of(JDBCType.VARCHAR);
    }

    @Override
    public Optional<String> typeHandler() {
        return Optional.empty();
    }

    @Override
    public String renderWithTableAlias(TableAliasCalculator tableAliasCalculator) {
        int serverTime = TimeUtils.timeToMinutes(LocalTime.now());
        return renderScript.replace("#{serverTime}", String.valueOf(serverTime))
                .replace("#{minutesInDay}", String.valueOf(TimeUtils.minutesInDay));
    }
}
