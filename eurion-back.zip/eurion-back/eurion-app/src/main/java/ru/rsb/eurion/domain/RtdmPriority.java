package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * <p>Справочник "Приоритеты RTDM"</p>
 * <p>
 * Представляет собой текстовое представление для кодов приоритета RTDM (0..100) и настройки
 * визуализациии приоритетности на Фронте.
 */
@Getter
@Setter
public class RtdmPriority extends BasicReference {
    private boolean needNotification;
    private boolean warning;
}
