package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Getter
@Setter
public class FieldComment {
    /**
     * ID заявки, к которой относится комментарий. Вместе с name образует первичный ключ сущности.
     */
    @NotNull
    private Long applicationId;
    /**
     * Произвольное наименование поля. Уникально в пределах заявки.
     */
    @NotNull
    private String name;
    /**
     * Текст комментария
     */
    private String commentText;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
