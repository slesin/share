package ru.rsb.eurion.service.application.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.SkillGroup;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class ProductRuleItem {

    @JsonIgnore
    private SkillGroup skillGroup;

    @NotNull
    private ProductType productType;

    @Valid
    private List<ProductRule> productRules;

    public List<ProductRule> getProductRules() {
        if (productRules == null) {
            productRules = new ArrayList<>();
        }
        return productRules;
    }
}
