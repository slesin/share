package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.PhoneSourceType;

import java.util.List;

@Mapper
public interface PhoneSourceDao {

    @Select("select " +
            "  ID, " +
            "  NAME, " +
            "  INNER, " +
            "  CREATED_AT, " +
            "  UPDATED_AT " +
            "from PHONE_SOURCE_TYPE")
    @Results(id = "phoneSourceMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "inner", column = "INNER"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT")
    })
    List<PhoneSourceType> findAll();

    @Select("select * from PHONE_SOURCE_TYPE where ID = #{id}")
    @ResultMap("phoneSourceMapping")
    PhoneSourceType findById(Integer id);
}