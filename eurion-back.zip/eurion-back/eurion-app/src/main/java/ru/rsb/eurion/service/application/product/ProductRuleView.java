package ru.rsb.eurion.service.application.product;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.SkillGroup;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class ProductRuleView {

    @NotNull
    private SkillGroup skillGroup;

    private List<ProductRuleItem> productRuleItems;

    @Valid
    public List<ProductRuleItem> getProductRuleItems() {
        if (productRuleItems == null) {
            productRuleItems = new ArrayList<>();
        }
        return productRuleItems;
    }
}
