package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.UserTab;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface UserTabDao {

    String BASE_SQL = "SELECT\n" +
            "  tab.ID as ID,\n" +
            "  tab.APPLICATION_ID as APPLICATION_ID,\n" +
            "  tab.USER_ID        as USER_ID,\n" +
            "  app.FIRST_NAME     as FIRST_NAME,\n" +
            "  app.MIDDLE_NAME    as MIDDLE_NAME,\n" +
            "  app.LAST_NAME      as LAST_NAME,\n" +
            "  tab.UPDATED_AT     as UPDATED_AT, \n" +
            "  tab.CREATED_AT     as CREATED_AT, \n" +
            "  tab.DISABLED_AT    as DISABLED_AT,\n" +
            "  tab.USER_ROLE_ID   as USER_ROLE,\n" +
            "  app.STATUS_CATEGORY_CODE as STATUS_CATEGORY_CODE\n" +
            "FROM USER_TAB tab\n" +
            "JOIN Application app ON app.id = tab.APPLICATION_ID";

    @Select(BASE_SQL + " WHERE tab.USER_ID = #{userId, jdbcType = INTEGER} AND\n" +
            "tab.USER_ROLE_ID= #{userRole, jdbcType = VARCHAR} AND tab.DISABLED_AT IS NULL ORDER BY ID")
    @Results(id = "userTabMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "applicationId", column = "APPLICATION_ID"),
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "firstName", column = "FIRST_NAME"),
            @Result(property = "middleName", column = "MIDDLE_NAME"),
            @Result(property = "lastName", column = "LAST_NAME"),
            @Result(property = "processStatusCode", column = "STATUS_CATEGORY_CODE"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<UserTab> listActiveUserTab(@Param("userId") Integer userId, @Param("userRole") Role userRole);

    @Update("UPDATE USER_TAB\n" +
            "SET UPDATED_AT = #{updatedAt, jdbcType = TIMESTAMP},\n" +
            "  DISABLED_AT  = #{userTab.disabledAt, jdbcType = TIMESTAMP}\n" +
            "WHERE APPLICATION_ID = #{userTab.applicationId, jdbcType = INTEGER} AND\n" +
            "      USER_ID = #{userId, jdbcType = INTEGER} AND USER_ROLE_ID = #{userRole, jdbcType = VARCHAR}")
    void updateUserTab(@Param("userTab") UserTab userTab, @Param("updatedAt") LocalDateTime updated,
                       @Param("userId") Integer userId, @Param("userRole") Role userRole);

    @Insert("INSERT INTO USER_TAB (APPLICATION_ID, USER_ID, CREATED_AT, UPDATED_AT, USER_ROLE_ID) VALUES\n" +
            "  (#{userTab.applicationId},\n" +
            "   #{userId, jdbcType = INTEGER},\n" +
            "   #{createdAt, jdbcType = INTEGER},\n" +
            "   #{createdAt, jdbcType = INTEGER},\n" +
            "   #{userRole, jdbcType = VARCHAR})\n")
    @SelectKey(
            keyProperty = "userTab.id",
            before = false,
            resultType = Integer.class,
            statement = {"select seq_user_tab.currval AS id from dual"})
    void create(@Param("userTab") UserTab userTab, @Param("userId") Integer userId,
                @Param("createdAt") LocalDateTime createdAt, @Param("userRole") Role userRole);

    @Select(BASE_SQL +
            " WHERE tab.USER_ID = #{userId, jdbcType = INTEGER}\n" +
            "  AND " +
            "tab.USER_ROLE_ID = #{userRole, jdbcType = VARCHAR}\n" +
            "  AND tab.DISABLED_AT IS NOT NULL\n" +
            "  AND tab.APPLICATION_ID = #{appId, jdbcType = BIGINT}\n" +
            "ORDER BY ID")
    UserTab findDisabled(@Param("appId") Long appId,
                         @Param("userId") Integer userId,
                         @Param("userRole") Role userRole);
}