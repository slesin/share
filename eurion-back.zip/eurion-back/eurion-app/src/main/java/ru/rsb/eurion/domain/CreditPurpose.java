package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Цель кредита
 */
@Setter
@Getter
public class CreditPurpose extends BasicReference {
}
