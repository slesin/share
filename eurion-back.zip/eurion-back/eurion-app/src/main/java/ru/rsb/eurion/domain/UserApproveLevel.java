package ru.rsb.eurion.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
public class UserApproveLevel {

    private BigDecimal approvePercent;

    private String fullName;

    @JsonIgnore
    private BigDecimal plannedApprovePercent;

    @JsonIgnore
    private BigDecimal stepPercent;

    @JsonIgnore
    private BigDecimal productionRatePercent;
}
