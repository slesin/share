package ru.rsb.eurion.service.admin.users;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.PrimaryPhoneType;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserDomain;
import ru.rsb.eurion.domain.UserStatus;

import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@XmlRootElement
@Getter
@Setter
public class UserView extends BasicReference {
    private String username;
    private Set<Role> roles;
    private LocalDate birthDate;
    private String personnelNumber;
    private BigDecimal limit;
    private BasicReference supervisor;
    private UserStatus status;
    private Set<Integer> skillGroupIds;
    private String lotusAddress;
    private String division;
    private UserDomain domain;
    private PrimaryPhoneType primaryPhoneType;
    private boolean hasUpdateLimitPermission;

    public static UserView of(User user, Set<Role> roles, Set<Integer> skillGroupIds) {
        UserView view = new UserView();
        BasicReference.map(user, view);

        view.username = user.getUsername();
        view.birthDate = user.getBirthDate();
        view.personnelNumber = user.getPersonnelNumber();
        view.limit = user.getLimit();
        view.supervisor = user.getSupervisor();
        view.status = user.getStatusHistory() != null ? user.getStatusHistory().getStatus() : null;

        view.roles = roles;
        view.skillGroupIds = skillGroupIds;
        view.setLotusAddress(user.getLotusAddress());
        view.setDivision(user.getDivision());
        view.setDomain(user.getDomain());
        view.setPrimaryPhoneType(user.getPrimaryPhoneType());
        view.setHasUpdateLimitPermission(user.isHasUpdateLimitPermission());

        return view;
    }

    @SuppressWarnings("unused")
    public Set<Role> getRoles() {
        if (roles == null) {
            roles = new HashSet<>();
        }
        return roles;
    }

    @SuppressWarnings("unused")
    public Set<Integer> getSkillGroupIds() {
        if (skillGroupIds == null) {
            return new HashSet<>();
        }
        return skillGroupIds;
    }
}
