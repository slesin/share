package ru.rsb.eurion.mybatis;

import org.mybatis.dynamic.sql.BindableColumn;
import org.mybatis.dynamic.sql.render.TableAliasCalculator;

import java.sql.JDBCType;
import java.util.Optional;

import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION_AUTHOR;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION_VERIFIER;

public class LiteralApplicationProcessName implements BindableColumn<String> {
    private static final String renderScript = " decode(AP.PROCESS_NAME, '%s', 'Андеррайтинг', '%s', 'Автор', '%s', 'Верификатор') as PROCESS_TITLE";

    private static final LiteralApplicationProcessName INSTANCE = new LiteralApplicationProcessName();

    public static LiteralApplicationProcessName getInstance() {
        return INSTANCE;
    }

    @Override
    public Optional<String> alias() {
        return Optional.empty();
    }

    @Override
    public BindableColumn<String> as(String s) {
        return null;
    }

    @Override
    public String renderWithTableAlias(TableAliasCalculator tableAliasCalculator) {
        return String.format(renderScript, APPLICATION, APPLICATION_AUTHOR, APPLICATION_VERIFIER);
    }

    @Override
    public Optional<JDBCType> jdbcType() {
        return Optional.empty();
    }

    @Override
    public Optional<String> typeHandler() {
        return Optional.empty();
    }
}
