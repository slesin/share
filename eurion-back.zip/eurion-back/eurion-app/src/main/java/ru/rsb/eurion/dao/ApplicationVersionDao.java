package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.ApplicationVersion;
import ru.rsb.eurion.domain.ApplicationVersionInfo;
import ru.rsb.eurion.domain.VersionInterval;

import javax.annotation.Nonnull;
import java.util.List;

@Mapper
public interface ApplicationVersionDao {

    String SELECT_SQL = "SELECT ID,\n" +
            "       APPLICATION_ID,\n" +
            "       BLANK_ID,\n" +
            "       STATUS,\n" +
            "       STATUS_CATEGORY_CODE,\n" +
            "       APPLICATION_DATA,\n" +
            "       FORM_DEFINITIONS,\n" +
            "       FORM_CONCLUSIONS,\n" +
            "       USER_ID,\n" +
            "       INCOME_INFO,\n" +
            "       IS_FRAUD_RETURN,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT,\n" +
            "       VERSION,\n" +
            "       FIELD_COMMENT,\n" +
            "       SKILL_GROUP_ID\n" +
            "from APPLICATION_VERSION";

    String SELECT_VERSION_INFO_BY_ID = "select av.ID,\n" +
            "(TO_CHAR(VERSION, 'DD.MM.YYYY HH24:MI:SS') || ' ' || sk.NAME) as NAME,\n" +
            "av.VERSION as VERSION\n" +
            "from APPLICATION_VERSION av\n" +
            "left join SKILL_GROUP sk on sk.id = av.SKILL_GROUP_ID\n" +
            "where APPLICATION_ID = #{appId, jdbcType=BIGINT}\n" +
            "order by av.VERSION desc";

    String INSERT_SQL = "insert into APPLICATION_VERSION (APPLICATION_ID,\n" +
            "                                 BLANK_ID,\n" +
            "                                 STATUS,\n" +
            "                                 STATUS_CATEGORY_CODE,\n" +
            "                                 APPLICATION_DATA,\n" +
            "                                 FORM_DEFINITIONS,\n" +
            "                                 FORM_CONCLUSIONS,\n" +
            "                                 USER_ID,\n" +
            "                                 INCOME_INFO,\n" +
            "                                 IS_FRAUD_RETURN,\n" +
            "                                 CREATED_AT,\n" +
            "                                 UPDATED_AT,\n" +
            "                                 VERSION,\n" +
            "                                 FIELD_COMMENT,\n" +
            "                                 SKILL_GROUP_ID)\n" +
            "values (#{appVersion.applicationId, jdbcType=BIGINT},\n" +
            "        #{appVersion.blankId, jdbcType=BIGINT},\n" +
            "        #{appVersion.status, jdbcType=VARCHAR},\n" +
            "        #{appVersion.statusCategoryCode, jdbcType=VARCHAR},\n" +
            "        #{appVersion.data, jdbcType=CLOB},\n" +
            "        #{appVersion.formDefinitions, jdbcType=CLOB},\n" +
            "        #{appVersion.formConclusions, jdbcType=CLOB},\n" +
            "        #{appVersion.userId, jdbcType=INTEGER},\n" +
            "        #{appVersion.incomeInfo, jdbcType=CLOB},\n" +
            "        #{appVersion.fraudReturn, jdbcType=BOOLEAN},\n" +
            "        #{appVersion.createdAt, jdbcType=TIMESTAMP},\n" +
            "        #{appVersion.updatedAt, jdbcType=TIMESTAMP},\n" +
            "        #{appVersion.version, jdbcType=TIMESTAMP},\n" +
            "        #{appVersion.fieldComment, jdbcType=CLOB},\n" +
            "        #{appVersion.skillGroupId, jdbcType=INTEGER})";

    String SELECT_VERSION_INTERVAL = "select AV2.id,\n" +
            "       AV2.APPLICATION_ID,\n" +
            "       decode(AV1.VERSION, null, AV2.CREATED_AT, AV1.VERSION) as PREVIOUS_VERSION,\n" +
            "       AV2.VERSION                                            as CURRENT_VERSION\n" +
            "from ((select id,\n" +
            "              APPLICATION_ID,\n" +
            "              CREATED_AT,\n" +
            "              VERSION,\n" +
            "              row_number() over (ORDER BY VERSION) as num\n" +
            "       from APPLICATION_VERSION\n" +
            "       where APPLICATION_ID = #{appId, jdbcType=BIGINT}) AV1\n" +
            "         right join(select id,\n" +
            "                           APPLICATION_ID,\n" +
            "                           VERSION,\n" +
            "                           CREATED_AT,\n" +
            "                           row_number() over (ORDER BY version) num\n" +
            "                    from APPLICATION_VERSION\n" +
            "                    where APPLICATION_ID = #{appId, jdbcType=BIGINT}) AV2 on AV1.num = AV2.num - 1)\n" +
            "where AV2.id = #{versionId, jdbcType=BIGINT}";

    @Select(SELECT_SQL + " where id = #{id}")
    @Results(id = "applicationVersionMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "applicationId", column = "APPLICATION_ID"),
            @Result(property = "blankId", column = "BLANK_ID"),
            @Result(property = "status", column = "STATUS"),
            @Result(property = "statusCategoryCode", column = "STATUS_CATEGORY_CODE"),
            @Result(property = "data", column = "APPLICATION_DATA"),
            @Result(property = "formDefinitions", column = "FORM_DEFINITIONS"),
            @Result(property = "formConclusions", column = "FORM_CONCLUSIONS"),
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "incomeInfo", column = "INCOME_INFO"),
            @Result(property = "fraudReturn", column = "IS_FRAUD_RETURN"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "version", column = "VERSION"),
            @Result(property = "skillGroupId", column = "SKILL_GROUP_ID"),
            @Result(property = "fieldComment", column = "FIELD_COMMENT"),
            @Result(property = "versionInterval", one = @One(select = "getVersionInterval",
                    fetchType = FetchType.EAGER), column = "{versionId=ID, appId=APPLICATION_ID}")
    })
    ApplicationVersion findById(@Nonnull Long id);

    @Insert(INSERT_SQL)
    @SelectKey(
            keyProperty = "id",
            before = false,
            resultType = Long.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_application_version.currval AS id from dual"}
    )
    void create(@Param("appVersion") ApplicationVersion appVersion);

    @Select(SELECT_VERSION_INFO_BY_ID)
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "name")
    })
    List<ApplicationVersionInfo> getVersionInfo(@Param("appId") Long appId);

    /**
     * Used by {@link #findById(Long)}
     */
    @SuppressWarnings("unused")
    @Select(SELECT_VERSION_INTERVAL)
    @Results({
            @Result(property = "start", column = "PREVIOUS_VERSION"),
            @Result(property = "end", column = "CURRENT_VERSION")
    })
    VersionInterval getVersionInterval(@Param("versionId") Long id, @Param("appId") Long appId);

    @Select(SELECT_SQL +
            " where application_id = #{appId, jdbcType = INTEGER}\n" +
            "order by UPDATED_AT desc\n" +
            "fetch first row only")
    @ResultMap("applicationVersionMapping")
    ApplicationVersion findLastByAppId(@Param("appId") Integer appId);

}
