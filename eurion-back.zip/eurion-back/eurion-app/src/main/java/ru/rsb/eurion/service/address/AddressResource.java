package ru.rsb.eurion.service.address;


import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;

import javax.validation.constraints.NotNull;
import java.util.List;

@RequestMapping(path = EurionApplication.API_BASE + "/address")
@RestController
@AllArgsConstructor
public class AddressResource {

    private final AddressLoader loader;

    @GetMapping(path = "/town")
    public List<TownAddressItem> getTown(@NotNull @RequestParam("name") String name,
                                         @NotNull @RequestParam("limit") Integer limit) {
        return loader.loadTown(name, limit);
    }

    @GetMapping(path = "/street")
    public List<StreetAddressItem> getStreet(@NotNull @RequestParam("name") String name,
                                             @NotNull @RequestParam("guid") String guid,
                                             @NotNull @RequestParam("limit") Integer limit) {
        return loader.loadStreet(name, guid, limit);
    }

    @GetMapping(path = "/house")
    public List<HouseAddressItem> getHouse(@NotNull @RequestParam("name") String name,
                                           @NotNull @RequestParam("type") HouseType houseType,
                                           @NotNull @RequestParam("guid") String guid) {
        return loader.loadHouse(name, houseType, guid);
    }

}
