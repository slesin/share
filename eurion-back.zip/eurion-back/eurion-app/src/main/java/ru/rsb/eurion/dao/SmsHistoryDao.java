package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import ru.rsb.eurion.domain.SmsHistory;

import java.util.List;

@Mapper
public interface SmsHistoryDao {

    String BASE_SQL = "SELECT ID, \n" +
            "       BLANK_ID, \n" +
            "       PHONE_NUMBER, \n" +
            "       MESSAGE_ID,\n" +
            "       MESSAGE_TEMPLATE_ID,\n" +
            "       CREATED_AT\n" +
            "FROM SMS_HISTORY ";

    @Select(BASE_SQL + "where BLANK_ID = #{blankId, jdbcType = BIGINT}")
    @Results(id = "smsHistory", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "blankId", column = "BLANK_ID"),
            @Result(property = "phoneNumber", column = "PHONE_NUMBER"),
            @Result(property = "messageId", column = "MESSAGE_ID"),
            @Result(property = "messageTemplateId", column = "MESSAGE_TEMPLATE_ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
    })
    List<SmsHistory> list(@Param("blankId") Long blankId);

    @Insert("INSERT INTO SMS_HISTORY (BLANK_ID, PHONE_NUMBER, MESSAGE_ID, MESSAGE_TEMPLATE_ID, CREATED_AT)\n" +
            "VALUES (#{smsHistory.blankId, jdbcType = BIGINT},\n" +
            "    #{smsHistory.phoneNumber, jdbcType = VARCHAR},\n" +
            "    #{smsHistory.messageId, jdbcType = VARCHAR},\n" +
            "    #{smsHistory.messageTemplateId, jdbcType = INTEGER},\n" +
            "    #{smsHistory.createdAt, jdbcType = TIMESTAMP})\n")
    @SelectKey(
            keyProperty = "smsHistory.id",
            before = false,
            resultType = Integer.class,
            statement = {"select seq_sms_history.currval AS id from dual"})
    void create(@Param("smsHistory") SmsHistory smsHistory);
}
