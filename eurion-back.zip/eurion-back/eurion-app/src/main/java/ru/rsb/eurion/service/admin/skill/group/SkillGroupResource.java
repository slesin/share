package ru.rsb.eurion.service.admin.skill.group;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.admin.Consts;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@RequestMapping(path = Consts.ADMIN_API_BASE + "/skill-group", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class SkillGroupResource {
    private final SkillGroupService service;
    private final SkillGroupLoader skillGroupLoader;

    @GetMapping(path = "/{id}/agg")
    public SkillGroupAggragate loadAgg(@PathVariable("id") Integer skillGroupId) {
        return skillGroupLoader.load(skillGroupId);
    }

    @GetMapping(path = "/ref/agg")
    public SkillGroupAggragate loadReFAgg() {
        return skillGroupLoader.loadRef();
    }

    @GetMapping
    public List<SkillGroup> skillGroupList() {
        return service.skillGroupList();
    }

    @PostMapping("/create-skill-group")
    public SkillGroup create(@RequestBody @Valid SkillGroup skillGroup) {
        return service.createSkillGroup(skillGroup);
    }

    @PostMapping("/update-skill-group")
    public void update(@RequestBody SkillGroup skillGroup) throws BusinessException {
        service.updateSkillGroup(skillGroup);
    }

    @PostMapping("/deactivate-skill-group/{id}")
    public void deactivateSkillGroup(@NotNull @PathVariable("id") Integer skillGroupId) {
        service.deactivateSkillGroup(skillGroupId);
    }

    @PostMapping("/deactivate-skill-group")
    public void deactivateSkillGroup(@NotNull @RequestBody List<Integer> skillGroupIds) {
        service.deactivateSkillGroups(skillGroupIds);
    }

    @PostMapping("/activate-skill-group/{id}")
    public void activateSkillGroup(@NotNull @PathVariable("id") Integer skillGroupId) {
        service.activateSkillGroup(skillGroupId);
    }

    @PostMapping("/activate-skill-group")
    public void activateSkillGroups(@NotNull @RequestBody List<Integer> skillGroupIds) {
        service.activateSkillGroups(skillGroupIds);
    }

    @GetMapping("/decline-category/{id}")
    public SkillGroupDeclineCategory getDeclineCategory(@NotNull @PathVariable("id") Integer skillGroupId) {
        return service.getDeclineCategoryReason(skillGroupId);
    }

    @PutMapping("/decline-category")
    public SkillGroupDeclineCategory updateDeclineCategory(@NotNull @RequestBody SkillGroupDeclineCategory skillGroupDeclineCategory) {
        service.updateDeclineCategoryReason(skillGroupDeclineCategory);
        return service.getDeclineCategoryReason(skillGroupDeclineCategory.getSkillGroupId());
    }
}