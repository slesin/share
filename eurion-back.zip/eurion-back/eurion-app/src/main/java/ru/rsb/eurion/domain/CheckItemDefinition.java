package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CheckItemDefinition extends BasicReference {
    @NotNull
    private CheckItemKind kind;
    private Integer orderNumber;
    @Valid
    private List<CheckItemElement> items;
    @NotNull
    private String code;
    private boolean isRequiredForReject;

    public List<CheckItemElement> getItems() {
        if (items == null) {
            items = new ArrayList<>();
        }
        return items;
    }
}
