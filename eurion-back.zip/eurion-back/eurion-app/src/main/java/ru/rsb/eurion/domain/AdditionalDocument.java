package ru.rsb.eurion.domain;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Дополнительный документ
 */
@Getter
@Setter
@NoArgsConstructor
@SuppressFBWarnings("EI_EXPOSE_REP")
public class AdditionalDocument extends BasicReference {
    /**
     * Номер
     */
    private String number;
    /**
     * Идентификатор типа документа
     */
    private Integer typeId;
    /**
     * Комментарий
     */
    private String remark;
    /**
     * Признак того, что документ создан в этом приложенни
     */
    private boolean inner;
    /**
     * Документ
     */
    private byte[] documentImage;
    /**
     * Формат
     */
    private String documentImageType;
    /**
     * Идентификатор заявки
     */
    private Long applicationId;
    /**
     * Имя файла
     */
    private String fileName;

    private String userName;
}
