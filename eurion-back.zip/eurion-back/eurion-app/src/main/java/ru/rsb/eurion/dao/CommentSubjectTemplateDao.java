package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.CommentSubject;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;

import java.util.List;

@Mapper
public interface CommentSubjectTemplateDao {

    String SELECT_SQL = "select ID,\n" +
            "       NAME,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT\n" +
            "from COMMENT_SUBJECT\n";

    @Select(SELECT_SQL + " order by NAME")
    @Results(id = "CommentTemplateMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
    })
    List<CommentSubject> findAll();

    @Select(SELECT_SQL + "where id = #{id, jdbcType = INTEGER}")
    @ResultMap("CommentTemplateMapping")
    CommentSubject findById(@Param("id") Integer id);

    @Insert("INSERT INTO COMMENT_SUBJECT (NAME, CREATED_AT)\n" +
            "VALUES (#{subject.name, jdbcType = VARCHAR},\n" +
            "        #{subject.createdAt, jdbcType=TIMESTAMP})")

    @SelectKey(
            keyProperty = "subject.id",
            before = false,
            resultType = Integer.class,
            statement = {"select seq_comment_subject.currval AS id from dual"})
    void create(@Param("subject") CommentSubject subject);

    @Update("UPDATE COMMENT_SUBJECT\n" +
            "SET NAME        = #{subject.name, jdbcType = VARCHAR},\n" +
            "    UPDATED_AT  = #{subject.updatedAt, jdbcType = TIMESTAMP}\n" +
            "WHERE ID = #{subject.id, jdbcType = INTEGER}")
    void update(@Param("subject") CommentSubject subject);

    @Delete("DELETE FROM COMMENT_SUBJECT WHERE ID IN (#{ids})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void delete(@Param("ids") List<Integer> ids);
}
