package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class VersionInterval {

    private LocalDateTime start;

    private LocalDateTime end;

}
