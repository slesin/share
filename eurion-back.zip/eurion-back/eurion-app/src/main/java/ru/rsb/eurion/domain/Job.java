package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Описание работы
 */
@Getter
@Setter
public class Job {
    /**
     * Место работы
     */
    private String name;
    /**
     * Отраслевая принадлежность
     */
    private String industry;
    /**
     * ИНН работодателя
     */
    private String inn;
}
