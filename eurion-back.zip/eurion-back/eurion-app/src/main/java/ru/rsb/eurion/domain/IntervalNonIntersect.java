package ru.rsb.eurion.domain;

import org.apache.commons.lang3.reflect.FieldUtils;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.Collection;
import java.util.List;

@Constraint(validatedBy = IntervalNonIntersect.Validator.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface IntervalNonIntersect {
    String value();

    String message() default "{app.interval.intersects}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    class Validator implements ConstraintValidator<IntervalNonIntersect, Object> {

        private String message;
        private String fieldName;

        @Override
        public void initialize(IntervalNonIntersect constraintAnnotation) {
            message = constraintAnnotation.message();
            fieldName = constraintAnnotation.value();
        }

        @Override
        @SuppressWarnings("unchecked")
        public boolean isValid(Object value, ConstraintValidatorContext context) {
            if (value == null) {
                return true;
            }
            Field field = FieldUtils.getField(value.getClass(), fieldName, true);
            if (field == null) {
                throw new IllegalArgumentException("Field not found: " + fieldName);
            }

            if (!Collection.class.isAssignableFrom(field.getType())) {
                throw new IllegalArgumentException("Field '" + fieldName +
                        "' must implements Collection<? extends Interval>");
            }
            List<Interval> intervals;
            try {
                intervals = (List<Interval>) field.get(value);
            } catch (IllegalAccessException e) {
                throw new IllegalArgumentException(e);
            }

            context.disableDefaultConstraintViolation();
            int i = 0;
            if (intervals == null) {
                return true;
            }

            boolean violationFound = false;
            for (Interval interval : intervals) {
                for (Interval anotherInterval : intervals) {
                    if (interval != anotherInterval && interval.intersects(anotherInterval)) {
                        String propertyPath = fieldName + "[" + i + "]";
                        context.buildConstraintViolationWithTemplate(message)
                                .addPropertyNode(propertyPath)
                                .addConstraintViolation();
                        violationFound = true;
                    }
                }
                i++;
            }

            return !violationFound;
        }
    }
}
