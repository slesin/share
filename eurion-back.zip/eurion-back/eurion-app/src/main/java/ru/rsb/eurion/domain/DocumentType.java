package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DocumentType {

    private Integer id;

    private String name;

    private boolean isDisabled;

}
