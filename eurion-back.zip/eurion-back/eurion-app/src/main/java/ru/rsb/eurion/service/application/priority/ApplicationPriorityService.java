package ru.rsb.eurion.service.application.priority;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationIdx;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.service.admin.users.UserDao;
import ru.rsb.eurion.service.application.ApplicationListProvider;
import ru.rsb.eurion.service.application.ApplicationViewMapper;
import ru.rsb.eurion.service.application.BaseApplicationListProvider.AppPageable;
import ru.rsb.eurion.service.application.StatusCode;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.ref.RegionService;
import ru.rsb.eurion.settings.AppConfig;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.Collections;
import java.util.List;
import java.util.Set;

@Service
@Transactional
@AllArgsConstructor
@Slf4j
public class ApplicationPriorityService {
    public static final String PRIORITY_HANDLER_PREFIX = "PRIORITY_HANDLER_";
    private static final AppPageable PAGEABLE =
            new AppPageable(0, 1, Collections.emptyList(), Collections.emptyList());
    private AppConfig appConfig;
    private RegionService regionService;

    private final ApplicationIdxDao dao;
    private final ApplicationViewMapper mapper;
    private final UserDao userDao;
    private final ApplicationQueueListProvider listProvider;

    public void createIndexItem(ApplicationEntity applicationEntity) {
        boolean exists = dao.exists(applicationEntity.getId());
        if (exists) {
            dao.delete(applicationEntity.getId());
        }
        ApplicationIdx idx = mapper.mapToIndex(applicationEntity);
        String regionCode = applicationEntity.getShortClientRegionCode();
        boolean regionExist = regionService.regionExist(regionCode);
        if (regionExist) {
            LocalTime dialStartTime = appConfig.getDialStartTime();
            Integer dialStartServerTimeMin = regionService.convertToServerTimeMin(dialStartTime, regionCode);
            idx.setDialStartTime(dialStartServerTimeMin);
            LocalTime dialEndTime = appConfig.getDialEndTime();
            Integer dialEndServerTimeMin = regionService.convertToServerTimeMin(dialEndTime, regionCode);
            idx.setDialEndTime(dialEndServerTimeMin);

            LocalTime holidayDialStartTime = appConfig.getHolidayDialStartTime();
            Integer dialHolidayStartServerTimeMin = regionService.convertToServerTimeMin(holidayDialStartTime, regionCode);
            idx.setHolidayDialStartTime(dialHolidayStartServerTimeMin);
            LocalTime holidayDialEndTime = appConfig.getHolidayDialEndTime();
            Integer dialHolidayEndServerTimeMin = regionService.convertToServerTimeMin(holidayDialEndTime, regionCode);
            idx.setHolidayDialEndTime(dialHolidayEndServerTimeMin);
        }
        dao.create(idx);
    }

    @Nonnull
    public PagedResult<ApplicationView> listQueue(@Nonnull AppPageable pageable, @Nonnull ApplicationListProvider.FilterSpec filterSpec) {
        return listProvider.listPage(pageable, filterSpec);
    }

    @Nullable
    public ApplicationView loadNextForOperator(Integer userId) {
        Set<Integer> skillGroupIds = userDao.listSkillGroup(userId);
        User user = userDao.findById(userId);
        if (skillGroupIds.isEmpty() || user == null) {
            return null;
        }
        ApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.getSkillGroupIds().addAll(skillGroupIds);
        if (user.getLimit() != null && user.getLimit().compareTo(appConfig.getAmountSkipLimit()) < 0) {
            filterSpec.setRequestedCreditAmountLimit(user.getLimit());
        }
        filterSpec.setProcessNames(Collections.singletonList(ProcessDefinitionKey.APPLICATION));
        filterSpec.setStatusCodes(Collections.singletonList(StatusCode.QUEUE));
        PagedResult<ApplicationView> page = listProvider.listPage(PAGEABLE, filterSpec);
        return !page.getItems().isEmpty() ? page.getItems().get(0) : null;
    }

    public List<ApplicationView> loadNextForOperators(Integer userId) {
        Set<Integer> skillGroupIds = userDao.listSkillGroup(userId);
        User user = userDao.findById(userId);
        if (skillGroupIds.isEmpty() || user == null) {
            return Collections.emptyList();
        }
        ApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.getSkillGroupIds().addAll(skillGroupIds);
        if (user.getLimit() != null && user.getLimit().compareTo(appConfig.getAmountSkipLimit()) < 0) {
            filterSpec.setRequestedCreditAmountLimit(user.getLimit());
        }
        filterSpec.setProcessNames(Collections.singletonList(ProcessDefinitionKey.APPLICATION));
        filterSpec.setStatusCodes(Collections.singletonList(StatusCode.QUEUE));
        PagedResult<ApplicationView> page = listProvider.listPage(PAGEABLE, filterSpec);
        return !page.getItems().isEmpty() ? page.getItems() : Collections.emptyList();
    }

    public void remove(ApplicationEntity entity) {
        dao.delete(entity.getId());
    }

}
