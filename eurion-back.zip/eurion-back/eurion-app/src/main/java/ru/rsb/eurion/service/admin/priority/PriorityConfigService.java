package ru.rsb.eurion.service.admin.priority;

import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.CreditAttractChannelDao;
import ru.rsb.eurion.dao.CreditSaleChannelDao;
import ru.rsb.eurion.dao.PriorityAmountIntervalDao;
import ru.rsb.eurion.dao.PriorityParameterDao;
import ru.rsb.eurion.dao.ProductPriorityDao;
import ru.rsb.eurion.dao.RegionDao;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.CreditAttractChannel;
import ru.rsb.eurion.domain.CreditSaleChannel;
import ru.rsb.eurion.domain.PriorityAmountInterval;
import ru.rsb.eurion.domain.Region;
import ru.rsb.eurion.domain.priority.DialInterval;
import ru.rsb.eurion.domain.priority.PriorityConfig;
import ru.rsb.eurion.domain.priority.PriorityParameter;
import ru.rsb.eurion.domain.priority.ProductSortPriorityView;
import ru.rsb.eurion.domain.priority.UpdatePriorityConfig;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.CollectionUtils;
import ru.rsb.eurion.service.application.priority.SwitchProvider;
import ru.rsb.eurion.settings.AppConfig;
import ru.rsb.eurion.settings.AppConfigFactory;
import ru.rsb.eurion.settings.AppConfigNotifyConsumer;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

@Service
@Transactional
@AllArgsConstructor
public class PriorityConfigService {

    private final AppConfig config;
    private final RegionDao regionDao;
    private final CreditSaleChannelDao creditSaleChannelDao;
    private final CreditAttractChannelDao creditAttractChannelDao;
    private final ProductPriorityDao productPriorityDao;
    private final PriorityParameterDao priorityParameterDao;
    private final AppConfigFactory appConfigFactory;
    private final PriorityAmountIntervalDao priorityAmountIntervalDao;
    private final AppConfigNotifyConsumer notifyConsumer;
    private final SwitchProvider switchProvider;

    public PriorityConfig read() {
        PriorityConfig result = new PriorityConfig();

        List<PriorityParameter> priorityParameters = priorityParameterDao.findAllOrdered();
        result.setParameters(priorityParameters);

        DialInterval workDialInterval = takeWorkDialInterval();
        result.setWorkDialInterval(workDialInterval);

        DialInterval holidayDialInterval = takeHolidayDialInterval();
        result.setHolidayDialInterval(holidayDialInterval);

        List<Region> regionPriorities = regionDao.listAllRegions();
        result.setRegionPriorities(regionPriorities);

        List<CreditSaleChannel> creditSaleChannels = creditSaleChannelDao.findAll();
        result.setChannelPriorities(creditSaleChannels);

        List<CreditAttractChannel> creditAttractChannels = creditAttractChannelDao.findAll();
        result.setCreditAttractChannelPriorities(creditAttractChannels);

        List<PriorityAmountInterval> amountIntervals = priorityAmountIntervalDao.findAll();
        result.setPriorityAmountIntervals(amountIntervals);

        result.setSwitchableOrder(config.isSwitchableOrder());
        result.setSwitchTopCount(config.getSwitchTopCount());
        result.setSwitchBottomCount(config.getSwitchBottomCount());

        return result;
    }

    public void write(UpdatePriorityConfig config) throws BusinessException {
        List<PriorityParameter> priorityParameters = config.getParameters();
        enumeratePriorityParameters(priorityParameters);
        priorityParameters.forEach(priorityParameterDao::update);
        config.getRegionPriorities().forEach(regionDao::updatePriorities);
        config.getChannelPriorities().forEach(creditSaleChannelDao::updatePriority);
        config.getCreditAttractChannelPriorities().forEach(creditAttractChannelDao::updatePriority);

        if (config.getWorkDialInterval() != null && config.getHolidayDialInterval() != null) {
            appConfigFactory.updateWorkDialInterval(config.getWorkDialInterval(), config.getHolidayDialInterval());
        } else {
            throw new BusinessException("PRIORITY_PARAM", "Интервалы дозвона не заданы");
        }

        UpdatePriorityConfig.ProductPriorityPatch productPriorityPatch = config.getProductPriorityPatch();
        if (productPriorityPatch != null) {
            updateProductPriorities(productPriorityPatch);
        }

        mergeAmountIntervals(config.getPriorityAmountIntervals());

        updateSwitch(config);
        notifyConsumer.notifyOnChange();
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateSwitch(PriorityConfig config) {
        if (config.getSwitchTopCount() <= 0) {
            config.setSwitchTopCount(1);
        }
        if (config.getSwitchBottomCount() <= 0) {
            config.setSwitchBottomCount(1);
        }
        if (config.isSwitchableOrder() != this.config.isSwitchableOrder() ||
                config.getSwitchTopCount() != this.config.getSwitchTopCount() ||
                config.getSwitchBottomCount() != this.config.getSwitchBottomCount()) {
            appConfigFactory.updateSwitch(config.isSwitchableOrder(), config.getSwitchTopCount(),
                    config.getSwitchBottomCount());
            if (config.isSwitchableOrder()) {
                switchProvider.reset();
            }
            notifyConsumer.notifyOnChange();
        }
    }

    @Nonnull
    public PagedResult<ProductSortPriorityView> listProductPriority(int offset, int limit, @Nullable String searchString) {
        String queryString = StringUtils.isEmpty(searchString) ? "%" : "%" + searchString + "%";
        List<ProductSortPriorityView> list = productPriorityDao.list(offset, limit, queryString);

        int count = productPriorityDao.count(queryString);
        return new PagedResult<>(offset, count, list);
    }

    private void updateProductPriorities(@Nonnull UpdatePriorityConfig.ProductPriorityPatch productPriorityPatch) {
        if (!productPriorityPatch.getAdded().isEmpty()) {
            productPriorityDao.updatePriority(productPriorityPatch.getAdded(), 1);
        }
        if (!productPriorityPatch.getDeleted().isEmpty()) {
            productPriorityDao.updatePriority(productPriorityPatch.getDeleted(), 0);
        }
    }

    private void mergeAmountIntervals(List<PriorityAmountInterval> intervals) {
        PriorityConfig oldConfig = read();
        CollectionUtils.mergeList(oldConfig.getPriorityAmountIntervals(), intervals, BasicReference::getId,
                priorityAmountInterval -> {
                    priorityAmountIntervalDao.create(priorityAmountInterval);
                    return priorityAmountInterval;
                },
                priorityAmountIntervalDao::delete,
                (oldValue, newValue) -> priorityAmountIntervalDao.update(newValue));
    }

    private void enumeratePriorityParameters(List<PriorityParameter> priorityParameters) {
        short i = 0;
        for (PriorityParameter parameter : priorityParameters) {
            parameter.setOrder(i);
            i++;
        }
    }

    private DialInterval takeWorkDialInterval() {
        return new DialInterval(config.getDialStartTime(), config.getDialEndTime());
    }

    private DialInterval takeHolidayDialInterval() {
        return new DialInterval(config.getHolidayDialStartTime(), config.getHolidayDialEndTime());
    }
}
