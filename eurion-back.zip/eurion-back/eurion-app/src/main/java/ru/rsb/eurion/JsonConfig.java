package ru.rsb.eurion;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.AnnotationIntrospectorPair;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import ru.rsb.eurion.domain.serializer.DurationDeserializer;
import ru.rsb.eurion.domain.serializer.DurationSerializer;

import java.time.Duration;

/**
 * @author sergius on 9/13/18.
 */
@Configuration
public class JsonConfig {

    public static final String QUALIFIER = "inner";
    public static final String QUALIFIER_XML = "inner-xml";

    @Qualifier(QUALIFIER)
    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = Jackson2ObjectMapperBuilder.json()
                .annotationIntrospector(new AnnotationIntrospectorPair(
                        new JaxbAnnotationIntrospector(TypeFactory.defaultInstance()),
                        new JacksonAnnotationIntrospector()
                ))
                .modules(new JavaTimeModule())
                .featuresToEnable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
                .featuresToEnable(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)
                .build();
        // to prevent stripping of BigDecimal, e.g. "100000" -> "1E+5"
        mapper.setNodeFactory(JsonNodeFactory.withExactBigDecimals(true));
        return mapper;
    }

    @Primary
    @Bean
    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    public ObjectMapper primaryObjectMapper(Jackson2ObjectMapperBuilder builder) {
        return builder
                .annotationIntrospector(new AnnotationIntrospectorPair(
                        new JaxbAnnotationIntrospector(TypeFactory.defaultInstance()),
                        new JacksonAnnotationIntrospector()
                ))
                .serializerByType(Duration.class, new DurationSerializer())
                .deserializerByType(Duration.class, new DurationDeserializer())
                .modules(new JavaTimeModule())
                .createXmlMapper(false)
                .build();
    }

    @Bean
    @Qualifier(QUALIFIER_XML)
    public XmlMapper xmlMapper() {
        return Jackson2ObjectMapperBuilder.xml()
                .annotationIntrospector(new AnnotationIntrospectorPair(
                        new JaxbAnnotationIntrospector(TypeFactory.defaultInstance()),
                        new JacksonAnnotationIntrospector()
                ))
                .modules(new SimpleModule().addDeserializer(JsonNode.class,
                        new DuplicateToArrayJsonNodeDeserializer()))
                .build();
    }
}
