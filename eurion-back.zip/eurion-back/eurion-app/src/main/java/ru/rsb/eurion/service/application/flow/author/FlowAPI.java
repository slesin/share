package ru.rsb.eurion.service.application.flow.author;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import javax.annotation.Nonnull;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class FlowAPI {

    static final String APPLICATION_ID = "applicationId";
    /**
     * Логин/Система
     */
    public static final String USER_ID = "userId";
    /**
     * Идентификатор пользователя
     */
    static final String USER_INT_ID = "userIntId";

    public static final String DECISION = "decision";

    static final String DEFAULT_USER_NAME = "SYSTEM";

    public static final String RTDM = "RTDM";

    static final String RETURN_INTO_QUEUE_MESSAGE = "returnIntoQueueMessage";

    static final String DECLINE_REASON_ID = "declineReasonId";

    static final String DECLINE_REASON_IDS = "declineReasonIds";

    static final String DECISION_COMMENT = "decisionComment";

    static final String PROCESS_NAME = "processName";

    static String idToBusinessKey(@Nonnull Long id) {
        return Long.toString(id);
    }
}
