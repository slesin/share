package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.application.StatusCode;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;

import java.time.LocalDateTime;

@Setter
@Getter
public class ProcessStatus {

    private Long id;

    private Long applicationId;

    private String status;

    private ApplicationDecision decision;

    private Integer userId;

    private String userName;

    private StatusCode statusCode;

    private ProcessDefinitionKey processName;

    private LocalDateTime doneAt;

    private String decisionComment;

    private LocalDateTime updatedAt;
}
