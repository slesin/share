package ru.rsb.eurion.security;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.TechUser;

@Mapper
public interface TechUserDao {

    @Select("select ID, LOGIN, PASSWORD_HASH, CREATED_AT, UPDATED_AT from TECH_USER where upper(LOGIN) = upper(#{login})")
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "login", column = "LOGIN"),
            @Result(property = "passwordHash", column = "PASSWORD_HASH"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
    })
    TechUser findByLogin(@Param("login") String login);
}
