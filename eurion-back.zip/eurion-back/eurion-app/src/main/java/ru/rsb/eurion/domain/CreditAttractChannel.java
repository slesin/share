package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreditAttractChannel extends BasicReference {
    private String code;
    private short priority;
    private boolean enabled;
}
