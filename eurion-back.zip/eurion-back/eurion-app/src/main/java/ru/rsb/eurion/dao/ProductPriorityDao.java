package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.priority.ProductSortPriority;
import ru.rsb.eurion.domain.priority.ProductSortPriorityView;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;

import javax.annotation.Nonnull;
import java.util.List;

@Mapper
public interface ProductPriorityDao {

    String BASE_SELECT_SQL = "select p.ID, ct.CARDTYPE_LABEL as NAME, p.SORT_PRIORITY\n" +
            "from PRODUCT_SORT_PRIORITY p\n" +
            "       join CARD_TYPE ct on p.ID = ct.ID_CARDTYPE\n";

    String COUNT_SQL = "select count(*)\n" +
            "from PRODUCT_SORT_PRIORITY p\n" +
            "       join CARD_TYPE ct on p.ID = ct.ID_CARDTYPE\n" +
            "where ct.ACTIV = 1 and ct.CARDTYPE_LABEL like #{searchString}";

    @Select("select ID, SORT_PRIORITY from PRODUCT_SORT_PRIORITY where ID = #{id}")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "SORT_PRIORITY", property = "priority"),
    })
    ProductSortPriority findByCardTypeId(@Param("id") Long cardTypeId);

    @Lang(MybatisExtendedLanguageDriver.class)
    @Update("update PRODUCT_SORT_PRIORITY set SORT_PRIORITY = #{value} where ID in (#{idList})")
    int updatePriority(@Param("idList") List<Integer> idList, @Param("value") int value);

    @Select(BASE_SELECT_SQL + "where ct.ACTIV = 1 and ct.CARDTYPE_LABEL like #{searchString}\n" +
            "order by ct.CARDTYPE_LABEL\n" +
            "offset #{offset} rows fetch first #{limit} rows only")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "NAME", property = "name"),
            @Result(column = "SORT_PRIORITY", property = "priority"),
    })
    List<ProductSortPriorityView> list(@Param("offset") int offset,
                                       @Param("limit") int limit,
                                       @Nonnull @Param("searchString") String searchString);

    @Select(COUNT_SQL)
    int count(String queryString);
}
