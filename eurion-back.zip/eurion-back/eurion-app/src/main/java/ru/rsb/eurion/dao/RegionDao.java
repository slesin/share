package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.Region;

import java.util.List;

@Mapper
public interface RegionDao {

    String BASE_SQL = "select ID, CREATED_AT, UPDATED_AT, NAME, CODE, RAW_OFFSET, APP_SORT_PRIORITY, CLIENT_SORT_PRIORITY " +
            "from REGION r ";

    @Select(BASE_SQL +
            "order by r.NAME")
    @Results(id = "regionMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "rawOffset", column = "RAW_OFFSET"),
            @Result(property = "clientPriority", column = "CLIENT_SORT_PRIORITY"),
            @Result(property = "applicationPriority", column = "APP_SORT_PRIORITY")
    })
    List<Region> listAllRegions();

    @Update("update region " +
            "set APP_SORT_PRIORITY = #{applicationPriority}, " +
            "    CLIENT_SORT_PRIORITY = #{clientPriority}, " +
            "    updated_at = current_timestamp " +
            "where ID = #{id}")
    void updatePriorities(Region regionPriority);

    @Select(BASE_SQL + "where CODE = #{code,jdbcType=VARCHAR}")
    @ResultMap("regionMapping")
    Region findByCode(String regionAppCode);

    @Select("select RAW_OFFSET from REGION where code = #{code}")
    Integer getTimeOffset(@Param("code") String code);
}
