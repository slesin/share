package ru.rsb.eurion.service.admin.users.status;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.flowable.common.engine.api.FlowableOptimisticLockingException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.StatusType;

@Slf4j
@Service
@AllArgsConstructor
public class UserStatusHelper {
    private final OperatorProcessService processService;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void setupStatusAndRole(Integer userId, Role role, StatusType statusType) {
        processService.setupStatusAndRole(userId, role.name(), statusType.name());
    }
}
