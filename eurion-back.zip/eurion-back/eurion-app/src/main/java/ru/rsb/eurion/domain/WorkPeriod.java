package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;


/**
 * Период работы в данной организации
 */
@Getter
@Setter
public class WorkPeriod extends BasicReference {

    private Integer scoringId;

    private boolean active;

    private Integer countryId;

    private Integer codeId;
}
