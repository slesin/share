package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.rtdm.application.RtdmDecisionCode;

import java.time.LocalDateTime;

@Getter
@Setter
public class RtdmDecisionEntity {
    /**
     * Уникальный идентификатор
     */
    private Long id;
    /**
     * Код решения
     */
    protected RtdmDecisionCode decisionCode;

    /**
     * Дата/время принятия решения на стороне RTDM.
     */
    protected LocalDateTime date;

    /**
     * Причина/обосновние принятия данного решения
     */
    protected String cause;

    /**
     * Дата создания
     */
    private LocalDateTime createdAt;
}
