package ru.rsb.eurion.service.agent.comments;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;
import ru.rsb.eurion.list.PagedResult;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping(path = EurionApplication.API_BASE + "/client", produces = MediaType.APPLICATION_JSON_VALUE)
public class ClientResource {

    private final GetAgentCommentServiceClient client;

    @GetMapping("/{clientId}/agent-comments")
    public PagedResult<AgentComment> listAgentComments(@PathVariable("clientId") Long clientId) {
        List<AgentComment> list = client.getAgentComments(clientId, true);
        return new PagedResult<>(0, list.size(), list);
    }
}
