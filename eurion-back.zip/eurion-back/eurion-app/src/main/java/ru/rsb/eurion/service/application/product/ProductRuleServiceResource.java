package ru.rsb.eurion.service.application.product;


import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;
import ru.rsb.eurion.service.admin.Consts;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class ProductRuleServiceResource {

    private final ProductRuleService productRuleService;

    @GetMapping(path = EurionApplication.API_BASE + "/product-rule/type/list")
    public List<ProductType> getProductType() {
        return productRuleService.productTypeList();
    }

    @GetMapping(path = EurionApplication.API_BASE + "/product-rule/list")
    public SkillGroupProductView getProductRule() {
        return productRuleService.getProductRuleView();
    }

    @PostMapping(path = Consts.ADMIN_API_BASE + "/product-rule/update")
    public SkillGroupProductView updateProductRule(@NotNull @Valid @RequestBody SkillGroupProductView view) {
        productRuleService.update(view);
        return productRuleService.getProductRuleView();
    }
}
