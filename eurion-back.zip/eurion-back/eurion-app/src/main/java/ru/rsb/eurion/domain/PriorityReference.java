package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Справочник приоритетов
 */
@Getter
@Setter
public class PriorityReference {
    /**
     * Приоритеты
     */
    public List<PriorityRule> rules;

    /**
     * Правила приоритизации
     */
    @Getter
    @Setter
    public static class PriorityRule {
        /**
         * Наименование правила
         */
        private String name;
    }
}
