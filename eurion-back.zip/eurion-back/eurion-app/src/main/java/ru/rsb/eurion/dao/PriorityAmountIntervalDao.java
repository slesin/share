package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.PriorityAmountInterval;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

@Mapper
public interface PriorityAmountIntervalDao {

    String UPDATE_SQL = "update PRIORITY_AMOUNT_INTERVAL " +
            "set NAME          = #{name}, " +
            "    BEGIN_AMOUNT  = #{beginAmount}, " +
            "    END_AMOUNT    = #{endAmount}, " +
            "    SORT_PRIORITY = #{priority}, " +
            "    UPDATED_AT    = current_timestamp " +
            "where ID = #{id}";
    String BASE_SELECT_SQL = "select ID, CREATED_AT, UPDATED_AT, NAME, BEGIN_AMOUNT, END_AMOUNT, SORT_PRIORITY\n" +
            "from PRIORITY_AMOUNT_INTERVAL";

    @Insert("insert into PRIORITY_AMOUNT_INTERVAL(NAME, BEGIN_AMOUNT, END_AMOUNT) " +
            "values (#{name}, #{beginAmount}, #{endAmount})")
    void create(@NotNull PriorityAmountInterval priorityAmountInterval);

    @Delete("delete from PRIORITY_AMOUNT_INTERVAL where ID = #{id}")
    void delete(@NotNull PriorityAmountInterval priorityAmountInterval);

    @Update(UPDATE_SQL)
    void update(@NotNull PriorityAmountInterval priorityAmountInterval);

    @Nullable
    @Select(BASE_SELECT_SQL + " where #{amount} > BEGIN_AMOUNT and #{amount} <= END_AMOUNT")
    @Results(id = "priorityAmountIntervalMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "beginAmount", column = "BEGIN_AMOUNT"),
            @Result(property = "endAmount", column = "END_AMOUNT"),
            @Result(property = "priority", column = "SORT_PRIORITY")
    })
    PriorityAmountInterval findByValue(@Param("amount") BigDecimal creditAmount);

    @Select(BASE_SELECT_SQL)
    @ResultMap("priorityAmountIntervalMapping")
    List<PriorityAmountInterval> findAll();

}
