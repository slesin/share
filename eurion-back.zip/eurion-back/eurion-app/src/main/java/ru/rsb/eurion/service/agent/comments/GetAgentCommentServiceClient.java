package ru.rsb.eurion.service.agent.comments;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.service.admin.users.upd.BaseEisClient;
import ru.rsb.eurion.settings.EisConfig;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Component
@AllArgsConstructor
public class GetAgentCommentServiceClient extends BaseEisClient {
    private EisConfig config;

    public List<AgentComment> getAgentComments(@Nonnull Long clientId, boolean fullHistory) {
        HashMap<String, String> parameters = new HashMap<>();
        parameters.put("clientId", String.valueOf(clientId));
        if (fullHistory) {
            parameters.put("fullHistory", String.valueOf(1));
        }

        AgentComment[] array = executeGet(AgentComment[].class,
                config.getEisGetAgentCommentsServiceUrl(), parameters);
        return Arrays.asList(array);
    }
}
