package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.RtdmPriority;

import javax.annotation.Nonnull;

@Mapper
public interface RtdmPriorityDao {

    String SQL = "select ID, CREATED_AT, UPDATED_AT, NAME, IS_NEED_NOTIFICATION, IS_WARNING " +
            "from RTDM_PRIORITY where ID = #{id,jdbcType=INTEGER}";

    @Select(SQL)
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "needNotification", column = "IS_NEED_NOTIFICATION"),
            @Result(property = "warning", column = "IS_WARNING"),
    })
    RtdmPriority findById(@Nonnull @Param("id") Integer id);
}
