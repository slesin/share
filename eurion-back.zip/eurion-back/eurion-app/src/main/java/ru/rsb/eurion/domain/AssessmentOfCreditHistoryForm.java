package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Форма оценка кредитной истории
 */
@Getter
@Setter
public class AssessmentOfCreditHistoryForm extends BasicForm {
    /**
     * Данные из АСКИЗ (todo ссылка?)
     */
    private String askizData;
    /**
     * Активы клиента (заявка)
     */
    private List<Asset> applicationAssets;
    /**
     * Дополнительные активы клиента
     */
    private List<Asset> additionalAssets;

}
