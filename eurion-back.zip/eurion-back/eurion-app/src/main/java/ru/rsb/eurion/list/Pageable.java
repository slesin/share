package ru.rsb.eurion.list;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public abstract class Pageable<T extends Enum> {
    private static final int DEFAULT_LIMIT = 10;
    private static final int MAX_LIMIT = 100;

    private int offset;
    private int limit;
    private List<T> sortBy;
    private List<SortDirection> sortDir;

    public int getLimit() {
        return limit > 0 ? limit : DEFAULT_LIMIT;
    }

    @Nonnull
    public List<T> getSortBy() {
        if (sortBy == null) {
            sortBy = new ArrayList<>();
        }
        return sortBy;
    }

    @Nonnull
    public List<SortDirection> getSortDir() {
        if (sortDir == null) {
            sortDir = new ArrayList<>();
        }
        return sortDir;
    }
}
