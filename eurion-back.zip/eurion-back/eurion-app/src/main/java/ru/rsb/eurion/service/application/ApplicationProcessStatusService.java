package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.ApplicationProcessStatusDao;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.ProcessStatus;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;

import java.time.LocalDateTime;

@Slf4j
@AllArgsConstructor
@Service
@Transactional
public class ApplicationProcessStatusService {

    private final ApplicationProcessStatusDao dao;

    private void updateStatus(ProcessStatus processStatus) {
        dao.update(processStatus);
    }

    public ProcessStatus getStatus(Long applicationId) {
        return dao.getStatus(applicationId);
    }

    public void create(ProcessStatus processStatus) {
        dao.create(processStatus);
    }

    public void updateStatus(Long applicationId, String status, StatusCode statusCode, String userName,
                             ApplicationDecision decision, LocalDateTime doneAt, ProcessDefinitionKey processName,
                             String decisionComment, Integer userId) {

        ProcessStatus existStatus = getStatus(applicationId);

        LocalDateTime updatedAt = LocalDateTime.now();

        if (existStatus != null) {
            existStatus.setStatus(status);
            existStatus.setStatusCode(statusCode);
            existStatus.setUserName(userName);
            existStatus.setUserId(userId);
            existStatus.setDecision(decision);
            existStatus.setProcessName(processName);
            existStatus.setDoneAt(doneAt);
            existStatus.setDecisionComment(decisionComment);
            existStatus.setUpdatedAt(updatedAt);
            updateStatus(existStatus);
        } else {
            ProcessStatus processStatus = new ProcessStatus();
            processStatus.setApplicationId(applicationId);
            processStatus.setStatus(status);
            processStatus.setStatusCode(statusCode);
            processStatus.setDecision(decision);
            processStatus.setProcessName(processName);
            processStatus.setUserId(userId);
            processStatus.setDoneAt(doneAt);
            processStatus.setUpdatedAt(updatedAt);
            create(processStatus);
        }
    }
}
