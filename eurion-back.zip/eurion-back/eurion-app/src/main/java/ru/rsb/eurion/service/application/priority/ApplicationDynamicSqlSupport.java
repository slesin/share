package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;
import ru.rsb.eurion.rtdm.application.CreditType;
import ru.rsb.eurion.service.application.StatusCode;

import java.math.BigDecimal;
import java.sql.JDBCType;
import java.time.LocalDate;
import java.time.LocalDateTime;

public final class ApplicationDynamicSqlSupport {
    public static final ApplicationTable APPLICATION = new ApplicationTable();

    public static final SqlColumn<Long> ID = APPLICATION.column("ID", JDBCType.BIGINT);
    public static final SqlColumn<Integer> CLIENT_ID = APPLICATION.column("CLIENT_ID", JDBCType.INTEGER);
    public static final SqlColumn<Integer> RTDM_ID = APPLICATION.column("RTDM_ID", JDBCType.INTEGER);
    public static final SqlColumn<String> LAST_NAME = APPLICATION.column("LAST_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<String> FIRST_NAME = APPLICATION.column("FIRST_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<String> MIDDLE_NAME = APPLICATION.column("MIDDLE_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<LocalDateTime> CREATED_AT = APPLICATION.column("CREATED_AT", JDBCType.TIMESTAMP);
    public static final SqlColumn<LocalDateTime> UPDATED_AT = APPLICATION.column("UPDATED_AT", JDBCType.TIMESTAMP);
    public static final SqlColumn<String> STATUS = APPLICATION.column("STATUS", JDBCType.VARCHAR);
    public static final SqlColumn<LocalDateTime> DONE_AT = APPLICATION.column("DONE_AT", JDBCType.TIMESTAMP);
    public static final SqlColumn<Integer> BLANK_ID = APPLICATION.column("BLANK_ID", JDBCType.INTEGER);
    public static final SqlColumn<LocalDate> BIRTH_DATE = APPLICATION.column("BIRTH_DATE", JDBCType.DATE);
    public static final SqlColumn<BigDecimal> CREDIT_AMOUNT = APPLICATION.column("CREDIT_AMOUNT", JDBCType.NUMERIC);
    public static final SqlColumn<BigDecimal> REQUESTED_CREDIT_AMOUNT = APPLICATION.column("REQUESTED_CREDIT_AMOUNT", JDBCType.NUMERIC);
    public static final SqlColumn<String> SHORT_CLIENT_REGION_CODE = APPLICATION.column("SHORT_CLIENT_REGION_CODE", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> SKILL_GROUP_ID = APPLICATION.column("SKILL_GROUP_ID", JDBCType.INTEGER);
    public static final SqlColumn<LocalDateTime> STATUS_UPDATED_AT = APPLICATION.column("STATUS_UPDATED_AT", JDBCType.TIMESTAMP);
    public static final SqlColumn<String> PASSPORT_NUMBER = APPLICATION.column("PASSPORT_NUMBER", JDBCType.VARCHAR);
    public static final SqlColumn<String> PASSPORT_SERIES = APPLICATION.column("PASSPORT_SERIES", JDBCType.VARCHAR);
    public static final SqlColumn<String> PRODUCT_TYPE = APPLICATION.column("PRODUCT_TYPE", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> CREDIT_SALE_CHANNEL_ID = APPLICATION.column("CREDIT_SALE_CHANNEL_ID", JDBCType.INTEGER);
    public static final SqlColumn<String> APPLICATION_REGION_CODE = APPLICATION.column("APPLICATION_REGION_CODE", JDBCType.VARCHAR);
    public static final SqlColumn<String> MOBILE_PHONE = APPLICATION.column("MOBILE_PHONE", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> BRANCH_ID = APPLICATION.column("BRANCH_ID", JDBCType.INTEGER);
    public static final SqlColumn<Integer> LAST_USER_ID = APPLICATION.column("LAST_USER_ID", JDBCType.INTEGER);
    public static final SqlColumn<Integer> USER_ID = APPLICATION.column("USER_ID", JDBCType.INTEGER);
    public static final SqlColumn<String> FORM_DEFINITIONS = APPLICATION.column("FORM_DEFINITIONS", JDBCType.VARCHAR);
    public static final SqlColumn<String> FORM_CONCLUSIONS = APPLICATION.column("FORM_CONCLUSIONS", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> CREDIT_ATTRACTION_CHANNEL_ID = APPLICATION.column("CREDIT_ATTRACTION_CHANNEL_ID", JDBCType.INTEGER);
    public static final SqlColumn<StatusCode> STATUS_CODE = APPLICATION.column("STATUS_CATEGORY_CODE", JDBCType.VARCHAR);
    public static final SqlColumn<LocalDate> SUSPEND_TIME = APPLICATION.column("SUSPEND_TIME", JDBCType.TIMESTAMP);
    public static final SqlColumn<String> ASSIGN_BY_SUPERVISOR = APPLICATION.column("ASSIGN_BY_SUPERVISOR", JDBCType.VARCHAR);
    public static final SqlColumn<String> CHECK_TYPE = APPLICATION.column("CHECK_TYPE", JDBCType.VARCHAR);
    public static final SqlColumn<String> REQUESTED_BRANCH_NAME = APPLICATION.column("REQUESTED_BRANCH_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<String> BRANCH_NAME = APPLICATION.column("BRANCH_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<String> CLIENT_REGION = APPLICATION.column("CLIENT_REGION", JDBCType.VARCHAR);
    public static final SqlColumn<CreditType> CREDIT_TYPE = APPLICATION.column("CREDIT_TYPE", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> RTDM_PRIORITY = APPLICATION.column("RTDM_PRIORITY", JDBCType.INTEGER);
    public static final SqlColumn<String> AUTHOR_FULL_NAME = APPLICATION.column("AUTHOR_FULL_NAME", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> SUPERVISOR_PRIORITY = APPLICATION.column("SUPERVISOR_PRIORITY", JDBCType.BOOLEAN);
    public static final SqlColumn<Integer> IS_NOVEL = APPLICATION.column("IS_NOVEL", JDBCType.INTEGER);
    public static final SqlColumn<Boolean> IS_SUSPENSIVE_TERMS = APPLICATION.column("IS_SUSPENSIVE_TERMS", JDBCType.BOOLEAN);
    public static final SqlColumn<Boolean> IS_OUT_OF_DIAL_TIME = APPLICATION.column("IS_OUT_OF_DIAL_TIME", JDBCType.BOOLEAN);
    public static final SqlColumn<Boolean> REGION_APP_PRIORITY = APPLICATION.column("REGION_APP_PRIORITY", JDBCType.INTEGER);
    public static final SqlColumn<Boolean> PRODUCT_PRIORITY = APPLICATION.column("PRODUCT_PRIORITY", JDBCType.INTEGER);
    public static final SqlColumn<Boolean> IS_FRAUD_RETURN = APPLICATION.column("IS_FRAUD_RETURN", JDBCType.INTEGER);
    public static final SqlColumn<Boolean> AMOUNT_PRIORITY = APPLICATION.column("AMOUNT_PRIORITY", JDBCType.INTEGER);
    public static final SqlColumn<Boolean> CHANNEL_PRIORITY = APPLICATION.column("CHANNEL_PRIORITY", JDBCType.INTEGER);
    public static final SqlColumn<Boolean> ATTRACT_CHANNEL_PRIORITY = APPLICATION.column("ATTRACT_CHANNEL_PRIORITY", JDBCType.INTEGER);
    public static final SqlColumn<Boolean> POSTPONE_COMMENT = APPLICATION.column("POSTPONE_COMMENT", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> AUTHOR_ID = APPLICATION.column("AUTHOR_ID", JDBCType.INTEGER);

    private static final class ApplicationTable extends SqlTable {
        ApplicationTable() {
            super("APPLICATION");
        }
    }
}
