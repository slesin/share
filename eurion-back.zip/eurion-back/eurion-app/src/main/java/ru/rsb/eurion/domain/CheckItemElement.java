package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import org.javers.core.metamodel.annotation.DiffIgnore;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CheckItemElement {
    /**
     * Уникальный идентификатор
     */
    @DiffIgnore
    private Integer id;

    /**
     * Наименование
     */
    private String name;

    /**
     * Дата создания
     */
    @DiffIgnore
    private LocalDateTime createdAt;

    /**
     * Дата редактирования
     */
    @DiffIgnore
    private LocalDateTime updatedAt;

    /**
     * Дата деактивации
     */
    @DiffIgnore
    private LocalDateTime disabledAt;

    private CheckItemType checkItemType;
    private List<CheckItemValue> itemValueList;

    public boolean isDisabled() {
        return disabledAt != null;
    }

    public List<CheckItemValue> getItemValueList() {
        if (itemValueList == null) {
            itemValueList = new ArrayList<>();
        }
        return itemValueList;
    }
}
