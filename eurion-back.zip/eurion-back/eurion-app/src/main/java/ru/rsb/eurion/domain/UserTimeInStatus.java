package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.Duration;

@Getter
@Setter
public class UserTimeInStatus {

    private Integer userId;

    private String statusName;

    private StatusType statusCode;

    private String fullName;

    private Duration timeInStatus;
}