package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.Country;

import java.util.List;

@Mapper
public interface CountryDao {

    @Select("select " +
            "  IND, " +
            "  NAME, " +
            "  COUNTRY, " +
            "  DATECHANGE, " +
            "  ACTIV, " +
            "  ISO3166, " +
            "  IDCOUNTRY " +
            "from COUNTRY")
    @Results(id = "countryMapping", value = {
            @Result(property = "id", column = "IND"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "countryCode", column = "COUNTRY"),
            @Result(property = "updatedAt", column = "DATECHANGE"),
            @Result(property = "active", column = "ACTIV"),
            @Result(property = "isoCode", column = "ISO3166")
    })
    List<Country> findAll();

    @Select("select " +
            "  IND, " +
            "  NAME, " +
            "  COUNTRY, " +
            "  DATECHANGE, " +
            "  ACTIV, " +
            "  ISO3166, " +
            "  IDCOUNTRY " +
            "from COUNTRY " +
            "where IND = #{id}")
    @ResultMap("countryMapping")
    Country findById(Integer id);
}

