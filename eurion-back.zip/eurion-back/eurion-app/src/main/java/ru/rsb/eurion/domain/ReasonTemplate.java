package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReasonTemplate extends BasicReference {

    private String template;

    private Integer reasonId;

    private Integer categoryId;

}