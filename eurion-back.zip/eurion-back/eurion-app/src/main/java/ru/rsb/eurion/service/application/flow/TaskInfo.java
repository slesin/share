package ru.rsb.eurion.service.application.flow;

import lombok.Getter;
import lombok.Setter;
import org.flowable.task.api.Task;
import ru.rsb.eurion.domain.FormData;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
public class TaskInfo {
    private String taskId;
    private String name;
    private String description;
    private String taskDefinitionKey;
    private FormData formData;

    public static TaskInfo of(Task task) {
        TaskInfo taskInfo = new TaskInfo();
        taskInfo.setTaskId(task.getId());
        taskInfo.setName(task.getName());
        taskInfo.setDescription(task.getDescription());
        taskInfo.setTaskDefinitionKey(task.getTaskDefinitionKey());
        return taskInfo;
    }
}
