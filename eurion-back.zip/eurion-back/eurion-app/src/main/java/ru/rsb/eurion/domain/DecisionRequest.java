package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class DecisionRequest {
    private String comment;
    private Set<Integer> declineIds;
}
