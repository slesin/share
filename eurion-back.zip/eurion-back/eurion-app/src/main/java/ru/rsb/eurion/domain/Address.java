package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Адрес
 */
@Getter
@Setter
public class Address {
    // todo Адрес из КЛАДР

}
