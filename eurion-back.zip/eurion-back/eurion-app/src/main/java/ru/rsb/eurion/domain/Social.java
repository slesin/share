package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Ссылка на социальную сеть
 */
@Getter
@Setter
public class Social extends BasicReference {
}
