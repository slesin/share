package ru.rsb.eurion.service.admin.skill.group;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.dao.DurationTypeHandler;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.DeclineCategory;
import ru.rsb.eurion.domain.DeclineReason;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;
import ru.rsb.eurion.service.application.statistics.ApplicationInfoBySkill;

import javax.annotation.Nullable;
import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface SkillGroupDao {

    String BASE_SELECT_SQL = "select" +
            " ID,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT,\n" +
            "       NAME,\n" +
            "       STAGE_SLA,\n" +
            "       EMPLOYEE_SLA,\n" +
            "       IS_ENABLED,\n" +
            "       CHECK_TYPE,\n" +
            "       ROLE_ID,\n" +
            "       SORT_PRIORITY,\n" +
            "       IS_RECOUNT\n" +
            "from SKILL_GROUP ";

    @Select(BASE_SELECT_SQL + "order BY ID")
    @Results(id = "skillGroupMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "stageSla", column = "stage_sla", typeHandler = DurationTypeHandler.class),
            @Result(property = "employeeSla", column = "employee_sla", typeHandler = DurationTypeHandler.class),
            @Result(property = "enabled", column = "is_enabled"),
            @Result(property = "priority", column = "sort_priority"),
            @Result(property = "checkType", column = "check_type"),
            @Result(property = "roleId", column = "role_id"),
            @Result(property = "isRecount", column = "is_recount"),
    })
    List<SkillGroup> listAll();

    @Select("SELECT * FROM SKILL_GROUP WHERE ID = #{id, jdbcType=INTEGER}")
    @ResultMap("skillGroupMapping")
    @Nullable
    SkillGroup findById(Integer skillGroupId);

    @Select("SELECT decode(count(GROUP_ID), 0, 0, 1)\n" +
            "FROM APP_USER_SKILL_GROUP\n" +
            "WHERE USER_ID = #{userId} AND GROUP_ID = #{groupId}")
    boolean hasUserSkillGroup(@Param("userId") Integer userId, @Param("groupId") Integer groupId);

    @Insert("INSERT INTO APP_USER_SKILL_GROUP (USER_ID, GROUP_ID) VALUES (#{userId}, #{groupId})")
    void assignSkillGroupToUser(@Param("userId") Integer userId, @Param("groupId") Integer groupId);

    @Delete("DELETE FROM APP_USER_SKILL_GROUP WHERE USER_ID = #{userId} AND GROUP_ID = #{groupId}")
    void deAssignSkillGroupToUser(@Param("userId") Integer userId, @Param("groupId") Integer groupId);

    @Insert("INSERT INTO SKILL_GROUP\n" +
            "(CREATED_AT,\n" +
            " UPDATED_AT,\n" +
            " NAME,\n" +
            " STAGE_SLA,\n" +
            " EMPLOYEE_SLA,\n" +
            " IS_ENABLED,\n" +
            " SORT_PRIORITY,\n" +
            " CHECK_TYPE,\n" +
            " ROLE_ID,\n" +
            " IS_RECOUNT)\n" +
            "VALUES (#{skillGroup.createdAt,jdbcType=TIMESTAMP},\n" +
            "        #{skillGroup.updatedAt,jdbcType=TIMESTAMP},\n" +
            "        #{skillGroup.name,jdbcType=VARCHAR},\n" +
            "        #{skillGroup.stageSla},\n" +
            "        #{skillGroup.employeeSla},\n" +
            "        1,\n" +
            "        #{skillGroup.priority,jdbcType=INTEGER},\n" +
            "        #{skillGroup.checkType},\n" +
            "        #{skillGroup.roleId,jdbcType=INTEGER},\n" +
            "        #{skillGroup.isRecount,jdbcType=BOOLEAN})")
    @SelectKey(
            keyProperty = "skillGroup.id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_skill_group.currval AS id from dual"}
    )
    @Options(useGeneratedKeys = true, keyProperty = "skillGroup.id", keyColumn = "id")
    void createSkillGroup(@Param("skillGroup") SkillGroup skillGroup);

    @Update("UPDATE SKILL_GROUP\n" +
            "SET NAME          = #{skillGroup.name},\n" +
            "    STAGE_SLA     = #{skillGroup.stageSla},\n" +
            "    EMPLOYEE_SLA  = #{skillGroup.employeeSla},\n" +
            "    CHECK_TYPE    = #{skillGroup.checkType},\n" +
            "    UPDATED_AT    = #{skillGroup.updatedAt,jdbcType=TIMESTAMP},\n" +
            "    ROLE_ID       = #{skillGroup.roleId,jdbcType=INTEGER},\n" +
            "    SORT_PRIORITY = #{skillGroup.priority,jdbcType=INTEGER},\n" +
            "    IS_RECOUNT    = #{skillGroup.isRecount,jdbcType=BOOLEAN}\n" +
            "WHERE ID = #{skillGroup.id}")
    void updateSkillGroup(@Param("skillGroup") SkillGroup skillGroup);

    @Update("UPDATE SKILL_GROUP\n" +
            "SET UPDATED_AT  = #{updatedAt, jdbcType=TIMESTAMP}, \n" +
            "    IS_ENABLED  = 0 " +
            "    WHERE ID IN (#{skillGroupIds})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void deactivateSkillGroups(@Param("skillGroupIds") List<Integer> skillGroupIds, @Param("updatedAt") LocalDateTime updatedAt);

    @Update("UPDATE SKILL_GROUP\n" +
            "SET UPDATED_AT  = #{updatedAt, jdbcType=TIMESTAMP}, \n" +
            "    IS_ENABLED  = 1 " +
            "    WHERE ID IN (#{skillGroupIds})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void activateSkillGroups(@Param("skillGroupIds") List<Integer> skillGroupIds, @Param("updatedAt") LocalDateTime updatedAt);

    @Select(BASE_SELECT_SQL + " WHERE CHECK_TYPE = #{checkType, jdbcType=VARCHAR} ORDER BY id FETCH FIRST ROW ONLY")
    @ResultMap("skillGroupMapping")
    SkillGroup getFirstGroupByCheckType(@Param("checkType") CheckType checkType);

    @Select("SELECT count(*)                                 AS AMOUNT,\n" +
            "       skg.ROLE_ID                              AS SKILL_GROUP_ROLE_ID,\n" +
            "       skg.ID                                   AS SKILL_GROUP_ID,\n" +
            "       skg.NAME                                 AS SKILL_GROUP_NAME,\n" +
            "       sgr.NAME                                 AS SKILL_GROUP_ROLE_NAME,\n" +
            "       decode(app.STATUS,\n" +
            "              'Назначено', 'ASSIGNED',\n" +
            "              'В очереди', 'IN_QUEUE',\n" +
            "              'В работе', 'IN_WORK',\n" +
            "              'Отложено', 'POSTPONED',\n" +
            "              'Пересчет', 'IN_WORK', 'UNKNOWN') AS STATUS,\n" +
            "       decode(app.CREDIT_TYPE,\n" +
            "              'PIL', 'PIL',\n" +
            "              'POS', 'POS',\n" +
            "              'DIRECT_SALE', 'DS',\n" +
            "              'CROSS_SALE', 'DS',\n" +
            "              'ZAYAVKA', 'DS', 'UNKNOWN')       AS CREDIT_TYPE\n" +
            "FROM SKILL_GROUP skg\n" +
            "       JOIN APPLICATION app ON skg.ID = app.SKILL_GROUP_ID\n" +
            "       JOIN SKILL_GROUP_ROLE sgr ON skg.ROLE_ID = sgr.ID\n" +
            "WHERE DONE_AT IS NULL\n" +
            "  AND STATUS IN ('В работе', 'В очереди', 'Назначено', 'Отложено', 'Пересчет')\n" +
            "GROUP BY skg.ROLE_ID, skg.ID, skg.NAME, sgr.NAME, STATUS, app.CREDIT_TYPE\n" +
            "ORDER BY SKILL_GROUP_ROLE_ID")
    @Results({
            @Result(property = "skillGroupRoleId", column = "SKILL_GROUP_ROLE_ID"),
            @Result(property = "skillGroupRoleName", column = "SKILL_GROUP_ROLE_NAME"),
            @Result(property = "skillGroupId", column = "SKILL_GROUP_ID"),
            @Result(property = "skillGroupName", column = "SKILL_GROUP_NAME"),
            @Result(property = "status", column = "STATUS"),
            @Result(property = "creditType", column = "CREDIT_TYPE")

    })
    List<ApplicationInfoBySkill> getApplicationInfoBySkill();

    @Select("select ID\n" +
            "from SKILL_GROUP\n" +
            "where ID = #{skillGroupId, jdbcType = INTEGER}")
    @SuppressWarnings("unused")
    @Results({
            @Result(property = "skillGroupId", column = "ID"),
            @Result(property = "declineCategories", column = "ID",
                    many = @Many(select = "getDeclineCategoryList", fetchType = FetchType.EAGER))
    })
    SkillGroupDeclineCategory getSkillGroupCategory(@Param("skillGroupId") Integer skillGroupId);

    /**
     * Used by {@link #getSkillGroupCategory(Integer skillGroupId)}
     */
    @Select("select dc.ID,\n" +
            "       dc.CREATED_AT,\n" +
            "       dc.UPDATED_AT,\n" +
            "       dc.CODE,\n" +
            "       dc.NAME,\n" +
            "       sgdc.SKILL_GROUP_ID\n" +
            "from SKILL_GROUP_DECLINE_CATEGORY sgdc\n" +
            "       left join DECLINE_CATEGORY  dc  ON dc.ID = sgdc.DECLINE_CATEGORY_ID\n" +
            "where sgdc.SKILL_GROUP_ID = #{skillGroupId, jdbcType = INTEGER} \n" +
            "order by dc.ORDER_NUMBER")
    @Results(value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "declineReasons", many = @Many(select = "getDeclineReasons", fetchType = FetchType.EAGER),
                    column = "{skillGroupId=SKILL_GROUP_ID, declineCategoryId=ID}")
    })
    @SuppressWarnings("unused")
    List<DeclineCategory> getDeclineCategoryList(@Param("skillGroupId") Integer skillGroupId);

    /**
     * Used by {@link #getDeclineCategoryList(Integer skillGroupId)}
     */
    @Select("select dr.ID,\n" +
            "       dr.CREATED_AT,\n" +
            "       dr.UPDATED_AT,\n" +
            "       dr.CODE,\n" +
            "       dr.NAME,\n" +
            "       dr.TIMEOUT\n" +
            "from SKILL_GROUP_DECLINE_REASON sr\n" +
            "       left join DECLINE_REASON dr ON sr.DECLINE_REASON_ID = dr.ID\n" +
            "where sr.SKILL_GROUP_ID = #{skillGroupId, jdbcType=INTEGER} and DECLINE_CATEGORY_ID= #{declineCategoryId, jdbcType=INTEGER}\n" +
            "order by dr.ORDER_NUMBER")
    @Results(id = "DeclineReasonMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "timeout", column = "TIMEOUT")
    })
    @SuppressWarnings("unused")
    List<DeclineReason> getDeclineReasons(@Param("skillGroupId") Integer skillGroupId, @Param("declineCategoryId") Integer declineCategoryId);

    @Insert("insert into SKILL_GROUP_DECLINE_CATEGORY (SKILL_GROUP_ID, DECLINE_CATEGORY_ID)\n" +
            "values (#{skillGroupId, jdbcType = INTEGER}, #{categoryId, jdbcType = INTEGER})")
    void addDeclineCategoryToSkillGroup(@Param("skillGroupId") Integer skillGroupId, @Param("categoryId") Integer categoryId);

    @Delete("delete\n" +
            "from SKILL_GROUP_DECLINE_CATEGORY\n" +
            "where SKILL_GROUP_ID = #{skillGroupId, jdbcType = INTEGER} and DECLINE_CATEGORY_ID = #{categoryId, jdbcType = INTEGER}")
    void deleteDeclineCategoryFromSkillGroup(@Param("skillGroupId") Integer skillGroupId, @Param("categoryId") Integer categoryId);

    @Insert("insert into SKILL_GROUP_DECLINE_REASON (SKILL_GROUP_ID, DECLINE_REASON_ID)\n" +
            "values (#{skillGroupId, jdbcType = INTEGER}, #{reasonId, jdbcType = INTEGER})")
    void addReasonToSkillGroup(@Param("skillGroupId") Integer skillGroupId, @Param("reasonId") Integer reasonId);

    @Delete("delete\n" +
            "from SKILL_GROUP_DECLINE_REASON\n" +
            "where SKILL_GROUP_ID = #{skillGroupId, jdbcType = INTEGER} and DECLINE_REASON_ID = #{reasonId, jdbcType = INTEGER}")
    void deleteDeclineReasonFromSkillGroup(@Param("skillGroupId") Integer skillGroupId, @Param("reasonId") Integer reasonId);

    @Delete("delete from SKILL_GROUP_DECLINE_REASON sgdr\n" +
            "where EXISTS (\n" +
            "        select\n" +
            "               SKILL_GROUP_ID,\n" +
            "               DECLINE_REASON_ID\n" +
            "        from SKILL_GROUP_DECLINE_REASON sr\n" +
            "               left join DECLINE_REASON dr ON sr.DECLINE_REASON_ID = dr.ID\n" +
            "        where sgdr.SKILL_GROUP_ID = sr.SKILL_GROUP_ID and\n" +
            "              sgdr.DECLINE_REASON_ID = sr.DECLINE_REASON_ID and\n" +
            "              sr.SKILL_GROUP_ID  = #{skillGroupId, jdbcType = INTEGER} and dr.DECLINE_CATEGORY_ID = #{categoryId, jdbcType = INTEGER})")
    void deleteDeclineReasonFromSkillGroupByCategory(@Param("skillGroupId") Integer skillGroupId, @Param("categoryId") Integer categoryId);

    @Select("select ID,\n" +
            "       NAME,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT\n" +
            "from SKILL_GROUP\n" +
            "where IS_ENABLED = 1\n" +
            "order by NAME")
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT")
    })
    List<BasicReference> findRefAll();
}
