package ru.rsb.eurion.service.application.history;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.service.application.ApplicationResource;
import ru.rsb.eurion.service.application.history.CheckConclusionHistoryService.CheckHistoryPageable;

import javax.annotation.Nonnull;

import static ru.rsb.eurion.domain.CheckConclusionHistory.DecisionMaker;

@RequestMapping(path = ApplicationResource.APPLICATION_PATH, produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class CheckConclusionHistoryResource {
    private final CheckConclusionHistoryService service;

    @GetMapping(path = "/{applicationId}/check-conclusion-history")
    public PagedResult<CheckConclusionHistoryView> listPage(@Nonnull CheckHistoryPageable pageable,
                                                            @Nonnull @PathVariable("applicationId") Long applicationId) {
        return service.listPage(applicationId, pageable);
    }

    @GetMapping(path = "/check-conclusion-history")
    public PagedResult<CheckConclusionHistoryViewExt> listUnderwriterComments(
            @Nonnull CheckHistoryPageable pageable,
            @Nonnull @RequestParam("clientId") Integer clientId,
            @Nonnull @RequestParam("decisionMaker") DecisionMaker decisionMaker) {
        return service.listCommentsByDecisionMaker(clientId, pageable, decisionMaker);
    }

}
