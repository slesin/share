package ru.rsb.eurion.list;

import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;

import javax.annotation.Nonnull;
import java.util.Map;

public class PageableSelectStatementProvider implements SelectStatementProvider {
    private final SelectStatementProvider delegate;
    private final Pageable pageable;

    public PageableSelectStatementProvider(@Nonnull SelectStatementProvider delegate, @Nonnull Pageable pageable) {
        this.delegate = delegate;
        this.pageable = pageable;
    }

    @Override
    public Map<String, Object> getParameters() {
        return delegate.getParameters();
    }

    @Override
    public String getSelectStatement() {
        String pagingClause = String.format(" offset %d rows fetch first %d rows only",
                pageable.getOffset(), pageable.getLimit());
        return delegate.getSelectStatement() + pagingClause;
    }
}
