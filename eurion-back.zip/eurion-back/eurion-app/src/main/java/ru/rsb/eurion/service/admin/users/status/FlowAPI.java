package ru.rsb.eurion.service.admin.users.status;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
final class FlowAPI {
    static final String DEFINITION_KEY = ProcessDefinitionKey.OPERATOR.getValue();
    static final String USER_ID = "userId";
    static final String SESSION_ID = "sessionId";
    static final String LOGOUT_MESSAGE = "logoutMessage";
    static final String STATUS = "status";
    static final String ROLE = "role";

    static String idToBusinessKey(Integer userId) {
        return "" + userId;
    }
}
