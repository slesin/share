package ru.rsb.eurion.service.admin.users;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserDomain;
import ru.rsb.eurion.security.ActiveDirectory;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.security.NotFoundInADException;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.CollectionUtils;
import ru.rsb.eurion.service.admin.skill.group.SkillGroupService;
import ru.rsb.eurion.service.admin.users.history.UserHistoryService;
import ru.rsb.eurion.service.application.NotFoundException;
import ru.rsb.eurion.settings.AppConfig;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static ru.rsb.eurion.domain.PrimaryPhoneType.INNER_PHONE_NUMBER;
import static ru.rsb.eurion.service.DaoHelper.execWithSQLCheck;
import static ru.rsb.eurion.service.admin.users.subdivision.SubdivisionService.NON_STATISTICS_SUBDIVISION_ID;

/**
 * @author sergius on 9/13/18.
 */
@Service
@Transactional
@AllArgsConstructor
@Slf4j
public class UserService {

    private static final String DUPLICATE_MSG = "Пользователь таким логином уже существует в системе";

    private final UserDao userDao;
    private final SkillGroupService skillGroupService;
    private final ActiveDirectory activeDirectory;
    private final UserInfoLoader userInfoLoader;
    private final AppConfig appConfig;
    private final UserHistoryService userHistoryService;

    public List<UserView> list() {
        return list(userDao::list);
    }

    public List<User> listForSubdivision() {
        return userDao.listForSubdivision();
    }

    public List<UserView> listActive(@Nullable Integer applicationId) {
        if (applicationId == null) {
            return list(userDao::listActive);
        }
        return list(() -> userDao.listActiveFor(applicationId, appConfig.getAmountSkipLimit()));
    }

    public List<UserView> list(Supplier<List<User>> supplier) {
        List<User> list = supplier.get();
        if (list.isEmpty()) {
            return Collections.emptyList();
        }
        List<Integer> idList = list.stream()
                .map(BasicReference::getId)
                .collect(Collectors.toList());

        Map<Integer, Set<Role>> roleIndex = new HashMap<>(idList.size());
        Map<Integer, Set<Integer>> skillGroupIndex = new HashMap<>(idList.size());

        CollectionUtils.splitListIntoBuckets(idList, 999).forEach(bucket -> {
            Map<Integer, Set<Role>> map = userDao.listRolesForList(bucket).stream()
                    .collect(Collectors.groupingBy(RoleAssociation::getUserId,
                            Collectors.mapping(RoleAssociation::getRole, Collectors.toSet())));
            roleIndex.putAll(map);
        });

        CollectionUtils.splitListIntoBuckets(idList, 999).forEach(bucket -> {
            Map<Integer, Set<Integer>> map = userDao.listSkillGroupsForList(bucket)
                    .stream().collect(Collectors.groupingBy(SkillGroupAssociation::getUserId,
                            Collectors.mapping(SkillGroupAssociation::getSkillGroupId, Collectors.toSet())));
            skillGroupIndex.putAll(map);
        });

        return list.stream()
                .map(user -> {
                    Set<Role> roles = roleIndex.get(user.getId());
                    Set<Integer> skillGroupIds = skillGroupIndex.get(user.getId());
                    return UserView.of(user, roles != null ? roles : Collections.emptySet(),
                            skillGroupIds != null ? skillGroupIds : Collections.emptySet());
                })
                .collect(Collectors.toList());
    }

    @Nullable
    public User findByUsernameFromAD(String username) {
        return innerFindUser(o -> userDao.findByUsername(username), username);
    }

    @Nullable
    public User findByUserName(String username) {
        return userDao.findByUsername(username);
    }

    @Nullable
    public User findByIdFromAD(@Nonnull Integer id) {
        return innerFindUser(o -> userDao.findById(id), id);
    }

    @Nullable
    public User findById(@Nonnull Integer id) {
        return userDao.findById(id);
    }

    public List<User> listOperators(Integer supervisorId) {
        return userDao.listOperators(supervisorId);
    }

    public User create(User user) throws BusinessException {
        userInfoLoader.loadInfo(user);
        LocalDateTime createdAt = LocalDateTime.now();
        user.setCreatedAt(createdAt);
        user.setUpdatedAt(createdAt);
        user.setPrimaryPhoneType(INNER_PHONE_NUMBER);
        int subdivisionId = geSupervisorSubdivisionId(user);
        user.setSubdivisionId(subdivisionId);
        execWithSQLCheck(() -> userDao.insert(user), DUPLICATE_MSG);

        Set<Role> newValues = user.getRoles();
        newValues.add(Role.AUTHORIZED);
        Set<Role> mergedRoles = mergeRoles(Collections.emptySet(), newValues, user);
        user.setRoles(mergedRoles);
        if (user.getRoles().contains(Role.SUPERVISOR)) {
            checkUser(user);
            User supervisor = userDao.findById(user.getId());
            Set<User> newOperators = getOperators(user);
            userHistoryService.addOperators(Collections.emptySet(), newOperators, supervisor);
            updateSupervisor(user.getId(), user.getSubdivisionId(), user.getOperators());
        }
        Set<Integer> mergedSkillGroupIds = mergeSkillGroup(Collections.emptySet(), user.getSkillGroupIds(), user.getId());
        user.setSkillGroupIds(mergedSkillGroupIds);
        userHistoryService.add(new User(), user);
        return userDao.findById(user.getId());
    }

    public User update(Integer id, User user) throws BusinessException {
        User oldUser = getOldUser(user.getId());
        Set<User> oldOperators = oldUser.getOperators();
        userDao.cleanSupervisor(user.getId(), LocalDateTime.now());
        addOperators(user, oldOperators);
        if (user.getRoles().contains(Role.SUPERVISOR)) {
            checkUser(user);
            updateSupervisor(user.getId(), oldUser.getSubdivisionId(), user.getOperators());
        }
        user.setId(id);
        int subdivisionId = getSubdivisionId(oldUser, user);
        user.setSubdivisionId(subdivisionId);
        updateLotusAddress(id, user);
        user.setUpdatedAt(LocalDateTime.now());
        execWithSQLCheck(() -> userDao.update(user), DUPLICATE_MSG);
        Set<Role> oldRoles = userDao.listRoles(user);
        Set<Role> mergedRoles = mergeRoles(oldRoles, user.getRoles(), user);
        user.setRoles(mergedRoles);
        Set<Integer> skillGroupIds = userDao.listSkillGroup(user.getId());
        Set<Integer> mergedSkillGroupIds = mergeSkillGroup(skillGroupIds, user.getSkillGroupIds(), user.getId());
        user.setSkillGroupIds(mergedSkillGroupIds);
        User updatedUser = userDao.findById(user.getId());
        userHistoryService.add(oldUser, updatedUser);
        return updatedUser;
    }

    private void addOperators(User user, Set<User> oldOperators) {
        Set<User> newOperators = getOperators(user);
        User supervisor = userDao.findById(user.getId());
        userHistoryService.addOperators(oldOperators, newOperators, supervisor);
    }

    private Set<User> getOperators(User user) {
        Set<Integer> newOperatorsIds = getOperatorsIds(user.getOperators());
        if (!newOperatorsIds.isEmpty()) {
            List<User> newOperatorList = userDao.findByIds(newOperatorsIds);
            return new HashSet<>(newOperatorList);
        }
        return Collections.emptySet();
    }

    public List<User> deactivate(Set<Integer> ids) {
        return disable(ids, LocalDateTime.now());
    }

    public List<User> activate(Set<Integer> ids) {
        return disable(ids, null);
    }

    public List<User> suggest(@Nullable Role role, @Nullable Integer userId, String query, Role excludeRole) {
        if (query.trim().isEmpty()) {
            return Collections.emptyList();
        }
        String q = "%" + query.toLowerCase() + "%";
        if (role == null && userId == null) {
            return userDao.suggestByQuery(q);
        }
        if (userId != null) {
            return userDao.suggestWithoutUser(role, userId, q, excludeRole);
        }
        return userDao.suggest(role, q, excludeRole);
    }

    public List<User> suggest(String query) {
        return suggest(null, null, query, null);
    }

    public Set<User> activeDirectorySuggest(String username, UserDomain userDomain) {
        List<User> users = activeDirectory.loadSuggestedUsersByUsername(username, userDomain);
        return new HashSet<>(users);
    }

    public User createUserByUserName(String username, UserDomain userDomain) throws BusinessException {
        User user = new User();
        user.setUsername(username);
        user.setDomain(userDomain);
        user.getRoles().add(Role.AUTHORIZED);
        appendUserDataFromAD(user);
        create(user);
        return user;
    }

    public List<FreeUserInfo> getFreeUsersInfo() {
        Integer appStatusTimeout = appConfig.getAppStatusTimeout();
        Integer userStatusTimeout = appConfig.getUserStatusTimeout();
        return userDao.getFreeUserInfo(LocalDateTime.now(), appStatusTimeout, userStatusTimeout);
    }

    public void update(User user) {
        userDao.update(user);
    }

    public void updateSubdivision(Integer supervisorId, Integer newSubdivisionId) {
        saveSubdivisionHistory(supervisorId, newSubdivisionId);
        userDao.updateSubdivision(supervisorId, newSubdivisionId);
    }

    public List<User> listBySubdivision(Integer subdivisionId, Integer excludeSubId) {
        return userDao.listBySubdivision(subdivisionId, excludeSubId);
    }

    public User getUser() {
        Integer userId = AuthUtil.loggedUser().getId();
        User user = userDao.findById(userId);
        if (user == null) {
            throw new NotFoundException(userId);
        }
        return user;
    }

    private void saveSubdivisionHistory(Integer supervisorId, Integer newSubdivisionId) {
        List<User> operators = userDao.listOperators(supervisorId);
        Integer loggedUserId = AuthUtil.loggedUser().getId();
        operators.forEach(
                operator -> {
                    String olValue = String.valueOf(operator.getSubdivisionId());
                    String newValue = String.valueOf(newSubdivisionId);
                    if (!olValue.equals(newValue)) {
                        userHistoryService.saveSubdivisionId(olValue, newValue, operator, loggedUserId);
                    }
                }
        );
    }

    private void updateSupervisor(Integer supervisorId, Integer subdivisionId, Set<User> operators) {
        if (operators == null || operators.isEmpty()) {
            return;
        }

        Set<Integer> ids = getOperatorsIds(operators);
        if (ids.isEmpty()) {
            return;
        }
        userDao.setSupervisorAndSubdivision(ids, supervisorId, subdivisionId, LocalDateTime.now());
    }

    private <T> User innerFindUser(Function<T, User> loader, T key) {
        if (key == null) {
            return null;
        }
        User user = loader.apply(key);
        return user != null ? appendUserDataFromAD(user) : null;
    }

    private User appendUserDataFromAD(User user) {
        try {
            activeDirectory.loadUserByUsername(user.getUsername(), user, user.getDomain());
        } catch (NotFoundInADException e) {
            log.debug("User is not found: {}", user.getName());
            log.trace("", e);
            return null;
        }
        return user;
    }

    private List<User> disable(Set<Integer> ids, @Nullable LocalDateTime disabledAt) {
        if (ids.isEmpty()) {
            return Collections.emptyList();
        }
        userDao.disable(ids, disabledAt, LocalDateTime.now());
        return userDao.findByIds(ids);
    }

    private Set<Integer> mergeSkillGroup(Set<Integer> oldValues, Set<Integer> newValues, Integer userId) {
        return CollectionUtils.mergeSet(oldValues, newValues, Function.identity(),
                skillGroup -> {
                    skillGroupService.assignSkillGroupToUser(userId, skillGroup);
                    return skillGroup;
                },
                skillGroup -> skillGroupService.deAssignSkillGroupToUser(userId, skillGroup),
                null
        );
    }

    private Set<Role> mergeRoles(Set<Role> oldValues, Set<Role> newValues, User user) {
        return CollectionUtils.mergeSet(oldValues, newValues, Function.identity(),
                role -> {
                    userDao.addRole(user, role);
                    return role;
                },
                role -> userDao.deleteRole(user, role),
                null
        );
    }

    private void updateLotusAddress(Integer id, User user) {
        User userBeforeUpdate = userDao.findById(id);
        if (userBeforeUpdate == null ||
                !Objects.equals(userBeforeUpdate.getPersonnelNumber(), user.getPersonnelNumber())) {
            userInfoLoader.loadInfo(user);
        }
    }

    private void checkUser(User user) throws BusinessException {
        if (user.getSupervisor() != null) {
            throw new BusinessException("set_supervisor", "Пользователь не может быть супервайзером т.к. является оператором.");
        }
        Set<User> operators = user.getOperators();
        if (operators != null && operators.size() > 0) {
            Set<Integer> supervisors = userDao.findUsersIdByRole(Role.SUPERVISOR);
            Set<Integer> ids = getOperatorsIds(operators);
            for (Integer id : ids) {
                if (supervisors.contains(id)) {
                    throw new BusinessException("set_supervisor", "Супрвайзеру нельзя задать оператора, который является супервайзером.");
                }
            }
        }
    }

    private Set<Integer> getOperatorsIds(Set<User> operators) {
        return operators.stream()
                .filter(user -> user.getId() != null)
                .map(BasicReference::getId)
                .collect(Collectors.toSet());
    }

    private User getOldUser(Integer userId) {
        User oldUser = userDao.findById(userId);
        if (oldUser != null) {
            oldUser.getSkillGroupIds();
            oldUser.getRoles();
            return oldUser;
        }
        return new User();
    }

    private int geSupervisorSubdivisionId(User user) {
        if (user.getSupervisor() != null) {
            BasicReference supervisor = user.getSupervisor();
            User supervisorUser = userDao.findById(supervisor.getId());
            if (supervisorUser != null) {
                return supervisorUser.getSubdivisionId() != 0 ? supervisorUser.getSubdivisionId() : NON_STATISTICS_SUBDIVISION_ID;
            }
        }
        return NON_STATISTICS_SUBDIVISION_ID;
    }

    private int getSubdivisionId(User oldUser, User newUser) {
        if (!newUser.getRoles().contains(Role.SUPERVISOR) && oldUser.getSupervisor() != newUser.getSupervisor()) {
            return geSupervisorSubdivisionId(newUser);
        }
        return oldUser.getSubdivisionId();
    }
}
