package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.IndustryAffiliation;

import java.util.List;

@Mapper
public interface IndustryAffiliationDao {

    String BASE_SELECT_SQL = "select IND, NAME from INDUSTRY_AFFILIATION";

    @Select(BASE_SELECT_SQL)
    @Results(id = "industryAffiliationMapping", value = {
            @Result(property = "id", column = "IND"),
            @Result(property = "name", column = "NAME")
    })
    List<IndustryAffiliation> findAll();

    @Select(BASE_SELECT_SQL + " where IND = #{id}")
    @ResultMap("industryAffiliationMapping")
    IndustryAffiliation findById(Integer id);
}
