package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
public class ApplicationIdx {
    private Long id;
    private LocalDateTime createDate;
    private LocalDateTime suspendTime;
    private Short supervisorPriority;
    private Integer rtdmPriority;
    private Short skillGroup;
    private Short regionAppPriority;
    private Short regionClientPriority;
    private Short amountPriority;
    private Short channelPriority;
    private Short attractChannelPriority;
    private Short productPriority;
    private Boolean novel;
    private Boolean fraudReturn;
    private Boolean suspensiveTerms;
    private Boolean outOfDialTime;
    private Integer lastUserId;
    private LocalDate monthlyPaymentDate;
    /**
     * Верхняя граница интервала дозвона (в минутах, рабочие дни)
     */
    private Integer dialStartTime;
    /**
     * Нижняя граница интервала дозвона (в минутах, рабочие дни)
     */
    private Integer dialEndTime;
    /**
     * Верхняя граница интервала дозвона (в минутах, выходные дни)
     */
    private Integer holidayDialStartTime;
    /**
     * Нижняя граница интервала дозвона (в минутах, выходные дни)
     */
    private Integer holidayDialEndTime;
}
