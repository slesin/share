package ru.rsb.eurion.service.application.statistics.productivity.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.UserApproveLevel;

import java.math.BigDecimal;
import java.util.List;

@Setter
@Getter
public class UserApproveLevelInfo {

    private BigDecimal plannedApprovalPercent;

    private BigDecimal productionRatePercent;

    private BigDecimal stepPercent;

    private List<UserApproveLevel> userDecisionInfoList;
}
