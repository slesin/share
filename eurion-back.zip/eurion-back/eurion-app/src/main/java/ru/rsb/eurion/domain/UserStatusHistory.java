package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
public class UserStatusHistory {
    private Integer id;
    private UserStatus status;
    private Role role;
    private LocalDateTime updatedAt;
    private String sessionId;
}
