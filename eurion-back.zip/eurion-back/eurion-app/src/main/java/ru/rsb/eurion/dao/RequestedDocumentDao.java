package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.RequestedDocument;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface RequestedDocumentDao {

    String BASE_SQL = "select RD.ID,\n" +
            "       RD.APPLICATION_ID,\n" +
            "       RD.TYPE_ID, USER_ID,\n" +
            "       RD.CREATED_AT,\n" +
            "       RD.UPDATED_AT,\n" +
            "       RD.DISABLED_AT,\n" +
            "       U.FULL_NAME \n" +
            "from REQUESTED_DOCUMENT RD\n" +
            "       join app_user U on RD.USER_ID = U.ID ";

    @Select(BASE_SQL + "where APPLICATION_ID = #{applicationId, jdbcType=BIGINT} and RD.DISABLED_AT is null and IS_REQUESTED = 0")
    @Results(id = "requestDocumentMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "applicationId", column = "APPLICATION_ID"),
            @Result(property = "typeId", column = "TYPE_ID"),
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "isRequested", column = "IS_REQUESTED"),
            @Result(property = "userFullName", column = "FULL_NAME")
    })
    List<RequestedDocument> listByApplicationId(@Param("applicationId") Long applicationId);

    @Insert("insert into REQUESTED_DOCUMENT(APPLICATION_ID, TYPE_ID, USER_ID, CREATED_AT, UPDATED_AT)\n" +
            "values (#{document.applicationId, jdbcType=BIGINT},\n" +
            "        #{document.typeId, jdbcType=INTEGER},\n" +
            "        #{document.userId, jdbcType=INTEGER},\n" +
            "        #{document.createdAt, jdbcType=TIMESTAMP},\n" +
            "        #{document.updatedAt, jdbcType=TIMESTAMP})\n")
    @SelectKey(
            keyProperty = "document.id",
            before = false,
            resultType = Long.class,
            statement = {"select seq_requested_document.currval AS id from dual"})
    void create(@Param("document") RequestedDocument document);

    @Update("update REQUESTED_DOCUMENT\n" +
            "set DISABLED_AT = #{document.disabledAt, jdbcType=TIMESTAMP}\n" +
            "where APPLICATION_ID = #{document.applicationId, jdbcType=BIGINT} " +
            "and TYPE_ID = #{document.typeId, jdbcType=INTEGER} and IS_REQUESTED = 0")
    void update(@Param("document") RequestedDocument document);

    @Update("update REQUESTED_DOCUMENT\n" +
            "set UPDATED_AT = #{updatedAt, jdbcType=TIMESTAMP},\n" +
            "    USER_ID    = #{userId,jdbcType=INTEGER},\n" +
            "    IS_REQUESTED = 1\n" +
            "    where APPLICATION_ID = #{applicationId, jdbcType=BIGINT} and DISABLED_AT is null")
    void updateRequested(@Param("applicationId") Long applicationId,
                         @Param("userId") Integer userId,
                         @Param("updatedAt") LocalDateTime updatedAt);

    @Select(BASE_SQL + "where APPLICATION_ID = #{applicationId, jdbcType=BIGINT} and IS_REQUESTED = 1")
    @ResultMap("requestDocumentMapping")
    List<RequestedDocument> listRequested(@Param("applicationId") Long applicationId);
}
