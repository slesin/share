package ru.rsb.eurion.service.admin.check.protocol.form.definition;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.ResultWrapper;
import ru.rsb.eurion.service.admin.Consts;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping(path = Consts.ADMIN_API_BASE + "/form-definition")
@RestController
@AllArgsConstructor
public class FormDefinitionResource {

    private final FormDefinitionService service;

    @GetMapping("/{id}/skill-group/{skillGroupId}")
    public FormDefinition findOne(@PathVariable("id") Integer id, @PathVariable("skillGroupId") Integer skillGroupId) {
        return service.findOneBySkillGroup(id, skillGroupId);
    }

    @PostMapping(path = "/skill-group/{skillGroupId}", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    public ResultWrapper<FormDefinition> create(@PathVariable("skillGroupId") Integer skillGroupId,
                                                @NotNull @Valid @RequestBody FormDefinition formDefinition) {
        FormDefinition created = service.create(skillGroupId, formDefinition);
        return ResultWrapper.of(created);
    }

    @PutMapping(path = "/{id}/skill-group/{skillGroupId}", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    public ResultWrapper<FormDefinition> update(@PathVariable("id") Integer id,
                                                @PathVariable("skillGroupId") Integer skillGroupId,
                                                @NotNull @Valid @RequestBody FormDefinition formDefinition) throws BusinessException {
        FormDefinition updated = service.update(id, skillGroupId, formDefinition);
        return ResultWrapper.of(updated);
    }

    @PostMapping(path = "/disable/{id}/skill-group/{skillGroupId}")
    public void disableBySkillGroup(@PathVariable("id") Integer id,
                                    @PathVariable("skillGroupId") Integer skillGroupId) {
        service.disableBySkillGroup(id, skillGroupId);
    }
}
