package ru.rsb.eurion;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.boot.autoconfigure.session.SessionProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.session.config.annotation.web.http.EnableSpringHttpSession;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.jms.ConnectionFactory;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;

import static net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock.InterceptMode.PROXY_METHOD;

@EnableSpringHttpSession
@EnableAsync
@RestController
@SpringBootApplication(exclude = {LiquibaseAutoConfiguration.class})
@EnableTransactionManagement
@EnableJms
@EnableScheduling
@EnableSchedulerLock(mode = PROXY_METHOD, defaultLockAtMostFor = "${app.schedule.defaultLockAtMostFor}")
@Slf4j
@AllArgsConstructor
public class EurionApplication {
    public static final String API_BASE = "/api";
    public static final String TOPIC_LISTENER_FACTORY = "topicListenerFactory";
    public static final String WS_API_BASE = "/ws";


    public static void main(String[] args) {
        SpringApplication.run(EurionApplication.class, args);
    }

    private final DataSource dataSource;

    @PostConstruct
    public void init() {
        // проверяем доступность SQL-соединения
        try (Connection connection = dataSource.getConnection()) {
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("select 1 from dual");
            }
            log.info("Connected to database");
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    @Nonnull
    @GetMapping(path = "/health", produces = "text/plain")
    public String health() {
        return "OK";
    }

    @Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource
                = new ReloadableResourceBundleMessageSource();

        messageSource.setBasename("classpath:messages");
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }

    @Bean
    public LocalValidatorFactoryBean getValidator(MessageSource messageSource) {
        LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
        bean.setValidationMessageSource(messageSource);
        return bean;
    }

    @Bean
    public FilterRegistrationBean<RequestIdFilter> requestIdFilter(SessionProperties sessionProperties) {
        FilterRegistrationBean<RequestIdFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new RequestIdFilter());
        registrationBean.setUrlPatterns(Collections.singletonList(API_BASE + "/*"));
        int order = sessionProperties.getServlet().getFilterOrder() + 2000;
        registrationBean.setOrder(order);
        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean<SessionStoreFilter> sessionStoreFilter(SessionProperties sessionProperties) {
        FilterRegistrationBean<SessionStoreFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new SessionStoreFilter());
        registrationBean.setUrlPatterns(Collections.singletonList("/*"));
        int order = sessionProperties.getServlet().getFilterOrder() + 1000;
        registrationBean.setOrder(order);
        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean<WebsocketFilter> websocketFilter(SessionProperties sessionProperties) {
        FilterRegistrationBean<WebsocketFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new WebsocketFilter());
        registrationBean.setUrlPatterns(Collections.singletonList("/wbs/*"));
        int order = sessionProperties.getServlet().getFilterOrder() + 3000;
        registrationBean.setOrder(order);
        return registrationBean;
    }

    @Bean(TOPIC_LISTENER_FACTORY)
    public JmsListenerContainerFactory<?> myFactory(ConnectionFactory connectionFactory,
                                                    DefaultJmsListenerContainerFactoryConfigurer configurer) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        factory.setPubSubDomain(true);
        factory.setSubscriptionDurable(false);
        return factory;
    }

    @Bean
    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    public MessageConverter jacksonJmsMessageConverter(ObjectMapper objectMapper) {
        MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
        converter.setTargetType(MessageType.TEXT);
        converter.setTypeIdPropertyName("_type");
        converter.setObjectMapper(objectMapper);
        return converter;
    }

    @Bean
    public TaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(1);
        executor.setMaxPoolSize(16);
        executor.setQueueCapacity(1024);
        return executor;
    }

    @Bean
    public LockProvider lockProvider(DataSource dataSource) {
        return new JdbcTemplateLockProvider(dataSource);
    }

    @GetMapping(path = "/api/test", produces = "text/plain")
    public String test() {
        return "OK";
    }
}
