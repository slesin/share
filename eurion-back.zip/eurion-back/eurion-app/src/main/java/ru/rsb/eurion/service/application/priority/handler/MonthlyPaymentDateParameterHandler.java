package ru.rsb.eurion.service.application.priority.handler;

import org.mybatis.dynamic.sql.SortSpecification;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.priority.PriorityParameter;
import ru.rsb.eurion.domain.priority.SortDirection;
import ru.rsb.eurion.service.application.priority.PriorityParameterHandler;

import static ru.rsb.eurion.service.application.priority.ApplicationPriorityService.PRIORITY_HANDLER_PREFIX;

@Component(PRIORITY_HANDLER_PREFIX + "MONTHLY_PAYMENT_DATE")
public class MonthlyPaymentDateParameterHandler implements PriorityParameterHandler {

    private static final String EXPRESSION = "decode(SIGN(IDX.MONTHLY_PAYMENT_DATE - trunc(CURRENT_DATE)),\n" +
            "           -1, IDX.MONTHLY_PAYMENT_DATE  + ceil((trunc(CURRENT_DATE) - IDX.MONTHLY_PAYMENT_DATE) / 30) * 30,\n" +
            "           1, IDX.MONTHLY_PAYMENT_DATE,\n" +
            "           0, IDX.MONTHLY_PAYMENT_DATE) ";

    @Override
    public SortSpecification apply(PriorityParameter parameter) {
        return new MonthlyPaymentDateParameterHandler.Spec(parameter.getDirection() == SortDirection.DESC ^ !parameter.isReverse());
    }

    @Override
    public boolean isCommon() {
        return true;
    }

    public static class Spec implements SortSpecification {
        private static final String EXPRESSION_ASC = EXPRESSION + "NULLS LAST";
        private static final String EXPRESSION_DESC = EXPRESSION + "DESC NULLS LAST";
        private final boolean descending;

        private Spec(boolean descending) {
            this.descending = descending;
        }

        @Override
        public SortSpecification descending() {
            return new MonthlyPaymentDateParameterHandler.Spec(true);
        }

        @Override
        public String aliasOrName() {
            return descending ? EXPRESSION_DESC : EXPRESSION_ASC;
        }

        @Override
        public boolean isDescending() {
            return false;
        }
    }
}
