package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Форма Цель кредита
 */
@Getter
@Setter
public class LoanPurposeForm extends BasicForm {
    /**
     * Сумма кредита (запрос)
     */
    private BigDecimal loanAmount;
    /**
     * Срок кредита (запрос)
     */
    private Integer loanPeriod;
    /**
     * Цель кредита
     */
    private String purpose;
    /**
     * Стоимость товара
     */
    private BigDecimal costOfGoods;
    /**
     * Включена ли страховка (true - да, false - нет)
     */
    private boolean insuranceIncluded;
    /**
     * Стоимость страховки
     */
    private BigDecimal costOfInsurance;
}
