package ru.rsb.eurion.service.application.product;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.dao.DurationTypeHandler;
import ru.rsb.eurion.domain.SkillGroup;

import javax.annotation.Nullable;
import java.util.List;

@Mapper
public interface ProductDao {

    @Select("select id, name from PRODUCT_TYPE")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "NAME", property = "name")
    })
    List<ProductType> listProductType();

    @Select("select id, name\n" +
            "from PRODUCT_TYPE\n" +
            "where id = #{jdbcType = INTEGER}")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "NAME", property = "name")
    })
    ProductType findById(@Param("productTypeId") Integer productTypeId);

    @Select("select id,\n" +
            "       begin_amount,\n" +
            "       end_amount,\n" +
            "       pti,\n" +
            "       product_type_id,\n" +
            "       skill_group_id\n" +
            "from PTI_PRODUCT_RULE\n")
    @Results(id = "productRuleMapping", value = {
            @Result(column = "ID", property = "id"),
            @Result(column = "BEGIN_AMOUNT", property = "beginAmount"),
            @Result(column = "END_AMOUNT", property = "endAmount"),
            @Result(column = "PTI", property = "pti"),
            @Result(column = "PRODUCT_TYPE_ID", one = @One(select = "findById", fetchType = FetchType.EAGER),
                    property = "productType"),
            @Result(column = "SKILL_GROUP_ID", one = @One(select = "findSkillGroupById", fetchType = FetchType.EAGER),
                    property = "skillGroup"),

    })
    List<ProductRule> listRules();

    @Insert("insert into PTI_PRODUCT_RULE (PRODUCT_TYPE_ID, SKILL_GROUP_ID, BEGIN_AMOUNT, END_AMOUNT, PTI, CREATED_AT, UPDATED_AT)\n" +
            "values (#{productType.id,jdbcType=INTEGER},\n" +
            "        #{skillGroup.id,jdbcType=INTEGER},\n" +
            "        #{beginAmount,jdbcType=NUMERIC},\n" +
            "        #{endAmount,jdbcType=NUMERIC},\n" +
            "        #{pti,jdbcType=NUMERIC},\n" +
            "        #{createdAt,jdbcType=TIMESTAMP},\n" +
            "        #{createdAt,jdbcType=TIMESTAMP})")
    @SelectKey(
            keyProperty = "id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_pti_product_rule.currval AS id from dual"}
    )
    void insert(ProductRule productRule);

    @Update("update PTI_PRODUCT_RULE\n" +
            "set BEGIN_AMOUNT = #{productRule.beginAmount, jdbcType = NUMERIC},\n" +
            "    END_AMOUNT   = #{productRule.endAmount, jdbcType = NUMERIC},\n" +
            "    PTI          = #{productRule.pti, jdbcType = NUMERIC},\n" +
            "    UPDATED_AT   = #{productRule.updatedAt, jdbcType = TIMESTAMP}\n" +
            "where id = #{productRule.id, jdbcType = INTEGER} ")
    void update(@Param("productRule") ProductRule productRule);

    @Delete("delete\n" +
            "from pti_product_rule\n" +
            "where ID = #{ id, jdbcType = INTEGER}")
    void deleteByRoleId(@Param("id") Integer id);

    @Select("SELECT * FROM SKILL_GROUP WHERE ID = #{id, jdbcType=INTEGER}")
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "stageSla", column = "stage_sla", typeHandler = DurationTypeHandler.class),
            @Result(property = "employeeSla", column = "employee_sla", typeHandler = DurationTypeHandler.class),
            @Result(property = "enabled", column = "is_enabled"),
            @Result(property = "priority", column = "sort_priority"),
            @Result(property = "checkType", column = "check_type"),
            @Result(property = "roleId", column = "role_id"),
            @Result(property = "isRecount", column = "is_recount")
    })
    @Nullable
    @SuppressWarnings("unused")
    SkillGroup findSkillGroupById(Integer skillGroupId);

}
