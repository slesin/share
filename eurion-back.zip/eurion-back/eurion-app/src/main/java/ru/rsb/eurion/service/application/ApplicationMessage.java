package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationMessage {
    private Long id;
    private String reason;
    private Integer userId;
}
