package ru.rsb.eurion.service.application.history;

import com.fasterxml.jackson.core.type.TypeReference;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.CheckConclusionHistory;
import ru.rsb.eurion.domain.CheckConclusionHistory.DecisionMaker;
import ru.rsb.eurion.domain.DeclineReason;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.list.Pageable;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.list.SortDirection;
import ru.rsb.eurion.rtdm.application.RtdmDecisionCode;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.application.RtdmDecisionService;
import ru.rsb.eurion.service.util.JsonService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static ru.rsb.eurion.domain.CheckConclusionHistory.DecisionMaker.RTDM;
import static ru.rsb.eurion.domain.CheckConclusionHistory.DecisionMaker.UNDERWRITING;

@Service
@Transactional
@Slf4j
@AllArgsConstructor
public class CheckConclusionHistoryService {

    private final CheckConclusionHistoryDao dao;
    private final JsonService jsonService;

    public PagedResult<CheckConclusionHistoryView> listPage(Long id, CheckHistoryPageable pageable) {

        boolean asc = !pageable.getSortDir().isEmpty() && pageable.getSortDir().get(0) == SortDirection.ASC;

        Supplier<List<CheckConclusionHistoryView>> listSupplier = asc ?
                () -> dao.listByApplicationIdPageOrderByUpdatedAtAsc(id, pageable.getOffset(), pageable.getLimit()) :
                () -> dao.listByApplicationIdPageOrderByUpdatedAtDesc(id, pageable.getOffset(), pageable.getLimit());
        Supplier<Integer> countSupplier = () -> dao.countByApplicationId(id);
        return listPage(pageable, listSupplier, countSupplier);
    }

    public PagedResult<CheckConclusionHistoryViewExt> listCommentsByDecisionMaker(Integer clientId, CheckHistoryPageable pageable,
                                                                                  DecisionMaker decisionMaker) {
        Supplier<List<CheckConclusionHistoryViewExt>> listSupplier =
                () -> dao.listByClientIdPageOrderByUpdatedAtDesc(clientId, pageable.getOffset(), pageable.getLimit(), decisionMaker);
        Supplier<Integer> countSupplier = () -> dao.countByClientId(clientId, decisionMaker);
        return listPage(pageable, listSupplier, countSupplier);
    }

    public void addHistoryRecordWithDecision(ApplicationEntity applicationEntity, DecisionMaker decisionMaker, Set<Integer> declineReasonsIds, ru.rsb.eurion.rtdm.application.RtdmDecision rtdmDecision) {
        CheckConclusionHistory history = new CheckConclusionHistory();
        history.setSkillGroup(applicationEntity.getSkillGroup());
        history.setFormDefinitions(applicationEntity.getFormDefinitions());
        history.setFormConclusions(applicationEntity.getFormConclusions());
        history.setCreatedAt(LocalDateTime.now());
        history.setUpdatedAt(LocalDateTime.now());
        history.setDecisionMaker(decisionMaker);
        history.setDecision(applicationEntity.getDecision());
        if (rtdmDecision != null) {
            history.setRtdmDecision(rtdmDecision.getDecision());
        }
        history.setCreatedAt(LocalDateTime.now());
        history.setDecisionComment(applicationEntity.getDecisionComment());

        UserData userData = AuthUtil.currentAuth();
        if (userData != null) {
            BasicReference user = new BasicReference();
            user.setId(userData.getId());
            history.setUser(user);
        }

        dao.create(applicationEntity.getId(), history);
        checkDeclineReason(applicationEntity.getDecision(), declineReasonsIds, applicationEntity.getId());
        declineReasonsIds.forEach(reasonId -> dao.addDeclineReason(history.getId(), reasonId));
    }

    public void addHistoryRecord(ApplicationEntity applicationEntity, DecisionMaker decisionMaker) {
        CheckConclusionHistory history = new CheckConclusionHistory();
        history.setSkillGroup(applicationEntity.getSkillGroup());
        history.setFormDefinitions(applicationEntity.getFormDefinitions());
        history.setFormConclusions(applicationEntity.getFormConclusions());
        history.setCreatedAt(LocalDateTime.now());
        history.setUpdatedAt(LocalDateTime.now());
        history.setDecisionMaker(decisionMaker);
        history.setCreatedAt(LocalDateTime.now());
        UserData userData = AuthUtil.currentAuth();
        if (userData != null) {
            BasicReference user = new BasicReference();
            user.setId(userData.getId());
            history.setUser(user);
        }
        dao.create(applicationEntity.getId(), history);
    }

    public void addHistoryRecord(Long applicationId, CheckConclusionHistory conclusionHistory) {
        dao.create(applicationId, conclusionHistory);
        conclusionHistory.getDeclineReasonIds().forEach(reasonId -> dao.addDeclineReason(conclusionHistory.getId(), reasonId));
    }

    //ToDo remove after fix ANDERATING-1285
    private void checkDeclineReason(ApplicationDecision decision, Set<Integer> declineIds, Long id) {
        if (decision == ApplicationDecision.REJECTED && (declineIds == null || declineIds.isEmpty())) {
            log.error("Decline reason not found for application: " + id);
        }
    }

    private <T extends CheckConclusionHistoryView> PagedResult<T> listPage(CheckHistoryPageable pageable,
                                                                           Supplier<List<T>> listSupplier,
                                                                           Supplier<Integer> countSupplier) {
        List<T> list = listSupplier.get();
        list.forEach(item -> {
            String decisionText = takeDecisionText(item.getDecisionMaker(), item.getDecision(), item.getRtdmDecision());
            item.setDecisionText(decisionText);
            if (item.getDecisionMaker() == UNDERWRITING && item.getDeclineReasons() != null && !item.getDeclineReasons().isEmpty()) {
                String declineText = getDeclineText(item.getDeclineReasons());
                item.setDeclineText(declineText);
            }
            if (item.getFormDefinitionsJson() != null) {
                item.setFormDefinitions(parse(item.getFormDefinitionsJson()));
            }
            if (item.getFormConclusionsJson() != null) {
                item.setFormConclusions(parse(item.getFormConclusionsJson()));
            }
        });
        int total = countSupplier.get();
        return new PagedResult<>(pageable.getOffset(), total, list);
    }

    private String getDeclineText(List<DeclineReason> reasons) {
        List<String> reasonNames = reasons.stream()
                .map(BasicReference::getName)
                .collect(Collectors.toList());
        return reasons.get(0).getCategory().getName() + "; " + StringUtils.join(reasonNames, "; ");
    }

    private String takeDecisionText(DecisionMaker decisionMaker, ApplicationDecision decision, RtdmDecisionCode rtdmDecision) {
        if (decisionMaker == RTDM) {
            return RtdmDecisionService.convertDecisionToStatusTextReal(rtdmDecision);

        }
        return decision != null ? decision.getDecisionText() : null;
    }

    private <T> List<T> parse(String formDefinitions) {
        TypeReference<List<T>> typeReference = new TypeReference<List<T>>() {
        };
        return jsonService.parse(formDefinitions, typeReference);
    }

    public enum SortBy {
        updatedAt
    }

    public static class CheckHistoryPageable extends Pageable<SortBy> {

    }
}
