package ru.rsb.eurion.service.admin.users.upd;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class PersonnelNumberData {
    private Wrapper personnelNumbersList;

    @Getter
    @Setter
    public static class Wrapper {
        private List<PersonnelNumbersItem> personnelNumbersItem;

        public List<PersonnelNumbersItem> getPersonnelNumbersItem() {
            if (personnelNumbersItem == null) {
                personnelNumbersItem = new ArrayList<>();
            }
            return personnelNumbersItem;
        }
    }

    @Getter
    @Setter
    public static class PersonnelNumbersItem {
        private String login;
        private String number;
    }
}
