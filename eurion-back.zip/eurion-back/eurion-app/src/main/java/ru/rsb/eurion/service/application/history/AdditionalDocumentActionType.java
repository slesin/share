package ru.rsb.eurion.service.application.history;

public enum AdditionalDocumentActionType {
    CREATE,
    DELETE,
    UPDATE
}
