package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.PhoneType;

import java.util.List;

@Mapper
public interface PhoneTypeDao {

    String BASE_SELECT_SQL = "select ID, NAME, CREATED_AT, UPDATED_AT, DISABLED_AT, CODE from PHONE_TYPE";

    @Select(BASE_SELECT_SQL + " order by ID")
    @Results(id = "phoneTypeMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "code", column = "CODE")
    })
    List<PhoneType> findAll();

    @Select(BASE_SELECT_SQL + " where ID = #{id}")
    @ResultMap("phoneTypeMapping")
    PhoneType findById(Integer id);
}
