package ru.rsb.eurion.service.application.flow;

import lombok.AllArgsConstructor;
import org.flowable.common.engine.api.delegate.event.FlowableEvent;
import org.flowable.common.engine.api.delegate.event.FlowableEventListener;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.delegate.event.FlowableCancelledEvent;
import org.flowable.engine.runtime.ProcessInstance;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.service.application.flow.api.FlowAPI;
import ru.rsb.eurion.service.application.priority.ApplicationIdxDao;

import java.util.Optional;

@Component
@AllArgsConstructor
public class ProcessCancelEventListener implements FlowableEventListener {
    private final RuntimeService runtimeService;
    private final ApplicationIdxDao applicationIdxDao;


    @Override
    public void onEvent(FlowableEvent flowableEvent) {
        FlowableCancelledEvent event = (FlowableCancelledEvent) flowableEvent;
        Optional.ofNullable(runtimeService.createProcessInstanceQuery()
                .processDefinitionKey(FlowAPI.APPLICATION_DEFINITION_KEY)
                .processInstanceId(event.getProcessInstanceId())
                .singleResult())
                .ifPresent(this::handle);
    }

    private void handle(ProcessInstance processInstance) {
        String businessKey = processInstance.getBusinessKey();
        Long applicationId = Long.valueOf(businessKey);
        applicationIdxDao.delete(applicationId);
    }

    @Override
    public boolean isFailOnException() {
        return false;
    }

    @Override
    public boolean isFireOnTransactionLifecycleEvent() {
        return false;
    }

    @Override
    public String getOnTransaction() {
        return null;
    }
}
