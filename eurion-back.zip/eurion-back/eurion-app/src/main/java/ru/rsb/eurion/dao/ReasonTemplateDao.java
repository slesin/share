package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import ru.rsb.eurion.domain.ReasonTemplate;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;

import java.util.List;

@Mapper
public interface ReasonTemplateDao {

    String SELECT_SQL = "select RT.ID,\n" +
            "       RT.TEMPLATE,\n" +
            "       RT.REASON_ID,\n" +
            "       DR.DECLINE_CATEGORY_ID,\n" +
            "       RT.CREATED_AT,\n" +
            "       RT.UPDATED_AT,\n" +
            "       RT.DISABLED_AT\n" +
            "from REASON_TEMPLATE RT\n" +
            "left join DECLINE_REASON DR on DR.ID = RT.REASON_ID ";

    @Select(SELECT_SQL + " order by DECLINE_CATEGORY_ID, REASON_ID")
    @Results(id = "ReasonTemplateMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "reasonId", column = "REASON_ID"),
            @Result(property = "categoryId", column = "DECLINE_CATEGORY_ID"),
            @Result(property = "template", column = "TEMPLATE"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT")
    })
    List<ReasonTemplate> findAll();

    @Select(SELECT_SQL + "where REASON_ID = #{reasonId, jdbcType = INTEGER}")
    @ResultMap("ReasonTemplateMapping")
    List<ReasonTemplate> findByReason(@Param("reasonId") Integer reasonId);

    @Insert("INSERT INTO REASON_TEMPLATE (TEMPLATE, REASON_ID, CREATED_AT)\n" +
            "VALUES (#{template.template, jdbcType = VARCHAR},\n" +
            "        #{template.reasonId, jdbcType = INTEGER},\n" +
            "        #{template.createdAt, jdbcType=TIMESTAMP})")
    @SelectKey(
            keyProperty = "template.id",
            before = false,
            resultType = Integer.class,
            statement = {"select seq_reason_template.currval AS id from dual"})
    void create(@Param("template") ReasonTemplate template);

    @Update("UPDATE REASON_TEMPLATE\n" +
            "SET TEMPLATE    = #{template.template, jdbcType = VARCHAR},\n" +
            "    REASON_ID   = #{template.reasonId, jdbcType = INTEGER},\n" +
            "    UPDATED_AT  = #{template.updatedAt, jdbcType = TIMESTAMP},\n" +
            "    DISABLED_AT = #{template.disabledAt, jdbcType = TIMESTAMP}\n" +
            "WHERE ID = #{template.id, jdbcType = INTEGER}")
    void update(@Param("template") ReasonTemplate template);

    @Delete("DELETE FROM REASON_TEMPLATE WHERE ID IN (#{idList})")
    @Lang(MybatisExtendedLanguageDriver.class)
    void delete(@Param("idList") List<Integer> idList);
}