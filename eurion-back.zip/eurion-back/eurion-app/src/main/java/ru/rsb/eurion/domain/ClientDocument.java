package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class ClientDocument {
    /**
     * Имя
     */
    private String name;
    /**
     * Фамилия
     */
    private String surname;
    /**
     * Отчество
     */
    private String patronymic;
    /**
     * Дата рождения
     */
    private LocalDate birthDate;
    /**
     * Серия паспорта
     */
    private String series;
    /**
     * Номер паспорта
     */
    private String number;
    /**
     * Код подразделения
     */
    private String departmentCode;
    /**
     * Дата выдачи
     */
    private LocalDate issueDate;
    /**
     * Источник данных
     */
    private String sourceData;
    /**
     * Дата редактирования данных о документе
     */
    private LocalDateTime changeDate;
}
