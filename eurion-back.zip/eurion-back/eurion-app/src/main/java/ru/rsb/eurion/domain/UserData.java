package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.admin.users.status.UserStatusAndRole;

import javax.validation.constraints.NotEmpty;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class UserData implements Serializable {
    private static final long serialVersionUID = 2;

    /**
     * ID пользователя в системе
     */
    private Integer id;

    /**
     * Имя пользователя
     */
    @NotEmpty
    private String username;

    /**
     * ФИО
     */
    private String name;

    /**
     * Роли пользователя
     */
    private Set<Role> roles;

    /**
     * Дата рождения
     */
    private LocalDate birthDate;

    /**
     * Табельный номер
     */
    private String personnelNumber;

    /**
     * Лимит
     */
    private BigDecimal limit;

    /**
     * Супервизор
     */
    private BasicReferenceDTO supervisor;

    /**
     * Текущий статус и выбранная пользователем роль
     */
    private UserStatusAndRole currentStatus;

    private String innerPhoneNumber;

    public static UserData of(User user) {
        UserData data = new UserData();
        data.setId(user.getId());
        data.setUsername(user.getUsername());
        data.setName(user.getName());
        data.setRoles(new HashSet<>(user.getRoles()));
        data.setBirthDate(user.getBirthDate());
        data.setPersonnelNumber(user.getPersonnelNumber());
        data.setLimit(user.getLimit());
        data.setInnerPhoneNumber(user.getInnerPhoneNumber());

        if (user.getSupervisor() != null) {
            BasicReferenceDTO supervisor = new BasicReferenceDTO();
            supervisor.setId(user.getSupervisor().getId());
            supervisor.setName(user.getSupervisor().getName());
            supervisor.setCreatedAt(user.getSupervisor().getCreatedAt());
            supervisor.setUpdatedAt(user.getSupervisor().getUpdatedAt());
            data.setSupervisor(supervisor);
        }

        return data;
    }

    public static UserData of(User user, UserStatusAndRole status) {
        UserData userData = of(user);
        userData.currentStatus = status;
        return userData;
    }

    @Override
    public String toString() {
        return "UserData{" +
                "id=" + id +
                ", username='" + username + '\'' +
                '}';
    }

    public static class BasicReferenceDTO extends BasicReference implements Serializable {

    }
}
