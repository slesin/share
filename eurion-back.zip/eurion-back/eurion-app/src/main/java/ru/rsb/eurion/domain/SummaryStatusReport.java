package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class SummaryStatusReport {
    /**
     * Количиство поступивших заявок
     */
    private Integer income;
    /**
     * Количество заявок в очереди
     */
    private Integer inQueue;
    /**
     * Количество заявок в работе
     */
    private Integer inWork;
    /**
     * Количество заявок в пересчете
     */
    private Integer recount;
    /**
     * Количество заявок в работе
     */
    private Integer rework;
    /**
     * Количество рассмотренных заявок
     */
    private Integer reviewed;
    /**
     * Количество одобренных заявок
     */
    private Integer approve;
    /**
     * Уровень одобрения
     */
    private BigDecimal approveLevel;
    /**
     * Тип продукта
     */
    private String creditType;
}
