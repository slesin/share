package ru.rsb.eurion.service.application.history.call;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class CustomerCallItem {
    private String numReg;
    private LocalDateTime dateCreate;
    private String nameReq;
    private String nameTheme;
    private String nameReqDecode;
    private String nameReqStat;
    private String num;
    private String nameUser;
    private String nameRegion;
    private String nameOffice;
    private String nameReply;
}
