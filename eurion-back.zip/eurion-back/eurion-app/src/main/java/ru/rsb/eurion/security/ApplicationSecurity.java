package ru.rsb.eurion.security;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.EurionApplication;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.service.admin.Consts;

import java.util.stream.Stream;

@AllArgsConstructor
@Component
@Slf4j
public class ApplicationSecurity extends WebSecurityConfigurerAdapter {
    private static final String API_MATCHER = EurionApplication.API_BASE + "/**";
    private static final String[] ALL_ROLES = Stream.of(Role.values())
            .map(Enum::name)
            .toArray(String[]::new);

    private final RESTAuthenticationEntryPoint authenticationEntryPoint;
    private final RESTAuthenticationFailureHandler authenticationFailureHandler;
    private final RESTAuthenticationSuccessHandler authenticationSuccessHandler;
    private final RESTAccessDeniedHandler restAccessDeniedHandler;
    private final AuthProvider authProvider;

    @Override
    protected void configure(AuthenticationManagerBuilder builder) {
        builder.authenticationProvider(authProvider);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        log.info("Configuring security: {}", ApplicationSecurity.API_MATCHER);
        http
                .antMatcher(API_MATCHER)
                .csrf().disable()
                .exceptionHandling()
                .authenticationEntryPoint(authenticationEntryPoint)
                .accessDeniedHandler(restAccessDeniedHandler)
                .and()
                .formLogin()
                .successHandler(authenticationSuccessHandler)
                .failureHandler(authenticationFailureHandler)
                .loginProcessingUrl(EurionApplication.API_BASE + "/auth/login").permitAll()
                .and()
                .logout()
                .logoutSuccessHandler((new HttpStatusReturningLogoutSuccessHandler(HttpStatus.OK)))
                .logoutUrl(EurionApplication.API_BASE + "/auth/logout").permitAll()
                .invalidateHttpSession(true)
                .and()
                .authorizeRequests()
                .antMatchers(Consts.AUTHOR_USER_API_BASE + "/**").hasAnyRole(ALL_ROLES)
                .antMatchers(EurionApplication.API_BASE + "/instance/**").permitAll()
                .antMatchers(EurionApplication.API_BASE + "/statistics/**").permitAll()
                .antMatchers(EurionApplication.API_BASE + "/auth").authenticated()
                .antMatchers(Consts.ADMIN_API_BASE).hasRole(Role.ADMIN.name())
                .antMatchers(Consts.SUPERVISOR_API_BASE + "/**").hasRole(Role.SUPERVISOR.name())
                .antMatchers(Consts.UNDERWRITER_API_BASE + "/**").hasRole(Role.UNDERWRITER.name())
                .antMatchers(Consts.VERIFIER_API_BASE + "/**").hasRole(Role.VERIFIER.name())
                .antMatchers(EurionApplication.API_BASE + "/reporting**").hasAnyRole(Role.SUPERVISOR.name(), Role.ADMIN.name())
                .antMatchers(EurionApplication.API_BASE + "/**").hasAnyRole(ALL_ROLES);
    }
}