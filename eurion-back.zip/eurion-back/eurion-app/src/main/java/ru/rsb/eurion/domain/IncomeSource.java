package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Источник дохода
 */
@Setter
@Getter
public class IncomeSource extends BasicReference {
}
