package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Типы расходов
 */
@Setter
@Getter
public class ExpenseType extends BasicReference {
}
