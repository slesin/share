package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.WorkPeriod;

import java.util.List;

@Mapper
public interface WorkPeriodDao {

    @Select("select " +
            "  IND, " +
            "  NAME, " +
            "  SCORIND, " +
            "  DATECHANGE, " +
            "  ACTIV, " +
            "  IDCOUNTRY, " +
            "  CODEID " +
            "from WORK_PERIOD")
    @Results(id = "workPeriodMapping", value = {
            @Result(property = "id", column = "IND"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "scoringId", column = "SCORIND"),
            @Result(property = "updatedAt", column = "DATECHANGE"),
            @Result(property = "active", column = "ACTIV"),
            @Result(property = "countryId", column = "IDCOUNTRY"),
            @Result(property = "codeId", column = "CODEID")
    })
    List<WorkPeriod> findAll();

    @Select("select * from WORK_PERIOD where IND = #{id}")
    @ResultMap("workPeriodMapping")
    WorkPeriod findById(Integer id);
}
