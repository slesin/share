package ru.rsb.eurion.service.application.priority.handler;

import org.mybatis.dynamic.sql.SortSpecification;
import org.mybatis.dynamic.sql.SqlColumn;
import ru.rsb.eurion.domain.priority.PriorityParameter;
import ru.rsb.eurion.domain.priority.SortDirection;
import ru.rsb.eurion.service.application.priority.PriorityParameterHandler;

import javax.annotation.Nonnull;

public abstract class SimplePriorityParameterHandler implements PriorityParameterHandler {
    private final SqlColumn<?> column;
    private final NullsOrdering nullsOrdering;

    protected SimplePriorityParameterHandler(SqlColumn<?> column) {
        this(column, NullsOrdering.DEFAULT);
    }

    protected SimplePriorityParameterHandler(@Nonnull SqlColumn<?> column, @Nonnull NullsOrdering nullsOrdering) {
        this.column = column;
        this.nullsOrdering = nullsOrdering;
    }

    @Override
    public SortSpecification apply(PriorityParameter parameter) {
        return new SortSpecificationImpl(column,
                parameter.getDirection() == SortDirection.DESC ^ parameter.isReverse(), nullsOrdering);
    }

    @Override
    public boolean isCommon() {
        return true;
    }


    public enum NullsOrdering {
        NULLS_LAST,
        NULLS_FIRST,
        DEFAULT
    }

    private static class SortSpecificationImpl implements SortSpecification {
        @Nonnull
        private final SqlColumn<?> column;
        private final boolean descending;
        @Nonnull
        private final NullsOrdering nullsOrdering;

        private SortSpecificationImpl(@Nonnull SqlColumn<?> column, boolean descending) {
            this(column, descending, NullsOrdering.DEFAULT);
        }

        private SortSpecificationImpl(@Nonnull SqlColumn<?> column,
                                      boolean descending,
                                      @Nonnull NullsOrdering nullsOrdering) {
            this.column = column;
            this.descending = descending;
            this.nullsOrdering = nullsOrdering;
        }

        @Override
        public SortSpecification descending() {
            return new SortSpecificationImpl(column, true);
        }

        @Override
        public String aliasOrName() {
            String nullsStr;
            switch (this.nullsOrdering) {
                case NULLS_LAST:
                    nullsStr = " NULLS LAST";
                    break;
                case NULLS_FIRST:
                    nullsStr = " NULLS FIRST";
                    break;
                default:
                    nullsStr = "";
            }
            return "IDX." + column.name() + (descending ? " DESC" : "") + nullsStr;
        }

        @Override
        public boolean isDescending() {
            return false;
        }
    }
}
