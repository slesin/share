package ru.rsb.eurion.security;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import ru.rsb.eurion.domain.UserData;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.servlet.http.HttpSession;
import java.nio.charset.StandardCharsets;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class AuthUtil {

    @Nullable
    public static UserData currentAuth() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication instanceof AppAuthenticationToken) {
            return ((AppAuthenticationToken) authentication).getUser();
        }
        return null;
    }

    /**
     * Возвращает текущего пользователя сессии
     *
     * @return текущий пользователь сессии
     * @throws IllegalArgumentException если пользователя нет
     */
    @Nonnull
    public static UserData loggedUser() {
        UserData user = currentAuth();
        if (user == null) {
            throw new IllegalArgumentException("User is not logged");
        }
        return user;
    }

    public static String getSessionId(HttpSession session) {
        return session.getId();
    }

    public static void setSessionTimeout(HttpSession session, Integer timeout) {
        session.setMaxInactiveInterval(timeout);
    }

    public static void logout(HttpSession session) {
        session.invalidate();
    }

    public static HttpHeaders getBasicAuthHeaders(String username, String password) {
        HttpHeaders httpHeaders = new HttpHeaders();
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeader = "Basic " + new String(encodedAuth, StandardCharsets.UTF_8);
        httpHeaders.set("Authorization", authHeader);
        return httpHeaders;
    }

}
