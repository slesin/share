package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Связанный (пересекающийся) клиент
 */
@Getter
@Setter
public class CrossClient {
    /**
     * ID клиента
     */
    private Long clientId;
    /**
     * ФИО
     */
    private String fullName;
}
