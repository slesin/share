package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LotusUserInfo {

    private String lastName;
    private String firstName;
    private String middleName;
    private String address;
    private String division;
    private String divisionId;
    private String position;
    private String territory;
    private String city;
    private String email;
    private String extension;
    private String hiddenPhoneNumber;
    private String cellPhone;
    private int birthDay;
    private int birthMonth;
    private String directChief;
    private String photo;
    private String dateStartWork;
    private String status;
    private String chiefEmail;
    private String chiefNetaddress;
    private String chiefAddomain;
    private String err;

}