package ru.rsb.eurion.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserDomain;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import java.util.List;

import static ru.rsb.eurion.security.SecurityConfiguration.REGION_QUALIFIER;
import static ru.rsb.eurion.security.SecurityConfiguration.RS_QUALIFIER;


@Component
@Slf4j
public class ActiveDirectory {
    private static final String USER_FILTER = "(&(objectClass=user)(sAMAccountName=%s))";
    private static final String SUGGESTED_USER_FILTER = "(&(objectClass=user)(|(cn=%s*)(employeeID=%s*)))";

    private LdapHelper rsLdap;
    private LdapHelper regionLdap;

    public ActiveDirectory(@Qualifier(RS_QUALIFIER) LdapHelper rsLdap, @Qualifier(REGION_QUALIFIER) LdapHelper regionLdap) {
        this.rsLdap = rsLdap;
        this.regionLdap = regionLdap;
    }

    boolean findByUserName(String userName, UserDomain userDomain) {
        LdapHelper ldapHelper = getLdapHelper(userDomain);
        LdapTemplate ldapTemplate = ldapHelper.getLdapTemplate();
        String userSearchBase = ldapHelper.getUserSearchBase();
        List<String> userNameList = ldapTemplate.search(userSearchBase, String.format(USER_FILTER, userName),
                (AttributesMapper<String>) attributes -> (String) attributes.get("sAMAccountname").get());
        return !userNameList.isEmpty();
    }

    String getRsDomain() {
        return rsLdap.getDomain();
    }

    String getRegionDomain() {
        return regionLdap.getDomain();
    }

    public void loadUserByUsername(String username, User target, UserDomain userDomain) throws NotFoundInADException {
        LdapHelper ldapHelper = getLdapHelper(userDomain);
        LdapTemplate ldapTemplate = ldapHelper.getLdapTemplate();
        String userSearchBase = ldapHelper.getUserSearchBase();
        List<User> list = ldapTemplate.search(userSearchBase, String.format(USER_FILTER, username),
                (AttributesMapper<User>) attributes -> {
                    mapUser(attributes, target);
                    return target;
                });
        if (list.isEmpty()) {
            throw new NotFoundInADException(username);
        }
    }

    public List<User> loadSuggestedUsersByUsername(String nameOrEmployeeId, UserDomain userDomain) {
        LdapHelper ldapHelper = getLdapHelper(userDomain);
        LdapTemplate ldapTemplate = ldapHelper.getLdapTemplate();
        String userSearchBase = ldapHelper.getUserSearchBase();
        return ldapTemplate.search(userSearchBase, String.format(SUGGESTED_USER_FILTER, nameOrEmployeeId, nameOrEmployeeId),
                (AttributesMapper<User>) attributes -> {
                    User user = new User();
                    mapUser(attributes, user);
                    return user;
                });
    }

    private LdapHelper getLdapHelper(UserDomain userDomain) {
        switch (userDomain) {
            case RS:
                return rsLdap;
            case REGION:
                return regionLdap;
            default:
                throw new IllegalStateException();
        }
    }

    private void mapUser(Attributes attributes, User data) throws NamingException {
        data.setName((String) attributes.get("cn").get());
        Attribute employeeId = attributes.get("employeeId");
        if (employeeId != null) {
            data.setPersonnelNumber((String) employeeId.get());
        }
        data.setUsername((String) attributes.get("sAMAccountname").get());
        // additional data from AD
    }

    void authenticate() {
        authenticateRS(rsLdap.getUsername(), rsLdap.getPassword());
        authenticateRegion(regionLdap.getUsername(), regionLdap.getPassword());
    }

    void authenticateRS(String username, String password) throws AuthenticationException {
        try {
            rsLdap.getLdapTemplate().getContextSource().getContext(username, password);
            log.debug("Authentication for domain rs success: {}", username);
        } catch (org.springframework.ldap.AuthenticationException e) {
            log.debug("Authentication for domain rs is failed: {}", username);
            throw new BadCredentialsException("Bad username or password", e);
        }
    }

    void authenticateRegion(String username, String password) throws AuthenticationException {
        try {
            regionLdap.getLdapTemplate().getContextSource().getContext(username, password);
            log.debug("Authentication for domain region success: {}", username);
        } catch (org.springframework.ldap.AuthenticationException e) {
            log.debug("Authentication for domain region is failed: {}", username);
            throw new BadCredentialsException("Bad username or password", e);
        }
    }
}
