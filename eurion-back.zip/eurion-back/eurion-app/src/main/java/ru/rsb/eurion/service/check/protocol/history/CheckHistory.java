package ru.rsb.eurion.service.check.protocol.history;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class CheckHistory {

    private Integer blankId;

    private Integer skillGroupId;

    private String declineCategoryName;

    private String declineReasonName;

    private String result;

    private LocalDateTime resultDate;

    private String comment;

    private String fullName;

    private BigDecimal income;

    private String code;
}
