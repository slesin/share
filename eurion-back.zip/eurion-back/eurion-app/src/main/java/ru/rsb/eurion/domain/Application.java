package ru.rsb.eurion.domain;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.service.application.StatusCode;
import ru.rsb.eurion.service.application.flow.TaskInfo;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Заявка
 */
@Getter
@Setter
public class Application {

    private Long id;
    /**
     * Уникальный идентификатор заявки
     */
    private Long blankId;
    /**
     * Дата и время создания заявки
     */
    private LocalDateTime created;
    /**
     * Время в работе
     */
    private Long elapsed;
    /**
     * Исходный объект "Заявка"
     */
    @NotNull
    @Valid
    private JsonNode data;
    /**
     * Описания форм
     */
    private List<FormDefinition> formDefinitions;
    /**
     * Значения форм
     */
    private List<FormConclusion> formConclusions;
    /**
     * Информация о форме редактирования
     */
    private TaskInfo taskInfo;
    /**
     * Статус заявки
     */
    private String status;

    private LocalDateTime version;
    /**
     * Пользователь, на которого назначена заявка
     */
    private Integer userId;

    private List<CallHistory> callHistoryList;

    private boolean readonly;

    private JsonNode incomeInfo;

    private String processStatus;

    private String processUserName;

    private StatusCode processStatusCode;
    /**
     * Признак проверки на мошенничество
     */
    private boolean fraud;
    /**
     * Комментарии к отдельным полям заявки.
     */
    private Map<String, String> fieldComments;
    /**
     * Можно ли звонить клиенту
     */
    private boolean isPhoneTime;

    private RtdmPriority rtdmPriority;

    private List<ApplicationVersionInfo> versionInfos;

    private VersionInterval versionInterval;

    private SkillGroup skillGroup;

    public List<FormDefinition> getFormDefinitions() {
        if (formDefinitions == null) {
            formDefinitions = new ArrayList<>();
        }
        return formDefinitions;
    }

    public List<FormConclusion> getFormConclusions() {
        if (formConclusions == null) {
            formConclusions = new ArrayList<>();
        }
        return formConclusions;
    }

    public Map<String, String> getFieldComments() {
        if (fieldComments == null) {
            fieldComments = new HashMap<>();
        }
        return fieldComments;
    }

    public List<ApplicationVersionInfo> getVersionInfos() {
        if (versionInfos == null) {
            versionInfos = new ArrayList<>();
        }
        return versionInfos;
    }
}
