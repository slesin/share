package ru.rsb.eurion.service.application.flow.api;

import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.service.admin.users.UserService;
import ru.rsb.eurion.service.application.ApplicationService;
import ru.rsb.eurion.service.application.DecisionCommentNotifier;
import ru.rsb.eurion.service.application.StatusCode;
import ru.rsb.eurion.service.application.history.ApplicationHistoryService;

import javax.annotation.Nonnull;

@SuppressWarnings("unused")
@Service("statusTask")
@Transactional
@Slf4j
@AllArgsConstructor
public class SetupStatusTask {
    private final ApplicationHistoryService applicationHistoryService;
    private final ApplicationService applicationService;
    private final UserService userService;
    private final DecisionCommentNotifier decisionCommentNotifier;

    public void setup(@NonNull @Nonnull Long applicationId,
                      @NonNull @Nonnull String status,
                      @NonNull @Nonnull String currentUserName) {
        StatusCode category;
        switch (status) {
            case "Новая":
                category = StatusCode.NEW;
                break;

            case "В очереди":
                category = StatusCode.QUEUE;
                break;

            case "Назначено":
                category = StatusCode.ASSIGNED;
                break;

            case "В работе":
                category = StatusCode.IN_WORK;
                break;

            case "Отложено":
                category = StatusCode.POSTPONED;
                break;

            case "Пересчет":
                category = StatusCode.RECOUNT;
                break;

            case "Доработка":
                category = StatusCode.REWORK;
                break;

            case "Одобрено":
            case "Отклонено":
            case "Отозвано RTDM":
            case "Отозвано":
                category = StatusCode.COMPLETED;
                break;
            default:
                category = StatusCode.NEW;
        }

        this.setup(applicationId, status, category, currentUserName, null);
    }

    public void setup(@NonNull @Nonnull Long applicationId,
                      @NonNull @Nonnull String status,
                      @NonNull @Nonnull String categoryStr,
                      @NonNull @Nonnull String currentUserName) {
        StatusCode category = StatusCode.valueOf(categoryStr);
        setup(applicationId, status, category, currentUserName, null);
    }

    public void setup(@NonNull @Nonnull Long applicationId,
                      @NonNull @Nonnull String status,
                      @NonNull @Nonnull String categoryStr,
                      @NonNull @Nonnull String currentUserName,
                      String decisionComment) {
        StatusCode category = StatusCode.valueOf(categoryStr);
        setup(applicationId, status, category, currentUserName, decisionComment);
    }

    private void setup(@Nonnull @NonNull Long applicationId,
                       @Nonnull @NonNull String status,
                       StatusCode category,
                       @NonNull @Nonnull String currentUserName,
                       String decisionComment) {
        ApplicationEntity entity = applicationService.findById(applicationId);

        String assignBySupervisor = getAssignUser(entity, category, currentUserName);
        applicationService.updateStatus(applicationId, status, category, assignBySupervisor);
        String oldStatus = entity.getStatus();
        applicationHistoryService.saveStatusHistory(applicationId, oldStatus, status, currentUserName);
        applicationHistoryService.saveApplicationStatusHistory(applicationId, currentUserName, status, category,
                decisionComment, entity.getDeclineReasonIds());
        log.info("Set up status: id={}, status={}", applicationId, status);
        if (!StringUtils.isBlank(decisionComment)) {
            log.info("Saving decision comment to Client System");
            decisionCommentNotifier.saveComment(entity, decisionComment);
        }
    }

    private String getAssignUser(ApplicationEntity entity, StatusCode statusCode, String currentUserName) {
        switch (statusCode) {
            case ASSIGNED:
                User user = userService.findByUserName(currentUserName);
                return user != null ? user.getName() : currentUserName;
            case QUEUE:
                return null;
            default:
                return entity.getAssignBySupervisor();
        }
    }
}
