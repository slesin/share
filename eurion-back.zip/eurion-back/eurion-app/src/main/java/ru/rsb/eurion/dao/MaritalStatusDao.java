package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.MaritalStatus;

import java.util.List;

@Mapper
public interface MaritalStatusDao {

    @Select("select " +
            "  IND, " +
            "  NAME, " +
            "  SCORIND, " +
            "  DATECHANGE, " +
            "  ACTIV, " +
            "  IDCOUNTRY, " +
            "  CODEID " +
            "from MARITAL_STATUS")
    @Results(id = "maritalStatusMapping", value = {
            @Result(property = "id", column = "IND"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "scoringId", column = "SCORIND"),
            @Result(property = "updatedAt", column = "DATECHANGE"),
            @Result(property = "active", column = "ACTIV"),
            @Result(property = "countryId", column = "IDCOUNTRY"),
            @Result(property = "codeId", column = "CODEID")
    })
    List<MaritalStatus> findAll();

    @Select("select * from MARITAL_STATUS where IND = #{id}")
    @ResultMap("maritalStatusMapping")
    MaritalStatus findById(Integer id);
}
