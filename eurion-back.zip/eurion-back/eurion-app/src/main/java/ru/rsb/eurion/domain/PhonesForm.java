package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Форма телефоны
 */
@Getter
@Setter
public class PhonesForm extends BasicForm {
    /**
     * Телефоны
     */
    private List<PhoneRecord> phoneRecords;
    /**
     * Пересечения телефонов
     */
    private List<CrossPhone> crossPhones;
    /**
     * Иные телефоны
     */
    private List<PhoneRecord> otherPhones;
    /**
     * Журналы прозвонов и результатов
     */
    private List<CallJournal> callJournals;

    /**
     * Личные адреса электронной почты
     */
    private List<String> emails;
    /**
     * Рейтинг доверия - телефоны
     */
    private Integer trustRating;

}
