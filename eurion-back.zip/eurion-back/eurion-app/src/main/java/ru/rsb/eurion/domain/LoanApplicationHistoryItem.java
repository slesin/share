package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Обращение за кредитом
 */
@Getter
@Setter
public class LoanApplicationHistoryItem {
    /**
     * Тип продукта
     */
    private ProductType productType;
    /**
     * Сумма
     */
    private BigDecimal amount;
    /**
     * Срок в днях
     */
    private Integer periodInDays;
    /**
     * Дата открытия
     */
    private LocalDate created;
    /**
     * Статус
     */
    private String status;
    /**
     * Канал обращения
     */
    private InboundChannel inboundChannel;
    /**
     * Регион выдачи
     */
    private Region region;
}
