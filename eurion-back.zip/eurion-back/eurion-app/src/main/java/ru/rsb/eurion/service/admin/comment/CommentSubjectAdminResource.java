package ru.rsb.eurion.service.admin.comment;


import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.CommentSubject;
import ru.rsb.eurion.service.admin.Consts;
import ru.rsb.eurion.service.comment.CommentSubjectService;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@RequestMapping(path = Consts.ADMIN_API_BASE + "/application/comment/subject", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class CommentSubjectAdminResource {

    private final CommentSubjectService service;

    @PostMapping(path = "/create")
    public CommentSubject create(@NotNull @Valid @RequestBody CommentSubject subject) {
        return service.create(subject);
    }

    @PostMapping(path = "/update")
    public CommentSubject update(@NotNull @Valid @RequestBody CommentSubject reasonTemplate) {
        return service.update(reasonTemplate);
    }

    @PostMapping("/delete/")
    public void delete(@RequestBody @NotNull List<Integer> ids) {
        service.delete(ids);
    }

}
