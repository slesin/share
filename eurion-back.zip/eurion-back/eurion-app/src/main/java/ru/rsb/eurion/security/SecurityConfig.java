package ru.rsb.eurion.security;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecurityConfig {
    private String ldapUrl;
    private String baseDn;
    private String username;
    private String password;
    private String userSearchBase;
    private String domain;
}
