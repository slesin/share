package ru.rsb.eurion.service.admin.check.protocol.form.definition;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.CheckItemDefinition;
import ru.rsb.eurion.domain.CheckItemElement;
import ru.rsb.eurion.domain.CheckItemValue;
import ru.rsb.eurion.domain.Form;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.CollectionUtils;
import ru.rsb.eurion.service.admin.check.protocol.item.definition.CheckItemDefinitionDao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@AllArgsConstructor
public class FormDefinitionService {

    private static final String NOT_FOUND_MSG = "Описание формы отсутствует";
    private static final String EXCEPTION_CODE = "formDefinition";

    private final FormDefinitionDao dao;
    private final CheckItemDefinitionDao checkItemDefinitionDao;

    public FormDefinition findOneBySkillGroup(Integer id, Integer skillGroupId) {
        FormDefinition formDefinition = dao.findOne(id);
        List<CheckItemDefinition> definitions = checkItemDefinitionDao.getCheckItemDefinitions(skillGroupId,
                formDefinition.getForm().getId());
        formDefinition.setCheckItemDefinitions(definitions);
        return formDefinition;
    }

    public List<FormDefinition> getFormDefinitionList(Integer skillGroupId) {
        List<FormDefinition> formDefinitions = dao.listFormDefinitionBySkillGroup(skillGroupId);
        for (FormDefinition formDefinition : formDefinitions) {
            List<CheckItemDefinition> definitions = checkItemDefinitionDao.getActiveCheckItemDefinitions(skillGroupId,
                    formDefinition.getForm().getId());

            // фильтруем
            definitions.forEach(checkItemDefinition -> {
                List<CheckItemElement> filteredElements = checkItemDefinition.getItems().stream()
                        .filter(checkItemElement -> !checkItemElement.isDisabled())
                        .collect(Collectors.toList());

                filteredElements.forEach(checkItemElement -> {
                    List<CheckItemValue> filteredValues = checkItemElement.getItemValueList().stream()
                            .filter(checkItemValue -> !checkItemValue.isDisabled())
                            .collect(Collectors.toList());
                    checkItemElement.setItemValueList(filteredValues);
                });

                checkItemDefinition.setItems(filteredElements);
            });

            formDefinition.setCheckItemDefinitions(definitions);
        }
        return formDefinitions;
    }

    public FormDefinition create(Integer skillGroupId, FormDefinition formDefinition) {
        FormDefinition formDef = dao.findOneByFormId(formDefinition.getForm().getId(), skillGroupId);
        if (formDef == null) {
            dao.createFormDefinition(formDefinition, skillGroupId);
        }
        for (CheckItemDefinition checkItemDefinition : formDefinition.getCheckItemDefinitions()) {
            dao.addCheckItemDefinitionToForm(skillGroupId, formDefinition.getForm().getId(), checkItemDefinition.getId());
        }
        return findOneBySkillGroup(formDefinition.getId(), skillGroupId);
    }

    public List<FormDefinition> getListBySkillGroup(Integer skillGroupId) {
        List<FormDefinition> formDefinitions = dao.listFormDefinitionBySkillGroup(skillGroupId);
        for (FormDefinition formDefinition : formDefinitions) {
            List<CheckItemDefinition> checkItemDefinitions = checkItemDefinitionDao.getCheckItemDefinitions(skillGroupId,
                    formDefinition.getForm().getId());
            formDefinition.setCheckItemDefinitions(checkItemDefinitions);
        }
        return formDefinitions;
    }

    public List<FormDefinition> getList() {
        return dao.list();
    }

    public FormDefinition update(Integer formDefinitionId, Integer skillGroupId, FormDefinition formDefinition) throws BusinessException {
        FormDefinition oldFormDefinition = findOneBySkillGroup(formDefinitionId, skillGroupId);
        if (oldFormDefinition == null) {
            throw new BusinessException(EXCEPTION_CODE, NOT_FOUND_MSG);
        }
        List<CheckItemDefinition> oldCheckItemDefinitions = oldFormDefinition.getCheckItemDefinitions();
        dao.updateFormDefinition(formDefinitionId, formDefinition, LocalDateTime.now(), skillGroupId);

        CollectionUtils.mergeList(oldCheckItemDefinitions, formDefinition.getCheckItemDefinitions(), BasicReference::getId,
                checkItemDefinition -> {
                    dao.addCheckItemDefinitionToForm(skillGroupId, formDefinition.getForm().getId(), checkItemDefinition.getId());
                    return checkItemDefinition;
                },
                checkItemDefinition ->
                        dao.deleteCheckItemDefinitionFromForm(skillGroupId, formDefinition.getForm().getId(), checkItemDefinition.getId()),
                null);

        return findOneBySkillGroup(formDefinitionId, skillGroupId);
    }

    public void disableBySkillGroup(Integer id, Integer skillGroupId) {
        FormDefinition formDefinition = dao.findOne(id);
        Form form = formDefinition.getForm();
        Integer formId = form.getId();
        List<CheckItemDefinition> checkItemDefinitions = checkItemDefinitionDao.getCheckItemDefinitions(skillGroupId, formId);
        formDefinition.setCheckItemDefinitions(checkItemDefinitions);
        dao.disableFormForSkillGroup(formId, skillGroupId);
        for (CheckItemDefinition item : formDefinition.getCheckItemDefinitions()) {
            dao.deleteCheckItemDefinitionFromForm(skillGroupId, formId, item.getId());
        }
    }

}
