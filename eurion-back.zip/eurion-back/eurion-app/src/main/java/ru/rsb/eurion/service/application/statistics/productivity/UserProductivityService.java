package ru.rsb.eurion.service.application.statistics.productivity;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.ProductivitySettingsDao;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.LoginLogoutTime;
import ru.rsb.eurion.domain.Role;
import ru.rsb.eurion.domain.RoleProductivitySettings;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserApproveLevel;
import ru.rsb.eurion.domain.UserDecision;
import ru.rsb.eurion.domain.UserStatusHistory;
import ru.rsb.eurion.domain.UserTimeInStatus;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.CollectionUtils;
import ru.rsb.eurion.service.admin.users.UserDao;
import ru.rsb.eurion.service.admin.users.status.UserStatusHistoryDao;
import ru.rsb.eurion.service.admin.users.subdivision.OrgTreeNode;
import ru.rsb.eurion.service.admin.users.subdivision.SubdivisionService;
import ru.rsb.eurion.service.application.history.ApplicationHistoryDao;
import ru.rsb.eurion.service.application.statistics.productivity.dto.SkillRoleProductivitySettings;
import ru.rsb.eurion.service.application.statistics.productivity.dto.UserApproveLevelInfo;
import ru.rsb.eurion.service.application.statistics.productivity.dto.UserProductivity;
import ru.rsb.eurion.service.application.statistics.productivity.dto.UserProductivityByTime;
import ru.rsb.eurion.settings.AppConfig;
import ru.rsb.eurion.settings.AppConfigFactory;
import ru.rsb.eurion.settings.AppConfigNotifyConsumer;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static ru.rsb.eurion.domain.StatusType.ABSENT;
import static ru.rsb.eurion.service.admin.users.subdivision.SubdivisionService.NON_STATISTICS_SUBDIVISION_ID;

@Slf4j
@RequiredArgsConstructor
@Service
@Transactional
public class UserProductivityService {
    private static final BigDecimal MILLIS_PER_HOUR = BigDecimal.valueOf(3600000);

    private final UserDao userDao;
    private final ApplicationHistoryDao applicationHistoryDao;
    private final AppConfig appConfig;
    private final ProductivitySettingsDao productivitySettingsDao;
    private final AppConfigFactory appConfigFactory;
    private final AppConfigNotifyConsumer notifyConsumer;
    private final UserStatusHistoryDao userStatusHistoryDao;
    private final SubdivisionService subdivisionService;

    public SkillRoleProductivitySettings getProductivitySettings() {
        SkillRoleProductivitySettings settings = new SkillRoleProductivitySettings();
        Integer planedDecisionCount = appConfig.getPlanedDecisionCount();
        settings.setPlanedDecisionCount(planedDecisionCount);
        List<RoleProductivitySettings> roleSettings = productivitySettingsDao.list();
        settings.setRoleProductivitySettings(roleSettings);
        return settings;
    }

    public SkillRoleProductivitySettings setProductivitySettings(SkillRoleProductivitySettings settings) {
        Integer oldPlanedDecisionCount = appConfig.getPlanedDecisionCount();
        Integer newPlanedDecisionCount = settings.getPlanedDecisionCount();
        if (oldPlanedDecisionCount != null && !oldPlanedDecisionCount.equals(newPlanedDecisionCount)) {
            appConfigFactory.updatePlanedDecisionCount(newPlanedDecisionCount);
            notifyConsumer.notifyOnChange();
        }
        List<RoleProductivitySettings> oldSettings = productivitySettingsDao.list();
        List<RoleProductivitySettings> newSettings = settings.getRoleProductivitySettings();
        CollectionUtils.mergeList(oldSettings, newSettings, RoleProductivitySettings::getRoleId,
                item -> {
                    item.setCreatedAt(LocalDateTime.now());
                    productivitySettingsDao.create(item);
                    return item;
                },
                null,
                (oldValue, newItem) -> {
                    if (!oldValue.equals(newItem)) {
                        oldValue.setApprovePercent(newItem.getApprovePercent());
                        oldValue.setStepPercent(newItem.getStepPercent());
                        oldValue.setProductionRatePercent(newItem.getProductionRatePercent());
                        oldValue.setProductionRatePerHour(newItem.getProductionRatePerHour());
                        oldValue.setUpdatedAt(LocalDateTime.now());
                        oldValue.setDisabledAt(newItem.getDisabledAt());
                        productivitySettingsDao.update(oldValue);
                    }
                });
        return getProductivitySettings();
    }

    public UserApproveLevelInfo getApprovalLevel(Integer skillGroupRoleId) throws BusinessException {
        Set<Integer> userIds = getUserIds();
        return getUserApproveLevelInfo(userIds, skillGroupRoleId);
    }

    public UserProductivity getProductivity() throws BusinessException {
        Set<Integer> userIds = getUserIds();
        return getUserProductivityInfo(userIds);
    }

    public OrgTreeNode getProductivityItemTree(Integer subdivisionId, LocalDate reportDate) throws BusinessException {
        List<User> users = userDao.listBySubdivision(subdivisionId, NON_STATISTICS_SUBDIVISION_ID);
        List<UserProductivityByTime> productivityByTime = getUserProductivityByTime(users, reportDate);
        return subdivisionService.getProductivityItemTree(productivityByTime, users, subdivisionId);
    }

    private List<UserProductivityByTime> getUserProductivityByTime(List<User> users, LocalDate reportDate) {
        if (users.isEmpty()) {
            return Collections.emptyList();
        }
        LocalDateTime beginDateTime = LocalDateTime.of(reportDate, LocalTime.MIN);
        LocalDateTime endDateTime = LocalDateTime.of(reportDate, LocalTime.MAX);
        LocalDateTime now = LocalDateTime.now();
        if (now.isBefore(endDateTime)) {
            endDateTime = now;
        }

        Set<Integer> userIds = users.stream()
                .map(BasicReference::getId)
                .collect(Collectors.toSet());

        List<UserTimeInStatus> userTimeInStatusList =
                userStatusHistoryDao.getUserTimeInStatus(userIds, beginDateTime, endDateTime);

        Map<Integer, List<UserTimeInStatus>> userStatusMap = userTimeInStatusList.stream()
                .collect(Collectors.groupingBy(UserTimeInStatus::getUserId, Collectors.toList()));

        List<LoginLogoutTime> loginLogoutTimeList =
                userStatusHistoryDao.getLoginLogoutTime(userIds, beginDateTime, endDateTime);

        Map<Integer, List<LoginLogoutTime>> loginInfoMap = loginLogoutTimeList.stream()
                .collect(Collectors.groupingBy(LoginLogoutTime::getUserId, Collectors.toList()));

        Map<Integer, UserDecision> userDecisionMap =
                applicationHistoryDao.getSummaryDecisionByUserIds(beginDateTime, endDateTime, userIds).stream()
                        .collect(Collectors.toMap(UserDecision::getUserId, Function.identity()));

        return users.stream()
                .map(user -> mapUserProductivityByTime(userStatusMap, loginInfoMap, userDecisionMap, user))
                .collect(Collectors.toList());
    }

    @Nonnull
    private UserProductivityByTime mapUserProductivityByTime(Map<Integer, List<UserTimeInStatus>> userStatusMap,
                                                             Map<Integer, List<LoginLogoutTime>> loginInfoMap,
                                                             Map<Integer, UserDecision> userDecisionMap,
                                                             User user) {
        UserProductivityByTime productivity = new UserProductivityByTime();
        productivity.setUserId(user.getId());
        productivity.setFullName(user.getName());
        List<UserTimeInStatus> timeInStatusList = userStatusMap.get(user.getId());
        if (timeInStatusList != null) {
            addStatusTime(productivity, timeInStatusList);
        }
        List<LoginLogoutTime> loginInfoList = loginInfoMap.get(user.getId());
        if (loginInfoList != null) {
            addLogOutInfo(productivity, loginInfoList);
        }
        BigDecimal decisionCount = getDecisionCount(userDecisionMap, user.getId());
        addApplicationPerHour(productivity, decisionCount);
        addAverageTimePerApplication(productivity, decisionCount);
        addProductivityPercent(productivity, decisionCount);
        UserStatusHistory statusHistory = user.getStatusHistory();
        if (statusHistory != null) {
            productivity.setStatus(statusHistory.getStatus().getName());
        }
        return productivity;
    }

    private BigDecimal getDecisionCount(Map<Integer, UserDecision> userDecisionMap, Integer userId) {
        UserDecision decisionInfo = userDecisionMap.get(userId);
        BigDecimal decisionCount = BigDecimal.ZERO;
        if (decisionInfo != null && decisionInfo.getDecisionCount() != null) {
            decisionCount = BigDecimal.valueOf(decisionInfo.getDecisionCount());
        }
        return decisionCount;
    }

    private Set<Integer> getOperatorIds(Integer supervisorId) {
        List<User> operators = userDao.listOperators(supervisorId);
        return operators.stream()
                .map(BasicReference::getId)
                .collect(Collectors.toSet());
    }

    private UserProductivity getUserProductivityInfo(Set<Integer> userIds) {
        LocalDate dateNow = LocalDate.now();
        LocalDateTime beginDateTime = LocalDateTime.of(dateNow, LocalTime.MIN);
        LocalDateTime endDateTime = LocalDateTime.of(dateNow, LocalTime.MAX);
        List<UserDecision> userDecisionList =
                applicationHistoryDao.getSummaryDecisionByUserIds(beginDateTime, endDateTime, userIds);
        UserProductivity userProductivityInfo = new UserProductivity();
        userProductivityInfo.setUserDecisionInfoList(userDecisionList);
        Integer planedDecisionCount = appConfig.getPlanedDecisionCount();
        userProductivityInfo.setPlannedCountDecision(planedDecisionCount);
        return userProductivityInfo;
    }

    private UserApproveLevelInfo getUserApproveLevelInfo(Set<Integer> userIds, Integer skillGroupRoleId) {
        LocalDate dateNow = LocalDate.now();
        LocalDateTime beginDateTime = LocalDateTime.of(dateNow, LocalTime.MIN);
        LocalDateTime endDateTime = LocalDateTime.of(dateNow, LocalTime.MAX);
        List<UserApproveLevel> userApproveLevelList =
                applicationHistoryDao.getSummaryApproveByUserIds(beginDateTime, endDateTime, userIds, skillGroupRoleId);
        UserApproveLevelInfo userApproveLevelInfo = new UserApproveLevelInfo();
        userApproveLevelInfo.setUserDecisionInfoList(userApproveLevelList);
        BigDecimal plannedApprovePercent = BigDecimal.ZERO;
        BigDecimal stepPercent = BigDecimal.ZERO;
        BigDecimal productionRatePercent = BigDecimal.ZERO;
        if (userApproveLevelList != null && !userApproveLevelList.isEmpty()) {
            plannedApprovePercent = userApproveLevelList.get(0).getPlannedApprovePercent();
            plannedApprovePercent = plannedApprovePercent != null ? plannedApprovePercent : BigDecimal.ZERO;
            stepPercent = userApproveLevelList.get(0).getStepPercent();
            stepPercent = stepPercent != null ? stepPercent : BigDecimal.ZERO;
            productionRatePercent = userApproveLevelList.get(0).getProductionRatePercent();
            productionRatePercent = productionRatePercent != null ? productionRatePercent : BigDecimal.ZERO;
        }
        userApproveLevelInfo.setPlannedApprovalPercent(plannedApprovePercent);
        userApproveLevelInfo.setStepPercent(stepPercent);
        userApproveLevelInfo.setProductionRatePercent(productionRatePercent);
        return userApproveLevelInfo;
    }


    private void addStatusTime(UserProductivityByTime productivity, List<UserTimeInStatus> timeInStatusList) {
        timeInStatusList.forEach(userTimeInStatus -> {
            switch (userTimeInStatus.getStatusCode()) {
                case WORK:
                    productivity.setWorkTime(userTimeInStatus.getTimeInStatus());
                    break;
                case ABSENT:
                    productivity.setAbsentTime(userTimeInStatus.getTimeInStatus());
                    break;
                case DINNER:
                    productivity.setDinnerTime(userTimeInStatus.getTimeInStatus());
                    break;
                case BREAK:
                    productivity.setBreakTime(userTimeInStatus.getTimeInStatus());
                    break;
                case TRAINING:
                    productivity.setTrainingTime(userTimeInStatus.getTimeInStatus());
                    break;
                case MEETING:
                    productivity.setMeetingTime(userTimeInStatus.getTimeInStatus());
                    break;
                case WORK_WITHOUT_APPLICATION:
                    productivity.setAdditionalWorkWithOutApplicationTime(userTimeInStatus.getTimeInStatus());
                    break;
                default:
                    log.warn("Unknown user status code: " + userTimeInStatus.getStatusCode());
            }
        });
    }

    private void addLogOutInfo(UserProductivityByTime productivity, List<LoginLogoutTime> loginInfoList) {
        LoginLogoutTime logout = loginInfoList.stream()
                .filter(info -> info.getStatusCode() == ABSENT)
                .findFirst()
                .orElse(null);
        LocalTime logoutTime = logout != null ? logout.getUpdatedAt() : null;
        productivity.setLogoutAt(logoutTime);

        loginInfoList.remove(logout);

        LoginLogoutTime firstLogin = loginInfoList.stream()
                .min(Comparator.comparing(LoginLogoutTime::getUpdatedAt))
                .orElse(null);

        LocalTime firstLoginTime = firstLogin != null ? firstLogin.getUpdatedAt() : null;
        productivity.setLoginAt(firstLoginTime);

        loginInfoList.remove(firstLogin);

        if (!loginInfoList.isEmpty()) {
            LoginLogoutTime lastLogin = loginInfoList.get(0);
            productivity.setLastLoginAt(lastLogin.getUpdatedAt());
        } else {
            productivity.setLastLoginAt(productivity.getLoginAt());
        }
    }

    private void addApplicationPerHour(UserProductivityByTime productivity, BigDecimal decisionCount) {
        if (BigDecimal.ZERO.compareTo(decisionCount) >= 0) {
            return;
        }
        Optional.ofNullable(productivity.getWorkTime())
                .filter(duration -> duration.compareTo(Duration.ZERO) > 0)
                .ifPresent(duration -> {
                    BigDecimal workTime = BigDecimal.valueOf(duration.toMillis());
                    BigDecimal result =
                            decisionCount.multiply(MILLIS_PER_HOUR).divide(workTime, 3, BigDecimal.ROUND_HALF_UP);
                    productivity.setApplicationDecisionPerHour(result);
                });
    }

    private void addAverageTimePerApplication(UserProductivityByTime productivity, BigDecimal decisionCount) {
        if (BigDecimal.ZERO.compareTo(decisionCount) >= 0) {
            return;
        }
        Optional.ofNullable(productivity.getWorkTime())
                .filter(duration -> duration.compareTo(Duration.ZERO) > 0)
                .ifPresent(duration -> {
                    Duration durationPerApplication = duration.dividedBy(decisionCount.longValue());
                    productivity.setAverageTimePerApplication(durationPerApplication);
                });
    }

    private void addProductivityPercent(UserProductivityByTime productivity, BigDecimal decisionCount) {
        Integer planedDecisionCount = appConfig.getPlanedDecisionCount();
        BigDecimal divisor = BigDecimal.valueOf(planedDecisionCount);
        BigDecimal productivityValue = decisionCount.divide(divisor, 2, BigDecimal.ROUND_FLOOR)
                .multiply(BigDecimal.valueOf(100));
        productivity.setProductivityPercent(productivityValue);
    }

    private Set<Integer> getUserIds() throws BusinessException {
        Integer userId = AuthUtil.loggedUser().getId();
        User user = userDao.findById(userId);
        if (user != null && user.getRoles().contains(Role.SUPERVISOR)) {
            Set<Integer> userIds = getOperatorIds(userId);
            userIds.add(userId);
            return userIds;
        }

        if (user != null && user.getSupervisor() != null) {
            Integer supervisorId = user.getSupervisor().getId();
            return getOperatorIds(supervisorId);
        }
        throw new BusinessException("user_role", "Пользователь ни андеррайтер и ни супервайзер");
    }
}
