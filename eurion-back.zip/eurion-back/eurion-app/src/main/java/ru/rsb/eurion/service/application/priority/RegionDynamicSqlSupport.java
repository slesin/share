package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;

public class RegionDynamicSqlSupport {
    public static final RegionTable REGION_TABLE = new RegionTable();

    public static final SqlColumn<String> REGION_CODE = REGION_TABLE.column("CODE", JDBCType.VARCHAR);
    public static final SqlColumn<Integer> RAW_OFFSET = REGION_TABLE.column("RAW_OFFSET", JDBCType.VARCHAR);

    private static final class RegionTable extends SqlTable {
        RegionTable() {
            super("REGION");
        }
    }
}
