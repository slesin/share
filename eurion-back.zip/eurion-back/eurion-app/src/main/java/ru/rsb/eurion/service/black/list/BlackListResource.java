package ru.rsb.eurion.service.black.list;

import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping(path = EurionApplication.API_BASE + "/black-list")
@RestController
@AllArgsConstructor
public class BlackListResource {

    private final BlackListService service;

    @GetMapping(path = "/{clientId}/{listType}", produces = APPLICATION_JSON_VALUE)
    public byte[] list(@NonNull @PathVariable("clientId") Integer clientId,
                       @NonNull @PathVariable("listType") Integer listType) {
        return service.getBlackList(clientId, listType);
    }

}
