package ru.rsb.eurion.security;

import org.springframework.context.annotation.Primary;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.stereotype.Component;

@Component
@Primary
public class LdapHelper {

    private final SecurityConfig config;
    private LdapTemplate ldapTemplate;

    public LdapHelper(SecurityConfig config) {
        this.config = config;
        this.ldapTemplate = createLdapTemplate(this.config);
    }

    LdapTemplate getLdapTemplate() {
        return ldapTemplate;
    }

    String getUserSearchBase() {
        return config.getUserSearchBase();
    }

    public String getDomain() {
        return config.getDomain();
    }

    public String getUsername() {
        return config.getUsername();
    }

    public String getPassword() {
        return config.getPassword();
    }

    private static LdapTemplate createLdapTemplate(SecurityConfig cc) {
        LdapContextSource ldapContextSource = new LdapContextSource();
        ldapContextSource.setUrl(cc.getLdapUrl());
        ldapContextSource.setBase(cc.getBaseDn());
        ldapContextSource.setUserDn(cc.getUsername());
        ldapContextSource.setPassword(cc.getPassword());
        ldapContextSource.afterPropertiesSet();
        return new LdapTemplate(ldapContextSource);
    }
}
