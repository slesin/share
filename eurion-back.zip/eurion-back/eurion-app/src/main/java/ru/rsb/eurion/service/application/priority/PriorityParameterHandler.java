package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SortSpecification;
import ru.rsb.eurion.domain.priority.PriorityParameter;

import java.util.function.Function;

public interface PriorityParameterHandler extends Function<PriorityParameter, SortSpecification> {

    /**
     * Флаг, означающий, что параметр учитывается при сортировке общего списка без привязки к оператору
     */
    boolean isCommon();
}
