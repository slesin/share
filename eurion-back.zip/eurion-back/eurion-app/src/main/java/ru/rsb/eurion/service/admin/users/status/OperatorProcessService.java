package ru.rsb.eurion.service.admin.users.status;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.flowable.common.engine.api.FlowableException;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.runtime.ProcessInstance;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.SessionStoreFilter;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class OperatorProcessService {

    private final RuntimeService runtimeService;
    private final TaskService taskService;

    public void setupStatusAndRole(@NonNull @Nonnull Integer userId,
                                   @NonNull @Nonnull String role,
                                   @NonNull @Nonnull String statusCode) {

        List<ProcessInstance> list = runtimeService.createProcessInstanceQuery()
                .processInstanceBusinessKey(FlowAPI.idToBusinessKey(userId))
                .processDefinitionKey(FlowAPI.DEFINITION_KEY)
                .list();

        Map<String, Object> variables = new HashMap<>();
        variables.put(FlowAPI.USER_ID, userId);
        variables.put(FlowAPI.SESSION_ID, SessionStoreFilter.takeSessionId());
        variables.put(FlowAPI.ROLE, role);
        variables.put(FlowAPI.STATUS, statusCode);

        if (list.isEmpty()) {
            runtimeService.startProcessInstanceByKey(FlowAPI.DEFINITION_KEY, FlowAPI.idToBusinessKey(userId), variables);
            return;
        }
        taskService.createTaskQuery()
                .processInstanceBusinessKey(FlowAPI.idToBusinessKey(userId))
                .processDefinitionKey(FlowAPI.DEFINITION_KEY)
                .list()
                .forEach(task -> taskService.complete(task.getId(), variables));
    }

    public void stop(@NonNull @Nonnull Integer userId) {
        runtimeService.createExecutionQuery()
                .processDefinitionKey(FlowAPI.DEFINITION_KEY)
                .processInstanceBusinessKey(FlowAPI.idToBusinessKey(userId), true)
                .messageEventSubscriptionName(FlowAPI.LOGOUT_MESSAGE)
                .list()
                .stream()
                .<Runnable>map(execution ->
                        () -> runtimeService.messageEventReceived(FlowAPI.LOGOUT_MESSAGE, execution.getId()))
                .forEach(this::executeWithErrorSuppression);

        runtimeService.createProcessInstanceQuery()
                .processDefinitionKey(FlowAPI.DEFINITION_KEY)
                .processInstanceBusinessKey(FlowAPI.idToBusinessKey(userId))
                .list()
                .stream()
                .<Runnable>map(processInstance ->
                        () -> runtimeService.deleteProcessInstance(processInstance.getId(), "force_logout"))
                .forEach(this::executeWithErrorSuppression);
    }

    private void executeWithErrorSuppression(Runnable runnable) {
        try {
            runnable.run();
        } catch (FlowableException e) {
            log.trace("", e);
        }
    }
}
