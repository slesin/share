package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.CreditAttractChannelDao;
import ru.rsb.eurion.dao.CreditSaleChannelDao;
import ru.rsb.eurion.dao.PriorityAmountIntervalDao;
import ru.rsb.eurion.dao.ProductPriorityDao;
import ru.rsb.eurion.dao.RegionDao;
import ru.rsb.eurion.dao.RtdmPriorityDao;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationPriorityAttributes;
import ru.rsb.eurion.domain.CreditAttractChannel;
import ru.rsb.eurion.domain.CreditSaleChannel;
import ru.rsb.eurion.domain.PriorityAmountInterval;
import ru.rsb.eurion.domain.Region;
import ru.rsb.eurion.domain.RtdmPriority;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.domain.priority.ProductSortPriority;
import ru.rsb.eurion.rtdm.application.AddApplicationRequest;
import ru.rsb.eurion.service.ClientRequestException;
import ru.rsb.eurion.service.FieldValidationException;
import ru.rsb.eurion.service.admin.skill.group.SkillGroupDao;

import java.math.BigDecimal;

@Service
@Transactional
@AllArgsConstructor
public class ApplicationMappingService {
    private static final short DEFAULT_PRIORITY = 0;

    private final ApplicationViewMapper applicationViewMapper;
    private final RegionDao regionDao;
    private final PriorityAmountIntervalDao priorityAmountIntervalDao;
    private final CreditSaleChannelDao creditSaleChannelDao;
    private final CreditAttractChannelDao creditAttractChannelDao;
    private final ProductPriorityDao productPriorityDao;
    private final SkillGroupDao skillGroupDao;
    private final RtdmPriorityDao rtdmPriorityDao;

    public void mapApplicationRequest(AddApplicationRequest request, ApplicationEntity entity) {
        applicationViewMapper.mapToApplicationEntity(request, entity);
        entity.setSource(request);

        ApplicationPriorityAttributes priorityAttributes = applicationViewMapper.mapToPriority(request);

        short regionAppPriority = takeRegionAppPriority(request, priorityAttributes.getApplicationRegionCode());
        entity.setRegionAppPriority(regionAppPriority);

        short regionClientPriority = takeRegionClientPriority(priorityAttributes.getClientKladrCode());
        entity.setRegionClientPriority(regionClientPriority);

        Short amountPriority = takeAmountPriority(priorityAttributes.getCreditAmount());
        entity.setAmountPriority(amountPriority);

        short saleChannelPriority = takeSaleChannelPriority(priorityAttributes.getSaleChannelId());
        entity.setChannelPriority(saleChannelPriority);

        short attractionChannelPriority = takeAttractChannelPriority(priorityAttributes.getAttractionChannelId());
        entity.setAttractChannelPriority(attractionChannelPriority);

        short productPriority = takeProductPriority(priorityAttributes);
        entity.setProductPriority(productPriority);

        SkillGroup skillGroup = skillGroupDao.findById(priorityAttributes.getSkillGroupId());
        if (skillGroup == null) {
            // skill group is critical to the business process
            throw new FieldValidationException(request, "requestInfo.skillGroupId",
                    "Skill group is not found for id=" + priorityAttributes.getSkillGroupId());
        }
        entity.setSkillGroup(skillGroup);

        entity.setMonthlyPaymentDate(priorityAttributes.getMonthlyPaymentDate());

        String clientRegionCode = request.getClient().getHomeAddress().getRegionCode();
        if (clientRegionCode != null && clientRegionCode.length() >= 2) {
            entity.setShortClientRegionCode(clientRegionCode.substring(0, 2));
        }

        if (request.getRequestInfo().getRtdmPriority() != null) {
            Integer rtdmPriorityId = request.getRequestInfo().getRtdmPriority();
            RtdmPriority rtdmPriority = rtdmPriorityDao.findById(rtdmPriorityId);
            if (rtdmPriority == null) {
                throw new ClientRequestException("Unknown RTDM priority ID: " + rtdmPriorityId);
            }
            entity.setRtdmPriority(rtdmPriority);
        }
    }

    private short takeProductPriority(ApplicationPriorityAttributes priorityAttributes) {
        ProductSortPriority product = productPriorityDao.findByCardTypeId(priorityAttributes.getCardTypeId());
        return (product != null ? product.getPriority() : DEFAULT_PRIORITY);
    }

    private short takeAttractChannelPriority(Integer attractionChannelId) {
        CreditAttractChannel channel = creditAttractChannelDao.findById(attractionChannelId);
        return channel != null ? channel.getPriority() : DEFAULT_PRIORITY;
    }

    private short takeSaleChannelPriority(Integer saleChannelId) {
        CreditSaleChannel saleChannel = creditSaleChannelDao.findById(saleChannelId);
        return saleChannel != null ? saleChannel.getPriority() : DEFAULT_PRIORITY;
    }

    private Short takeAmountPriority(BigDecimal creditAmount) {
        PriorityAmountInterval interval = priorityAmountIntervalDao.findByValue(creditAmount);
        return interval != null ? interval.getPriority() : DEFAULT_PRIORITY;
    }

    private short takeRegionAppPriority(AddApplicationRequest request, String regionAppCode) {
        if (regionAppCode != null) {
            Region regionApp = regionDao.findByCode(request.getRequestInfo().getRegionCode());
            return regionApp != null ? regionApp.getApplicationPriority() : DEFAULT_PRIORITY;
        }
        return DEFAULT_PRIORITY;
    }

    private short takeRegionClientPriority(String clientKladrCode) {
        if (clientKladrCode != null && clientKladrCode.length() >= 2) {
            Region regionClient = regionDao.findByCode(clientKladrCode.substring(0, 2));
            return regionClient != null ? regionClient.getClientPriority() : DEFAULT_PRIORITY;
        }
        return DEFAULT_PRIORITY;
    }
}
