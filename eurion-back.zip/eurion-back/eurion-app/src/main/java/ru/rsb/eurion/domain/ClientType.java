package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Тип клиента
 */
@Getter
@Setter
public class ClientType extends BasicReference {
}
