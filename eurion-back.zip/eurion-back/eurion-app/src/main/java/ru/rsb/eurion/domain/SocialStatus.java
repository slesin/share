package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Социальный статус
 */
@Getter
@Setter
class SocialStatus extends BasicReference {

}
