package ru.rsb.eurion.service.admin.check.protocol.form.definition;

import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.Form;
import ru.rsb.eurion.domain.FormDefinition;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface FormDefinitionDao {

    @Select("select ID, NAME, CREATED_AT, DISABLED_AT, CODE, ORDER_IDX from FORM where ID = #{id}")
    @Results(id = "formMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "orderIndex", column = "ORDER_IDX")
    })
    @SuppressWarnings("unused")
    Form getForm(@Param("id") Integer id);

    @Select("select * from CHECK_FORM_DEFINITION")
    @Results(id = "formDefinitionMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "hasRemark", column = "HAS_REMARK"),
            @Result(property = "form", column = "form_id",
                    one = @One(select = "getForm", fetchType = FetchType.EAGER)),
    })
    List<FormDefinition> list();

    @Select("select\n" +
            "  cfd.ID as id,\n" +
            "  cfd.FORM_ID,\n" +
            "  cfd.NAME,\n" +
            "  cfd.HAS_REMARK,\n" +
            "  f.CODE\n" +
            "from CHECK_FORM_DEFINITION cfd\n" +
            "  join FORM f on cfd.FORM_ID = f.ID\n" +
            "where cfd.SKILL_GROUP_ID = #{skillGroupId} and cfd.DISABLED_AT is null\n")
    @ResultMap("formDefinitionMapping")
    List<FormDefinition> listFormDefinitionBySkillGroup(@Param("skillGroupId") Integer skillGroupId);

    @Insert("insert into SKILL_FORM_CHECK (SKILL_ID, FORM_ID, CHECK_ITEM_DEFINITION_ID)\n" +
            "values (#{skillGroupId}, #{formId}, #{checkItemDefinitionId})")
    void addCheckItemDefinitionToForm(@Param("skillGroupId") Integer skillGroupId,
                                      @Param("formId") Integer formId,
                                      @Param("checkItemDefinitionId") Integer checkItemDefinitionId);

    @Delete("delete\n" +
            "from SKILL_FORM_CHECK\n" +
            "where SKILL_ID = #{skillGroupId} and FORM_ID = #{formId} and CHECK_ITEM_DEFINITION_ID = #{checkItemDefinitionId}")
    void deleteCheckItemDefinitionFromForm(@Param("skillGroupId") Integer skillGroupId,
                                           @Param("formId") Integer formId,
                                           @Param("checkItemDefinitionId") Integer checkItemDefinitionId);

    @Select("select * from CHECK_FORM_DEFINITION where ID = #{id}")
    @ResultMap("formDefinitionMapping")
    FormDefinition findOne(@Param("id") Integer id);

    @Select("select * from CHECK_FORM_DEFINITION where FORM_ID = #{formId} AND SKILL_GROUP_ID = #{skillGroupId}")
    @ResultMap("formDefinitionMapping")
    FormDefinition findOneByFormId(@Param("formId") Integer formId, @Param("skillGroupId") Integer skillGroupId);

    @Insert("insert into CHECK_FORM_DEFINITION(FORM_ID, HAS_REMARK, NAME, SKILL_GROUP_ID)\n" +
            "values (#{formDefinition.form.id}, #{formDefinition.hasRemark}, #{formDefinition.form.name}, " +
            " #{skillGroupId})")
    @SelectKey(
            keyProperty = "formDefinition.id",
            before = false,
            resultType = Integer.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_check_form_definition.currval AS id from dual"}
    )
    void createFormDefinition(@Param("formDefinition") FormDefinition formDefinition,
                              @Param("skillGroupId") Integer skillGroupId);

    @Update("update CHECK_FORM_DEFINITION\n" +
            "set FORM_ID    = #{formDefinition.form.id},\n" +
            "    HAS_REMARK = #{formDefinition.hasRemark},\n" +
            "    UPDATED_AT  = current_timestamp,\n" +
            "    DISABLED_AT = #{formDefinition.disabledAt,jdbcType=DATE},\n" +
            "    SKILL_GROUP_ID = #{skillGroupId}\n" +
            "where ID = #{id}")
    void updateFormDefinition(@Param("id") Integer id,
                              @Param("formDefinition") FormDefinition formDefinition,
                              @Param("updatedAt") LocalDateTime updated,
                              @Param("skillGroupId") Integer skillGroupId);

    @Delete("delete from CHECK_FORM_DEFINITION where FORM_ID = #{formId} and SKILL_GROUP_ID = #{skillGroupId}")
    void disableFormForSkillGroup(@Param("formId") Integer formId,
                                  @Param("skillGroupId") Integer skillGroupId);
}
