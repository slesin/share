package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import ru.rsb.eurion.EurionApplication;
import ru.rsb.eurion.domain.Application;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.RtdmDecisionEntity;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.ResultWrapper;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static ru.rsb.eurion.service.ResultType.OK;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION;

@RequestMapping(path = ApplicationResource.APPLICATION_PATH, produces = APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class ApplicationResource {

    public static final String APPLICATION_PATH = EurionApplication.API_BASE + "/application";
    public static final String REASSIGN_APPLICATION = "REASSIGN_APPLICATION";
    private static final Consumer<ApplicationEntity> EMPTY_CONSUMER = entity -> {
    };

    private final ApplicationService applicationService;
    private final RtdmDecisionService rtdmDecisionService;

    @GetMapping(path = "/{id}")
    public ResultWrapper<Application> getApplication(@PathVariable("id") Long id) {
        Application application = applicationService.getApplicationWithTakeInWork(id);
        return ResultWrapper.of(application);
    }

    @PutMapping(path = "/{id}")
    public ResultWrapper<Application> updateApplication(@PathVariable("id") Long id,
                                                        @Valid @NotNull @RequestBody Application application
    ) throws JsonProcessingException, BusinessException {
        applicationService.updateApplication(id, application, EMPTY_CONSUMER, APPLICATION);
        return ResultWrapper.of(applicationService.getApplicationWithOutTakeInWork(id));
    }

    @PutMapping(path = "/{id}/approve")
    public ResultWrapper<Application> approve(@PathVariable("id") Long id,
                                              @NotNull @RequestBody ApplicationDto applicationDto
    ) throws JsonProcessingException, BusinessException {
        String reAssignCause = applicationService.approve(id, applicationDto);
        Application application = applicationService.getApplicationWithOutTakeInWork(id);
        if (reAssignCause != null) {
            return ResultWrapper.of(application, OK, REASSIGN_APPLICATION, reAssignCause);
        }
        return ResultWrapper.of(application);
    }

    @PutMapping(path = "/{id}/reject")
    public ResultWrapper<Application> reject(@PathVariable("id") Long id,
                                             @NotNull @Valid @RequestBody ApplicationDto applicationDto
    ) throws JsonProcessingException, BusinessException {
        applicationService.reject(id, applicationDto);
        Application application = applicationService.getApplicationWithOutTakeInWork(id);
        return ResultWrapper.of(application);
    }

    @PutMapping(path = "/{id}/rework")
    public ResultWrapper<Application> rework(@PathVariable("id") Long id,
                                             @NotNull @Valid @RequestBody ApplicationDto applicationDto
    ) throws JsonProcessingException, BusinessException {
        applicationService.rework(id, applicationDto);
        Application application = applicationService.getApplicationWithOutTakeInWork(id);
        return ResultWrapper.of(application);
    }

    @PutMapping(path = "/{id}/recount")
    public ResultWrapper<Application> recount(@PathVariable("id") Long id,
                                              @NotNull @RequestBody ApplicationDto applicationDto
    ) throws JsonProcessingException, BusinessException {
        applicationService.recount(id, applicationDto);
        Application application = applicationService.getApplicationWithOutTakeInWork(id);
        return ResultWrapper.of(application);
    }

    @PutMapping(path = "/{id}/fraud")
    public ResultWrapper<Application> fraud(@PathVariable("id") Long id,
                                            @NotNull @RequestBody ApplicationDto applicationDto
    ) throws BusinessException {
        applicationService.fraud(id, applicationDto);
        Application application = applicationService.getApplicationWithOutTakeInWork(id);
        return ResultWrapper.of(application);
    }

    @GetMapping(path = "/redirect/{blankId}")
    public ModelAndView redirectToApplication(@PathVariable("blankId") Integer blankId,
                                              @RequestParam("clientId") String clientId,
                                              @RequestParam("host") String host,
                                              ModelMap model) {
        String url = applicationService.getRedirectURL(blankId, clientId, host);
        return new ModelAndView(url, model);
    }

    @PutMapping(path = "/{id}/postpone")
    public ResultWrapper<Application> suspend(@PathVariable("id") Long id,
                                              @NotNull @RequestBody PostponeRequest request
    ) throws BusinessException {
        applicationService.postpone(id, request);
        Application application = applicationService.getApplicationWithOutTakeInWork(id);
        return ResultWrapper.of(application);
    }

    @Nonnull
    @GetMapping(path = "/{id}/rtdm-decision-history")
    public ResultWrapper<List<RtdmDecisionEntity>> listRtdmDecisionHistory(@PathVariable("id") Long id,
                                                                           @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                                                                           @Nullable @RequestParam("startDate") LocalDateTime startDate,
                                                                           @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                                                                           @Nullable @RequestParam("endDate") LocalDateTime endDate) {
        @Nonnull
        List<RtdmDecisionEntity> list = rtdmDecisionService.listRtdmDecisionHistory(id, startDate, endDate);
        return ResultWrapper.of(list);
    }

    @GetMapping(path = "/last-approved/{clientId}")
    public ResultWrapper<Application> reject(@PathVariable("clientId") Long clientId) {
        Application application = applicationService.getLastApproveAppData(clientId);
        return ResultWrapper.of(application);
    }

}
