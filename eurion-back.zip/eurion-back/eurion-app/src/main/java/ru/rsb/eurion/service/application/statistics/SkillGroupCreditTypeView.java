package ru.rsb.eurion.service.application.statistics;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Setter
@Getter
public class SkillGroupCreditTypeView {

    private CreditType creditType;
    private List<SkillGroupRoleView> skillGroupRoleViews;
    private Map<ApplicationViewStatus, Integer> amounts;

    public List<SkillGroupRoleView> getSkillGroupRoleViews() {
        if (skillGroupRoleViews == null) {
            skillGroupRoleViews = new ArrayList<>();
        }
        return skillGroupRoleViews;
    }

}
