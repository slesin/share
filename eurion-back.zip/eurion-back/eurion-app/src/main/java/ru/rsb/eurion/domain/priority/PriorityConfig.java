package ru.rsb.eurion.domain.priority;

import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.CreditAttractChannel;
import ru.rsb.eurion.domain.CreditSaleChannel;
import ru.rsb.eurion.domain.IntervalNonIntersect;
import ru.rsb.eurion.domain.PriorityAmountInterval;
import ru.rsb.eurion.domain.Region;

import javax.validation.Valid;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
@IntervalNonIntersect("priorityAmountIntervals")
public class PriorityConfig {
    /**
     * Упорядоченный список параметров приоретизации. При обновлении ожидаются все параметры, которые получены при чтении
     */
    private List<PriorityParameter> parameters;

    /**
     * Параметры интервала дозвона клиенту (рабочие дни). При обновлении ожидаются все параметры, которые получены при чтении
     */
    @Valid
    private DialInterval workDialInterval;
    /**
     * Параметры интервала дозвона клиенту (праздничные/выходные дни).
     */
    @Valid
    private DialInterval holidayDialInterval;
    /**
     * Список приоритета по регионам. При обновлении ожидаются все параметры, которые получены при чтении
     */
    private List<Region> regionPriorities;

    /**
     * Список приоритета по каналам продаж. При обновлении ожидаются все параметры, которые получены при чтении
     */
    private List<CreditSaleChannel> channelPriorities;

    /**
     * Список приоритета по каналам привлечения. При обновлении ожидаются все параметры, которые получены при чтении
     */
    private List<CreditAttractChannel> creditAttractChannelPriorities;

    /**
     * Интервалы сумм
     */
    private List<PriorityAmountInterval> priorityAmountIntervals;

    /**
     * Флаг, указывающий использовать переключаемую стратегию приоритезации. Если true, то в выборку попадают сначала
     * switchTopCount заявок сверху списка, а затем switchBottomCount - с конца.
     */
    private boolean switchableOrder;

    private int switchTopCount;

    private int switchBottomCount;


    public List<PriorityParameter> getParameters() {
        if (parameters == null) {
            parameters = new ArrayList<>();
        }
        return parameters;
    }

    public List<Region> getRegionPriorities() {
        if (regionPriorities == null) {
            regionPriorities = new ArrayList<>();
        }
        return regionPriorities;
    }

    public List<CreditSaleChannel> getChannelPriorities() {
        if (channelPriorities == null) {
            channelPriorities = new ArrayList<>();
        }
        return channelPriorities;
    }

    public List<PriorityAmountInterval> getPriorityAmountIntervals() {
        if (priorityAmountIntervals == null) {
            priorityAmountIntervals = new ArrayList<>();
        }
        return priorityAmountIntervals;
    }

    public List<CreditAttractChannel> getCreditAttractChannelPriorities() {
        if (creditAttractChannelPriorities == null) {
            creditAttractChannelPriorities = new ArrayList<>();
        }
        return creditAttractChannelPriorities;
    }
}
