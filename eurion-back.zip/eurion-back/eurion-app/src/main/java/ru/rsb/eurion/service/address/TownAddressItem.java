package ru.rsb.eurion.service.address;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TownAddressItem extends AddressItem {

    private String nameHead;

    private String region;

    private String district;

    private String town;

    private String place;
}
