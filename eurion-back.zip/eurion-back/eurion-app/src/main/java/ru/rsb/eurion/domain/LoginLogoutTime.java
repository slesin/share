package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;

@Setter
@Getter
public class LoginLogoutTime {

    private Integer userId;

    private LocalTime UpdatedAt;

    private StatusType statusCode;
}
