package ru.rsb.eurion.service.application.priority.handler;

import org.springframework.stereotype.Component;
import ru.rsb.eurion.service.application.priority.ApplicationIdxDynamicSqlSupport;

import static ru.rsb.eurion.service.application.priority.ApplicationPriorityService.PRIORITY_HANDLER_PREFIX;

@Component(PRIORITY_HANDLER_PREFIX + "SUPERVISOR")
public class SupervisorPriorityParameterHandler extends SimplePriorityParameterHandler {

    public SupervisorPriorityParameterHandler() {
        super(ApplicationIdxDynamicSqlSupport.SUPERVISOR_PRIORITY);
    }
}
