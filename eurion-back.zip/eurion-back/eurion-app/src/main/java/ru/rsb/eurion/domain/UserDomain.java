package ru.rsb.eurion.domain;

import lombok.Getter;

@Getter
public enum UserDomain {
    RS,
    REGION
}
