package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mfms.mfmsgate.out_message_service.Auth;
import ru.mfms.mfmsgate.out_message_service.ConsumeOutMessageArg;
import ru.mfms.mfmsgate.out_message_service.ConsumeOutMessageCode;
import ru.mfms.mfmsgate.out_message_service.ConsumeOutMessageRequest;
import ru.mfms.mfmsgate.out_message_service.ConsumeOutMessageResponse;
import ru.mfms.mfmsgate.out_message_service.ConsumeOutMessageResponseCode;
import ru.mfms.mfmsgate.out_message_service.ConsumeOutMessageResult;
import ru.mfms.mfmsgate.out_message_service.OutMessageService;
import ru.mfms.mfmsgate.out_message_service.OutMessageServiceFault_Exception;
import ru.mfms.mfmsgate.out_message_service.OutMessageTemplate;
import ru.rsb.eurion.settings.AppConfig;

import java.util.UUID;
import java.util.function.Supplier;

@Component
@AllArgsConstructor
@Slf4j
public class SmsService {

    private final Supplier<OutMessageService> smsWSSupplier;
    private final AppConfig appConfig;

    public void sendSms(UUID messageId, String phoneNumber, String message) throws OutMessageServiceFault_Exception {
        OutMessageService port = smsWSSupplier.get();
        ConsumeOutMessageRequest request = getRequest(messageId, phoneNumber, message);
        ConsumeOutMessageResponse response = port.consumeOutMessage(request);
        if (response.getResponseCode() == ConsumeOutMessageResponseCode.OK && !response.getConsumeOutMessageResult().isEmpty()) {
            ConsumeOutMessageResult result = response.getConsumeOutMessageResult().get(0);
            ConsumeOutMessageCode resultCode = result.getConsumeOutMessageCode();
            if (resultCode != ConsumeOutMessageCode.OK) {
                log.error("Send sms error with code: {}", resultCode.toString());
                throw new IllegalStateException("Send sms error code: " + resultCode.toString());
            }
        }
    }

    private ConsumeOutMessageRequest getRequest(UUID messageId, String phoneNumber, String message) {
        ConsumeOutMessageRequest request = new ConsumeOutMessageRequest();
        Auth auth = new Auth();
        auth.setLogin(appConfig.getSmsServiceLogin());
        auth.setPassword(appConfig.getSmsServicePassword());
        request.setAuth(auth);
        ConsumeOutMessageArg messageArg = new ConsumeOutMessageArg();
        messageArg.setMessageId(messageId.toString());
        messageArg.setOutMessageTypeId(appConfig.getSmsServiceMessageTypeId());
        messageArg.setSubject(appConfig.getSmsServiceSubjectName());
        messageArg.setAddress(phoneNumber);
        OutMessageTemplate template = new OutMessageTemplate();
        template.setText(message);
        messageArg.setOutMessageTemplate(template);
        request.getConsumeOutMessageArg().add(messageArg);
        return request;
    }

}
