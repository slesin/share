package ru.rsb.eurion.service.application.priority;

import org.mybatis.dynamic.sql.SqlColumn;
import org.mybatis.dynamic.sql.SqlTable;

import java.sql.JDBCType;

public class CreditSaleChannelDynamicSqlSupport {

    public static final CreditSaleChannelTable CREDIT_SALE_CHANNEL_TABLE = new CreditSaleChannelTable();

    public static final SqlColumn<Integer> ID = CREDIT_SALE_CHANNEL_TABLE.column("ID", JDBCType.INTEGER);
    public static final SqlColumn<String> CREDIT_SALE_CHANNEL_NAME = CREDIT_SALE_CHANNEL_TABLE.column("NAME", JDBCType.VARCHAR);

    private static final class CreditSaleChannelTable extends SqlTable {
        CreditSaleChannelTable() {
            super("CREDIT_SALE_CHANNEL");
        }
    }
}
