package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Тип номера телефона
 */
@Setter
@Getter
public class PhoneType extends BasicReference {
    private PhoneTypeCode code;
}
