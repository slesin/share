package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.Application;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.admin.Consts;
import ru.rsb.eurion.service.util.PageableUtils;

import javax.annotation.Nonnull;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.Collections;
import java.util.function.Consumer;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey.APPLICATION_VERIFIER;

@RequestMapping(path = Consts.VERIFIER_API_BASE + "/application", produces = APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class VerifierApplicationResource {

    private static final int DEFAULT_PAGE_SIZE = 10;
    private static final Consumer<ApplicationEntity> EMPTY_CONSUMER = entity -> {
    };

    private final ApplicationListProvider listProvider;

    private final ApplicationService applicationService;

    @GetMapping(path = "/{id}")
    public Application getApplication(@PathVariable("id") Long id) {
        return applicationService.getApplicationByProcessNameWithCheckList(id, Collections.singleton(APPLICATION_VERIFIER));
    }

    @GetMapping("/list/{code}")
    public PagedResult<ApplicationView> list(@Nonnull @PathVariable(value = "code") AuthorApplicationResource.ViewCode code,
                                             @Nonnull ApplicationListProvider.AppPageable pageable,
                                             @Nonnull ApplicationListProvider.FilterSpec filterSpec) {
        PageableUtils.setupDefaultValues(pageable, DEFAULT_PAGE_SIZE);
        filterSpec.getStatusCodes().clear();
        filterSpec.getProcessStatusCodes().addAll(Arrays.asList(code.getCodes()));
        filterSpec.setProcessNames(Collections.singletonList(APPLICATION_VERIFIER));
        PagedResult<ApplicationView> pagedResult = listProvider.listPage(pageable, filterSpec);
        applicationService.clearPersonalData(pagedResult);
        return pagedResult;
    }

    @PutMapping(path = "/{id}/approve")
    public Application approve(@PathVariable("id") Long id,
                               @NotNull @Valid @RequestBody ApplicationDto applicationDto) throws JsonProcessingException, BusinessException {
        applicationService.authorApprove(id, applicationDto, APPLICATION_VERIFIER);
        return applicationService.getApplicationByProcessNameWithCheckList(id, Collections.singleton(APPLICATION_VERIFIER));
    }

    @PutMapping(path = "/{id}/reject")
    public Application reject(@PathVariable("id") Long id,
                              @NotNull @Valid @RequestBody ApplicationDto applicationDto) throws BusinessException, JsonProcessingException {
        applicationService.authorReject(id, applicationDto, APPLICATION_VERIFIER);
        return applicationService.getApplicationByProcessNameWithCheckList(id, Collections.singleton(APPLICATION_VERIFIER));
    }

    @PutMapping(path = "/{id}/rework")
    public Application rework(@PathVariable("id") Long id,
                              @NotNull @Valid @RequestBody ApplicationDto applicationDto) throws BusinessException, JsonProcessingException {
        applicationService.authorRework(id, applicationDto, APPLICATION_VERIFIER);
        return applicationService.getApplicationByProcessNameWithCheckList(id, Collections.singleton(APPLICATION_VERIFIER));
    }

    @GetMapping(path = "/{id}/take-in-work")
    public Application takeInWork(@PathVariable("id") Long id) {
        applicationService.takeInWork(id, APPLICATION_VERIFIER);
        return applicationService.getApplicationByProcessNameWithCheckList(id, Collections.singleton(APPLICATION_VERIFIER));
    }

    @PutMapping(path = "/{id}/return-into-queue")
    public ApplicationView returnIntoQueue(@PathVariable("id") Long id) {
        applicationService.authorReturnIntoQueue(id);
        return getSingleApplicationView(id);
    }

    @PutMapping(path = "/{id}")
    public Application updateApplication(@PathVariable("id") Long id,
                                         @Valid @NotNull @RequestBody Application application
    ) throws JsonProcessingException, BusinessException {
        applicationService.updateApplication(id, application, EMPTY_CONSUMER, APPLICATION_VERIFIER);
        return applicationService.getApplicationByProcessNameWithCheckList(id, Collections.singleton(APPLICATION_VERIFIER));
    }

    private ApplicationView getSingleApplicationView(Long id) {
        BaseApplicationListProvider.FilterSpec filterSpec = new ApplicationListProvider.FilterSpec();
        filterSpec.setApplicationId(id);
        return listProvider.getById(BaseApplicationListProvider.AppPageable.SINGLE_VALUE, filterSpec);
    }

}
