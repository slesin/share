package ru.rsb.eurion.service.admin.skill.group;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.dao.DeclineReasonDao;
import ru.rsb.eurion.dao.FormDao;
import ru.rsb.eurion.domain.DeclineCategory;
import ru.rsb.eurion.domain.DeclineReason;
import ru.rsb.eurion.domain.Form;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.CollectionUtils;
import ru.rsb.eurion.service.admin.check.protocol.form.definition.FormDefinitionService;
import ru.rsb.eurion.service.admin.users.UserDao;
import ru.rsb.eurion.service.admin.users.history.UserHistoryService;
import ru.rsb.eurion.settings.AppConfig;

import javax.annotation.PostConstruct;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional
@AllArgsConstructor
@Slf4j
public class SkillGroupService {

    private final SkillGroupDao dao;
    private final UserDao userDao;
    private final FormDefinitionService formDefinitionService;
    private final AppConfig config;
    private final FormDao formDao;
    private final DeclineReasonDao declineReasonDao;
    private List<String> defaultSkillGroupForms = new ArrayList<>();
    private UserHistoryService userHistoryService;

    @PostConstruct
    private void init() {
        String fieldPaths = config.getSkillGroupDefaultForms();
        defaultSkillGroupForms = Arrays.asList(fieldPaths.split(";"));
    }

    public List<SkillGroup> skillGroupList() {
        return dao.listAll();
    }

    public void assignSkillGroupToUser(Integer userId, Integer groupId) {
        dao.assignSkillGroupToUser(userId, groupId);
    }

    public void deAssignSkillGroupToUser(Integer userId, Integer groupId) {
        dao.deAssignSkillGroupToUser(userId, groupId);
    }

    public List<SkillGroup> list() {
        return dao.listAll();
    }

    public List<User> getUsersBySkillGroupId(Integer id) {
        return userDao.findBySkillGroupId(id);
    }

    public SkillGroup createSkillGroup(SkillGroup skillGroup) {
        skillGroup.setCreatedAt(LocalDateTime.now());
        skillGroup.setUpdatedAt(LocalDateTime.now());
        dao.createSkillGroup(skillGroup);
        updateUsers(skillGroup);
        if (defaultSkillGroupForms.size() > 0) {
            addDefaultForms(skillGroup.getFormDefinitions());
        }
        for (FormDefinition formDefinition : skillGroup.getFormDefinitions()) {
            formDefinitionService.create(skillGroup.getId(), formDefinition);
        }
        return skillGroup;
    }

    public void updateSkillGroup(SkillGroup skillGroup) {
        skillGroup.setUpdatedAt(LocalDateTime.now());
        dao.updateSkillGroup(skillGroup);
        updateUsers(skillGroup);
        updateFormDefinitions(skillGroup);
    }

    public void deactivateSkillGroups(List<Integer> skillGroupIds) {
        if (skillGroupIds.isEmpty()) {
            return;
        }
        dao.deactivateSkillGroups(skillGroupIds, LocalDateTime.now());
    }

    public void deactivateSkillGroup(Integer skillGroupId) {
        List<Integer> skillGroupIds = Collections.singletonList(skillGroupId);
        deactivateSkillGroups(skillGroupIds);
    }

    public void activateSkillGroups(List<Integer> skillGroupIds) {
        if (skillGroupIds.isEmpty()) {
            return;
        }
        dao.activateSkillGroups(skillGroupIds, LocalDateTime.now());
    }

    public void activateSkillGroup(Integer skillGroupId) {
        List<Integer> skillGroupIds = Collections.singletonList(skillGroupId);
        activateSkillGroups(skillGroupIds);
    }

    public SkillGroup getFirstGroupByCheckType(CheckType checkType) {
        SkillGroup skillGroup = dao.getFirstGroupByCheckType(checkType);
        if (skillGroup == null) {
            throw new IllegalStateException("Skill-group not found for check type : " + checkType);
        }
        return skillGroup;
    }

    public boolean hasUserSkillGroup(Integer userId, Integer groupId) {
        return dao.hasUserSkillGroup(userId, groupId);
    }

    public SkillGroupDeclineCategory getDeclineCategoryReason(Integer skillGroupId) {
        return dao.getSkillGroupCategory(skillGroupId);
    }

    public void updateDeclineCategoryReason(@NotNull SkillGroupDeclineCategory skillGroupDeclineCategory) {
        Integer skillGroupId = skillGroupDeclineCategory.getSkillGroupId();
        SkillGroupDeclineCategory oldSkillCategory = getDeclineCategoryReason(skillGroupId);
        List<DeclineCategory> oldCategories = oldSkillCategory.getDeclineCategories();
        List<DeclineCategory> newCategories = skillGroupDeclineCategory.getDeclineCategories();
        CollectionUtils.mergeList(oldCategories, newCategories, DeclineCategory::getId,
                category -> {
                    dao.addDeclineCategoryToSkillGroup(skillGroupId, category.getId());
                    List<DeclineReason> oldDeclineReason = dao.getDeclineReasons(skillGroupId, category.getId());
                    mergeDeclineReasons(skillGroupId, oldDeclineReason, category.getDeclineReasons());
                    return category;
                },
                category -> {
                    dao.deleteDeclineCategoryFromSkillGroup(skillGroupId, category.getId());
                    dao.deleteDeclineReasonFromSkillGroupByCategory(skillGroupId, category.getId());
                }, ((oldValue, newValue) -> mergeDeclineReasons(skillGroupId, oldValue.getDeclineReasons(), newValue.getDeclineReasons())));
    }

    private void mergeDeclineReasons(Integer skillGroupId, List<DeclineReason> oldReasons, List<DeclineReason> newReasons) {
        CollectionUtils.mergeList(oldReasons, newReasons, DeclineReason::getId,
                reason -> {
                    dao.addReasonToSkillGroup(skillGroupId, reason.getId());
                    return reason;
                },
                reason -> dao.deleteDeclineReasonFromSkillGroup(skillGroupId, reason.getId()),
                ((oldValue, newValue) -> declineReasonDao.setTimeOut(oldValue.getId(), newValue.getTimeout(), LocalDateTime.now())));
    }

    private void updateUsers(SkillGroup skillGroup) {
        List<User> oldUsers = userDao.findBySkillGroupId(skillGroup.getId());
        mergeUsers(oldUsers, skillGroup);
    }

    private void mergeUsers(List<User> oldValues, SkillGroup skillGroup) {
        List<User> skillGroupUsers = skillGroup.getUsers();
        Integer loggedUserId = AuthUtil.loggedUser().getId();
        oldValues.forEach(User::getSkillGroupIds);
        CollectionUtils.mergeList(oldValues, skillGroupUsers, User::getId,
                user -> {
                    userDao.addUserToSkillGroup(skillGroup, user);
                    Set<Integer> newSkillGroups = new HashSet<>(user.getSkillGroupIds());
                    newSkillGroups.add(skillGroup.getId());
                    userHistoryService.addSkillGroup(user, newSkillGroups, loggedUserId);
                    return user;
                },
                user -> {
                    userDao.deleteUserFromSkillGroup(skillGroup, user);
                    Set<Integer> newSkillGroups = new HashSet<>(user.getSkillGroupIds());
                    newSkillGroups.remove(skillGroup.getId());
                    userHistoryService.addSkillGroup(user, newSkillGroups, loggedUserId);
                },
                null
        );
    }

    private void updateFormDefinitions(SkillGroup skillGroup) {
        Integer skillGroupId = skillGroup.getId();
        List<FormDefinition> oldFormDefinitions = formDefinitionService.getFormDefinitionList(skillGroupId);
        oldFormDefinitions.forEach(formDefinition -> formDefinitionService.disableBySkillGroup(formDefinition.getId(), skillGroupId));
        List<FormDefinition> newFormDefinitions = skillGroup.getFormDefinitions();
        for (FormDefinition formDefinition : newFormDefinitions) {
            formDefinitionService.create(skillGroupId, formDefinition);
        }
    }

    private void addDefaultForms(List<FormDefinition> formDefinitionList) {
        List<String> defaultForm = getDefaultForm(formDefinitionList);
        for (String code : defaultSkillGroupForms) {
            if (!defaultForm.contains(code)) {
                FormDefinition formDefinition = new FormDefinition();
                Form form = formDao.findByCode(code);
                if (form == null) {
                    throw new IllegalStateException("Form with code not found: " + code);
                }
                formDefinition.setForm(form);
                formDefinition.setCheckItemDefinitions(null);
                formDefinition.setHasRemark(false);
                LocalDateTime now = LocalDateTime.now();
                formDefinition.setCreatedAt(now);
                formDefinition.setName(form.getName());
                formDefinitionList.add(formDefinition);
            }
        }
    }

    private List<String> getDefaultForm(List<FormDefinition> formDefinitionList) {
        return formDefinitionList.stream()
                .filter(formDefinition -> defaultSkillGroupForms.contains(formDefinition.getForm().getCode()))
                .map(formDefinition -> formDefinition.getForm().getCode())
                .collect(Collectors.toList());
    }

}