package ru.rsb.eurion.domain;

public enum PrimaryPhoneType {
    INNER_PHONE_NUMBER,
    HIDDEN_PHONE_NUMBER
}
