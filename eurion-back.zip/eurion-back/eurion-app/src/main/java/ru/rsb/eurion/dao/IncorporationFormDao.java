package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import ru.rsb.eurion.domain.IncorporationForm;

import java.util.List;

@Mapper
public interface IncorporationFormDao {

    @Select("select ID_CS,\n" +
            "       NAME,\n" +
            "       DESCRIPTION\n" +
            "from INCORPORATION_FORM order by NAME")
    @Results(id = "incorporationFormMapping", value = {
            @Result(property = "id", column = "ID_CS"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "description", column = "DESCRIPTION")
    })
    List<IncorporationForm> findAll();

    @Select("select ID_CS,\n" +
            "       NAME,\n" +
            "       DESCRIPTION\n" +
            "from INCORPORATION_FORM\n" +
            "where ID_CS = #{id}")
    @ResultMap("incorporationFormMapping")
    IncorporationForm findById(Integer id);
}
