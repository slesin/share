package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.CreditAttractChannel;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

@Mapper
public interface CreditAttractChannelDao {
    String BASE_SELECT_SQL = "select ID, CREATED_AT, UPDATED_AT, NAME, SORT_PRIORITY, ENABLED from CREDIT_ATTRACT_CHANNEL";

    @Nonnull
    @Select(BASE_SELECT_SQL + " order by ID")
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "priority", column = "SORT_PRIORITY"),
            @Result(property = "code", column = "CODE"),
            @Result(property = "enabled", column = "ENABLED")
    })
    List<CreditAttractChannel> findAll();

    @Update("update CREDIT_ATTRACT_CHANNEL set SORT_PRIORITY = #{priority}, updated_at = current_timestamp where ID = #{id}")
    void updatePriority(CreditAttractChannel creditSaleChannel);

    @Nullable
    @Select(BASE_SELECT_SQL + " where ID = #{id,jdbcType=INTEGER}")
    CreditAttractChannel findById(@Param("id") Integer id);
}
