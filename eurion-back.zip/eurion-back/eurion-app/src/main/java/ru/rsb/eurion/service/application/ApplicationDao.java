package ru.rsb.eurion.service.application;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.FetchType;
import org.apache.ibatis.mapping.StatementType;
import org.mybatis.dynamic.sql.select.render.SelectStatementProvider;
import org.mybatis.dynamic.sql.util.SqlProviderAdapter;
import ru.rsb.eurion.dao.DurationTypeHandler;
import ru.rsb.eurion.domain.ApplicationEntity;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.mybatis.MybatisExtendedLanguageDriver;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.credit.dto.IdInfo;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * @author sergius on 9/14/18.
 */
@Mapper
public interface ApplicationDao {

    String UPDATE_STATUS_SQL = "UPDATE APPLICATION\n" +
            "SET STATUS           = #{status},\n" +
            "    DONE_AT         = #{doneAt,jdbcType=TIMESTAMP},\n" +
            "    DECISION         = #{decision,jdbcType=VARCHAR},\n" +
            "    DECISION_COMMENT = #{decisionComment,jdbcType=VARCHAR}\n" +
            "WHERE ID = #{id}";

    String BASE_SELECT_SQL = "select A.ID,\n" +
            "       A.CREATED_AT,\n" +
            "       A.UPDATED_AT,\n" +
            "       A.CLIENT_ID,\n" +
            "       A.RTDM_ID,\n" +
            "       A.APPLICATION_DATA,\n" +
            "       A.STATUS,\n" +
            "       A.DONE_AT,\n" +
            "       A.DECISION,\n" +
            "       A.DECISION_COMMENT,\n" +
            "       A.FORM_DEFINITIONS,\n" +
            "       A.FORM_CONCLUSIONS,\n" +
            "       A.SKILL_GROUP_ID,\n" +
            "       A.CREDIT_AMOUNT,\n" +
            "       A.BLANK_ID,\n" +
            "       A.BIRTH_DATE,\n" +
            "       A.CLIENT_REGION_CODE,\n" +
            "       A.PASSPORT_NUMBER,\n" +
            "       A.PASSPORT_SERIES,\n" +
            "       A.PRODUCT_TYPE,\n" +
            "       A.CREDIT_SALE_CHANNEL_ID,\n" +
            "       A.APPLICATION_REGION_CODE,\n" +
            "       A.MOBILE_PHONE,\n" +
            "       A.BRANCH_ID,\n" +
            "       A.VERSION,\n" +
            "       A.USER_ID,\n" +
            "       A.STATUS_CATEGORY_CODE,\n" +
            "       A.VERIF_REQUEST_ID,\n" +
            "       A.INCOME_INFO,\n" +
            "       A.SHORT_CLIENT_REGION_CODE,\n" +
            "       A.CHECK_TYPE,\n" +
            "       A.FIRST_NAME,\n" +
            "       A.MIDDLE_NAME,\n" +
            "       A.LAST_NAME,\n" +
            "       A.ASSIGN_BY_SUPERVISOR,\n" +
            "       A.REQUESTED_CREDIT_AMOUNT,\n" +
            "       A.SKILL_GROUP_PRIORITY,\n" +
            "       A.SUPERVISOR_PRIORITY,\n" +
            "       A.RTDM_PRIORITY,\n" +
            "       A.REGION_CLIENT_PRIORITY,\n" +
            "       A.REGION_APP_PRIORITY,\n" +
            "       A.AMOUNT_PRIORITY,\n" +
            "       A.CHANNEL_PRIORITY,\n" +
            "       A.ATTRACT_CHANNEL_PRIORITY,\n" +
            "       A.PRODUCT_PRIORITY,\n" +
            "       A.PRODUCT_CREDIT_AMOUNT_SUM,\n" +
            "       A.MONTHLY_PAYMENT_DATE,\n" +
            "       A.AUTHOR_ID,\n" +
            "       AP.PROCESS_NAME,\n" +
            "       APS.STATUS              AS PROCESS_STATUS,\n" +
            "       APS.USER_NAME           AS PROCESS_USER_NAME,\n" +
            "       APS.CATEGORY_CODE       AS PROCESS_CATEGORY_CODE,\n" +
            "       APS.DECISION            as PROCESS_DECISION,\n" +
            "       RP.ID                   as RP_ID,\n" +
            "       RP.CREATED_AT           as RP_CREATED_AT,\n" +
            "       RP.UPDATED_AT           as RP_UPDATED_AT,\n" +
            "       RP.NAME                 as RP_NAME,\n" +
            "       RP.IS_NEED_NOTIFICATION as RP_IS_NEED_NOTIFICATION,\n" +
            "       RP.IS_WARNING           as RP_IS_WARNING\n" +
            "from APPLICATION A\n" +
            "         LEFT JOIN APPLICATION_PROCESS AP ON A.ID = AP.APPLICATION_ID\n" +
            "         LEFT JOIN APPLICATION_PROCESS_STATUS APS on AP.APPLICATION_ID = APS.APPLICATION_ID\n" +
            "         LEFT JOIN RTDM_PRIORITY RP ON A.RTDM_PRIORITY = RP.ID\n";

    String SELECT_SQL_WITH_PHONE_TIME =
            "select A.ID,\n" +
                    "       A.CREATED_AT,\n" +
                    "       A.UPDATED_AT,\n" +
                    "       A.CLIENT_ID,\n" +
                    "       A.RTDM_ID,\n" +
                    "       A.APPLICATION_DATA,\n" +
                    "       A.STATUS,\n" +
                    "       A.DONE_AT,\n" +
                    "       A.DECISION,\n" +
                    "       A.DECLINE_REASON_ID,\n" +
                    "       A.DECISION_COMMENT,\n" +
                    "       A.FORM_DEFINITIONS,\n" +
                    "       A.FORM_CONCLUSIONS,\n" +
                    "       A.SKILL_GROUP_ID,\n" +
                    "       A.CREDIT_AMOUNT,\n" +
                    "       A.BLANK_ID,\n" +
                    "       A.BIRTH_DATE,\n" +
                    "       A.CLIENT_REGION_CODE,\n" +
                    "       A.PASSPORT_NUMBER,\n" +
                    "       A.PASSPORT_SERIES,\n" +
                    "       A.PRODUCT_TYPE,\n" +
                    "       A.CREDIT_SALE_CHANNEL_ID,\n" +
                    "       A.APPLICATION_REGION_CODE,\n" +
                    "       A.MOBILE_PHONE,\n" +
                    "       A.BRANCH_ID,\n" +
                    "       A.VERSION,\n" +
                    "       A.USER_ID,\n" +
                    "       A.STATUS_CATEGORY_CODE,\n" +
                    "       A.VERIF_REQUEST_ID,\n" +
                    "       A.INCOME_INFO,\n" +
                    "       A.SHORT_CLIENT_REGION_CODE,\n" +
                    "       A.CHECK_TYPE,\n" +
                    "       A.FIRST_NAME,\n" +
                    "       A.MIDDLE_NAME,\n" +
                    "       A.LAST_NAME,\n" +
                    "       A.ASSIGN_BY_SUPERVISOR,\n" +
                    "       A.REQUESTED_CREDIT_AMOUNT,\n" +
                    "       A.PRODUCT_CREDIT_AMOUNT_SUM,\n" +
                    "       A.MONTHLY_PAYMENT_DATE,\n" +
                    "       A.AUTHOR_ID,\n" +
                    "       AP.PROCESS_NAME,\n" +
                    "       APS.STATUS as PROCESS_STATUS,\n" +
                    "       APS.USER_NAME as PROCESS_USER_NAME,\n" +
                    "       APS.CATEGORY_CODE as PROCESS_CATEGORY_CODE,\n" +
                    "       decode(#{isTodayHoliday, jdbcType=BOOLEAN}, 1, DT.IS_HOLIDAY_ENABLED, DT.IS_ENABLED) as IS_PHONE_TIME,\n" +
                    "       RP.ID                   as RP_ID,\n" +
                    "       RP.CREATED_AT           as RP_CREATED_AT,\n" +
                    "       RP.UPDATED_AT           as RP_UPDATED_AT,\n" +
                    "       RP.NAME                 as RP_NAME,\n" +
                    "       RP.IS_NEED_NOTIFICATION as RP_IS_NEED_NOTIFICATION,\n" +
                    "       RP.IS_WARNING           as RP_IS_WARNING\n" +
                    "from APPLICATION A\n" +
                    "       left join APPLICATION_PROCESS AP on A.ID = AP.APPLICATION_ID\n" +
                    "       left join APPLICATION_PROCESS_STATUS APS on AP.APPLICATION_ID = APS.APPLICATION_ID\n" +
                    "       left join REGION R on A.SHORT_CLIENT_REGION_CODE = R.CODE\n" +
                    "       left join DIAL_TIME DT on (select case when currentTime <= #{dateInMin, jdbcType = INTEGER}\n" +
                    "                                                   then currentTime else currentTime - #{dateInMin, jdbcType = INTEGER} end as result\n" +
                    "                                  from (select (RAW_OFFSET - #{serverOffset, jdbcType=INTEGER}) * 60 + #{currentDateInMin, jdbcType=INTEGER} as currentTime\n" +
                    "                                        from dual)) = DT.ID\n" +
                    "       LEFT JOIN RTDM_PRIORITY RP ON A.RTDM_PRIORITY = RP.ID\n" +
                    "where A.id = #{id}\n";

    String SELECT_SQL = BASE_SELECT_SQL +
            "where A.id = #{id}";

    String SELECT_BY_RTDM_SQL = BASE_SELECT_SQL +
            "where A.RTDM_ID = #{rtdmId}";

    String SELECT_BY_BLANK_ID_SQL = BASE_SELECT_SQL +
            "where A.BLANK_ID = #{blankId}";

    String INSERT_SQL = "insert into APPLICATION (CLIENT_ID,\n" +
            "                         CREATED_AT,\n" +
            "                         UPDATED_AT,\n" +
            "                         RTDM_ID,\n" +
            "                         APPLICATION_DATA,\n" +
            "                         STATUS,\n" +
            "                         DONE_AT,\n" +
            "                         DECISION,\n" +
            "                         DECISION_COMMENT,\n" +
            "                         LAST_NAME,\n" +
            "                         FIRST_NAME,\n" +
            "                         MIDDLE_NAME,\n" +
            "                         SKILL_GROUP_ID,\n" +
            "                         BEGIN_PHONE_TIME,\n" +
            "                         END_PHONE_TIME,\n" +
            "                         SUSPEND_TIME,\n" +
            "                         SUPERVISOR_PRIORITY,\n" +
            "                         RTDM_PRIORITY,\n" +
            "                         REGION_CLIENT_PRIORITY,\n" +
            "                         REGION_APP_PRIORITY,\n" +
            "                         AMOUNT_PRIORITY,\n" +
            "                         CHANNEL_PRIORITY,\n" +
            "                         ATTRACT_CHANNEL_PRIORITY,\n" +
            "                         PRODUCT_PRIORITY,\n" +
            "                         IS_NOVEL,\n" +
            "                         IS_FRAUD_RETURN,\n" +
            "                         IS_SUSPENSIVE_TERMS,\n" +
            "                         IS_OUT_OF_DIAL_TIME,\n" +
            "                         LAST_USER_ID,\n" +
            "                         FORM_DEFINITIONS,\n" +
            "                         FORM_CONCLUSIONS,\n" +
            "                         CREDIT_AMOUNT,\n" +
            "                         BLANK_ID,\n" +
            "                         BIRTH_DATE,\n" +
            "                         CLIENT_REGION_CODE,\n" +
            "                         PASSPORT_NUMBER,\n" +
            "                         PASSPORT_SERIES,\n" +
            "                         PRODUCT_TYPE,\n" +
            "                         CREDIT_SALE_CHANNEL_ID,\n" +
            "                         APPLICATION_REGION_CODE,\n" +
            "                         MOBILE_PHONE,\n" +
            "                         BRANCH_ID,\n" +
            "                         VERSION,\n" +
            "                         STATUS_CATEGORY_CODE,\n" +
            "                         VERIF_REQUEST_ID,\n" +
            "                         SOURCE_XML,\n" +
            "                         REQUESTED_CREDIT_AMOUNT,\n" +
            "                         SHORT_CLIENT_REGION_CODE,\n" +
            "                         CREDIT_ATTRACTION_CHANNEL_ID,\n" +
            "                         CHECK_TYPE,\n" +
            "                         REQUESTED_BRANCH_NAME,\n" +
            "                         BRANCH_NAME,\n" +
            "                         CLIENT_REGION,\n" +
            "                         CREDIT_TYPE,\n" +
            "                         AUTHOR_FULL_NAME,\n" +
            "                         MONTHLY_PAYMENT_DATE,\n" +
            "                         AUTHOR_ID)\n" +
            "values (#{clientId,jdbcType=INTEGER},\n" +
            "        #{createdAt,jdbcType=TIMESTAMP},\n" +
            "        #{updatedAt,jdbcType=TIMESTAMP},\n" +
            "        #{rtdmId,jdbcType=INTEGER},\n" +
            "        #{data,jdbcType=VARCHAR},\n" +
            "        #{status,jdbcType=VARCHAR},\n" +
            "        #{doneAt,jdbcType=TIMESTAMP},\n" +
            "        #{decision,jdbcType=VARCHAR},\n" +
            "        #{decisionComment,jdbcType=VARCHAR},\n" +
            "        #{lastName,jdbcType=VARCHAR},\n" +
            "        #{firstName,jdbcType=VARCHAR},\n" +
            "        #{middleName,jdbcType=VARCHAR},\n" +
            "        #{skillGroup.id,jdbcType=INTEGER},\n" +
            "        #{beginPhoneTime,jdbcType=TIME},\n" +
            "        #{endPhoneTime,jdbcType=TIME},\n" +
            "        #{suspendTime,jdbcType=TIMESTAMP},\n" +
            "        #{supervisorPriority,jdbcType=SMALLINT},\n" +
            "        #{rtdmPriority.id,jdbcType=SMALLINT},\n" +
            "        #{regionClientPriority,jdbcType=SMALLINT},\n" +
            "        #{regionAppPriority,jdbcType=SMALLINT},\n" +
            "        #{amountPriority,jdbcType=SMALLINT},\n" +
            "        #{channelPriority,jdbcType=SMALLINT},\n" +
            "        #{attractChannelPriority,jdbcType=SMALLINT},\n" +
            "        #{productPriority,jdbcType=SMALLINT},\n" +
            "        #{novel,jdbcType=BOOLEAN},\n" +
            "        #{fraudReturn,jdbcType=BOOLEAN},\n" +
            "        #{suspensiveTerms,jdbcType=BOOLEAN},\n" +
            "        #{outOfDialTime,jdbcType=BOOLEAN},\n" +
            "        #{lastUserId,jdbcType=INTEGER},\n" +
            "        #{formDefinitions,jdbcType=CLOB},\n" +
            "        #{formConclusions,jdbcType=CLOB},\n" +
            "        #{creditAmount,jdbcType=DECIMAL},\n" +
            "        #{blankId,jdbcType=INTEGER},\n" +
            "        #{birthDate,jdbcType=DATE},\n" +
            "        #{clientRegionCode,jdbcType=VARCHAR},\n" +
            "        #{passportNumber,jdbcType=VARCHAR},\n" +
            "        #{passportSeries,jdbcType=VARCHAR},\n" +
            "        #{productType,jdbcType=VARCHAR},\n" +
            "        #{creditSaleChannelId,jdbcType=INTEGER},\n" +
            "        #{applicationRegionCode,jdbcType=VARCHAR},\n" +
            "        #{mobilePhone,jdbcType=VARCHAR},\n" +
            "        #{branchId,jdbcType=INTEGER},\n" +
            "        #{version,jdbcType=TIMESTAMP},\n" +
            "        #{statusCategoryCode,jdbcType=VARCHAR},\n" +
            "        #{verifRequestId,jdbcType=VARCHAR},\n" +
            "        #{sourceXml,jdbcType=VARCHAR},\n" +
            "        #{requestedCreditAmount,jdbcType=DECIMAL},\n" +
            "        #{shortClientRegionCode,jdbcType=VARCHAR},\n" +
            "        #{creditAttractionChannelId,jdbcType=INTEGER},\n" +
            "        #{checkType,jdbcType=VARCHAR},\n" +
            "        #{requestedBranchName,jdbcType=VARCHAR},\n" +
            "        #{branchName,jdbcType=VARCHAR},\n" +
            "        #{clientRegion,jdbcType=VARCHAR},\n" +
            "        #{creditType,jdbcType=VARCHAR},\n" +
            "        #{authorFullName, jdbcType=VARCHAR},\n" +
            "        #{monthlyPaymentDate,jdbcType=TIMESTAMP},\n" +
            "        #{authorId,jdbcType=INTEGER})";

    String UPDATE_SQL = "UPDATE APPLICATION\n" +
            "SET UPDATED_AT                = #{updatedAt,jdbcType=TIMESTAMP},\n" +
            "    APPLICATION_DATA          = #{data},\n" +
            "    FORM_DEFINITIONS          = #{formDefinitions, jdbcType = CLOB},\n" +
            "    FORM_CONCLUSIONS          = #{formConclusions, jdbcType = CLOB},\n" +
            "    USER_ID                   = #{user.id, jdbcType=INTEGER},\n" +
            "    VERSION                   = #{version, jdbcType=TIMESTAMP},\n" +
            "    VERIF_REQUEST_ID          = #{verifRequestId, jdbcType=VARCHAR},\n" +
            "    SOURCE_XML                = #{sourceXml, jdbcType=VARCHAR},\n" +
            "    STATUS                    = #{status, jdbcType=VARCHAR},\n" +
            "    STATUS_CATEGORY_CODE      = #{statusCategoryCode, jdbcType=VARCHAR},\n" +
            "    DECISION                  = #{decision, jdbcType=VARCHAR},\n" +
            "    DONE_AT                   = #{doneAt, jdbcType=TIMESTAMP},\n" +
            "    INCOME_INFO               = #{incomeInfo, jdbcType = CLOB},\n" +
            "    CREDIT_AMOUNT             = #{creditAmount,jdbcType=DECIMAL},\n" +
            "    REQUESTED_CREDIT_AMOUNT   = #{requestedCreditAmount,jdbcType=DECIMAL},\n" +
            "    SKILL_GROUP_ID            = #{skillGroup.id, jdbcType=INTEGER},\n" +
            "    SUSPEND_TIME              = #{suspendTime, jdbcType=TIMESTAMP},\n" +
            "    CHECK_TYPE                = #{checkType, jdbcType=VARCHAR},\n" +
            "    ASSIGN_BY_SUPERVISOR      = #{assignBySupervisor, jdbcType=VARCHAR},\n" +
            "    RTDM_PRIORITY             = #{rtdmPriority.id, jdbcType= VARCHAR},\n" +
            "    POSTPONE_COMMENT          = #{postponeComment, jdbcType= VARCHAR},\n" +
            "    PRODUCT_CREDIT_AMOUNT_SUM = #{productCreditAmountSum, jdbcType= DECIMAL},\n" +
            "    MONTHLY_PAYMENT_DATE      = #{monthlyPaymentDate,jdbcType=TIMESTAMP},\n" +
            "    AUTHOR_ID                 = #{monthlyPaymentDate,jdbcType=INTEGER}\n" +
            "where id = #{id}\n";

    @Insert(INSERT_SQL)
    @SelectKey(
            keyProperty = "id",
            before = false,
            resultType = Long.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_application.currval AS id from dual"}
    )
    void create(ApplicationEntity application);

    @Update(UPDATE_SQL)
    void update(ApplicationEntity applicationEntity);

    @Select(SELECT_BY_BLANK_ID_SQL)
    @ResultMap("applicationEntityMapping")
    ApplicationEntity findEntityByBlankId(@Param("blankId") Integer blankId);

    @Select(SELECT_BY_RTDM_SQL)
    @ResultMap("applicationEntityMapping")
    List<ApplicationEntity> findByRtdmId(@Param("rtdmId") Integer rtdmId);

    @Results(id = "applicationEntityMapping",
            value = {
                    @Result(property = "id", column = "id"),
                    @Result(property = "createdAt", column = "created_at"),
                    @Result(property = "updatedAt", column = "updated_at"),
                    @Result(property = "clientId", column = "client_id"),
                    @Result(property = "rtdmId", column = "rtdm_id"),
                    @Result(property = "data", column = "application_data"),
                    @Result(property = "status", column = "status"),
                    @Result(property = "doneAt", column = "done_at"),
                    @Result(property = "decision", column = "decision"),
                    @Result(property = "declineReasonIds", many = @Many(select = "listDeclineReasonIds", fetchType = FetchType.LAZY),
                            column = "ID"),
                    @Result(property = "decisionComment", column = "decision_comment"),
                    @Result(property = "formDefinitions", column = "form_definitions"),
                    @Result(property = "formConclusions", column = "form_conclusions"),
                    @Result(property = "skillGroup", column = "skill_group_id",
                            one = @One(select = "findSkillGroupById", fetchType = FetchType.EAGER)),
                    @Result(property = "formConclusions", column = "form_conclusions"),
                    @Result(property = "creditAmount", column = "credit_amount"),
                    @Result(property = "version", column = "version"),
                    @Result(property = "user", column = "user_id",
                            one = @One(select = "findUserById", fetchType = FetchType.EAGER)),
                    @Result(property = "statusCategoryCode", column = "status_category_code"),
                    @Result(property = "verifRequestId", column = "verif_request_id"),
                    @Result(property = "blankId", column = "blank_id"),
                    @Result(property = "incomeInfo", column = "income_info"),
                    @Result(property = "clientRegionCode", column = "client_region_code"),
                    @Result(property = "shortClientRegionCode", column = "short_client_region_code"),
                    @Result(property = "processName", column = "process_name"),
                    @Result(property = "processStatus", column = "process_status"),
                    @Result(property = "processUserName", column = "process_user_name"),
                    @Result(property = "processStatusCode", column = "process_category_code"),
                    @Result(property = "processDecision", column = "process_decision"),
                    @Result(property = "checkType", column = "check_type"),
                    @Result(property = "firstName", column = "first_name"),
                    @Result(property = "middleName", column = "middle_name"),
                    @Result(property = "lastName", column = "last_name"),
                    @Result(property = "assignBySupervisor", column = "assign_by_supervisor"),
                    @Result(property = "requestedCreditAmount", column = "requested_credit_amount"),
                    @Result(property = "lastUserId", column = "LAST_USER_ID"),
                    @Result(property = "isPhoneTime", column = "IS_PHONE_TIME"),
                    @Result(property = "skillGroupPriority", column = "SKILL_GROUP_PRIORITY"),
                    @Result(property = "supervisorPriority", column = "SUPERVISOR_PRIORITY"),
                    @Result(property = "regionClientPriority", column = "REGION_CLIENT_PRIORITY"),
                    @Result(property = "regionAppPriority", column = "REGION_APP_PRIORITY"),
                    @Result(property = "amountPriority", column = "AMOUNT_PRIORITY"),
                    @Result(property = "channelPriority", column = "CHANNEL_PRIORITY"),
                    @Result(property = "attractChannelPriority", column = "ATTRACT_CHANNEL_PRIORITY"),
                    @Result(property = "productPriority", column = "PRODUCT_PRIORITY"),
                    @Result(property = "rtdmPriority.id", column = "RP_ID"),
                    @Result(property = "rtdmPriority.createdAt", column = "RP_CREATED_AT"),
                    @Result(property = "rtdmPriority.updatedAt", column = "RP_UPDATED_AT"),
                    @Result(property = "rtdmPriority.name", column = "RP_NAME"),
                    @Result(property = "rtdmPriority.needNotification", column = "RP_IS_NEED_NOTIFICATION"),
                    @Result(property = "rtdmPriority.warning", column = "RP_IS_WARNING"),
                    @Result(property = "postponeComment", column = "POSTPONE_COMMENT"),
                    @Result(property = "productCreditAmountSum", column = "PRODUCT_CREDIT_AMOUNT_SUM"),
                    @Result(property = "monthlyPaymentDate", column = "MONTHLY_PAYMENT_DATE"),
                    @Result(property = "authorId", column = "AUTHOR_ID")
            })
    @Select(SELECT_SQL)
    ApplicationEntity findById(@Nonnull Long id);

    @Select(SELECT_SQL + "\nfor update of A.ID, AP.APPLICATION_ID")
    @ResultMap("applicationEntityMapping")
    ApplicationEntity findByIdForUpdate(@Nonnull Long id);


    @Select(SELECT_SQL_WITH_PHONE_TIME)
    @ResultMap("applicationEntityMapping")
    ApplicationEntity findByIdWithPhoneTime(@Param("id") @Nonnull Long id,
                                            @Param("isTodayHoliday") boolean isTodayHoliday,
                                            @Param("currentDateInMin") Integer currentDateInMin,
                                            @Param("serverOffset") Integer serverOffset,
                                            @Param("dateInMin") Integer dateInMin);


    @Update(UPDATE_STATUS_SQL)
    void updateStatusAndDecision(ApplicationEntity application);

    /**
     * Used in {@link #findById}
     */
    @SuppressWarnings("unused")
    @Select("SELECT\n" +
            "  ID,\n" +
            "  CREATED_AT,\n" +
            "  UPDATED_AT,\n" +
            "  USERNAME,\n" +
            "  FULL_NAME,\n" +
            "  EXTENDED_NAME,\n" +
            "  BIRTH_DATE,\n" +
            "  PERSONNEL_NUMBER,\n" +
            "  LOTUS_ADDRESS,\n" +
            "  LIMIT,\n" +
            "  DISABLED_AT,\n" +
            "  INNER_PHONE_NUMBER,\n" +
            "  DIVISION_ID     \n" +
            "FROM APP_USER\n" +
            "WHERE id = #{id}")
    @Results({
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "username", column = "USERNAME"),
            @Result(property = "name", column = "FULL_NAME"),
            @Result(property = "extendedName", column = "EXTENDED_NAME"),
            @Result(property = "birthDate", column = "BIRTH_DATE"),
            @Result(property = "personnelNumber", column = "PERSONNEL_NUMBER"),
            @Result(property = "lotusAddress", column = "LOTUS_ADDRESS"),
            @Result(property = "limit", column = "LIMIT"),
            @Result(property = "disabledAt", column = "DISABLED_AT"),
            @Result(property = "innerPhoneNumber", column = "INNER_PHONE_NUMBER"),
            @Result(property = "skillGroupIds", many = @Many(select = "listSkillGroup",
                    fetchType = FetchType.LAZY), column = "ID"),
            @Result(property = "divisionId", column = "DIVISION_ID")
    })
    User findUserById(@Param("id") Integer id);

    @Select(BASE_SELECT_SQL + " FETCH FIRST 10 ROWS ONLY")
    List<ApplicationEntity> list();

    @Select("SELECT ID,\n" +
            "       CREATED_AT,\n" +
            "       UPDATED_AT,\n" +
            "       NAME,\n" +
            "       STAGE_SLA,\n" +
            "       EMPLOYEE_SLA,\n" +
            "       IS_ENABLED,\n" +
            "       SORT_PRIORITY,\n" +
            "       IS_RECOUNT\n" +
            "FROM SKILL_GROUP\n" +
            "WHERE ID = #{id}")
    @Results(id = "skillGroupMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "name", column = "NAME"),
            @Result(property = "stageSla", column = "STAGE_SLA", typeHandler = DurationTypeHandler.class),
            @Result(property = "employeeSla", column = "EMPLOYEE_SLA", typeHandler = DurationTypeHandler.class),
            @Result(property = "enabled", column = "IS_ENABLED"),
            @Result(property = "priority", column = "SORT_PRIORITY"),
            @Result(property = "isRecount", column = "IS_RECOUNT")
    })
    @SuppressWarnings("unused")
    SkillGroup findSkillGroupById(Integer skillGroupId);

    @Update("update APPLICATION\n" +
            "set STATUS             = #{status, jdbcType=VARCHAR},\n" +
            "  STATUS_CATEGORY_CODE = #{category, jdbcType=VARCHAR},\n" +
            "  STATUS_UPDATED_AT    = #{updatedAt,jdbcType=TIMESTAMP},\n" +
            "  ASSIGN_BY_SUPERVISOR = #{assignBySupervisor,jdbcType=VARCHAR}\n" +
            "where ID = #{id}")
    void updateStatus(@Param("id") Long applicationId,
                      @Param("status") String status,
                      @Param("category") StatusCode category,
                      @Param("updatedAt") LocalDateTime updatedAt,
                      @Param("assignBySupervisor") String assignBySupervisor);

    @Select("SELECT CASE\n" +
            "         WHEN exists(SELECT * FROM APPLICATION WHERE ID = #{id}) THEN 1\n" +
            "         ELSE 0 END AS is_exists\n" +
            "FROM dual")
    boolean exists(Integer applicationId);

    @Update("UPDATE APPLICATION SET USER_ID = #{userId, jdbcType=BIGINT} WHERE ID = #{id}")
    void setUser(@Param("id") Long applicationId, @Param("userId") Integer userId);

    @SelectProvider(type = SqlProviderAdapter.class, method = "select")
    @Results(id = "applicationViewMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "updatedAt", column = "UPDATED_AT"),
            @Result(property = "rtdmId", column = "RTDM_ID"),
            @Result(property = "clientId", column = "CLIENT_ID"),
            @Result(property = "lastName", column = "LAST_NAME"),
            @Result(property = "firstName", column = "FIRST_NAME"),
            @Result(property = "middleName", column = "MIDDLE_NAME"),
            @Result(property = "status", column = "STATUS"),
            @Result(property = "statusCode", column = "STATUS_CATEGORY_CODE"),
            @Result(property = "createdAt", column = "CREATED_AT"),
            @Result(property = "blankId", column = "BLANK_ID"),
            @Result(property = "birthDate", column = "BIRTH_DATE"),
            @Result(property = "creditAmount", column = "CREDIT_AMOUNT"),
            @Result(property = "requestedCreditAmount", column = "REQUESTED_CREDIT_AMOUNT"),
            @Result(property = "clientRegionCode", column = "CLIENT_REGION_CODE"),
            @Result(property = "clientRegion", column = "CLIENT_REGION"),
            @Result(property = "skillGroupName", column = "SKILL_GROUP_NAME"),
            @Result(property = "statusUpdatedAt", column = "STATUS_UPDATED_AT"),
            @Result(property = "skillGroupRole", column = "SKILL_GROUP_WORK"),
            @Result(property = "skillGroupId", column = "SKILL_GROUP_ID"),
            @Result(property = "passportNumber", column = "PASSPORT_NUMBER"),
            @Result(property = "passportSeries", column = "PASSPORT_SERIES"),
            @Result(property = "productType", column = "PRODUCT_TYPE"),
            @Result(property = "creditSaleChannelId", column = "CREDIT_SALE_CHANNEL_ID"),
            @Result(property = "applicationRegionCode", column = "APPLICATION_REGION_CODE"),
            @Result(property = "mobilePhone", column = "MOBILE_PHONE"),
            @Result(property = "lastUserName", column = "LAST_USER_FULL_NAME"),
            @Result(property = "branchId", column = "BRANCH_ID"),
            @Result(property = "user.id", column = "USER_ID"),
            @Result(property = "user.name", column = "USER_FULL_NAME"),

            @Result(property = "skillGroupPriority", column = "SKILL_GROUP_PRIORITY"),
            @Result(property = "beginPhoneTime", column = "BEGIN_PHONE_TIME"),
            @Result(property = "endPhoneTime", column = "END_PHONE_TIME"),
            @Result(property = "suspendTime", column = "SUSPEND_TIME"),
            @Result(property = "supervisorPriority", column = "SUPERVISOR_PRIORITY"),
            @Result(property = "regionClientPriority", column = "REGION_CLIENT_PRIORITY"),
            @Result(property = "regionAppPriority", column = "REGION_APP_PRIORITY"),
            @Result(property = "amountPriority", column = "AMOUNT_PRIORITY"),
            @Result(property = "channelPriority", column = "CHANNEL_PRIORITY"),
            @Result(property = "attractChannelPriority", column = "ATTRACT_CHANNEL_PRIORITY"),
            @Result(property = "productPriority", column = "PRODUCT_PRIORITY"),
            @Result(property = "novel", column = "IS_NOVEL"),
            @Result(property = "fraudReturn", column = "IS_FRAUD_RETURN"),
            @Result(property = "suspensiveTerms", column = "IS_SUSPENSIVE_TERMS"),
            @Result(property = "outOfDialTime", column = "IS_OUT_OF_DIAL_TIME"),
            @Result(property = "formDefinitions", column = "FORM_DEFINITIONS"),
            @Result(property = "formConclusions", column = "FORM_CONCLUSIONS"),
            @Result(property = "creditSaleChannelName", column = "CREDIT_SALE_CHANNEL_NAME"),
            @Result(property = "clientRegionRawOffSet", column = "RAW_OFFSET"),
            @Result(property = "creditAttractChannelName", column = "CREDIT_ATTRACT_CHANNEL_NAME"),
            @Result(property = "creditAttractionChannelId", column = "CREDIT_ATTRACTION_CHANNEL_ID"),
            @Result(property = "processStatus", column = "PROCESS_STATUS"),
            @Result(property = "processUserName", column = "PROCESS_USER_NAME"),
            @Result(property = "assignBySupervisor", column = "ASSIGN_BY_SUPERVISOR"),
            @Result(property = "processTitle", column = "PROCESS_TITLE"),
            @Result(property = "decisionComment", column = "DECISION_COMMENT"),
            @Result(property = "checkType", column = "CHECK_TYPE"),
            @Result(property = "requestedBranchName", column = "REQUESTED_BRANCH_NAME"),
            @Result(property = "branchName", column = "BRANCH_NAME"),

            @Result(property = "rtdmPriorityView.id", column = "RP_ID"),
            @Result(property = "rtdmPriorityView.createdAt", column = "RP_CREATED_AT"),
            @Result(property = "rtdmPriorityView.updatedAt", column = "RP_UPDATED_AT"),
            @Result(property = "rtdmPriorityView.name", column = "RP_NAME"),
            @Result(property = "rtdmPriorityView.needNotification", column = "RP_IS_NEED_NOTIFICATION"),
            @Result(property = "rtdmPriorityView.warning", column = "RP_IS_WARNING"),
            @Result(property = "rtdmPriority", column = "RTDM_PRIORITY"),
            @Result(property = "leftToDialTime", column = "LEFT_TIME"),
            @Result(property = "leftToHolidayDialTime", column = "HOLIDAY_LEFT_TIME"),
            @Result(property = "dialTime", column = "DIAL_TIME"),
            @Result(property = "holidayDialTime", column = "HOLIDAY_DIAL_TIME"),
            @Result(property = "lastUserId", column = "LAST_USER_ID"),
            @Result(property = "skillGroupPriority", column = "SORT_PRIORITY"),
            @Result(property = "creditType", column = "CREDIT_TYPE"),
            @Result(property = "authorFullName", column = "AUTHOR_FULL_NAME"),
            @Result(property = "postponeComment", column = "POSTPONE_COMMENT")
    })
    @Nonnull
    List<ApplicationView> select(SelectStatementProvider selectStatement);

    @Select("select count(*)\n" +
            "from APPLICATION A\n" +
            "       left join APPLICATION_PROCESS AP on A.ID = AP.APPLICATION_ID\n" +
            "       left join APPLICATION_PROCESS_STATUS APS on AP.APPLICATION_ID = APS.APPLICATION_ID\n" +
            "where A.USER_ID = #{userId} and AP.PROCESS_NAME = #{processName, jdbcType=VARCHAR}  and A.DONE_AT is null and\n" +
            "        (STATUS_CATEGORY_CODE = 'ASSIGNED' or STATUS_CATEGORY_CODE = 'IN_WORK')")
    int countByUserId(@Param("userId") Integer userId, @Param("processName") ProcessDefinitionKey processName);

    @Update("UPDATE APPLICATION SET DONE_AT = #{doneAt, jdbcType=TIMESTAMP} WHERE ID = #{id, jdbcType=BIGINT}")
    void setDone(@Param("id") Long id, @Param("doneAt") LocalDateTime value);

    @Update("UPDATE APPLICATION\n" +
            "SET FORM_DEFINITIONS = #{formDefinitions, jdbcType=CLOB},\n" +
            "    UPDATED_AT       = #{updatedAt , jdbcType=TIMESTAMP}\n" +
            "WHERE ID = #{id, jdbcType=BIGINT}")
    void updateFormDefinition(@Param("id") Long id,
                              @Param("formDefinitions") String formDefinitions,
                              @Param("updatedAt") LocalDateTime updatedAt);

    @Select("SELECT BLANK_ID FROM APPLICATION WHERE BLANK_ID = #{blankId}")
    Long findByBlankId(@Param("blankId") Integer blankId);

    @SelectProvider(type = SqlProviderAdapter.class, method = "select")
    int count(SelectStatementProvider statementProvider);

    @Update("UPDATE APPLICATION SET SUPERVISOR_PRIORITY = #{priority} WHERE ID = #{id}")
    void updateSupervisorPriority(@Param("id") Long id, @Param("priority") short supervisorPriority);

    @Insert("INSERT INTO APPLICATION_PROCESS (APPLICATION_ID, PROCESS_NAME) VALUES (#{id,jdbcType=BIGINT}, #{processName, jdbcType=VARCHAR})")
    void addProcessName(@Param("id") Long id, @Param("processName") ProcessDefinitionKey processName);

    @Update("UPDATE APPLICATION_PROCESS SET PROCESS_NAME = #{processName, jdbcType=VARCHAR} WHERE APPLICATION_ID = #{id}")
    void updateProcessName(@Param("id") Long id, @Param("processName") ProcessDefinitionKey processName);

    @Select(SELECT_SQL + " and AP.PROCESS_NAME in (#{processNames})")
    @Lang(MybatisExtendedLanguageDriver.class)
    @ResultMap("applicationEntityMapping")
    ApplicationEntity findByProcess(@Param("id") Long id, @Param("processNames") Set<ProcessDefinitionKey> processNames);

    @Delete("delete from application where id = #{id, jdbcType=BIGINT}")
    void delete(@Param("id") Long id);

    /**
     * Used by {@link #findById(Long applicationId)}
     */
    @Select("select DECLINE_REASON_ID\n" +
            "from CONCLUSION_REASON\n" +
            "where CHECK_CONCLUSION_ID = (select id\n" +
            "                             from CHECK_CONCLUSION_HISTORY\n" +
            "                             where APPLICATION_ID = #{appId , jdbcType = BIGINT}\n" +
            "                               and DECISION_MAKER in ('UNDERWRITING', 'VERIFICATION', 'AUTHOR')\n" +
            "                             order by CREATED_AT desc\n" +
            "                             fetch first row only)")
    @SuppressWarnings("unused")
    Set<Integer> listDeclineReasonIds(@Param("appId") Long applicationId);

    @Select("select BLANK_ID, ID\n" +
            "from APPLICATION\n" +
            "where BLANK_ID in (#{blankIds})\n" +
            "  and STATUS_CATEGORY_CODE = 'COMPLETED'")
    @Results(value = {
            @Result(property = "applicationId", column = "ID"),
            @Result(property = "blankId", column = "BLANK_ID")
    })
    @Lang(MybatisExtendedLanguageDriver.class)
    List<IdInfo> getBlankIdAppId(@Param("blankIds") Set<Integer> blankIds);

    /**
     * Used by {@link #findUserById(Integer supervisorId)}
     */
    @SuppressWarnings("unused")
    @Select("select GROUP_ID\n" +
            "from APP_USER_SKILL_GROUP\n" +
            "where USER_ID = #{user_id}")
    Set<Integer> listSkillGroup(@Param("user_id") Integer userId);

    @Select("select ID,\n" +
            "APPLICATION_DATA,\n" +
            "       DONE_AT\n" +
            "from APPLICATION\n" +
            "where CLIENT_ID = #{clientId, jdbcType = INTEGER}\n" +
            "  and DECISION in ('APPROVED', 'REJECTED')\n" +
            "  and STATUS_CATEGORY_CODE = 'COMPLETED'\n" +
            "  and DONE_AT is not null\n" +
            "order by DONE_AT desc\n" +
            "fetch first row only")
    @ResultMap("applicationEntityMapping")
    ApplicationEntity findLastApproveByClientId(@Param("clientId") Long clientId);

    @Select(BASE_SELECT_SQL +
            "where MOBILE_PHONE = #{phoneNumber} and STATUS_CATEGORY_CODE in (#{statusList})\n" +
            "order by CREATED_AT desc\n" +
            "fetch first 1 row only")
    @Lang(MybatisExtendedLanguageDriver.class)
    @ResultMap("applicationEntityMapping")
    @Nullable
    ApplicationEntity findFirst1ByMobilePhoneAndStatuses(@Param("phoneNumber") String externalNumber,
                                                         @Param("statusList") List<StatusCode> statusList);
}
