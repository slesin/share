package ru.rsb.eurion.service.application;

public enum StatusCode {
    NEW,
    QUEUE,
    ASSIGNED,
    IN_WORK,
    POSTPONED,
    RECOUNT,
    REWORK,
    COMPLETED
}
