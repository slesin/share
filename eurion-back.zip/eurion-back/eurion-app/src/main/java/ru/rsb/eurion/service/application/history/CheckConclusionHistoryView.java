package ru.rsb.eurion.service.application.history;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import ru.rsb.eurion.domain.ApplicationDecision;
import ru.rsb.eurion.domain.BaseEntity;
import ru.rsb.eurion.domain.BasicReference;
import ru.rsb.eurion.domain.CheckConclusionHistory;
import ru.rsb.eurion.domain.DeclineReason;
import ru.rsb.eurion.domain.FormConclusion;
import ru.rsb.eurion.domain.FormDefinition;
import ru.rsb.eurion.rtdm.application.RtdmDecisionCode;

import java.util.List;

@Getter
@Setter
public class CheckConclusionHistoryView extends BaseEntity {
    private BasicReference skillGroup;
    private CheckConclusionHistory.DecisionMaker decisionMaker;
    @JsonIgnore
    private ApplicationDecision decision;
    @JsonIgnore
    private RtdmDecisionCode rtdmDecision;
    private String decisionText;
    @JsonIgnore
    private List<DeclineReason> declineReasons;
    @JsonIgnore
    private String declineCategory;
    private BasicReference user;
    private String decisionComment;
    private String declineText;
    private List<FormDefinition> formDefinitions;
    private List<FormConclusion> formConclusions;
    @JsonIgnore
    private String formDefinitionsJson;
    @JsonIgnore
    private String formConclusionsJson;
}
