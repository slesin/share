package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;
import ru.rsb.eurion.domain.ProcessStatus;

@Mapper
public interface ApplicationProcessStatusDao {

    String BASE_SELECT = "SELECT\n" +
            "  ID,\n" +
            "  APPLICATION_ID,\n" +
            "  STATUS,\n" +
            "  DECISION,\n" +
            "  USER_ID,\n" +
            "  CATEGORY_CODE,\n" +
            "  DONE_AT,\n" +
            "  PROCESS_NAME\n" +
            "FROM APPLICATION_PROCESS_STATUS ";

    String INSERT_SQL = "INSERT INTO APPLICATION_PROCESS_STATUS (APPLICATION_ID, STATUS, DECISION, USER_ID, CATEGORY_CODE, PROCESS_NAME, UPDATED_AT)\n" +
            "VALUES (#{processStatus.applicationId,jdbcType=BIGINT},\n" +
            "        #{processStatus.status,jdbcType=VARCHAR},\n" +
            "        #{processStatus.decision,jdbcType=VARCHAR},\n" +
            "        #{processStatus.userId,jdbcType=VARCHAR},\n" +
            "        #{processStatus.statusCode,jdbcType=VARCHAR},\n" +
            "        #{processStatus.processName,jdbcType=VARCHAR},\n" +
            "        #{processStatus.updatedAt,jdbcType=TIMESTAMP})";

    String UPDATE_SQL = "UPDATE APPLICATION_PROCESS_STATUS\n" +
            "SET STATUS            = #{processStatus.status,jdbcType=VARCHAR},\n" +
            "    DECISION          = #{processStatus.decision,jdbcType=VARCHAR},\n" +
            "    USER_NAME         = #{processStatus.userName,jdbcType=VARCHAR},\n" +
            "    CATEGORY_CODE     = #{processStatus.statusCode,jdbcType=VARCHAR},\n" +
            "    DONE_AT           = #{processStatus.doneAt,jdbcType=TIMESTAMP},\n" +
            "    DECISION_COMMENT  = #{processStatus.decisionComment,jdbcType=VARCHAR},\n" +
            "    UPDATED_AT        = #{processStatus.updatedAt,jdbcType=TIMESTAMP},\n" +
            "    USER_ID           = #{processStatus.userId,jdbcType=INTEGER},\n" +
            "    PROCESS_NAME      = #{processStatus.processName,jdbcType=VARCHAR}\n" +
            "WHERE APPLICATION_ID = #{processStatus.applicationId,jdbcType=BIGINT}";

    @Update(UPDATE_SQL)
    void update(@Param("processStatus") ProcessStatus processStatus);

    @Insert(INSERT_SQL)
    @SelectKey(
            keyProperty = "processStatus.id",
            before = false,
            resultType = Long.class,
            statementType = StatementType.PREPARED,
            statement = {"select seq_application_process_status.currval AS id from dual"}
    )
    void create(@Param("processStatus") ProcessStatus processStatus);

    @Select(BASE_SELECT + "WHERE APPLICATION_ID = #{applicationId, jdbcType=BIGINT}")
    @Results(id = "processStatusMapping", value = {
            @Result(property = "id", column = "ID"),
            @Result(property = "applicationId", column = "APPLICATION_ID"),
            @Result(property = "status", column = "STATUS"),
            @Result(property = "decision", column = "DECISION"),
            @Result(property = "userId", column = "USER_ID"),
            @Result(property = "userName", column = "USER_NAME"),
            @Result(property = "statusCode", column = "CATEGORY_CODE"),
            @Result(property = "doneAt", column = "DONE_AT"),
            @Result(property = "processName", column = "PROCESS_NAME"),
            @Result(property = "decisionComment", column = "decision_comment")
    })
    ProcessStatus getStatus(@Param("applicationId") Long applicationId);
}
