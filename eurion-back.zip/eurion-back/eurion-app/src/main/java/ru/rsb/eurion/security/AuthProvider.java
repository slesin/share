package ru.rsb.eurion.security;

import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.common.util.StringUtils;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.domain.User;
import ru.rsb.eurion.domain.UserDomain;
import ru.rsb.eurion.service.BusinessException;
import ru.rsb.eurion.service.admin.users.UserService;

/**
 * @author sergius on 9/12/18.
 */
@Component
@Slf4j
public class AuthProvider implements AuthenticationProvider {

    private final UserService userService;
    private final ActiveDirectory activeDirectory;

    public AuthProvider(ActiveDirectory activeDirectory, UserService userService) {
        this.activeDirectory = activeDirectory;
        this.userService = userService;
    }

    @Override
    public Authentication authenticate(Authentication auth) throws AuthenticationException {
        String username = (auth.getPrincipal() != null) ? auth.getPrincipal().toString() : null;
        String password = (auth.getCredentials() != null) ? auth.getCredentials().toString() : null;
        if (username == null) {
            throw new BadCredentialsException("Username is not found: null");
        }
        if (password == null || StringUtils.isEmpty(password)) {
            throw new BadCredentialsException("Password is incorrect");
        }
        User user = userService.findByUsernameFromAD(username);

        if (user == null) {
            log.info("User is not found in DB: {}", username);
            try {
                user = createNewUser(username);
            } catch (BusinessException e) {
                // что-то пошло не так, ведь мы выше проверили существование пользователя
                throw new IllegalStateException(e);
            }
        }

        authenticateUser(user, username, password);

        if (user.isDisabled()) {
            log.info("User is disabled: {}", username);
            throw new DisabledException("Account is disabled");
        }

        return new AppAuthenticationToken(user);
    }

    private User createNewUser(String username) throws BusinessException {
        if (activeDirectory.findByUserName(username, UserDomain.RS)) {
            return userService.createUserByUserName(username, UserDomain.RS);
        }
        if (activeDirectory.findByUserName(username, UserDomain.REGION)) {
            return userService.createUserByUserName(username, UserDomain.REGION);
        }
        throw new UsernameNotFoundException(username);
    }

    private void authenticateUser(User user, String username, String password) {
        String accountName;
        switch (user.getDomain()) {
            case RS:
                accountName = activeDirectory.getRsDomain() + "\\" + username;
                activeDirectory.authenticateRS(accountName, password);
                break;
            case REGION:
                accountName = activeDirectory.getRegionDomain() + "\\" + username;
                activeDirectory.authenticateRegion(accountName, password);
                break;
            default:
                log.info("Incorrect domain for user id: ", user.getId());
                throw new IllegalStateException();
        }
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
