package ru.rsb.eurion.dao;

import org.apache.ibatis.annotations.*;
import ru.rsb.eurion.domain.Children;

import java.util.List;

@Mapper
public interface ChildrenDao {

    String BASE_SELECT_SQL = "select IND, NAME from CHILDREN";

    @Select(BASE_SELECT_SQL + " order by IND")
    @Results(id = "childrenMapping", value = {
            @Result(property = "id", column = "IND"),
            @Result(property = "name", column = "NAME"),
    })
    List<Children> findAll();

    @Select(BASE_SELECT_SQL + " where IND = #{id}")
    @ResultMap("childrenMapping")
    Children findById(Integer id);
}
