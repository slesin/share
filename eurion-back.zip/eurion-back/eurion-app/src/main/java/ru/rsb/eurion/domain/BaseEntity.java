package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

/**
 * @author sergius on 9/14/18.
 */
@Getter
@Setter
@ToString
public abstract class BaseEntity {
    private Long id;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public void map(BaseEntity another) {
        this.id = another.id;
        this.createdAt = another.createdAt;
        this.updatedAt = another.updatedAt;
    }
}
