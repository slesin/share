package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.math.BigDecimal;

@Getter
@Setter
@XmlAccessorType(XmlAccessType.FIELD)
public class PriorityAmountInterval extends BasicReference implements Interval<BigDecimal> {
    @NotNull
    private BigDecimal beginAmount;

    @NotNull
    private BigDecimal endAmount;

    @NotNull
    private Short priority;

    @Override
    public BigDecimal getStartValue() {
        return beginAmount;
    }

    @Override
    public BigDecimal getEndValue() {
        return endAmount;
    }
}
