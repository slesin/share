package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * Регион
 */
@Getter
@Setter
public class Region extends BasicReference {
    /**
     * Код региона
     */
    private String code;

    /**
     * Смещение часового пояса в часах относительно UTC
     */
    private int rawOffset;

    /**
     * Индекс приоритета сортировки по региону клиента
     */
    @NotNull
    private short clientPriority;

    /**
     * Индекс приоритета сортировки по региону заявки
     */
    @NotNull
    private short applicationPriority;
}
