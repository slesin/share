package ru.rsb.eurion.service.application;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ContainerNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import ru.rsb.eurion.rtdm.application.Adapter2;
import ru.rsb.eurion.rtdm.application.Adapter3;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.Consumer;

@Component
@AllArgsConstructor
public final class DynamicContentEditor {

    private JsonTransformer transformer;

    /**
     * <p>Редактирование динамического содержимого</p>
     *
     * <p>Динамическое содержимое задается в виде JSON-дреева (билиотека Jackson). Метод предоставляет
     * возможность типобезопасного изменения данных, не затрагивающих свойства, не описанные в классе заданного
     * бина.</p>
     *
     * <p>ВАЖНО! Отстутствует возможность редактирования состава свойств-коллекций. Элементы коллекции редактировать
     * допустимо. После применения consumer количество элементов любой коллекции должно совпадать иначе выбрасывается
     * исключение {@link CollectionModifiedException}</p>
     *
     * @param treeNode редактируемый объект в виде динамической структуры
     * @param clazz    класс, описывающий структуру данных
     * @param consumer callback-функция редактирования содержимого
     * @throws JsonProcessingException     ошибка обработки JSON объектов
     * @throws CollectionModifiedException изменена какая либо коллекция внутри бина, включая вложенные
     */
    @SuppressWarnings("WeakerAccess")
    public <T> void edit(ObjectNode treeNode,
                         Class<T> clazz,
                         Consumer<T> consumer) throws JsonProcessingException, CollectionModifiedException {
        T bean = transformer.treeToValue(treeNode, clazz);
        consumer.accept(bean);
        walk(treeNode, bean);
    }

    private void walk(JsonNode jsonNode, Object bean) {
        if (jsonNode.isArray()) {
            Collection collection = (Collection) bean;
            ArrayNode arrayNode = (ArrayNode) jsonNode;
            if (collection.size() != arrayNode.size()) {
                throw new CollectionModifiedException();
            }

            int i = 0;
            for (Object item : collection) {
                JsonNode itemNode = arrayNode.get(i);
                walk(itemNode, item);
                i++;
            }
        }

        if (!(jsonNode instanceof ObjectNode)) {
            return;
        }

        ObjectNode node = (ObjectNode) jsonNode;
        Iterator<String> iterator = node.fieldNames();
        while (iterator.hasNext()) {
            String next = iterator.next();

            Class<?> clazz = bean.getClass();
            PropertyDescriptor propertyDescriptor = BeanUtils.getPropertyDescriptor(clazz, next);
            if (propertyDescriptor == null) {
                continue;
            }
            Method readMethod = propertyDescriptor.getReadMethod();
            if (readMethod == null || readMethod.getParameterCount() > 0) {
                continue;
            }
            Object value = readValue(bean, readMethod);

            if (value instanceof LocalDate) {
                value = new Adapter3().marshal((LocalDate) value);
            } else if (value instanceof LocalDateTime) {
                value = new Adapter2().marshal((LocalDateTime) value);
            }

            JsonNode valueNode = node.get(next);
            if (valueNode instanceof ContainerNode) {
                walk(valueNode, value);
            } else {
                JsonNode newValueNode = transformer.writeAsTree(value);
                node.set(next, newValueNode);
            }
        }
    }

    private Object readValue(Object bean, Method readMethod) {
        try {
            return readMethod.invoke(bean);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new IllegalStateException(e);
        }
    }

    public static class CollectionModifiedException extends RuntimeException {
        CollectionModifiedException() {
            super();
        }
    }
}
