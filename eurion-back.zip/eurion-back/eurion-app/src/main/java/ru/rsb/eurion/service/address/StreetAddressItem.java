package ru.rsb.eurion.service.address;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StreetAddressItem extends AddressItem {

}
