package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Организационно-правовая форма
 */
@Getter
@Setter
public class IncorporationForm extends BasicReference {
    private String description;
}
