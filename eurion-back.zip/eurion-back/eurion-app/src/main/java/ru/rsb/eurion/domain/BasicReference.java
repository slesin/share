package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.javers.core.metamodel.annotation.DiffIgnore;

import javax.validation.constraints.NotEmpty;
import java.time.LocalDateTime;

/**
 * Базовый класс справочника
 */
@Getter
@Setter
@ToString(of = {"id", "name"})
public class BasicReference {
    /**
     * Уникальный идентификатор
     */
    @DiffIgnore
    private Integer id;

    /**
     * Наименование
     */
    @NotEmpty(message = "{app.notempty}")
    private String name;

    /**
     * Дата создания
     */
    @DiffIgnore
    private LocalDateTime createdAt;

    /**
     * Дата редактирования
     */
    @DiffIgnore
    private LocalDateTime updatedAt;

    /**
     * Дата деактивации
     */
    @DiffIgnore
    private LocalDateTime disabledAt;

    public boolean isDisabled() {
        return disabledAt != null;
    }

    public static void map(BasicReference source, BasicReference target) {
        target.id = source.id;
        target.name = source.name;
        target.createdAt = source.createdAt;
        target.updatedAt = source.updatedAt;
        target.disabledAt = source.disabledAt;
    }

}
