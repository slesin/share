package ru.rsb.eurion.service.application.product;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rsb.eurion.domain.SkillGroup;
import ru.rsb.eurion.service.CollectionUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Slf4j
@Service
@Transactional
@AllArgsConstructor
public class ProductRuleService {

    private final ProductDao dao;

    public List<ProductType> productTypeList() {
        return dao.listProductType();
    }

    public SkillGroupProductView getProductRuleView() {
        List<ProductRule> rules = dao.listRules();

        Map<SkillGroup, List<ProductRuleItem>> skillGroupRoleItemMap = getProductRoleItems(rules);

        Map<SkillGroup, List<ProductRule>> skillGroupProductRuleMap = rules.stream()
                .collect(Collectors.groupingBy(ProductRule::getSkillGroup, Collectors.toList()));

        List<ProductRuleView> productRuleViews = skillGroupProductRuleMap.keySet().stream()
                .map(skillGroup -> {
                    ProductRuleView productRuleView = new ProductRuleView();
                    productRuleView.setSkillGroup(skillGroup);
                    List<ProductRuleItem> productRuleItemSet = skillGroupRoleItemMap.get(skillGroup);
                    productRuleItemSet = sortByProduct(productRuleItemSet);
                    productRuleView.setProductRuleItems(productRuleItemSet);
                    return productRuleView;
                })
                .sorted(Comparator.comparing(item -> item.getSkillGroup().getId()))
                .collect(Collectors.toList());
        SkillGroupProductView skillGroupProductView = new SkillGroupProductView();
        skillGroupProductView.getProductRuleViewList().addAll(productRuleViews);
        return skillGroupProductView;
    }

    public void update(SkillGroupProductView skillGroupProductView) {
        List<ProductRule> ruleNew = convertToProductRule(skillGroupProductView);
        List<ProductRule> ruleOld = dao.listRules();
        CollectionUtils.mergeSet(ruleOld, ruleNew, ProductRule::getId,
                rule -> {
                    rule.setUpdatedAt(LocalDateTime.now());
                    rule.setCreatedAt(LocalDateTime.now());
                    dao.insert(rule);
                    return rule;
                },
                rule -> dao.deleteByRoleId(rule.getId()),
                (oldValue, newValue) -> dao.update(newValue)
        );

    }

    private List<ProductRule> convertToProductRule(SkillGroupProductView skillGroupProductView) {
        List<ProductRuleView> productRuleViewList = skillGroupProductView.getProductRuleViewList();
        List<ProductRule> result = new ArrayList<>();
        for (ProductRuleView ruleView : productRuleViewList) {
            List<ProductRuleItem> ruleItems = ruleView.getProductRuleItems();
            for (ProductRuleItem ruleItem : ruleItems) {
                List<ProductRule> productRules = ruleItem.getProductRules();
                for (ProductRule role : productRules) {
                    role.setSkillGroup(ruleView.getSkillGroup());
                    role.setProductType(ruleItem.getProductType());
                    result.add(role);
                }
            }
        }
        return result;
    }

    private Map<SkillGroup, List<ProductRuleItem>> getProductRoleItems(List<ProductRule> rules) {

        Map<Pair<SkillGroup, ProductType>, List<ProductRule>> skillGroupPairMap = rules.stream()
                .collect(Collectors.groupingBy(r -> Pair.of(r.getSkillGroup(), r.getProductType()), Collectors.toList()));

        return skillGroupPairMap.entrySet().stream()
                .map(item -> {
                    ProductRuleItem productRuleItem = new ProductRuleItem();
                    Pair<SkillGroup, ProductType> pair = item.getKey();
                    productRuleItem.setProductType(pair.getRight());
                    productRuleItem.setSkillGroup(pair.getLeft());
                    List<ProductRule> productRules = sortRule(item.getValue());
                    productRuleItem.setProductRules(productRules);
                    return productRuleItem;
                })
                .collect(Collectors.groupingBy(ProductRuleItem::getSkillGroup, Collectors.toList()));
    }

    private List<ProductRule> sortRule(List<ProductRule> productRules) {
        return productRules.stream()
                .sorted(Comparator.comparing(ProductRule::getBeginAmount))
                .collect(Collectors.toList());

    }

    private List<ProductRuleItem> sortByProduct(List<ProductRuleItem> productRuleItems) {
        return productRuleItems.stream()
                .sorted(Comparator.comparing(item -> item.getProductType().getId()))
                .collect(Collectors.toList());

    }

}
