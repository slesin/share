package ru.rsb.eurion.service.application;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.domain.ApplicationView;
import ru.rsb.eurion.domain.UserData;
import ru.rsb.eurion.list.PagedResult;
import ru.rsb.eurion.security.AuthUtil;
import ru.rsb.eurion.service.admin.Consts;
import ru.rsb.eurion.service.application.flow.api.ProcessDefinitionKey;
import ru.rsb.eurion.service.util.PageableUtils;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collections;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RequestMapping(path = Consts.UNDERWRITER_API_BASE + "/application", produces = APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class UnderwriterApplicationResource {
    private static final int DEFAULT_PAGE_SIZE = 10;

    private final ApplicationListProvider listProvider;
    private final ApplicationService applicationService;

    @GetMapping("/list/{code}")
    public PagedResult<ApplicationView> list(
            @Nonnull @PathVariable(value = "code") ViewCode code,
            @Nonnull ApplicationListProvider.AppPageable pageable,
            @Nonnull ApplicationListProvider.FilterSpec filterSpec) {
        // непонятно, как задать значения по умолчанию для query-параметров, передаваемых в бин типа Pageable
        PageableUtils.setupDefaultValues(pageable, DEFAULT_PAGE_SIZE);
        // игнорируем код представления, пришедший через query-параметры
        filterSpec.getStatusCodes().clear();
        filterSpec.getStatusCodes().addAll(Arrays.asList(code.getCodes()));
        // оператор всегда видит только собственные заявки
        UserData loggedUser = AuthUtil.loggedUser();
        filterSpec.setUserId(loggedUser.getId());
        filterSpec.setProcessNames(Collections.singletonList(ProcessDefinitionKey.APPLICATION));
        PagedResult<ApplicationView> pagedResult = listProvider.listPage(pageable, filterSpec);
        applicationService.clearPersonalData(pagedResult);
        return pagedResult;
    }

    @Getter
    public enum ViewCode {
        IN_WORK(true, StatusCode.IN_WORK, StatusCode.RECOUNT),

        NOT_IN_WORK(true, StatusCode.ASSIGNED),

        POSTPONED(true, StatusCode.POSTPONED),

        MY_COMPLETED(true, StatusCode.COMPLETED);

        private final StatusCode[] codes;
        private final boolean owned;

        ViewCode(boolean owned, StatusCode... codes) {
            this.codes = codes;
            this.owned = owned;
        }

        public StatusCode[] getCodes() {
            return codes.clone();
        }
    }
}
