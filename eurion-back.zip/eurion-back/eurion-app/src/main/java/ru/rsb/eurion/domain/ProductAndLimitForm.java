package ru.rsb.eurion.domain;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Форма управления продуктом и лимитом
 */
@Getter
@Setter
public class ProductAndLimitForm extends BasicForm {
    /**
     * Расчёты SAS todo структура из SAS
     */
    private String sasCalculation;
    /**
     * Расчёты по заявке
     */
    private ApplicationCalculation applicationCalculation;
    /**
     * Предложения
     */
    private List<LoanProposal> loanProposals;
    // todo тут ещё есть ряд полей про смену продукта, перераспределение лимитов, не ясно нужно ли их типизировать
    /**
     * Итоговый продукт по заявке
     */
    private Product finalProduct;
    /**
     * Итоговая сумма кредита по заявке
     */
    private BigDecimal finalLoanAmount;
    /**
     * Итоговый срок кредита по заявке
     */
    private Integer finalLoanPeriod;
    /**
     * Итоговый ЕП по заявке
     */
    private Integer finalLoanPayment;
}
