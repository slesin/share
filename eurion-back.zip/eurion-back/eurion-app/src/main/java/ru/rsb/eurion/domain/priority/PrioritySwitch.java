package ru.rsb.eurion.domain.priority;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrioritySwitch {
    private boolean reverse;
    private int counter;
}
