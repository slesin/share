package ru.rsb.eurion.service.application.history;

import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.rsb.eurion.EurionApplication;
import ru.rsb.eurion.domain.ApplicationStatusHistoryView;
import ru.rsb.eurion.list.PagedResult;

import javax.annotation.Nonnull;
import java.time.LocalDateTime;
import java.util.List;

@RequestMapping(path = EurionApplication.API_BASE + "/application-history", produces = MediaType.APPLICATION_JSON_VALUE)
@RestController
@AllArgsConstructor
public class ApplicationHistoryResource {

    private final ApplicationHistoryService service;
    private final ApplicationHistoryListProvider listProvider;
    private final ApplicationStatusHistoryListProvider listStatusProvider;

    @GetMapping(path = "/{applicationId}")
    public PagedResult<ApplicationHistory> getHistory(@Nonnull ApplicationHistoryListProvider.AppHistoryPageable pageable,
                                                      @Nonnull @PathVariable("applicationId") Integer applicationId,
                                                      @Nonnull ApplicationHistoryListProvider.FilterSpec filterSpec) {
        LocalDateTime startDate = filterSpec.getStartDate();
        LocalDateTime endDate = filterSpec.getEndDate();
        return listProvider.listByApplicationId(pageable, applicationId, startDate, endDate);
    }

    @PostMapping(path = "/{systemId}/{clientId}")
    public void logClientReview(@PathVariable("systemId") ExternalSystem externalSystem,
                                @PathVariable("clientId") Integer clientId) {
        service.saveClientReview(clientId, externalSystem);
    }

    @GetMapping(path = "/application-field-title")
    public List<ApplicationFieldTitle> getApplicationFieldTitle() {
        return service.getApplicationFieldTitle();
    }

    @GetMapping(path = "/status/{applicationId}")
    public PagedResult<ApplicationStatusHistoryView> getApplicationStatus(@Nonnull ApplicationHistoryListProvider.AppHistoryPageable pageable,
                                                                          @Nonnull @PathVariable("applicationId") Integer applicationId,
                                                                          @Nonnull ApplicationStatusHistoryListProvider.FilterSpec filterSpec) {
        LocalDateTime startDate = filterSpec.getStartDate();
        LocalDateTime endDate = filterSpec.getEndDate();
        return listStatusProvider.listByApplicationId(pageable, applicationId, startDate, endDate);
    }
}
