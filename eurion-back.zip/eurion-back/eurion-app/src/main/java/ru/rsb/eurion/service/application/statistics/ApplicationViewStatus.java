package ru.rsb.eurion.service.application.statistics;

public enum ApplicationViewStatus {
    ASSIGNED,
    POSTPONED,
    IN_QUEUE,
    IN_WORK,
    UNKNOWN
}
