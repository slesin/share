update CREDIT_SALE_CHANNEL
set SORT_PRIORITY = round(dbms_random.value() * 2) - 1;
update CREDIT_ATTRACT_CHANNEL
set SORT_PRIORITY = round(dbms_random.value() * 2) - 1;
update SKILL_GROUP
set SORT_PRIORITY = round(dbms_random.value() * 2) - 1;
update PRIORITY_AMOUNT_INTERVAL
set SORT_PRIORITY = round(dbms_random.value() * 2) - 1;
update REGION
set CLIENT_SORT_PRIORITY = round(dbms_random.value() * 2) - 1,
    APP_SORT_PRIORITY    = round(dbms_random.value() * 2) - 1;


update PRIORITY_PARAM
set IS_ENABLED = 0
where ID = 'REGION_APP';
