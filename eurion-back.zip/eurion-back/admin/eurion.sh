#!/bin/bash

#********************************* PARAMETERS *********************************
INSTANCE=eurion-main
SHUTDOWN_WAIT=20
STARTUP_WAIT=60
JAVA_CMD=/opt/underwriting/jdk/bin/java
JAVA_OPTS="-server -Xmx1024m -XX:MaxMetaspaceSize=256m -Deurion.instance=$INSTANCE"
APP_HOME=/opt/underwriting/eurion-app
APP_NAME=eurion-app.jar
PID_FILE="$APP_HOME/eurion-app.pid"
LISTEN_PORT=8080
#******************************************************************************

RETVAL=0

eurion_pid() {
    if [ -r "$PID_FILE" ]; then
        pid=$(pgrep -F $PID_FILE)
        echo "$pid"
    fi
}

health() {
    echo "$(curl -s http://localhost:$LISTEN_PORT/health)"
}

status() {
    pid=$(eurion_pid)
    if [ -n "$pid" ]; then
        RED='\033[1;31m'
        GREEN='\033[1;32m'
        NC='\033[0m'
        [[ -n $(health) ]] && active="${GREEN}active${NC}" || active="${RED}inactive${NC}"
        echo -e "Eurion is running with pid: $pid ($active)"
    else
        echo "Eurion is not running"
        RETVAL=3
    fi
}

start() {
    pid=$(eurion_pid)
    if [ -n "$pid" ]; then
        echo "Eurion is already running (pid: $pid)"
        RETVAL=3
    else
        echo "Starting Eurion instance: $INSTANCE"
        cd $APP_HOME
        $JAVA_CMD $JAVA_OPTS -jar $APP_NAME >/dev/null 2>eurion-err.log &
        RETVAL=$?
        echo $! >$PID_FILE
        if [ $RETVAL != 0 ]; then
            return
        fi
        ((kwait = STARTUP_WAIT))
        ((count = 0))
        until [ -n "$(health)" ] || [ $count -gt $kwait ]; do
            pid=$(eurion_pid)
            if [ -z $pid ]; then
                echo "Process is terminated"
                RETVAL=1
                return
            fi
            echo "Waiting for process to init"
            sleep 1
            ((count = count + 1))
        done

        if [ -z $(health) ]; then
            echo "Timeout exceeded"
            stop
            RETVAL=2
        else
            echo "Application is started"
        fi
    fi
}

stop() {
    pid=$(eurion_pid)
    if [ -n "$pid" ]; then
        echo "Stoping Eurion"
        kill "$pid"
        ((kwait = SHUTDOWN_WAIT))
        ((count = 0))
        until [ -z "$(eurion_pid)" ] || [ $count -gt $kwait ]; do
            echo "Waiting for process $pid to exit"
            sleep 1
            ((count = count + 1))
        done
        if [ $count -gt $kwait ]; then
            echo "Killing processes didn't stop after $SHUTDOWN_WAIT seconds"
            kill -9 "$(eurion_pid)"
        fi
        rm -f $PID_FILE
        echo "Eurion instance '$INSTANCE' is stopped"
    else
        echo "Eurion is not running"
    fi
}

case $1 in
start)
    start
    ;;
stop)
    stop
    ;;
restart)
    stop
    start
    ;;
status)
    status
    ;;
*)
    echo "Usage: $0 [start | stop | restart | status]"
    ;;
esac

exit $RETVAL
